# Module: check-in app (the Carmen PWA), alpha

> **Alpha.** This is the app exactly as its author uses it today, shipped as is. It was built
> for one person on one server, so expect rough edges, hard-coded defaults (below) and changes
> without notice. It starts in **test mode**: nothing is written or sent until you press
> "Go live" on each device.

## What it does and why

The daily check-in as one web app on your phone, your laptop and inside Telegram. It shows
today's tasks ranked by what matters, the replies you owe with a drafted message, the day's
calendar with a proposed plan, what Claude can do for you, and the daily meditation journal.
Every tap counts on its own: add a task to today, push it to tomorrow, mark it done, send a
drafted mail, or chat with Claude about one task.

It is a small Python server (`code/automation/jobs/checkin_app/`) on your vault server, reached
over a Tailscale Funnel path, and installable as an app (a PWA: Add to Home Screen on iPhone,
Install in Chrome on a laptop). The page holds no data; every call is signed in.

## Before you start: what it depends on

The app shows what the morning pre-run wrote, so it is empty without the rest of the daily
check-in. You need these modules working first:

- **vps**, **tailscale**, **automation-runner** (the server, the Funnel, `bin/run-job`)
- **tasks** (task notes in `Inbox/` with `type: action`)
- **calendar** and **email** (the day view, the Replies tab and Send read Google through the
  Workspace MCP credentials)
- **telegram** (optional: the app inside the bot, and chat with voice)
- The **plan-today** skill and its pre-run job `plan_today_prerun` (in the code export and in
  `vault-template/_system/skills/plan-today/`). It writes
  `_system/claude/plan-today-prerun.md`, which is what the app reads.
- The meditation journal (`vault-template/_system/daily-meditation.md`), if you want the
  Meditate tab and its effect on the ranking.

## Accounts you need

None new. It uses the Claude login, Google credentials and (optionally) Telegram bot you
already set up.

## Steps

1. **Python packages.** The app needs Starlette and Uvicorn, which `requirements.txt` does not
   list yet:
   `~/automation/.venv/bin/pip install starlette uvicorn python-multipart`
2. **Keys.** Add to `~/.automation.env` (mode 600), generated, never typed by hand:
   ```bash
   python3 -c 'import secrets; print("CHECKIN_PASSWORD=" + secrets.token_urlsafe(12)); print("CHECKIN_SECRET=" + secrets.token_hex(32))' >> ~/.automation.env
   ```
   `TELEGRAM_BOT_TOKEN` and `TELEGRAM_OWNER_ID` are already there if you did the telegram
   module. Read the password back when you need it: `grep CHECKIN_PASSWORD ~/.automation.env`.
3. **Your values in the code.** Search the app for these and set them:
   - `<YOUR_EMAIL>`, `<YOUR_PERSONAL_EMAIL>`: your mailboxes (`page.html` MAILBOXES, `__init__.py`
     CAL_KIND). Delete the second if you have one.
   - `<WORK_MAIL_DOMAIN>`: the domain of a work or school mailbox, shown as "Work". Leave it if
     you have none.
   - **Timezone:** `America/Los_Angeles` is hard-coded in `jobs/checkin_app/__init__.py` (`TZ`)
     and `jobs/checkin_app/chat.py`. Change both to yours (the server runs UTC; without this an
     evening tap lands on the next day).
   - `CAL_KIND` in `__init__.py` maps calendar names (Focus, Social, ...) to colours. Rename to
     your calendars; unknown ones still show.
4. **Service and Funnel** (needs sudo, run it yourself):
   ```bash
   cd ~/automation && sudo cp units/checkin-app.service /etc/systemd/system/ \
     && sudo systemctl daemon-reload && sudo systemctl enable --now checkin-app \
     && sudo tailscale funnel --bg --set-path /checkin 8790 && tailscale funnel status
   ```
   `tailscale funnel status` must still list `/` (the vault MCP) next to `/checkin`.
5. **Open it:** `https://<your-server>.<your-tailnet>.ts.net/checkin/`, sign in with the
   password once (30-day cookie).
   - iPhone: Safari, Share, Add to Home Screen, then sign in once more inside the home-screen app.
   - Laptop: Chrome's Install button in the address bar, or Safari's File, Add to Dock.
6. **Inside Telegram (optional):** set the bot's menu button once with the Bot API
   `setChatMenuButton` (type `web_app`, the URL above). Only `TELEGRAM_OWNER_ID` gets in.
7. **Check it:** `.venv/bin/python -m tests.checkin_app_send` and
   `.venv/bin/python -m tests.checkin_app_chat` pass offline. The page should show the rows of
   the last pre-run; if it is empty, run `bin/run-job plan_today_prerun` once.

## Gotchas

- **Test mode is per device** and on by default. "Go live" in the banner switches it off after
  a confirmation. Leave it on until you trust the ranking.
- **The home-screen app caches the page.** After an update, close it fully to load the new one.
- **Restart after code changes** to `__init__.py` or `chat.py`: `sudo systemctl restart
  checkin-app`. `page.html` is read on every request.
- **Do not `pkill -f jobs.checkin_app` over ssh**: it matches your own ssh command. Use
  `fuser -k 8790/tcp`.
- **The budget window is 09:00 to 21:00 every day** (`DAY_START`, `DAY_END` in `__init__.py`).
- **Chat runs Claude on your server** with your Claude login. Each open chat holds about 400 MB
  for five minutes; a small server may need swap.
- **Send is mail only** and goes out from your Google account the moment you tap Send in live
  mode. WhatsApp drafts open WhatsApp with the text; Claude never sends them.
