# Module: transcription (recordings to text, locally on the Mac)

## What it does and why

Turns audio and video (lectures, voice memos, meetings you are allowed to record) into text
**on your Mac**, with **whisper.cpp**, an open-source speech-to-text model. The audio never
leaves your machine; only the resulting text goes wherever you put it (for example, a vault
note Claude later reads). About 99 languages, detected automatically.

**It runs on the Mac, not the server, on purpose.** The good models need more memory and CPU
than a ~€6 server has: the large model does not fit in 4 GB at all, and the "turbo" model runs
slower than real time on two server cores (a 2.5 hour recording could take 5 to 8 hours). An
Apple Silicon Mac does the same job in minutes. This is the one module that needs the Mac awake.

## Already have one?

- `which whisper-cli whisper-cpp ffmpeg yt-dlp; ls ~/.cache/whisper* 2>/dev/null`
- Already using MacWhisper, Superwhisper or a transcription service: reuse it; this module only
  adds a command Claude can run itself.

## Accounts you need

None.

## Steps

1. **Install the tools** (Homebrew; if `which brew` prints nothing, install it first as in the
   email module, step 1):
   ```bash
   brew install whisper-cpp ffmpeg
   brew install yt-dlp          # only if you want to transcribe from web video links
   ```
2. **Download a model** once (about 1.5 GB for `large-v3-turbo`, a good default). The
   whisper.cpp README lists the download script and model names; keep models in
   `~/.cache/whisper/`.
3. **A small wrapper** Claude writes for the user on the Mac, e.g. `~/bin/transcribe` (code
   never lives in the vault, because Sync does not carry it): convert to 16 kHz mono WAV with ffmpeg, run `whisper-cli -m <model> -l
   auto -f <wav> -otxt`, and print or save the text. (The kit's `vt` has no transcribe tool;
   this wrapper is it.)
4. Optionally, a skill in the vault (`_system/skills/transcribe/SKILL.md`, symlinked into
   `~/.claude/skills/`) so "transcribe this file" works in any session.

## Gotchas

- **Too big for a small server.** Do not install this on the VPS unless it has 8 GB+ RAM and
  4+ cores, and even then expect it to be slow.
- **Whisper can invent text** during long silences or music: fluent, confident and wrong. Spot
  check transcripts that matter, and try the larger model if a passage reads oddly.
- **Bigger is not always better**; compare models on a sample of your own audio.
- **Recording consent** is your responsibility; laws differ by place.
- **Text goes to Anthropic** once Claude reads it, like any vault note.

## Self-test

Record a 20-second voice memo, then: "transcribe ~/Downloads/<memo file>". Pass: the text
matches what was said, and the run happened locally (no network needed: try with Wi-Fi off).
