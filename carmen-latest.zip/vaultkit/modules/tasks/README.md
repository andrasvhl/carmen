# Module: tasks (the task cockpit inside the starter vault)

## What it does and why

Your tasks are plain notes in the vault's `Inbox/` folder (the ones with `type: action`). This
module makes them visible and workable in four places, all reading the same notes:

- **`ToDo.base`**, the cockpit: lists like ToDo, Today, Waiting, Triage and Unscheduled, which
  you reorder by dragging. Drawn by the **TaskNotes** plugin (from the Obsidian store).
- **The Cockpit button** in Obsidian's left ribbon: one click lays out Today, Waiting and As
  scheduled side by side. A small plugin that ships inside the vault.
- **"Work in Claude"**, a button on every task note: opens Claude Desktop's Code tab in your
  vault with the task already typed in, waiting for you to send it. Also ships inside the vault.
- **`vt todos`**, for Claude and the command line: prints the same views and adds new tasks.

It is part of the starter vault: no accounts, no cost, nothing on the server. How the pieces fit:
`vault-template/_system/task-cockpit.md`.

## Already have one?

- **A task plugin or system in Obsidian already** (Tasks, Todoist sync, Kanban, Dataview lists):
  it can stay. TaskNotes only reads notes with `type: action`, so the two do not collide. Agree
  with the user which one is the daily driver; two live task lists drift.
- **TaskNotes already installed with your own settings:** keep them. The template copy skipped
  its `data.json` (only missing files are copied). Compare against `SETUP-NOTES.md` § 3 and
  change only what the user agrees to, in TaskNotes' settings screen.
- **An existing `community-plugins.json`:** it was kept, so Cockpit and Claude Task Launcher are
  in `.obsidian/plugins/` but not switched on. Enable them in Settings → Community plugins.

## Accounts you need

None. The "Work in Claude" button on the desktop needs the **Claude Desktop** app installed
(free download, signed in with the same Claude account). Without it the button copies the
prompt to the clipboard instead.

## Steps

Most of this already happened in the obsidian-sync module (`SETUP-NOTES.md` § 2 and § 3). Here
it is checked end to end, once `vt` exists (automation-runner module).

1. **Plugins on.** In Obsidian: Settings → Core plugins → **Bases** on. Settings → Community
   plugins: community plugins on (Restricted mode off); **TaskNotes** installed from the store;
   **Cockpit** and **Claude Task Launcher** listed under Installed plugins and switched on.
2. **TaskNotes settings took.** Settings → TaskNotes: tasks identified by property `type` =
   `action`, default folder `Inbox`, statuses `inbox / open / in-progress / done`, priorities
   `1-none` to `4-high`. If any differ, fix them in that screen (`SETUP-NOTES.md` § 3 has the
   list) and never press "Create files" or "Update files".
3. **Back up `ToDo.base`** once, outside the vault, so a wrong click in TaskNotes' settings can
   be undone:
   `cp "$VAULT_PATH/ToDo.base" ~/ToDo.base.backup`
4. **Claude Desktop** (optional): if the user wants the desktop launch, they install the app
   and sign in. Otherwise set Settings → Claude Task Launcher → Desktop action to "Copy to
   clipboard".
5. **Sync to the phone** (if Obsidian Sync is used): Settings → Sync → "Active community plugin
   list" and "Installed community plugins" on, on the Mac first.

## Gotchas

- **"Create files" / "Update files" in TaskNotes → General → View commands overwrite the target
  `.base` with no undo.** That is what step 3's backup is for.
- **Changing a view's filter in `ToDo.base` means changing `vt todos` too**
  (`code/automation/tools/todos.py`), or Claude and the cockpit disagree about what is active.
- **Renaming a view breaks the Cockpit pane that uses it** until the name is updated in Settings
  → Cockpit.
- **Claude Desktop asks to confirm the folder every time** "Work in Claude" opens it. By design.

## Self-test

Run on the Mac. Proof is what the user sees, so ask them to look and say what is there.

1. **The views render.** The user opens `ToDo.base`: it shows as a task list (cards with status
   and priority, not a plain table), and the view menu lists ToDo, Today, Waiting, As scheduled,
   Triage, Unscheduled, Undecided, Decisions, All Tasks, Done. The example task "Book a dentist
   check-up" is in **Unscheduled**.
2. **The cockpit shows.** The user clicks the dashboard icon in the left ribbon: three panes open
   (Today and Waiting on top, As scheduled below). Clicking any note restores the previous
   layout.
3. **A new task appears everywhere.** Create a test task:
   ```bash
   ~/automation/bin/vt todos --add "vaultkit self-test task" --scheduled "$(date +%F)"
   ~/automation/bin/vt todos --view todo
   ```
   The command prints the new file's path, and the second command lists it under ToDo. The user
   checks that it also shows in `ToDo.base` → **ToDo** and **Triage** (it has `status: inbox`)
   and in the Cockpit's **Today** pane, and in `Inbox/Inbox.base` → **Actions**.
4. **"Work in Claude" launches.** The user opens the test task note: a bot icon is in its title
   bar. Clicking it opens Claude Desktop's Code tab, asks to confirm the vault folder, and shows a
   prompt starting `Help with this task from the vault.` with the file path, **unsent**. (In
   clipboard mode: a notice says the task was copied; paste into any text field to check.) The
   user closes that session without sending. Opening a non-task note (for example
   `SETUP-NOTES.md`) shows no bot icon.
5. **Clean up.** Delete the test task, with the user's yes:
   `rm "$VAULT_PATH/Inbox/vaultkit self-test task.md"` (the path printed in step 3). Then
   `~/automation/bin/vt todos` no longer lists it.

Record the result with the date in `PROGRESS.md`.
