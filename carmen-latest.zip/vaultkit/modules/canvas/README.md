# Module: canvas (your Canvas courses, archived into the vault) - OPTIONAL

## What it does and why

If your school uses **Canvas** (the course website from Instructure), this module copies your
own courses into the vault: every module, page, assignment with its rubric, your own
submissions and grades, announcements, discussions, and every file you can download, with the
**text of each PDF, slide deck, Word file and spreadsheet extracted** next to it. Claude can
then answer "what did week 4 of Negotiation say about anchoring?" from your own material, and
the archive survives the day your Canvas access ends (usually some time after a course or
degree finishes, and nothing is recoverable after that).

It is plain code, not Claude: no model reads or summarises anything during the pull. One note
per Canvas item, verbatim, incremental (a second run writes nothing), with three local caches so
re-deriving notes after a layout change costs no requests to your school.

Optional extras, both off until you choose them:

- **Readings** (`vt canvas links`): fetches the articles a course links out to, and is honest
  about what came back. Anything behind a login or paywall is listed, never faked; you save
  those from your browser and `vt canvas adopt` files them by their content.
- **Daily task sync** (`automation@canvas_tasks.timer`, 05:30 your time): refreshes the current
  term's enrolled courses and turns assignments due in the next 21 days into Triage tasks in
  `Inbox/`, following due-date changes and marking tasks done when you submit on Canvas.

How it works: `tools/canvas/` in `~/automation`, run as `vt canvas ...` on the server (or the
Mac). The vault doc is `_system/canvas-archive.md` and the skill is `canvas-archive`, both
shipped with the starter vault.

**Rules, plainly. Only archive your own courses, and check your school's acceptable-use policy
first.** The token acts as you: it sees exactly what you see in Canvas, nothing more. Most
schools allow personal access tokens for your own use; some restrict automated access or have
turned student tokens off. Course material (cases, readings, slides) is licensed to you as a
student: keeping a private archive for yourself is the point, sharing or publishing it is not.
Never use it to collect classmates' work, and never archive a course on someone else's behalf.

**Data note:** the archive contains your grades, feedback and discussion posts by classmates.
It lives in your vault, which Obsidian Sync carries to your devices and Claude reads when it
works there (WALKTHROUGH § 0). Treat it as private.

**Cost:** nothing for Canvas. Disk and Sync are the real costs: a full degree can be several
gigabytes of slide decks. `vt canvas plan` tells you the size before anything downloads.

## Already have one?

- **Another Canvas exporter or a browser extension**: fine to keep; this one only reads Canvas.
  Do not point both at the same vault folder.
- **An existing Canvas access token** for another tool: make a separate one for this (step 1).
  Revoking one then never breaks the other.
- **Course notes you already wrote**: keep them where they are. The archive goes into its own
  folder (`Areas/School/Course Archive/` by default) and never touches anything it did not
  write. You can also keep your own notes inside a course folder; the tool leaves them alone.

## Accounts you need

**A Canvas access token.** The user makes it, step by step, and says "done". **They never paste
it into this chat**: it goes into a hidden prompt in their own Terminal (step 2).

1. Sign in to your school's Canvas in a browser, on a computer.
2. Note the address in the address bar: the part between `https://` and the next `/` is your
   **Canvas host** (for example `canvas.yourschool.edu`; some schools use
   `yourschool.instructure.com`). You need it in step 2 of Steps.
3. Click **Account** (your picture, top left), then **Settings**.
4. Scroll to **Approved Integrations** and click **+ New Access Token**.
   *No such button?* Your school has switched off student tokens. Stop here: this module
   cannot work without one. Some schools issue them on request through their IT help desk.
5. **Purpose:** anything you will recognise, e.g. `My vault archive`.
   **Expiration date:** pick one. Many schools cap tokens at a few months (90 days is common)
   and fill the date in for you; if you can choose, pick the end of your term. A token with no
   expiry is convenient and a standing risk if it ever leaks. **Write the date down**: you type
   it in step 2, and the system warns you two weeks before it.
6. Click **Generate Token**. Canvas shows the token **once**: a number, a `~`, and a long string
   of letters and digits. Leave that page open until step 2 is done; do not save it in a file.
7. Say "done".

**Renewing later:** repeat steps 3 to 6 (you can delete the old token there too), then step 2 of
Steps again. The daily job and `vt canvas` both tell you when it is due.

## Steps

Prerequisites: automation-runner module done (`~/automation` on the server, `vt` working). The
tasks module is needed only for the daily task sync.

1. **Choose where the archive goes** (optional). Default: `Areas/School/Course Archive`. To
   change it, add to the kit's `config.env` and copy it to the server as usual:
   ```
   VK_CANVAS_ARCHIVE=Areas/University/Course Archive
   VK_CANVAS_TASK_PROJECT=School        # optional: new assignment tasks link [[School]] in projects:
   ```
   A project note named there must exist; create it as a project anchor if not.
2. **Store the token. You run this in your own Terminal** (it asks for the host, which shows as
   you type, then the token, which does not, then the expiry date):
   ```bash
   ssh -t vault-host '~/automation/bin/set-canvas-token'
   ```
   The host prompt shows an example default; press Return only if it is your school's address,
   otherwise type yours. Pass: `written: 3 CANVAS_ lines, host ..., expiry ...`. Say "done".
3. **Claude checks the shape** (key names and mode only, never values):
   ```bash
   ssh vault-host 'grep -o "^CANVAS_[A-Z_]*=" ~/.automation.env; stat -c %a ~/.automation.env'
   ```
   Pass: `CANVAS_HOST=`, `CANVAS_TOKEN=`, `CANVAS_TOKEN_EXPIRES=`, then `600`.
4. **The text-extraction libraries, into the shared virtualenv** (the telegram or fitness
   module may have made it already). The pull works without them; extraction and readings do
   not:
   ```bash
   ssh vault-host 'cd ~/automation && { [ -x .venv/bin/python ] || { sudo apt -y install python3-venv && python3 -m venv .venv; }; } && \
     .venv/bin/pip install -q -r requirements.txt && \
     .venv/bin/python -c "import pypdf, pptx, docx, openpyxl, trafilatura; print(\"ok\")"'
   ```
   Optional, for scanned PDFs: `ssh vault-host 'sudo apt -y install tesseract-ocr poppler-utils'`.
   If other modules share the venv, re-run their tests afterwards (their READMEs say how).
5. **The offline tests** (scratch folders, fictional courses, no network):
   ```bash
   ssh vault-host 'cd ~/automation && for t in tests/canvas_*.py; do m=$(basename $t .py); \
     printf "%-22s " $m; .venv/bin/python -m tests.$m 2>&1 | tail -1; done'
   ```
   Pass: every line ends `0 failure(s)` (`canvas_stub_run` ends `extract-preservation assertions
   passed`).
6. **Obsidian Sync can carry the binaries** (on the Mac, the user clicks): Settings → Sync →
   **Selective sync**: turn on **All other file types** (otherwise `.pptx` and `.xlsx` never
   reach other devices) and check the plan's per-file size cap; a lecture deck can exceed a
   small cap and is then silently skipped. On a phone, you may exclude
   `<archive>/_files` there to keep gigabytes off it: the notes and all extracted text still
   arrive.
7. **First look, writing nothing:**
   ```bash
   ssh vault-host '~/automation/bin/vt canvas courses && ~/automation/bin/vt canvas plan'
   ```
   Show the user the course list and the byte total, and agree which courses to archive. A
   course listed that is not theirs to keep (a sandbox, a site they help run as staff) is
   simply not pulled.
8. **One course first**, dry run then real:
   ```bash
   ssh vault-host 'cd ~/automation && bin/vt canvas pull --course <ID> --dry-run && \
     bin/vt canvas pull --course <ID> --prune && bin/vt canvas extract'
   ```
   Open the course anchor in Obsidian together and check it reads right before the rest.
9. **The rest, and the readings** (optional): `vt canvas refresh --all`, or per course. For
   readings, always `vt canvas links --plan` first and show the host breakdown, then
   `vt canvas links --prune` and `vt canvas links --gated`. Long runs: `nohup ... &` on the
   server and check back.
10. **Daily task sync (optional)**: timer from the shipped template, rendered with the CLAUDE.md
    command (unit list: `automation@canvas_tasks.timer`; `automation@.service` is installed
    already), after a dry run:
    ```bash
    ssh vault-host '~/automation/bin/run-job canvas_tasks --dry-run && \
      sudo systemd-analyze verify /etc/systemd/system/automation@canvas_tasks.timer && \
      sudo systemctl enable --now automation@canvas_tasks.timer && \
      systemctl list-timers automation@canvas_tasks.timer --no-pager'
    ```
    Pass: the dry run lists the term, the enrolled courses and the tasks it would create; the
    timer shows its next run at 05:30 your time.
11. **Skill and docs** (Claude, on the Mac, showing each change first):
    - Link the skill: `ln -s "$VAULT_PATH/_system/skills/canvas-archive" ~/.claude/skills/canvas-archive`,
      and on the server with its vault path.
    - `_system/canvas-archive.md`: `stage: built`, `verified:` today, Status line
      `**Status:** built <date>, verified <date>. Referenced from SYSTEM.md § Components.`
      If the archive folder is not the default, replace the default path in it.
    - `_system/SYSTEM.md` § Components, one row:
      `| Canvas archive (courses into the vault; optional daily task sync) | Built <date> | [[canvas-archive]] |`
    - `_system/README.md` (Vault Map) § Folders: one line for the archive folder, e.g.
      `- \`Areas/School/Course Archive/\`: **machine-written** Canvas archive, one folder per term and course; never hand-edit a note in it (see \`_system/canvas-archive.md\`)`

## Gotchas

- **Never paste the token into the chat**, and never print `~/.automation.env`. If it ever
  appears in a transcript, delete it in Canvas (Account → Settings → Approved Integrations) and
  make a new one.
- **An expired token looks like "nothing changed".** That is why the expiry date is not
  optional: `vt canvas` refuses to run past it and warns two weeks before; the daily job fails a
  check a week before.
- **`--prune` deletes** what the tool wrote earlier and no longer produces. It never touches a
  file you added, but a path bug becomes data loss, so it is always tried on one course first.
- **Never rename or move archive folders by hand, and never edit a note the tool wrote.** The
  next pull recreates or reverts it. Rename modules with `vt canvas alias`; write your own notes
  as separate files.
- **One writer at a time.** Every writing command takes the Canvas lock; a manual command while
  the 05:30 job runs is refused with "another Canvas run holds the lock". Re-run after.
- **`unavailable:403` sections and "no download URL (locked?)" files are normal**: tabs an
  instructor turned off, files not released yet.
- **The readings pass talks to other people's servers.** It waits 1 second between requests to
  one host and honours robots.txt; do not lower either.
- **When you finish school**, run one last `vt canvas refresh --all` while access lasts, then
  disable the timer
  (`sudo systemctl disable --now automation@canvas_tasks.timer`), delete the token in Canvas,
  and keep the archive. `vt canvas pull --from-cache --max-age 9999` can still re-derive notes
  without a token.

## Self-test

```bash
ssh vault-host 'cd ~/automation && bin/vt canvas courses | head -5 && \
  bin/vt canvas pull --course <ID> --dry-run | tail -3 && bin/vt canvas status'
```

Pass: `courses` lists your enrolments with their terms (proof the host and token work); the dry
run of an already-pulled course says `would write 0 note(s)` (proof of incrementality; a course
that changed upstream shows a small number); `status` shows notes, files and extracted text per
course. Then the real proof: open one course anchor and one slide deck's note in Obsidian on
another device and check the extracted text is there. If the timer is installed, the next
morning `journalctl -u automation@canvas_tasks -n 20` ends `canvas_tasks: ok`. Record the
result in `PROGRESS.md`, plus the host and archive folder (never the token).
