# Module: wiki (a compiled wiki of what you know, written by Claude from your notes)

## What it does and why

You write raw notes: class notes, book notes, journal entries, quick `learning` captures. Over
time they hold a lot of what you have concluded, but nobody rereads them, and search only finds
what you can already name. This module adds a small **wiki** in `Wiki/` that Claude compiles
from those notes: one short article per concept ("fixed slot beats intention", "anchoring sets
the negotiation range"), each one citing the notes it came from. Claude reads its catalog
(`Wiki/index.md`) **first** whenever you ask what you know or think about something, or ask for
advice where your own past thinking matters, so the answer starts from your view rather than
from the model's generic one.

It follows Andrej Karpathy's "LLM wiki" idea, with four rules that make it hold up:

- **Derived, never authored.** You never edit the wiki. To correct an article you fix the source
  note and ask Claude to re-ingest it. That keeps every page reconstructible from your notes.
- **Every article cites its sources** (`wiki_sources` in its frontmatter).
- **Two-step ingest.** Claude first shows a map (which articles, fed by which notes, what it
  rejected and why) and waits for your yes before writing anything.
- **A staleness job.** A small daily job on the server hashes every source and lists, in
  `Wiki/_pending.md`, the articles whose sources have changed and the new notes nobody has
  looked at yet. It only reports; it never writes an article.

What is in the kit: `vault-template/Wiki/` (the catalog, folder note, log and two registry
files, no articles), `vault-template/_system/schema.md` (the rules and reasons),
`vault-template/_system/skills/wiki/` (the procedure Claude follows), and
`code/automation/jobs/wiki.py` with `units/automation@wiki.timer` (the staleness job).

## Already have one?

- Check the vault: `ls "$VAULT_PATH/Wiki" "$VAULT_PATH/_system/schema.md" 2>/dev/null`. If a
  `Wiki/` folder already exists for something else, pick another folder name and change
  `WIKI` at the top of `jobs/wiki.py` and every `Wiki/` path in `schema.md` and the skill to
  match. Do not merge two different things into one folder.
- Already keep an evergreen or "zettelkasten" layer you write by hand: keep it. Register those
  notes as sources (they are exactly what the wiki should cite) rather than letting the wiki
  write competing pages.
- Already use a notes-AI plugin that summarises your vault: it can stay, but it is not this. The
  wiki is a few dozen articles you approved, with sources, that Claude reads first.

## Accounts you need

None.

## Steps

1. **Files in the vault.** If the vault was made from the kit's template, `Wiki/`,
   `_system/schema.md` and `_system/skills/wiki/` are already there. Otherwise Claude copies
   just those from `vault-template/`, shows the list first, and overwrites nothing. If the
   install dates were already filled in (`SETUP-NOTES.md` § 1), fill `<INSTALL-DATE>` in
   `_system/schema.md` the same way. Then check the other template files mention the wiki
   (`CLAUDE.md` § Always true, the Router, `SYSTEM.md` § Components, the Vault Map,
   `frontmatter-properties.md`); for an existing vault, Claude proposes those small edits and
   applies them with your yes.
2. **Link the skill** on each machine that runs Claude Code:
   ```bash
   ln -s "$VAULT_PATH/_system/skills/wiki" ~/.claude/skills/wiki
   ```
3. **The staleness job on the server** (needs the automation-runner module). If the server's
   `~/automation` predates this module, copy the two files in and commit:
   ```bash
   scp ~/vaultkit/code/automation/jobs/wiki.py vault-host:~/automation/jobs/
   scp ~/vaultkit/code/automation/units/automation@wiki.timer vault-host:~/automation/units/
   ssh vault-host 'cd ~/automation && git add jobs/wiki.py units/automation@wiki.timer && git commit -qm "wiki job"'
   ```
   Render and install the timer with the same `envsubst` loop as automation-runner step 5, with
   `automation@wiki.timer` as the only unit (the shared `automation@.service` is already
   installed). Then dry-run before enabling:
   ```bash
   ssh vault-host 'cd ~/automation && bin/run-job wiki --dry-run | tail -8'
   ssh vault-host 'sudo systemctl enable --now automation@wiki.timer; systemctl list-timers "automation@wiki*"'
   ```
   On a fresh wiki the dry run passes every check except possibly "no unregistered ingest
   candidates", which lists your existing `type: learning` notes. That is the job working. Only
   ever dry-run it on the Mac: the server owns the pending page and its history.
4. **The first ingest**, together with Claude. Pick a small slice on one theme: 10 to 40 notes,
   for example a folder of book notes or one class you took real notes in. Say "ingest
   `Resources/Learning/` into the wiki". Claude reads them, then shows the map and stops. Push
   back on the structure now; this is the cheapest moment to change it. After your yes it writes
   the articles, the index, the log entry, and a registry row with a hash for every note it
   read, including the ones it rejected.
5. **Use it.** Ask "what do I know about negotiation?" or "what have I concluded about how I
   learn best?". Claude reads the index first, answers from the articles, keeps your view and
   its own additions apart, and logs anything the wiki could not answer in `Wiki/log.md` as a
   gap. Those gaps are what to ingest next.
6. **Keep it current.** When `Wiki/_pending.md` lists something, say "ingest what's pending in
   the wiki". Once a month, or after a big ingest: "lint the wiki".

## Gotchas

- **Keep it small.** Claude reads the whole index before every query, which only works while it
  fits in one sitting (under about 200 lines). A page needs two sources, or one source plus an
  existing note; a wiki of one-note stubs is a slower copy of your notes.
- **Navigation-only notes are not sources.** Folder index pages and lists of links, especially
  after an import from another notes app, are what a first ingest most often wrongly turns into
  articles. Same for empty tables, attachment-only notes, and logistics (itineraries, deadlines).
- **Some real notes are for reading, not compiling.** A list of favourite quotes or a table of
  numbers has nothing to distil; summarising it destroys it. It gets a "considered" row, and is
  left alone.
- **Don't hand-edit, even a typo.** Fix the source, re-ingest. A hand-edited page silently stops
  being reconstructible, and the first exception is the one that breaks the rule.
- **Don't distil bulk reference material wholesale** (a downloaded course archive, saved
  papers). The value is your delta over what the model already knows. It enters the wiki through
  your own notes about it, or through a gap you hit.
- **Atomic facts belong in the profile layer, not the wiki.** "Prefers morning study" is a dated
  fact for the profile notes; "every habit that lasted had a fixed slot" is wiki synthesis. The
  wiki links to the profile, never repeats it.
- **Answers filed back must trace to your notes.** Something Claude knows from general knowledge
  or the web is not your knowledge; it goes in only if you deliberately capture it as a note.
- **Never distil a note that points to a password or account**; never record anything about
  another person's health, money or relationships without asking.
- **The staleness job runs on one machine.** Two machines writing `_pending.md` for real produce
  two competing versions in one synced file.
- **Your notes reach Anthropic** when Claude reads them for an ingest, like any vault note.

## Self-test

1. Make two small notes, for example `Resources/Cooking/Resting meat.md` ("Cut the steak
   straight away: juice all over the board. Rested 5 minutes: much juicier.") and an Inbox
   capture with `type: learning` ("Rested the roast chicken 15 minutes under foil, best one
   yet.").
2. "Ingest those two notes into the wiki." Pass: Claude shows a map and **stops** before writing.
3. Approve it. Pass: one article exists, its `wiki_sources` lists both notes, `Wiki/index.md` has
   one line for it, `Wiki/log.md` has an `ingest` entry, and `Wiki/_sources.md` has two rows
   with 12-character hashes that match `shasum -a 256 "<file>" | cut -c1-12`.
4. Ask "what do I know about sourdough?". Pass: Claude says the wiki has nothing on it and a
   `gap` entry appears in `Wiki/log.md`.
5. Ask Claude to "change the article to say 10 minutes". Pass: it proposes editing the source
   note instead, not the article.
6. Edit one source note, then on the server:
   `ssh vault-host 'cd ~/automation && bin/run-job wiki --dry-run | tail -8'`. Pass: it reports
   that source as changed and names the article it feeds. Delete the test notes and article
   afterwards, and remove their rows from `_sources.md`.
