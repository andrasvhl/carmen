# vaultkit

A kit that sets up your own personal AI system, guided step by step by Claude.
Shared by András Habsburg. The designed version of this page is `START HERE.pdf`.

> **Educational purposes only.** Provided as is, with no warranty of any kind. András Habsburg
> takes zero responsibility for this kit or anything that results from using it. Setting it up
> and running it is fully your decision and your responsibility. See the end of this page.

## Why it is worth it

- **Claude Code in your pocket.** Chat with your own Claude over Telegram, wherever you are. It
  can reach your vault, your mail and WhatsApp, and asks before it does anything with an
  Allow / Deny button.
- **Connects to basically everything.** Out of the box: WhatsApp, Telegram, Gmail, Google
  Calendar, Canvas, Strava, WHOOP, Apple Shortcuts, Raycast and Obsidian, on a server built with
  Hetzner, Tailscale, Backblaze B2, Pushover and Healthchecks.io. Anything else with an API or an
  MCP connector, Claude can add for you.
- **Not locked to any AI.** Everything you know lives in plain Markdown files that you own. If a
  better model comes along, point it at the same folder. Your notes move with you, and nothing
  needs exporting.
- **Fast, because it is all local.** Your notes are plain files on your laptop, so your agent
  searches thousands of them in milliseconds, with no database or app in the way.
- **Task management built in.** Tasks, priorities and schedules live in your vault. Talk through
  what is on your mind, and Claude turns it into tasks, helps you prioritise and fits them into
  your week.
- **One button to capture.** The iPhone Action Button or a Mac hotkey drops an idea, note or task
  into your Inbox in two seconds. Send it to your Telegram bot instead, and Claude starts on it
  straight away.
- **Works overnight, laptop off.** The server keeps going while you sleep: backups, health checks
  and tidy-ups out of the box. You can add your own jobs with Claude, such as sorting mail, a
  morning briefing or background work on tasks.

- **It messages you, you tap once.** Claude can message you on Telegram when something needs
  you. Have it watch for what you care about, for example sign-ups for a View From The
  Top speaker you would love to hear: it messages you, you reply "sign me up", and before it acts it
  asks for your OK with one tap on Allow.
- **Your perfect week, planned for you.** Describe your ideal week once (wake and bed times,
  focus blocks, sport, social plans, classes). Claude schedules your tasks, assignments and
  readings around it, reads your calendars, says plainly when the week is overbooked, and puts
  the blocks in your calendar once you approve.
- **Priorities that mean something.** Your North Star note holds what matters this quarter. You
  rate Health, Work, Play and Love (inspired by *Designing Your Life*), set an objective for
  each, and rank three to five priorities. Every prioritisation pass reads it first.

- **A second brain that maintains itself.** Inspired by Andrej Karpathy's LLM wiki. Claude
  compiles your class notes, readings and life lessons into one small wiki that you never have to
  maintain. Ask it for advice, and it answers from what you yourself concluded, citing your
  notes. It keeps evolving as you write.
- **Great memory, built in.** Agents get much better with good memory. Your profile notes hold
  durable facts about you (preferences, routines, people, goals), each dated, and Claude adds to
  them on its own as you work together. Unlike a chat app's memory, it is readable, editable,
  yours, and works with any model.
- **Fully yours to change.** Everything is plain files and readable code. Change any piece, drop
  what you do not need, and build what is right for you. The kit simply lets you speedrun the
  infrastructure.

## What you end up with

- **An Obsidian vault** (your notes, tasks and plans as plain text files) that stays in sync
  between your Mac, your phone and a small rented server.
- **A small always-on server** (a Linux "VPS", about the price of a coffee a month) where
  Claude Code runs 24/7 against your vault. Your laptop can be shut.
- **Claude from your phone.** Open the Claude app, pick your server's session, and ask it to
  capture a task, look something up in your notes, or reorganise a project.
- **Scheduled jobs** that run on their own: health checks, a nightly encrypted backup, a weekly
  tidy-up of finished tasks, and alerts to your phone if something breaks.
- **Optional extras:** Telegram (Claude on the go), email access, calendar, a WhatsApp chat with your vault, local audio
  transcription on your Mac, a quick-capture hotkey.

You do not need to be technical. Claude does the typing; you create a few accounts, approve
steps, and answer questions.

## How to start

1. Install Claude Code from [claude.com](https://claude.com/product/claude-code). You need a paid
   Claude plan (Pro or Max). Whether your plan includes Remote Control, and how much you can use
   it, is on claude.com/pricing; Max is recommended for heavy use.
2. Put this `vaultkit` folder in your home folder (so it is at `~/vaultkit`).
3. Open the folder in Claude Code (in the Terminal: `cd ~/vaultkit` and then `claude`; or open
   the folder in the Claude desktop app's Code tab).
4. Type: **start the setup**

Claude will first explain what the system does and what data goes where, and will not build
anything until you say "I understand, continue". Then it looks at what you already have, so
it can reuse it instead of starting over.

You can stop at any point. Progress is saved in `~/vaultkit/PROGRESS.md`, and a new session
picks up where you left off.

## Time

About **2 to 3 hours** in total, including waiting (servers starting, the first sync, the
first backup upload). It works well split across two sittings. The optional modules add about
15 to 45 minutes each.

## Costs (checked 2026-10-04, prices change)

| Item | Cost |
|---|---|
| Claude Pro (required) | $20/month ($17/month billed yearly). Max is $100 or $200/month |
| Hetzner server (CX23: 2 CPUs, 4 GB RAM) | about €6/month (plus VAT if you are in the EU) |
| Obsidian Sync (required for the server copy) | from $4/month billed yearly |
| Pushover (phone alerts) | $4.99 once |
| Backblaze B2 (backups) | first 10 GB free, so usually $0 |
| Tailscale, Healthchecks.io, Google Cloud | free for this use |
| Optional: Strava subscription (fitness module, Strava API access) | about $12/month |

**Typical total: about $30 to $40 a month, plus $5 once.** Details and the optional extras are
in [WALKTHROUGH.md](WALKTHROUGH.md) § 0.

## Privacy, in short

- **Whatever Claude reads is sent to Anthropic to be processed.** That includes your notes, and
  your emails and WhatsApp messages if you turn those modules on. There is no way around this
  with this kit: it would need a local AI model on your own hardware, which this kit does not
  support.
- Everything else is locked down. The server is only reachable through your own private
  Tailscale network, passwords and keys sit in locked files on the server, and backups are
  encrypted before they leave it.
- **The author of this kit sees nothing and has no access** to your server, vault or accounts.
  Every account is yours.
- The WhatsApp module uses an unofficial connection and **can get your phone number banned**.
  It is optional and off by default.

The full explanation is in [WALKTHROUGH.md](WALKTHROUGH.md) § 0, and Claude walks you through it
before anything starts.

## No responsibility, educational purposes only

This kit is shared for educational purposes only and is provided as is, with no warranty of
any kind. András Habsburg takes zero responsibility for it or for anything that results from
using it, including data loss, security incidents, costs, account suspensions or broken
services.

If you set it up, that is fully your decision and your responsibility: your server, your
accounts, your data, your bills, and following the terms of every service you connect
(WhatsApp included). Read what Claude proposes before you approve it.
