---
type: area
stage: draft
horizon_start: <YYYY-MM-DD>
horizon_end: <YYYY-MM-DD>
revisit: <YYYY-MM-DD>
---

# North Star

**What matters right now, in priority order, so that prioritisation and the daily loop have
judgement instead of guesses.** Every prioritisation and planning pass reads this file first.

> **How to fill this in.** Write a quick v1 in one sitting (30-45 minutes, or ask Claude:
> *"Help me write my North Star, one section at a time."*). **It is meant to be wrong in places.**
> Ship it quick so the system has something real to read, then refine it after two weeks of real
> use rather than trying to perfect it now. Replace the three `<YYYY-MM-DD>` placeholders in
> the frontmatter with real dates: `horizon_start` is today, `horizon_end` is when this plan
> stops being valid (a quarter, a term, a season; usually 2 to 4 months out), and `revisit` is
> when you will look at it again (about halfway, or after the first month). When either passes,
> Claude will say so and ask. Until the placeholders are replaced, Claude treats the dates as
> unknown and asks.

Referenced from [[_system/SYSTEM|SYSTEM]] and the [[Claude Master Router]].

---

## 1. Horizon

<The window this plan covers, and why it ends when it does. Example: "October to mid-December,
the end of the term.">

<If the effective working window is shorter than the calendar window (travel, a holiday, a
deadline), say so here. Anything that must be *finished* this horizon has to fit the effective
window.>

<The single most important thing to know when judging whether a day's list is realistic.
Example: "Two big decisions in one quarter, on top of a full job.">

---

## 1b. Balance: Health, Work, Play, Love

Borrowed from *Designing Your Life* (Bill Burnett and Dave Evans). Before ranking priorities,
rate each area from 0 to 10 for how full it feels right now, and write one objective for this
horizon. The priorities below should visibly serve these, and an area at 2 out of 10 with no
objective is a decision you are making, not an accident.

| Area | Now (0-10) | Objective this horizon |
|---|---|---|
| Health | <n> | <e.g. "Run three times a week, sleep by 23:30 on weeknights"> |
| Work | <n> | <e.g. "Ship the first version of X; keep classes above the bar"> |
| Play | <n> | <e.g. "One evening a week with no plan"> |
| Love | <n> | <e.g. "One unhurried evening a week with the people closest to you"> |

---

## 2. Where attention goes

Ranked. Ties break downward. **Three to five priorities.** Each one is a cap unit for
`prioritise` (max three `4-high` tasks per priority), so a priority is a goal, not a folder.

### 1. <Priority name>

<One or two lines: what it is, and why it is first.>

**Definition of done for this horizon:** <specific and checkable.>

### 2. <Priority name>

<...>

### 3. <Priority name>

<...>

**Horizon decisions.** If one of these is a big open choice (stay or leave, commit or drop),
name it here. It never becomes a task; its component steps do.

---

## 3. Explicitly not doing this horizon

<The anti-list. What you are saying no to, on purpose, until `horizon_end`.>

- <...>
- <...>

> Anything landing in the Inbox that belongs to one of these is a **defer candidate**, not a
> today candidate. Flag it; never delete it.

---

## 4. Known traps

Things that reliably consume time while feeling productive.

- <Example: "Tinkering with this productivity system. It feels like progress and produces
  visible output. The system is a tool for the real priorities, not another project.">
- <Example: "Research as a substitute for talking to people.">

---

## 5. Decision rules

Plain tie-breaks, applicable without thinking.

1. <Example: "Priority 1 beats Priority 2 until the deadline in §1.">
2. <Example: "Graded or paid deliverables with a due date beat preparation work.">
3. <...>

When work can be *placed* (hours, days, calendars) is not a priority: it lives in
[[_system/working-conditions|working-conditions]].

---

## 6. How Claude uses this file

Read this before any prioritisation or daily-loop pass.

| Section | Drives |
|---|---|
| §1 Horizon | Whether a due date is inside the window; when this file is stale |
| §2 Where attention goes | `projects` assignment, the importance judgement behind `priority`, and the cap unit |
| §3 Not doing | Flagging **defer candidates**: flag only, never auto-defer or delete |
| §4 Traps | `quadrant`, specifically spotting urgent-feeling but unimportant work |
| §5 Decision rules | Tie-breaks when ordering the list |
| [[_system/working-conditions\|working-conditions]] | **When** work can realistically be placed |

**Constraints that override anything above:**

- **Urgency is a one-way ratchet.** Claude may flag "this looks time-sensitive, confirm?" but may
  **never** downgrade an existing `urgent: true` or `priority: 4-high`. The owner's call only.
- **Flag, never delete.** Nothing in §3 or §4 authorises removing a task.
- **Capacity is the honest constraint.** When the list exceeds the available hours, say so
  plainly. An over-full list is the expected default, not a personal failure.

---

## Open, deliberately unresolved in v1

<Questions you know are open but are not deciding yet. Listing them stops Claude from guessing.>
