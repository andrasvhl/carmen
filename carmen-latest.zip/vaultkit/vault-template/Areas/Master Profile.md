---
type: master-profile
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Master Profile

**Entry point for any durable fact about the owner of this vault.** This file stays deliberately
thin: the few facts asked constantly, then a router to the domain that holds the rest. Depth
belongs in sub-profiles, never here.

Companion to [[Areas/North Star|North Star]]. **North Star is what matters *now* and is built to
expire. This is what stays true.**

**Read this when:** any question depends on who the owner is, what they are bound by, or who is
around them, and you do not already know which domain holds the answer.

Conventions and the template: [[_system/profile-convention|profile-convention]],
[[_system/_profile-template|_profile-template]]. `(elicit)` marks a field worth having that is not
yet known. Fill it when it comes up. **Never invent one**, and if a value was concluded from vault
evidence rather than stated by the owner, its source is `inferred` and it is a question, not an
answer.

> **How to fill this in.** You do not have to sit down and complete it. Claude records facts as
> you mention them in passing (`CLAUDE.md` § Always true). If you want a head start, ask Claude:
> *"Interview me for my Master Profile, one section at a time."* Replace `(elicit)` with the
> value, and fill `Tier`, `Source` and `As of` on every row.

---

## 1. Core

The handful of facts asked so often that a second hop would be wasted. Everything else routes.

| Fact | Value | Tier | Source | As of |
|---|---|---|---|---|
| Name | (elicit) | Fixed | - | - |
| Date of birth | (elicit) | Fixed | - | - |
| Nationality / passports | (elicit) | Fixed | - | - |
| Languages | (elicit) | Slow | - | - |
| Where you live now | (elicit) | Current | - | - |
| Work or study | (elicit) | Slow | - | - |
| Email addresses (which one for what) | (elicit) | Slow | - | - |
| Devices | (elicit) | Slow | - | - |
| Reachability (what you read promptly: push, email, messages) | (elicit) | Current | - | - |

---

## 2. Where facts about the owner live

**Route by fact type.** This table is the reason this file exists: the [[Claude Master Router]]
routes by *work* type; this routes by *fact* type.

Add a row each time you create a sub-profile (copy [[_system/_profile-template|_profile-template]]
into the area folder). Suggested starting set, create them only when there is something to put in:

| If you need to know | Go to | Read it when |
|---|---|---|
| Body, sleep, medical, fitness | `Areas/Health/Health Profile.md` (create when needed) | Health, training, how they feel |
| Documents, addresses, insurance | `Areas/Personal/Identity Profile.md` (create when needed) | Any travel, date or enrolment decision |
| Income, obligations, budgets | `Areas/Finances/Finances Profile.md` (create when needed) | Anything costing money or carrying a payment date |
| Career history, credentials | `Areas/Career/Career Profile.md` (create when needed) | Intros, applications, CV-shaped questions |
| Books, music, taste | `Areas/Personal/Interests Profile.md` (create when needed) | Any recommendation request |
| A named person | `Areas/People/<Name>.md` (create when needed) | Any "who is this", "who is waiting on whom" question |
| What matters *right now* | [[Areas/North Star]] | Before any prioritisation or planning pass |
| When work can be *placed* | [[_system/working-conditions\|working-conditions]] | Before proposing any day plan |

Every file above carries `verified:`. **If it is past its shelf life, say so in one line and ask;
never plan against it silently.**

## 3. Unknowns register

The master's own gaps. Domain gaps live in their sub-profiles.

| Unknown | Blocks | How to resolve |
|---|---|---|
| Most of § 1 | Any answer that depends on who the owner is | Fill in as facts come up, or run an interview |

## Maintenance

- Keep this file thin. A fact that belongs to one domain goes in that domain, not here. If a
  section grows past its table, that is the signal it has landed in the wrong file.
- **The router must match reality.** Every file with `parent: "[[Master Profile]]"` (see this
  note's backlinks pane) must have a row in § 2, and every row must point at a real file.

## See also
- [[_system/profile-convention|profile-convention]]: how facts are recorded
- [[Areas/North Star]]: what matters now
- [[Claude Master Router]]: routing by work type
