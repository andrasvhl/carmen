---
type: person
aliases: [Jonah]
crm_circle: active
crm_relation: colleague
crm_org: Example Studio
crm_cohort:
crm_city: Berlin
areas: []
crm_owed: they-owe-me
crm_email: [jonah@example.org]
crm_phone: []
crm_handles: ["@jonah.example"]
crm_channel: mail
crm_languages: [English, German]
crm_birthday:
crm_met: 2026-05-20
crm_last_contact: 2026-10-20
crm_next_contact:
---

# Jonah Okafor

**Sample person, made up.** Designer on the side project. Active while the project runs, likely
back to `dormant` afterwards.

## Current

| Fact | Value | Source | As of |
|---|---|---|---|
| What is live | Landing page redesign | mail | 2026-10-20 |
| Who owes whom | He owes you the first draft | mail | 2026-10-20 |

## Do not get wrong

Prefers mail over chat for anything with a deadline.

## See also
- [[Areas/People/People|People]], the database
