---
type: person
aliases: []
crm_circle: dormant
crm_relation: classmate
crm_org:
crm_cohort: MBA 2027
crm_city:
areas: []
crm_owed: none
crm_email: [noor@example.net]
crm_phone: []
crm_handles: []
crm_channel: mail
crm_languages: []
crm_birthday:
crm_met:
crm_last_contact:
crm_next_contact:
---

# Noor Rafferty

**Sample person, made up.** Classmate, imported from a class list. Nothing open, so `dormant`,
kept so that a message from her lands with context.

## See also
- [[Areas/People/People|People]], the database
