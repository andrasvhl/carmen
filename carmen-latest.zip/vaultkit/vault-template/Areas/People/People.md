---
type: sub-profile
parent: "[[Master Profile]]"
domain: people
---

# People

Sub-profile of [[Areas/Master Profile|Master Profile]]. **Who is in your life, what they are to
you, and what is currently open with each.** Claude reads this before any mail or message
triage, any "who is waiting on whom" question, and before drafting anything addressed to a named
person.

**Why it exists.** Without person notes, every triage pass has to re-derive who someone is from a
single line. In practice, the items where someone is really blocked on you come from 1:1
relationships, not from a channel. The relationship carries the signal, so it has to be written
down somewhere a script can read it.

**This folder ships with three made-up sample people.** Delete them once you have your own.

---

## 1. Circles

How close someone is decides whether a message from them changes your week. `crm_circle` in each
note's frontmatter is what lets the set grow without the signal degrading.

| Circle | Meaning |
|---|---|
| **inner** | Decisions get made with them, or about them. Their needs change your week |
| **close** | A real relationship, sustained over years; contact is expected in both directions |
| **warm** | More than a live thread, not yet close: people you want to keep seeing |
| **active** | A live thread right now (a project, a decision, an event) that may or may not outlast it |
| **dormant** | Matters, but nothing is open. Kept so a message from them lands with context |

**Promote and demote deliberately.** A wedding RSVP makes someone `active` for six weeks, and then
they go back to `dormant`. That is the system working, not a failure to maintain it. Keep `inner`
and `close` small. Everyone else can enter as `dormant` at no cost.

## 2. What a person note is for

Four questions, in order of how often they get asked:

1. **Who are they to you:** one line, the highest-value field in the note
2. **What is open between you:** who owes whom, and since when
3. **What are they good for:** intros, expertise, an ear, a favour already offered
4. **What should you not get wrong:** a name, a sensitivity, a date

Depth beyond that makes retrieval worse. **Cap: 150 to 300 words per note.**

## 3. The database

**One note per person, `type: person`, in this folder. That is the whole database.** There is no
separate contact store: two systems means two places a name can live, and one of them rots
silently. New notes start from [[Areas/People/_Person Template|_Person Template]].

![[People.base]]

Views: Everyone · Inner + close · Close circle · Cohort · I owe them · They owe me · Going cold ·
Birthdays · Needs filling. **Going cold and Needs filling skip `dormant`**, so a large imported
contact list cannot bury the people who matter.

## 4. Schema

Every person note carries these fields, in this order. Most will be empty for most people. That
is fine, and it is how the views find what needs filling. Contact fields carry a `crm_` prefix so
they can never collide with properties elsewhere in the vault.

| Field | Values | Why it exists |
|---|---|---|
| `aliases` | list | What you actually call them. Obsidian resolves links and search through it |
| `crm_circle` | `inner` · `close` · `warm` · `active` · `dormant` | **The pull mechanism.** Retrieval selects by circle and never reads everything |
| `crm_relation` | partner · family · friend · colleague · classmate · client · advisor · mentor · acquaintance | What kind of tie |
| `crm_org` / `crm_city` | free text | Intros, and "who is where" when you travel |
| `crm_cohort` | e.g. `MBA 2027` | A class or team year, so the Cohort view can filter |
| `crm_owed` | `i-owe-them` · `they-owe-me` · `none` | **Open loops as a query, not prose.** Never mix up the two directions |
| `crm_email` / `crm_phone` / `crm_handles` | lists | **The join key.** How an incoming message resolves to a person, so its circle can weight triage |
| `crm_channel` | whatsapp · mail · signal · both · other | Where you actually reach them |
| `crm_languages` | list | What to draft in |
| `crm_birthday` / `crm_met` | dates | Birthdays, and how long you have known them |
| `crm_last_contact` / `crm_next_contact` | dates | Going-cold detection. `crm_next_contact` is optional |
| `areas` | links | Which life area they show up in |

**Identifiers go in; authenticators never do.** Emails, numbers and handles are contact details.
Passwords, PINs and anything else that grants access stay out of the vault.

## 5. Pulling by circle

`vt people --circle inner close` reads frontmatter only and returns the matching people. This is
what makes the set scale: at a thousand people nothing reads the whole folder. The tool also
takes `--owed i-owe-them`, `--cold 60`, `--org <name>` and
`--find <email|phone|handle|alias|name>`. It strips the `crm_` prefix internally.

**Edit `People.base` through Obsidian's UI, never by hand.** Obsidian silently rewrites `.base`
files.

## 6. Filling it

Start with the 20 to 40 people who matter, by hand or by telling Claude about them. To bring in
everyone else, ask Claude to build an import from your own exports (a contacts vCard file, a
class or team list, your chat list). The rules that worked:

- Everyone imported enters as `dormant`. You set `inner` and `close` yourself.
- Merge records on a shared phone number or email. Other names for the same person become
  `aliases`.
- Match existing notes on frontmatter identifiers only, never on body text.
- Only fill fields that are empty. Never overwrite what is already written.
- Hold back anything that looks like a PIN, password or account number.
- Contacts you never talk to can stay out of the vault, in a lookup index of names and numbers
  only, so an unknown number still resolves to a name.

## Maintenance

- `crm_last_contact` and each note's Current section decay fastest. A note not touched in six
  months is reporting a state that has probably moved.
- What degrades retrieval is `inner` and `close` inflating, not the headcount.

## See also
- [[Areas/Master Profile]], the hub
- [[Areas/People/_Person Template|_Person Template]]
