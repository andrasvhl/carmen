---
type: person
aliases: []
crm_circle: active
crm_relation: friend
crm_org:
crm_cohort:
crm_city:
areas: []
crm_owed: none
crm_email: []
crm_phone: []
crm_handles: []
crm_channel: both
crm_languages: []
crm_birthday:
crm_met:
crm_last_contact:
crm_next_contact:
---

# <Name>

**One line: who they are to you.** The highest-value field in the note. Not their job title, but
what they are *to you*, and why a message from them matters.

## Fixed

| Fact | Value | Source | As of |
|---|---|---|---|
| How you met | | | |
| Relation | | | |
| Nationality / base | | | |
| Family ties | | | |

## Slow

| Fact | Value | Source | As of |
|---|---|---|---|
| Role / organisation | | | |
| Partner / children | | | |
| Situation | | | |

## Current

| Fact | Value | Source | As of |
|---|---|---|---|
| What is live | | | |
| Who owes whom | | | |

## What they are good for

Intros, expertise, an ear, a favour already offered. One or two lines, or delete the section.

## Do not get wrong

A name, a sensitivity, a date. Delete if there is nothing.

## Unknowns

| Unknown | Blocks | How to resolve |
|---|---|---|

## See also
- [[Areas/People/People|People]], the database
