---
type: person
aliases: [Priya]
crm_circle: close
crm_relation: friend
crm_org: Northwind Robotics
crm_cohort:
crm_city: Copenhagen
areas: []
crm_owed: i-owe-them
crm_email: [priya@example.com]
crm_phone: []
crm_handles: []
crm_channel: whatsapp
crm_languages: [English, Swedish]
crm_birthday: 1994-03-14
crm_met: 2016-09-01
crm_last_contact: 2026-10-12
crm_next_contact: 2026-11-15
---

# Priya Lindqvist

**Sample person, made up.** Oldest friend from university. The first call on any big decision,
and she always tells you the uncomfortable version.

## Fixed

| Fact | Value | Source | As of |
|---|---|---|---|
| How you met | First week of university, same corridor | stated | 2016 |
| Relation | Close friend | stated | 2026-10 |

## Slow

| Fact | Value | Source | As of |
|---|---|---|---|
| Role / organisation | Product lead, Northwind Robotics | stated | 2026-10 |
| Situation | Moved to Copenhagen for the job | stated | 2026-06 |

## Current

| Fact | Value | Source | As of |
|---|---|---|---|
| What is live | Visiting in November | WhatsApp | 2026-10-12 |
| Who owes whom | You owe her the intro to a robotics investor | WhatsApp | 2026-10-12 |

## What they are good for

Hiring and product questions. Honest feedback on pitches.

## See also
- [[Areas/People/People|People]], the database
