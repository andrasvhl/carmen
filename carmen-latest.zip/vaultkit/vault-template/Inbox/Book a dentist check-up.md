---
type: action
captured: <INSTALL-DATE>T09:15
status: open
priority: 2-low
waiting: false
startable: cold
timeEstimate: 15
---

## Next action
- [ ] Next: call the practice and ask for the first free slot after 16:00
- [ ] Then: put the appointment in the calendar

> "I haven't been to the dentist in over a year, need to book that."

This is an example task showing the schema (see `_system/SYSTEM.md` § Capture note schema).
Delete it once you have real tasks. A task that belongs to a project or area also carries
`projects:` with an indented `- "[[Project Name]]"` line per project, linking to a note that
exists.

Source: example
