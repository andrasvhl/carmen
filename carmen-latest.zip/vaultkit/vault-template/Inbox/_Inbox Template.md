---
type: ""
captured: ""
status: inbox
priority: 1-none
---
<!-- Reference only: the capture schema (SYSTEM.md § Capture note schema). Not wired to any
template plugin. type is "" (untriaged) | action | todo | learning | idea | reference | dump.
Every task carries a next action as a checkbox, first thing under the frontmatter. Quote,
facts, status notes and the Source: line follow below it. If no step can be named yet,
propose one and ask; never leave it blank. -->

## Next action
- [ ] Next: 

<content>
