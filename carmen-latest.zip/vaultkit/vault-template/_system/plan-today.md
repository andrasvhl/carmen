---
type: reference
component: plan-today
stage: partial
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# plan-today: the morning check-in after the meditation

**Status:** partial. The pre-run, delta fetch, always-on panel server, live updates, fast lane and
pre-Submit task writes are built. The remaining work is tracked in a separate build task.
Referenced from `SYSTEM.md` § Components (Daily loop row).

## What it's for

Without it, the morning starts with the Q4 steps from the meditation journal before you look at
the plan. plan-today puts the plan first. You press one button after the meditation, get a
pre-filled check-in panel, and end with today's plan in the calendar, all in under 30 minutes and
ideally 20. The procedure lives in the skill. This doc covers the moving parts and how they
connect.

## How it works

Five parts. Everything unattended runs on the server. The panel is Mac-only by design and stays
that way (see [[_system/vps-vault-host|vps-vault-host]] § Standing rule, third exception).

| Part | Where | Does |
|---|---|---|
| **Pre-run** | `~/automation/jobs/plan_today_prerun.py` on the server, timer 08:00 local time | Pulls the panel set from `vt todos`, 10 days of WhatsApp (every chat, paged overview, through the delta fetch's reader) and the mailboxes, every calendar from 3 days back to 5 ahead, the session log, vault snapshots, North Star, working-conditions and Week Structure. One read-only Opus pass returns panel rows as JSON. Python validates them and writes the pre-run page (`_system/claude/plan-today-prerun.md`). The row guesses wait for Submit. Python also writes each touched task's `## Current context` block, ticks sub-steps the data proves done, and sets very certain next steps. Never frontmatter. About 7-8 min |
| **Delta fetch** | `~/automation/jobs/plan_today_delta.py` on the server, called by `fetch_delta.sh` on the Mac over ssh | No model. Every WhatsApp chat (16 in parallel), the mailboxes and every calendar, since the pre-run's `generated:` time. Writes `~/.cache/plan-today/delta.json`, the lossless digest `delta.txt` and `calendar.txt`. About 10 s |
| **Panel server** | `panel_server.py`, always on as the LaunchAgent `com.<YOUR_NAME>.plan-today-panel` (127.0.0.1:8765, Mac only) | Builds the panel on every GET / (`build_panel.build_current`, about 0.1-0.2 s): the pre-run rows, freshened against the task notes (closed, moved, new since the pre-run), plus today's meditation items matched to tasks by a deterministic scorer. It then regroups them for the run's **plan day** (tomorrow for a run started from 18:00 local time, stored in `updates.json`): rows that need no decision now go into a closed "Not today (N)" section. POST /submit writes `answers-<run id>.txt`; /health answers `plan-today-panel` |
| **Panel page** | `panel.html` (template), `panel_rows.py` (shared normaliser, run state, lock), `update_panel.py` (live updates) | One card per task, a prefilled guess, a sticky bar, folding to mark reviewed, and "becomes" for new rows. Polls `updates.json` every 3 s and applies new rows, changes, row replaces and drops. A newer run id reloads it |
| **Skill + agents** | [[_system/skills/plan-today/SKILL\|plan-today]] (SKILL.md is the fast lane and an outline; `reference/background.md`, `panel.md`, `after-submit.md` and `day-plan.md` are read when their step comes) and `agents/delta.md`, `agents/q4.md` (`agents/context.md` is the fallback) | Fast lane: the first message starts the run and the fetch, opens the URL, arms the Submit watcher and launches the two agents. Delta judges the digest (2 tool calls) and pushes. q4 enriches only the meditation rows the builder could not finish (3 tool calls). The session reads calendar.txt and the three context notes itself while you click. After Submit it writes the answers, log lines, "becomes" tasks and the day plan |

**Approval model.** Submit sends only the changed rows back into the session as your reply. "Let
Claude handle this" switches on safe actions (drafts, research, vault, your own calendar blocks).
Send, RSVP, delete and pay run only where you switched that action on, and each re-checks its
thread or event right before it runs. Claude never sends WhatsApp.

**Task writes before Submit.** The pre-run writes three things into task bodies without a Submit,
so a skipped morning still lands its pull: a `## Current context` block under `## Next action`
(status, sources, verbatim lines, replaced each morning and closed by a hidden
`%% end current context %%` marker), ticks on `Next:` / `Then:` lines the data proves done
(`td`), and the next step where the model is very certain (`anx`). An open step the data made
obsolete is never rewritten: it stays verbatim as `- ~~Next: …~~ (replaced by the pre-run, <date>)`
under the new one. It is not demoted to `Then:`, because that would claim an order nobody decided.
The open `Next:` line is always the block's top line, with the step it replaced right under it.
The pre-run never writes status, dates or waiting, and never a `Waiting:` line. What it wrote is
listed under `applied` in the pre-run page. Code: `apply_to_tasks` in the job.

**Task log.** After Submit, every checked task gets one `## Log` line (schema: [[SYSTEM]] §
Capture note schema). "The last run" is the newest log date.

## Setup / rebuild

From scratch, in this order. Paths: the skill folder is `_system/skills/plan-today/` in the vault
(`~/.claude/skills/plan-today` links to it); the automation repo is `~/automation` on the Mac and
the server, and the server checkout is updated by `git push origin HEAD` from the Mac.

1. **Skill link, both machines:** `ln -s $VAULT_PATH/_system/skills/plan-today ~/.claude/skills/plan-today`
   on the Mac, and the same with `~/vault/...` on the server (the pre-run reads SKILL.md).
2. **Journal button:** the Claude Task Launcher plugin's journal prompt is
   `Run the plan-today skill on this meditation journal entry.` ([[claude-task-launcher-plugin]]).
   Reload the plugin after editing `main.js`.
3. **Pre-run timer (server):** copy `units/automation@plan_today_prerun.timer` (08:00 in
   `<YOUR_TIMEZONE>`) and the `automation@plan_today_prerun.service.d/timeout.conf` drop-in to
   `/etc/systemd/system/`, run `systemctl daemon-reload`, then `systemctl enable --now
   automation@plan_today_prerun.timer`. `Persistent=true` means a timer change triggers a catch-up run.
4. **Calendar token (once, and after any revocation),** from the Mac:
   `ssh -t -L 8766:127.0.0.1:8766 <SERVER> '~/automation/bin/run-job plan_today_prerun --auth'`,
   then sign in as <YOUR_EMAIL> in the Mac browser. It needs the Google Calendar API enabled in
   your Google Cloud project `<YOUR_GCP_PROJECT>` ([[gmail-mcp]]). The delta fetch reuses the token.
5. **Delta fetch:** nothing to install beyond the repo (`jobs/plan_today_delta.py`, which needs
   `~/.waha.env` and the gws mailbox credentials on the server, see your credentials note) and an
   ssh alias for the server on the Mac. Test: `~/.claude/skills/plan-today/fetch_delta.sh` prints
   counts, errors and elapsed seconds (about 10 s).
6. **Panel server (Mac):** `~/.claude/skills/plan-today/install_panel_server.sh` writes
   `~/Library/LaunchAgents/com.<YOUR_NAME>.plan-today-panel.plist`, starts it, and checks /health.
   Log: `~/Library/Logs/plan-today-panel.log`. Remove with `install_panel_server.sh --remove`. The
   server reloads the builder when `build_panel.py` or `panel_rows.py` change; after editing
   `panel_server.py` itself, rerun the installer.
7. **Agent types (Mac):** the two background agents are defined in the vault, the only copies:
   `_system/skills/plan-today/agents/delta.md` and `q4.md` (frontmatter `name: plan-today-delta` /
   `plan-today-q4`, `tools`, `model`). Link them:
   `mkdir -p ~/.claude/agents && ln -sf $VAULT_PATH/_system/skills/plan-today/agents/delta.md ~/.claude/agents/plan-today-delta.md && ln -sf $VAULT_PATH/_system/skills/plan-today/agents/q4.md ~/.claude/agents/plan-today-q4.md`.
   New sessions pick them up. To change the model, edit the `model:` line in each file.
8. **Browser-pane fallback:** the vault's `.claude/launch.json` has a `plan-today-panel` entry
   (`python3 …/panel_server.py 8765`), used only if the LaunchAgent is down.
9. **Test end to end:** `python3 ~/.claude/skills/plan-today/build_panel.py --new-run --streams delta,q4 --journal "Areas/Personal/Meditation Journal/<date>.md"`,
   then `curl -s localhost:8765/ | head -c 200`, then a push:
   `echo '{}' | python3 ~/.claude/skills/plan-today/update_panel.py - --stream delta --done`.
   For the real thing, do a dry run in a fresh session with this prompt: *Dry run of plan-today on
   Areas/Personal/Meditation Journal/<date>.md. Do everything up to and including the check-in
   panel and the live updates, but write nothing: no task notes, no calendar, no mail, no
   messages. After I submit, show me what you would write. Report the time per step from the
   skill's start until: the panel is on screen, the first live update, the meditation rows are
   done, the new messages are done, and my Submit. Also count the tool calls each background agent
   made.*
   Pre-run: `ssh <SERVER> '~/automation/bin/run-job plan_today_prerun --dry-run'` (calls the model).

**Scripts in the skill folder:** `build_panel.py`, `panel_rows.py`, `panel_server.py`, `update_panel.py`,
`fetch_delta.sh`, `context_read.sh` (the day-plan context in four parts under the 30 KB tool-output
limit; the calendar starts at the plan day), `sweep.py` (the plan-day sweep: `--day` lists open
tasks scheduled on or before a day, `--apply` writes the dates you okayed plus a log line), and
`install_panel_server.sh`. All Mac-side; nothing to install beyond step 6.

**Caches (Mac, safe to delete):** `~/.cache/plan-today/` holds delta.json, delta.txt,
calendar.txt and `panel/` (index.html, updates.json, titles.txt, match.json, answers-<run id>.txt).
`PLAN_TODAY_CACHE=<dir>` points the panel scripts at another `panel/` folder, for testing a build
(`build_panel.py --new-run --plan-day <date>`) without touching the live run.

## Config

| What | Where |
|---|---|
| Window, caps, model | top of `jobs/plan_today_prerun.py`: `WINDOW_DAYS = 10`, `DUE_SOON_DAYS = 3`, `MAX_WA_CHARS = 200_000`, `MAX_MAILS = 200`, `MODEL = "opus"` |
| Model input | `~/.local/state/automation/plan_today_prerun/input.md` on the server (outside the vault on purpose, so other people's messages are not synced twice) |
| Output page | `_system/claude/plan-today-prerun.md`, machine-written, overwritten daily |
| Secrets | your credentials note: the gws mailbox tokens (read-only use) and `~/.config/plan-today/google-calendar.json` |
| Row fields | the field table in `_system/skills/plan-today/reference/panel.md` |
| Maintenance | concern `plan-today-prerun` in [[_system/maintenance/maintenance\|maintenance]] |

## Gotchas

- **The prompt is too big for argv.** Linux caps one argument at 128 KB, and a 300 KB prompt fails
  with E2BIG. The data goes into `input.md` and the model reads it.
- **Two WhatsApp keys.** `wa_consumer`'s `WA_API_KEY` gets 401 on the read endpoints. The read
  key is `WAHA_API_KEY` in `~/.waha.env`.
- **The Mac vault is not a git repo.** Snapshot history lives on the server at `~/vault`.
- **"Waiting" lives in two places.** `waiting:` and the `- [ ] Waiting:` line can disagree. The
  pre-run takes either and flags `waiting_mismatch`, and the skill always writes both together.
- **Obsidian links do not open from the panel.** The sandbox blocks app links, localhost and
  background fetches, so name tasks as text.
- **Host styles shrink nothing.** The app overrides class-based button and input sizes, so the
  template sets them inline with `!important`.
- **Sync can revert a file mid-edit.** `panel.html` can be reverted to an older version by sync
  while being edited; check the file after a big change.

## Known limitations

- **The panel runs only in the Claude desktop app** (browser pane, or the `show_widget` fallback
  after one `read_me` call per session). The browser pane needs a `plan-today-panel` entry in the
  session folder's `.claude/launch.json`, which the skill adds if missing. The journal button opens
  exactly there; elsewhere the skill falls back to a keyed table in chat.
- No class-prep rows: there is no session-to-readings source yet.
- No one-click "open in Obsidian" from the panel.
- WhatsApp is copy-only; Claude never sends from your number.
- Dependencies are modelled ad hoc as chain rows; the general model is open.
- The pre-run's only write to the vault is its page; the runner commits before and after.

## Decisions

- **Own skill, flat:** `_system/skills/plan-today/` owns the morning run, and commit-to-action's
  journal flow lives in it. It is not an umbrella skill, because umbrella skills trigger less
  reliably.
- **Today first:** plan today in 2-3 minutes. The week is a proposal at the end, never silent.
- **The pre-run writes context, sub-steps and next steps, never status:** a skipped morning would
  otherwise lose the whole pull. Frontmatter stays Submit-only.
- **Approval is the click, per action:** outward actions need their own switch with the content in
  view, and a staleness check runs right before each.
- **WhatsApp stays copy-only** because of the documented ban risk ([[whatsapp-source]] § Ban risk).
- **Model tier opus** for the pre-run, per the model-tier standard for AI jobs.
- **Plan day:** a run started at or after 18:00 local time plans tomorrow and checks everything
  (panel rows, sweep, calendar, must-do question) against that day; `--plan-day` overrides.
  Otherwise an evening run plans tomorrow but sees only today's tasks, and tasks scheduled for
  tomorrow never reach the panel or the plan. The 08:00 pre-run is unchanged: morning runs plan
  today.
- **The panel shows only rows that need a decision now:** the rest go into a closed "Not today (N)"
  section, still answerable. This is built on the Mac by regrouping the pre-run's rows, so the
  server pre-run stays as it is. Rule: `reference/panel.md` § Which rows appear.
- **Pre-run at 08:00:** with a 7-8 min pass the page is ready about 08:10. A button press before
  that finds yesterday's page and runs the live pull.

## See also

[[_system/skills/plan-today/SKILL|plan-today skill]] · the pre-run page (`_system/claude/plan-today-prerun.md`) ·
[[daily-loop]] · [[_system/skills/schedule-work/SKILL|schedule-work]] ·
[[_system/skills/commit-to-action/SKILL|commit-to-action]] · [[claude-task-launcher-plugin]] ·
your credentials note · the build task for the rest of plan-today
