---
type: reference
component: build-backlog
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Build backlog: ideas captured all week, one brief for Monday

**Status:** built, dry-run verified on <SERVER>. Runs every Monday at 14:00. Referenced from
`SYSTEM.md` § Components.

## What it's for

Build ideas (agents, skills, automations, prototypes) come up all the time and get lost easily.
All building happens in one standing weekly build block on Monday evening, set in your week
structure note. The backlog gives ideas a place to wait without turning them into dated to-dos.
The brief turns them into one plan for that block and has it ready that afternoon.

## How it works

**Capture.** Both capture paths have a **Build backlog** option in the same flow as everything
else ([[raycast-extension/README|Raycast]], [[apple-shortcuts-capture|Shortcut]]). It writes a note
into `Inbox/`:

```
type: idea
captured: <now>
status: inbox
priority: 3-normal        # or 4-high
---
#build

<the idea>
```

There is no `scheduled` and no `due`, so the note never reaches the ToDo cockpit. Both paths push
for a real description, because the brief plans from that text: Raycast swaps the Description hint
when Build backlog is chosen, and the Shortcut asks again if the Description was left empty. Both
then ask Normal / High.

**Membership is the tag, not the type.** A note in `Inbox/` is in the backlog if it carries
`build`, as a frontmatter tag or a bare inline `#build`, and its `status` is not `done` or
`cancelled`. So an existing action joins by adding `tags: [build]` and keeps its type. A
backticked `#build` is prose about the tag and does not count. `#build-brief` is a different tag.
Only `Inbox/` is scanned.

**The brief.** `~/automation/jobs/build_brief.py` runs on <SERVER> every Monday at 14:00
<YOUR_TIMEZONE>. It reads every open item and hands them all to one read-only `claude -p` turn
(`runner.ask`: Read, Glob, Grep on the vault). It also passes the file list and recent git log of
`~/automation`, which the model cannot read itself. For every item the model decides:

- **Already built?** built / partly built / not built, with evidence. Ideas often get built and
  never closed.
- **Estimate** of wall-clock time with Claude Code doing the typing, docs and tests included.
- **Proposal:** 2-4 sentences on how to implement it, naming real files.
- **Dependencies** and **patterns**: which items are one build, which unlock others.

It then writes a **session plan** of about 3 hours (the coding cap), high priority first unless a
dependency says otherwise, with a `--- cut line ---`, and a **discard list**. Items older than 28
days are marked STALE, and each one must be weighed there. Python refuses an answer that is
missing a section, has no cut line, or has no `### [[item]]` heading for an item. Em dashes are
stripped from the model's text, since the prompt alone did not stop them.

**Layout, top to bottom:** the `## Next action` block, then three numbered steps, each saying what
a tick means. **Step 1: Mark what is already built** and **Step 2: Drop or move** put only the item
on the checkbox line, so a tick strikes through the title and not the reasoning. Under it go an
`Evidence:` or `Why:` line and an empty `Missing:` or `Keep because:` line for your answer. Step 2
opens each line with a bold verb (Drop, Merge into ..., Move to ..., Make a normal task). **Step
3: Check tonight's build order** renders the session plan as two lists, **Tonight** and **If time
remains**, split at the model's cut line. You change the plan by moving lines, not by moving a cut
line. Next comes a fixed **What happens when you say "process build brief"** section, the contract
for the session that acts on your answers. Then **Items**: session items first, then those after
the cut line, then the rest, then built and discard candidates. **Under each item heading Python
inserts the item's own captured text** (checkboxes and the tag line stripped, cut at 1,200
characters), because filenames are truncated and a link alone does not say what the idea was.
Python lifts the three sections out of the model's answer and renders them, so the model never
writes the top of the note. The top two lists use plain language with no file paths. The Items
entries carry the detail.

**The brief is one note that is both the task and the record:**
`Inbox/Build brief <date>.md`, `type: action`, `scheduled: <that Monday>`, tag `build-brief`. It
shows in the ToDo cockpit that afternoon. Python writes its frontmatter and the `## Next action`
block (work through the steps, then say "process build brief <date>"). The model writes the body.
A Pushover notification with a tappable link goes out when the note lands. Past briefs are in the
**🧭 Build briefs** view of `Inbox.base`, and open items are in **🛠 Build backlog**.

**Closing.** The job never closes or discards anything. When you say "process build brief
<date>", the session follows the brief's own **What happens** section. Ticked step 1 items go to
`status: done`. Ticked step 2 items are dropped (`status: cancelled` plus a log line saying dropped
or merged into what), merged or moved. Your `Missing:` and `Keep because:` answers are written into
the item's note. **After that the processing session builds nothing itself.** It starts one new
session per **Tonight** item, all in parallel, each told to enter plan mode first, with a
self-contained prompt: the item note, the brief's analysis, the open question, and which parallel
sessions touch the same files. **If time remains** items get a session only when you ask. Each
session plans, asks its question, builds after your approval and closes its own item. None of them
edits the brief. Without a start-session tool, the sessions are task chips you click. Then the
brief goes to `status: done`. A recorded `Keep because:` tells next Monday's model not to propose
that item again unless something changed. An item that was planned but not built simply shows up
again next Monday.

## Setup / rebuild

```bash
ssh <SERVER> '~/automation/bin/run-job build_brief --dry-run'   # logs the brief, writes and pushes nothing
ssh <SERVER> 'sudo cp ~/automation/units/automation@build_brief.timer /etc/systemd/system/ && sudo systemctl daemon-reload && sudo systemctl enable --now automation@build_brief.timer'
ssh <SERVER> 'sudo mkdir -p /etc/systemd/system/automation@build_brief.service.d && sudo cp ~/automation/units/automation@build_brief.service.d/timeout.conf /etc/systemd/system/automation@build_brief.service.d/ && sudo systemctl daemon-reload'
```

The drop-in is required. The template unit's `TimeoutStartSec=600` bounds the whole oneshot run,
so without the drop-in a model turn longer than about 10 minutes gets the job killed and reported
as a crash. Check with `systemctl cat automation@build_brief.service`, which should list the
drop-in.

Capture paths: rebuild them following their own docs. The Shortcut is generated by
`~/automation/tools/build_capture_shortcut.py`. The Raycast source is
`~/RaycastExtensions/obsidian-inbox/src/inbox.tsx`, mirrored in `_system/raycast-extension/`.

## Config

| Knob | Value | Where |
|---|---|---|
| Schedule | Mon 14:00 <YOUR_TIMEZONE> | `units/automation@build_brief.timer` |
| Model timeout | 1500 s | `ASK_TIMEOUT` in the job |
| Whole-run timeout | 1800 s, must stay above the model timeout | `units/automation@build_brief.service.d/timeout.conf` |
| Stale after | 28 days since `captured` | `STALE_DAYS` |
| Item text sent inline | first 2,500 chars; the model can Read the rest | `MAX_ITEM_CHARS` |
| Session size | about 3 h, never more than 4 | the prompt |
| Priorities | `3-normal` default, `4-high` if flagged | both capture paths |

## Gotchas

- **A rerun on the same Monday does nothing** if `Build brief <date>.md` already exists. Delete it
  first to regenerate.
- **Items tagged on another machine need Obsidian Sync before the job sees them.** Tag them before
  14:00.

## Known limitations

- **Passages are not scanned.** A `#build` line inside a note outside `Inbox/` (a journal, a
  project doc) is invisible. Captures and `commit-to-action` output both land in `Inbox/`, which
  covers the paths in real use.
- **Estimates and "already built" are judgement calls.** Nothing checks them. Reading the brief
  before the build block is the check.
- **Raycast is not on <SERVER>**, so the already-built check sees the capture extension only
  through its vault mirror and docs.

## Decisions

- **A tag, not a property.** No schema change, it works on any note whatever its `type`, and
  Bases can filter it with `file.hasTag`.
- **`type: idea` for captures.** It is already in the Inbox schema with its own view. It keeps
  ideas out of Actions and the cockpit without inventing a type.
- **No `briefed:` property.** An idea that was planned and not built should reappear, and the
  brief note already records which items it picked.
- **Unpicked items stay; the brief proposes discards.** Nothing drops automatically.
- **Drafted unattended in the afternoon with a push**, not run by hand just before the block.
- **Ideas are not dated tasks.** Making each build idea a task scheduled for next Monday put every
  idea in the cockpit as a dated to-do, so the backlog replaces that.
- **One parallel plan-mode session per item.** Once the old backlog has been sorted out, each
  Tonight item gets its own session in plan mode, instead of the processing session building the
  list top to bottom.
- **Drops are `status: cancelled`**, so dropped work does not count as done.

## See also

- [[SYSTEM]] § opening rules, the build-ideas rule
- [[maintenance/maintenance|maintenance]], concern `build-backlog-brief`
- `~/automation/jobs/build_brief.py`
