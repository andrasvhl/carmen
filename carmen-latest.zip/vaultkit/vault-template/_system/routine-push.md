---
type: reference
component: routine-push
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Routine push: routine reminders via Pushover, text from the vault

**Status:** built. Referenced from `SYSTEM.md` § Components.

## What it's for

Routines reach you as step-by-step reminders at the right minute. The routine notes own the wording, so when you change a routine in Obsidian, the next push uses the new text. Nothing is written into code or config: the notes are the single source.

## How it works

- **Slots**, one systemd timer (`automation@routine_push.timer`, one `OnCalendar` line per slot,
  in your timezone). An example configuration with five slots:

  | Slot | Time | Note | Priority | Meaning |
  |---|---|---|---|---|
  | `morning` | `<MORNING_TIME>` Mon-Fri | your morning routine note | strong (1) | The routine steps |
  | `weekend` | `<WEEKEND_TIME>` Sat-Sun | morning routine note, the `morning` callout | strong (1) | Same steps, later. No callout of its own |
  | `evening` | `<EVENING_TIME>` | your evening routine note | critical (2), with a per-slot repeat limit (e.g. every 5 min for up to 1 h) | Stop working, first evening step |
  | `bedready` | `<BEDREADY_TIME>` | evening routine note | critical (2) | Screens away, get ready for bed |
  | `lightsout` | `<LIGHTSOUT_TIME>` | evening routine note | critical (2) | Lights out |

- **The text is a callout in the note:**
  ```
  > [!push] morning · <MORNING_TIME> · strong
  > **Morning Routine**
  > 1. First step of your routine ...
  ```
  The header is split on `·`: slot id, time, priority word (`silent` / `normal` / `strong` / `critical` =
  Pushover -1 / 0 / 1 / 2; `critical` rings through the phone's mute switch and Focus and repeats
  until acknowledged: by default twice, two minutes apart (`retry` 120 s / `expire` 245 s); a slot listed in
  `CRITICAL_LIMITS` in the job uses its own limits, e.g. every 5 min for up to 1 h (`retry` 300 s / `expire` 3600 s)), optional `device <name>` to send to one Pushover device only. The bold first line
  is the title; the remaining lines are the message, with wikilinks flattened to their label and
  emphasis marks removed. **Only what is inside the `[!push]` callout is sent.**
- **A tappable link:** a body line `Link: [[Note|Label]]` is taken out of the text and sent as
  Pushover's URL, opening that note in Obsidian. One per block. Useful for a checklist note you want open at that moment.
- **The weekend slot borrows the `morning` callout** (`BORROWS` in the job), so the text is edited
  once; its header time stays the weekday time and is not checked for `weekend`.
- `jobs/routine_push.py` works out the slot from the clock and weekday (due within the last 20 minutes) and
  refuses to send anything later than that, so a reboot never delivers a morning reminder at noon.
- Failures are checks under the `routine-push` concern: a missing or empty block, a header time
  that disagrees with the timer, or Pushover refusing. Each mails through the normal job report.

## Setup / rebuild

On <SERVER>: the job ships in `~/automation` (a push from your laptop deploys it).
The timer lives outside the repo, so its full text is here. Write it to
`/etc/systemd/system/automation@routine_push.timer`, then `sudo systemctl daemon-reload &&
sudo systemctl enable --now automation@routine_push.timer`:

```ini
[Unit]
Description=Schedule for automation job routine_push

[Timer]
OnCalendar=Mon..Fri *-*-* <MORNING_TIME>:00 <YOUR_TIMEZONE>
OnCalendar=Sat,Sun *-*-* <WEEKEND_TIME>:00 <YOUR_TIMEZONE>
OnCalendar=*-*-* <EVENING_TIME>:00 <YOUR_TIMEZONE>
OnCalendar=*-*-* <BEDREADY_TIME>:00 <YOUR_TIMEZONE>
OnCalendar=*-*-* <LIGHTSOUT_TIME>:00 <YOUR_TIMEZONE>
Persistent=false
AccuracySec=1s
Unit=automation@routine_push.service

[Install]
WantedBy=timers.target
```

Pushover credentials are the shared `PUSHOVER_USER` / `PUSHOVER_TOKEN` in `~/.automation.env`.

Test without sending: `ssh <SERVER> '~/automation/bin/run-job routine_push --dry-run --slot morning'`.

## Config

- **Change the text or the priority:** edit the `[!push]` callout in the routine note. Nothing else.
- **Change how long a `critical` slot repeats:** `CRITICAL_RETRY_S` / `CRITICAL_EXPIRE_S` (default)
  and `CRITICAL_LIMITS` (per slot) in `jobs/routine_push.py`. `notify.send_push` refuses
  `expire` above 3600 s.
- **Change a time:** three places must agree: the callout header, `SLOTS` in
  `jobs/routine_push.py`, and the timer's `OnCalendar` line. The weekend time lives only in
  `SLOTS` and the timer. Ask Claude; a mismatch raises a check.
- **Send a slot to one device only:** install Pushover on that device, name it
  (e.g. `<DEVICE_NAME>`), then add `· device <DEVICE_NAME>` to that slot's header.

## Gotchas

- **Not `Persistent=`, on purpose.** A missed reminder is dropped, not delivered late.
- **Obsidian Sync carries the edit to the server.** An edit made seconds before a slot fires may
  miss that send; the next one has it.

## Known limitations

- Without a `device` in the header, a slot goes to every device, including ones you may have put away by then.
- Pushover's own quiet hours, if set in the app, can silence `normal` reminders; `strong`
  bypasses them.
- Plain text only, capped at 1,024 characters by Pushover.

## Decisions

- **The weekend morning slot borrows the weekday text.** Same steps at a later time, borrowed rather than duplicated, so the text is edited once.
- **One slot can repeat longer than the default.** Two rings are easy to miss, so a slot that must not be missed gets its own limits in `CRITICAL_LIMITS`; the others keep the default.
- **Levels.** Evening reminders are `critical`, because `strong` stays silent under the mute switch.
  Default repeats are capped at two, two minutes apart, since endless repeating is too much. Morning is `strong`: one sound, no repeats.
- **Text from the vault, not from config.** You adapt the routine in Obsidian and the push follows, with the sent part visibly marked in the note.
- **One job and one timer for all slots.** The job picks the slot from the clock instead of one
  service per slot, keeping one unit per job like every other job in [[automation]].

## See also
- [[push-notifications]]: the Pushover channel and who else pushes
- [[automation]]: the job runner and timers
