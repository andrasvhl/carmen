---
type: reference
component: profile-template
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Profile template

**Copy this file when creating a sub-profile of [[Areas/Master Profile|Master Profile]].** It is
the standard every profile note follows. The rules at the bottom matter more than the headings:
read them before deviating.

Companion to [[_component-doc-template]], which does the same job for `_system/` docs.
Conventions this template implements (tiers, sourcing, shelf lives, the staleness rule) are
defined once in [[_system/profile-convention|profile-convention]].

---

## The template

````markdown
---
type: sub-profile
parent: "[[Master Profile]]"
domain: <slug>                 # health | identity | finances | career | interests
verified: 2026-01-15           # when these claims were last checked, not when the file was touched
captured: 2026-01-15T12:00
---

# <Domain> Profile

Sub-profile of [[Areas/Master Profile|Master Profile]]. **<One bold line: what is true of the
owner in this domain.>**

**Read this when:** <the trigger, in one line. What question sends someone here.>

Conventions: [[_system/profile-convention|profile-convention]]. `(elicit)` marks a field worth
having that is not yet known.

---

## 1. <Domain section>

<One line stating what this section answers. Required, see rule 2.>

| Fact | Value | Tier | Source | As of |
|---|---|---|---|---|
| | | | | |

## 2. <Domain section>
...

## N. Unknowns register

<Always the last numbered section.>

| Unknown | Blocks | How to resolve |
|---|---|---|
| | | |

## Maintenance

- <What rots here, and how fast.>

## Config

<Optional. Where the underlying data actually lives: documents, accounts, other notes.>

## See also
- [[Areas/Master Profile|Master Profile]]: the hub
````

Sections are optional but their **order is fixed**: numbered domain sections, then Unknowns
register, then Maintenance, then Config, then See also. Skip what does not apply; never reorder.

---

## Rules

1. **`parent:` is mandatory and is what makes the layer checkable.** Every file declaring
   `parent: "[[Master Profile]]"` must appear in the Master Profile's router table, and every
   router row must point at a real file. A sub-profile missing from the router is unreachable;
   a router row with no file is a dead link. Both fail silently. Check with Obsidian's backlinks
   pane on the Master Profile.

2. **Every section opens with one line saying what it answers.** Not decoration. A retrieval
   pass often sees a single section without the rest of the file, and a bare table under a bare
   heading cannot be interpreted alone.

3. **Keep each section short enough to stand alone: roughly 200-500 words. Per section; there is
   no file-level cap.** A section that has to be read together with its neighbours is one
   section doing two jobs: split the section, never the file.

3b. **A profile states facts and does not reason about them. Hard limit: about 110 words of prose
   per section, and less is better.** A section is a table with a lead-in line, not an essay
   with a table attached. If a fact suggests a conclusion, **the conclusion goes in the note
   that acts on it** and the profile carries a one-line pointer. Create a companion note if none
   exists. **This is the rule most likely to be broken**, because an important deadline always
   feels like it belongs next to the fact that produced it. It does not.

4. **The default fact table is five columns, in this order:**
   `| Fact | Value | Tier | Source | As of |`. A section with a genuinely different shape (a
   payment schedule, a career sequence) **may change the leading columns but must keep `Source`
   and `As of` as the last two.** Losing them turns a fact into a rumour.

5. **Unknown is a first-class entry.** A field worth having but not yet known is written
   `(elicit)` in place, so the gap is visible where the answer belongs. Gaps needing more than an
   answer (a measurement, a document lookup) go in the Unknowns register with what they block
   and how to resolve them. **Never leave a cell blank**; a blank invites a plausible invention.

6. **Never write a fact you were not given.** If it was inferred from vault evidence rather than
   stated by the owner, its `Source` is `inferred` and it is a question, not an answer.

7. **Depth belongs in the sub-profile, never in the master.** [[Areas/Master Profile|Master
   Profile]] is deliberately thin and routes by fact type.

8. **Identifiers may be recorded. Authenticators may not.** The line is whether the value *is*
   the key to something, not whether it looks sensitive.

   | May be recorded (owner's choice) | Never record |
   |---|---|
   | Document, ID and policy numbers | Passwords, PINs, TANs, 2FA and recovery codes |
   | Emails, phone numbers, handles, addresses | Full card numbers, CVV, bank details paired with credentials |
   | Which institution, which product, which document | Anything that alone grants access to an account |

   Remember the vault syncs across devices and is read by Claude, so decide deliberately how
   much of the left column you want in it. The right column is not negotiable: **if a password,
   PIN, 2FA seed or recovery code is ever supplied, do not write it down. Say so and move on.**
   A document number identifies you; a password *is* access, and no profile ever needs it.

## See also
- [[_system/profile-convention|profile-convention]]: the conventions this template implements
- [[Areas/Master Profile|Master Profile]]: the hub
- [[_component-doc-template]]: the equivalent standard for `_system/` docs
