---
type: reference
component: frontmatter-properties
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Frontmatter properties: which names are taken, and by what

**Status:** shipped with the starter vault, verified <INSTALL-DATE> against the pieces shipped with this template.
Referenced from `SYSTEM.md` § Architecture decisions.

## What it's for

**Read this before inventing a new frontmatter property.** Some names are load-bearing:
software (a Base view, a plugin, a skill, `vt todos`) reads them and behaves differently based
on what it finds. Reusing one for your own meaning breaks that software silently, and nothing
will tell you.

Obsidian has no schema and will happily accept any key, so the only thing preventing
collisions is this page. Without it, a vault drifts within weeks into dozens of properties,
several naming conventions, and one property carrying unrelated vocabularies at once.

## How it works

Properties fall into four classes. The first two are the ones that matter.

### 1. Reserved: software reads these. Do not repurpose.

| Property | Read by | Meaning | Values |
|---|---|---|---|
| `type` | everything | What kind of note this is | `action`, `todo`, `learning`, `idea`, `reference`, `dump`, `area`, `project`, `master-profile`, `sub-profile`, `person`, `wiki`, `class`, `class-material`, `""` (untriaged) |
| `status` | `ToDo.base`, `Inbox.base`, `vt todos`, the loop skills | **Tasks and captures only.** Nothing else may use it | `inbox` / `open` / `in-progress` / `done` |
| `stage` | humans, `vt docs` | How finished a doc, project or note is | `built` / `partial` / `design-only` / `draft` / `active` / `paused` / `superseded` / `dead`. **Component docs in `_system/` may use only `built` / `partial` / `design-only` / `superseded` / `dead`** ([[_component-doc-template]]) |
| `verified` | humans, the staleness rule | Date a **person** last checked this note's claims against reality | ISO date |
| `revisit` | humans, the staleness rule | Date this note must be reviewed by. **A promise with a consequence** | ISO date |
| `horizon_start`, `horizon_end` | [[Areas/North Star]] | The window a plan is valid for | ISO date |
| `component` | convention, `vt docs` | Slug tying a `_system/` doc to its component | slug |
| `captured` | `Inbox.base`, skills | When a note was created by a person or capture path | ISO datetime, to the minute |
| `parent`, `domain` | profile layer | Ties a sub-profile to [[Areas/Master Profile]] | `"[[Master Profile]]"`, slug |
| `wiki_sources` | `jobs/wiki.py`, the `wiki` skill | The source notes a `Wiki/` article was compiled from. Every claim must trace to one | list of quoted wikilinks |
| `wiki_origin` | the `wiki` skill's lint | How the page came to exist. `query` pages are audited harder | `ingest` / `query` |
| `wiki_ingested` | the `wiki` skill | Date of the last ingest that touched the page | ISO date |
| `canvas_*` | `vt canvas` (optional canvas module) | Every property on a Canvas archive note the tool writes: `canvas_source`, `canvas_course`, `canvas_course_id`, `canvas_kind`, `canvas_module`, `canvas_url`, `canvas_updated_at`, `canvas_due`, `canvas_file_path`, `canvas_extract_status`, `canvas_external_url`, `canvas_fetch_status`, `canvas_fetched_at`. **Never set by hand**; the next pull overwrites them | see [[_system/canvas-archive\|canvas-archive]] |
| `mine_source`, `mine_course`, `mine_extract_status` | `vt canvas mine` | Text notes beside your own coursework in a course's `_mine/`. Prefixed `mine_`, not `canvas_`, because the material never came from Canvas | |
| `code`, `term`, `instructors` | `vt canvas`, on a course anchor (`type: class`) only | The general course vocabulary, deliberately unprefixed so hand-written class notes can use it too | text |

**`Wiki/` pages are machine-written** (class 4 below) even though a session writes them: never
put `verified:` or `captured:` on one. Rules: [[_system/schema|schema]].

**`verified:` means a person checked this.** Never put it on a file a script rewrites.

**`revisit:` is how something gets put under maintenance.** Declare the date on the note
itself, not in a script or a reminder app, so anyone reading the note sees when it expires. If
you later add a job that sweeps `revisit:` dates, every note already enrolled works with no code
change.

### 2. Task schema: the cockpit reads these

`ToDo.base`, TaskNotes and `vt todos` filter and sort on these. Full semantics in `SYSTEM.md`
§ Capture note schema; this table exists so the names are visibly taken.

| Property | Meaning |
|---|---|
| `priority` | `1-none` / `2-low` / `3-normal` / `4-high`. Importance, never urgency |
| `scheduled` | Commitment to a date. Written by `schedule-work`, never decided by `prioritise` |
| `due` | Real deadline. On a decision task, the decide-by date |
| `urgent` | Asked, never inferred. `true` / `false` |
| `quadrant` | `urgent-important` / `important-not-urgent` / `urgent-not-important` / `neither` |
| `startable` | `cold` / `run-up` |
| `waiting` | The user is blocked on someone else. Not the same as the `blocking-someone` tag. A TaskNotes user field (boolean); the `Waiting` view and the Cockpit read it |
| `decision` | `pending` / `made`. Absent means not decision-shaped |
| `prioritised` | When priority was last set |
| `projects` | List of wikilinks to project or area notes. Plural, always |
| `tags` | Obsidian tags. Used by the skills: `blocking-someone`, `needs-breakdown`. TaskNotes reserves the tag `archived` (its archive marker) |
| `timeEstimate`, `completedDate`, `dateModified`, `dateCreated`, `tasknotes_manual_order`, `recurrence`, `recurrence_anchor`, `recurrence_parent`, `occurrence_date`, `complete_instances`, `skipped_instances`, `blockedBy`, `contexts`, `timeEntries`, `pomodoros`, `reminders` | Written by TaskNotes itself, and read by `ToDo.base` and `TaskNotes/Views/`. **Never hand-edit**, and never copy their `camelCase` style. The full list is TaskNotes' field mapping (Settings → TaskNotes → Task properties, shipped in its `data.json`); every key there is taken, including the calendar-sync ones (`icsEventId`, `googleCalendarEventId`, ...) and the `occurrence_*` family |

### 3. Domain properties: extend freely within their folder

Nothing central reads these, so adding them is safe as long as they stay inside their folder.
Examples you might add: a recipes folder with `portions` and `time_min`, a reading list with
`author` and `rating`. Keep a new domain property inside its folder's existing vocabulary. **If
it starts being read outside that folder, promote it to Reserved above.**

### 4. Machine-written pages

A file that a script rewrites (a status page, a generated report) carries `last_run` (ISO
datetime) and, if it reports on health, `healthy` (`true` / `false`). It carries **no
`verified:` and no `captured:`**: both mean a person did something, and no person did.

### Naming rules

- **`snake_case` for anything new.**
- **Never `camelCase`.** TaskNotes' own names (`dateModified`, `timeEstimate`) cannot be
  changed. Do not add more.
- **Never capitalise.** `Paid` and `paid` become two properties that look like one, and the
  capitalised one can shadow the other in every Bases picker.
- **Name a machine-owned property after the operation that owns it.** If a property exists only
  so one script can find its own output, prefix it with that system (`sync_source`, not
  `source`). It keeps general words free for things a person would reach for, and it stops a
  query or an agent picking it up thinking it means something broader. **The test is who reads
  it:** only one piece of code → prefix it; a person, or unrelated notes → keep it general.
- **A status-like property must never take a boolean-looking value.** `fetched: true` renders
  as a checkbox while the same property holds `failed` elsewhere, so one property gets two
  types. Say `ok`.
- **Check this page first.** If the name is here, it is taken.

## Setup / rebuild

### How to rescan

Lists every property in use, with counts. Anything in the output and not on this page is either
new and undocumented, or a typo.

```bash
cd "$VAULT_PATH"
python3 - <<'PY'
import pathlib, re, collections
keys = collections.Counter()
for p in pathlib.Path(".").rglob("*.md"):
    if any(x in (".obsidian", "Archive") for x in p.parts): continue
    t = p.read_text(errors="ignore")
    if not t.startswith("---"): continue
    end = t.find("\n---", 3)
    for line in t[3:end if end > 0 else 0].split("\n"):
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):", line)
        if m: keys[m.group(1)] += 1
for k, c in keys.most_common(): print(f"{k:28s} {c}")
PY
```

## Gotchas

- **`status:` is for tasks and captures, nothing else.** If documents also carry it, any query
  filtering on `status` without also filtering `type` mixes tasks with docs. Docs use `stage:`.
  A non-task note with `status:` is a regression. The most common source is a template that
  shipped with `status:` in it, so check templates first.
- **`verified:` on a generated file is a self-referential bug**: the staleness rule will
  eventually flag the script's own output as needing a human re-check.
- **Adding `revisit:` has a real consequence.** It is a promise that someone will look at the
  note by that date. Do not add one casually.
- **Obsidian enforces none of this.** Every rule here is convention. The rescan above is the
  only thing that catches a violation.

## Known limitations

- **No enforcement.** A typo like `revist:` silently drops the note out of any sweep and looks
  identical to a note that was never enrolled.
- **This page can rot.** It is a hand-maintained list. Rerun the scan after adding any new
  kind of note.

## Decisions

**Reserved names are documented, not enforced.** A validating hook would have to run on every
device and every capture path to be trustworthy, and a partially enforced schema is worse than
an honest convention. Revisit if a collision actually causes a failure.

**Maintenance is declared in the vault, not in code.** A date that lives in a script is
invisible to anyone reading the note. `revisit:` on the note itself is readable and editable by
anyone.

## See also

- [[_system/SYSTEM|SYSTEM]] § Capture note schema: full task-schema semantics
- [[_component-doc-template]]: the frontmatter every `_system/` doc carries
