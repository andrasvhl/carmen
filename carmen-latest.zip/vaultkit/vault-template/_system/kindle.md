---
type: reference
component: kindle
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Kindle delivery: sending documents to your Kindle by email

**Status:** built. Skill: `send-to-kindle`. Referenced from `SYSTEM.md` § Components.

## What it's for

Use this if you read course cases, articles and books on a Kindle instead of a screen. A "send X to my Kindle" request should take one lookup, not a Gmail search for the address. This doc owns the address, the sending account and the traps. The skill owns the steps.

## How it works

- **Route:** email the file as an attachment from **`<YOUR_SENDING_EMAIL>`** to **`<YOUR_KINDLE_ADDRESS>@kindle.com`**, through `mcp__gws__send_gmail_message` with `include_signature: false`. Amazon's Send to Kindle service puts it on the device within minutes.
- **Attachments go by `path`, and only from `~/.workspace-mcp/attachments/`.** Copy the file there, send it, then delete the copy ([[_system/gmail-mcp|gmail-mcp]] § Gotchas).
- **The subject and body are only labels.** Convention: subject `<what it is>`, with a one-line body. For a course: subject `<COURSE NUM> Session <N> <case>`, body `<COURSE NUM> readings for <Day D Mon>.`

### Course readings

The usual request is "send tomorrow's readings for <class>". Course files live in the [[_system/canvas-archive|canvas-archive]]:

- **Find the session:** each module's `<Case> Class Prep.pdf.md` opens with `Session N: <Day>, <Month D>`. Running `grep -rl "<Month D>"` over the course folder finds tomorrow's module.
- **The binaries** are at the `canvas_file_path` in each material note's frontmatter, under `Course Archive/_files/`. Send every PDF in the module (the case and the class prep).
- **Readings listed in the Class Prep but missing from the module** (for example a journal article) are often in the course's `_Unfiled/Readings/`, so grep for the title. These are external links with no file (`canvas_fetch_status: robots-disallowed` for library links).
- **Library links (`<YOUR_LIBRARY_PROXY>/login?url=...`) are fetched through the user's own Chrome** (Claude in Chrome). Never use the built-in browser, because it has no school session. Open the link. If the school login page appears, stop and ask the user to sign in (the password and 2FA belong to them), then reopen the link. On EBSCO: Download, decline non-essential cookies, Full text, PDF, Download. After a few seconds of "Preparing your file", the file lands in `~/Downloads` as `EBSCO-FullText-<MM_DD_YYYY>.pdf`. Rename it to the article title when you stage it. Close the tab afterwards.
- **Proxy gotchas:** after login the proxy can drop the redirect and land on a "Database Menu" page. If that happens, reopen the original link. If it lands on the menu again, open the proxied host directly: `https://research-ebsco-com.<YOUR_LIBRARY_PROXY>/<path>` (the `url=` target with `research.ebsco.com` rewritten). Screenshots there can be stale, so check the tab title: it can show the article while the screenshot still shows the menu.
- **Readings adopted by hand** (`canvas_fetch_status: manual`, publisher links such as `hbsp.harvard.edu`) have extracted text in the note but no PDF under `_files/`. Render the text after `## Extracted text` to a PDF in the scratchpad (pandoc to HTML, then headless Chrome `--print-to-pdf`) and send that. Tables and exhibits come out flattened. For links on other hosts that have no file at all, put the links in the reply so the user can fetch them.

## Config

| What | Value |
|---|---|
| Kindle address (current) | `<YOUR_KINDLE_ADDRESS>@kindle.com` |
| Sending account | `<YOUR_SENDING_EMAIL>` (must be on Amazon's approved-sender list) |
| Attachment staging dir | `~/.workspace-mcp/attachments/` |
| Device | Kindle e-reader ([[Areas/Master Profile\|Master Profile]] § Core, Devices) |

## Gotchas

- **Use only the configured Kindle address.** Old sent mail can contain other `kindle.com` addresses (another device or the Kindle app) that are not where readings should go. A Gmail search for `to:kindle.com` can return the wrong one, and documents then go to the wrong place. Do not look the address up again by searching mail.
- **Gmail caps a message at 25 MB.** Split a large module across two emails.

## Known limitations

- Amazon sends no confirmation when a delivery works. It only emails when a document fails.
- Do not send from an account unless you know it is on Amazon's approved-sender list.

## Decisions

**A component plus a thin skill, not a section of canvas-archive.** Sending to Kindle is a general feature, not a course feature, so it lives in its own component and not in [[_system/canvas-archive|canvas-archive]].

**Open: any other `kindle.com` address found in mail.** Ask the user before using it for anything.

## See also
- [[_system/gmail-mcp|gmail-mcp]]: the mail server that sends
- [[_system/canvas-archive|canvas-archive]]: where course files come from
- `_system/skills/send-to-kindle/SKILL.md`: the steps
