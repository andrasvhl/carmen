# Vault Map

Start at [[Claude Master Router]] (vault root). It routes to `SYSTEM.md` for how capture, the
Inbox and the task system work. This file is the folder map: where things are, and where new
things go.

## What this file covers

Top-level folders, always. Below that, go deeper wherever a folder's **name does not tell you
what is inside**. That test is the rule. `_system/` is always enumerated one level down, because
which components exist is the reason someone opens this file. `Projects/` is enumerated too,
one line per project, once there are projects.

**No dates.** This is a map: it says where things are now, in the present tense. When something
moved, and why, belongs in the owning doc's `## History`, or in git if the vault is versioned.

**Keep it current in the same session.** When you add a folder or a `_system/` doc, list it here
before you finish. A map that is missing one entry teaches every reader to stop trusting it.

## Folders

- `CLAUDE.md` (vault root): the rules that bind every Claude session. Auto-loads.
- `Claude Master Router.md` (vault root): where Claude looks for what. Routes to this file,
  `SYSTEM.md`, and the profile layer.
- `SETUP-NOTES.md` (vault root): one-time install steps (plugins, skill links). Safe to delete
  once set up.
- `ToDo.base` (vault root): the task cockpit, a view over `Inbox/`. See `task-cockpit.md`.
- `TaskNotes/Views/`: the TaskNotes plugin's extra views (agenda, calendar, mini-calendar,
  kanban, relationships, pomodoro stats), opened by its commands. Views only, no notes.
- `Inbox/`: **the one database.** Every capture is a typed note here (see `SYSTEM.md`),
  triaged via `Inbox/Inbox.base`. Tasks are not a separate folder; they are the notes with
  `type: action`. `_Inbox Template.md` documents the schema.
- `Areas/`: ongoing parts of life with no end date (for example Work, Health, Personal,
  Finances, People). Tasks and projects link here. Also holds **two files that are not areas**,
  both life content rather than machinery, which is why neither sits in `_system/`:
  - **`North Star.md`**: current priorities, the explicit not-doing list, and decision
    tie-breaks, read by every prioritisation and planning pass. Expires by design.
  - **`Master Profile.md`**: the entry point for any durable fact about the owner, and the
    router to every sub-profile. Deliberately thin. North Star is what matters *now*; the Master
    Profile is what stays *true*. Sub-profiles live inside their areas (for example
    `Areas/Health/Health Profile.md`), each carrying `parent: "[[Master Profile]]"`.
- `Projects/`: active, deadline-bound work, one folder per project with its anchor note inside
  (see Folder conventions). Empty to start.
- `Resources/`: curated reference and reading.
- `Wiki/`: the compiled wiki of what the owner knows and has concluded, **written by Claude
  from the owner's notes, never by hand.** `index.md` is the catalog and is read first;
  `Wiki.md` is the folder note; `log.md` records ingests and gaps; `_sources.md` is the
  source registry; `_pending.md` is generated daily. Rules in `_system/schema.md`.
- `Attachments/`: files (PDFs, images) embedded in notes.
- `Archive/`: finished projects and areas, moved here whole.
- `_system/`: config and living docs about the machinery. `SYSTEM.md` is the hub; every
  component doc follows `_component-doc-template.md`:
  - `SYSTEM.md`: the productivity-stack hub: locked decisions, the task schema, vault-wide
    gotchas, one status line per component
  - `_component-doc-template.md`: the documentation standard for every doc in `_system/`
  - `task-cockpit.md`: how the task cockpit fits together: `ToDo.base` and its views, TaskNotes
    and its settings, `TaskNotes/Views/`, the Cockpit button and `vt todos`
  - `cockpit-plugin.md`: the shipped local plugin behind the ribbon's Cockpit button
  - `claude-task-launcher-plugin.md`: the shipped local plugin that adds "Work in Claude" to
    task notes
  - `frontmatter-properties.md`: which property names are taken and by what. Check before
    inventing one
  - `profile-convention.md`: how facts about the owner are recorded (tiers, sources, shelf
    lives, the staleness rule)
  - `_profile-template.md`: the template every sub-profile copies
  - `daily-loop.md`: how the four daily-loop skills fit together, and why they are separate
  - `working-conditions.md`: when work can realistically be placed, and the calendar roster.
    Read by `schedule-work`. Carries its own `revisit:` date
  - `canvas-archive.md`: the optional Canvas course archive (`vt canvas`): layout, the
    readings pass, the daily assignment-task sync. Delete it if you do not use Canvas
  - `schema.md`: how the `Wiki/` layer is built: what counts as a source, the article format,
    ingest, re-ingest, query and lint, and how it divides from the profile layer
  - `claude/`: Claude's own config: `global-CLAUDE.md` (the master of `~/.claude/CLAUDE.md`)
    and `commands/` (slash commands). See its README
  - `skills/`: Claude skills, source of truth, symlinked into `~/.claude/skills/`. Conventions
    in `skills/README.md`:
    - `dump/`: the verbal brain dump, the offloading half of the daily check-in
    - `commit-to-action/`: turns a dump into task notes
    - `prioritise/`: decides what matters (`priority`, `quadrant`)
    - `schedule-work/`: decides when it happens (`scheduled`, calendar blocks)
    - `obsidian-todo/`: the fast reader and writer over `Inbox/`, via `vt todos`
    - `wiki/`: ingest notes into `Wiki/`, answer "what do I know about X" from it, lint it
    - `canvas-archive/`: runs `vt canvas` (optional canvas module) and answers from the archive

## Folder conventions

- **A project's anchor note lives *inside* its folder, as a folder note, never as a sibling
  next to it.** For a project `X`, write `Projects/X/X.md` (the anchor) and put every detail doc
  alongside it in `Projects/X/`. The `folder-notes` plugin then makes clicking the folder open
  the anchor, so the file explorer shows one entry with the detail docs nested under it. Why
  not `Projects/X.md` beside `Projects/X/`: Obsidian sorts folders before files, so the anchor
  renders *below* its own folder and the name appears twice. Applies to any folder-plus-overview
  pairing, not just `Projects/`.

- **Anything live archives into itself; it moves to `Archive/` only when it is finished.**
  Two different things get called "archiving", and collapsing them splits one project across
  two folders:

  | Situation | Where it goes |
  |---|---|
  | A doc inside a live project or area is superseded | `<that folder>/Archive/` |
  | The project or area itself is finished | `Archive/<Name>/`, the whole folder |

  **There is no shared holding pen**: no `Projects/Archive/`, no `Areas/Archive/`. A holding pen
  gives "where is X?" two answers. Live means the archive is inside it; finished means it is not
  under `Projects/` or `Areas/` at all.

  **Moving any of it: `~/automation/bin/vt move <old> <new>`, never `mv`.** Obsidian only
  rewrites links for moves made inside Obsidian, so a shell or agent move silently breaks every
  path-qualified link pointing at what moved.

- **File order inside a folder is set with the `flexplorer` plugin, never by renaming** (no
  `01 ` prefixes). Renaming to sort breaks links and makes names lie about content. Anchor notes
  are pinned to the top of their folder.

## Loose files in the vault root

Only `CLAUDE.md`, `Claude Master Router.md`, `SETUP-NOTES.md` and `ToDo.base`. Anything else
in the root is unfiled: give it a home.
