---
type: reference
component: daily-loop
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Daily loop: decision record

**Status:** shipped with the starter vault, verified <INSTALL-DATE>. Five skills in `_system/skills/`. Referenced from
`SYSTEM.md` § Components.

This is the reasoning behind the skills that make up the daily loop. **The skills hold
operating instructions only. The reasoning lives here.** It was split out because long
instructions get followed less reliably than short ones, and rationale is worth reading but
costs effort when the skill is being run.

| Skill | What it decides | Writes |
|---|---|---|
| `dump` · `_system/skills/dump/` | Nothing. It captures what is in your head | a dated `type: dump` note |
| `commit-to-action` | What becomes a task | `type: action` notes, and `decision` on each |
| `prioritise` | What matters | `priority`, `quadrant`, `timeEstimate`, `startable`, `prioritised` |
| `schedule-work` | When it happens | `scheduled`, calendar blocks |
| `plan-today` · `_system/skills/plan-today/` | Where each live task stands, and today's plan | `status`, `waiting`, `scheduled`, `## Log` lines and today's calendar blocks, from your panel answers |

Each skill links here. When a decision changes, record it **here** and keep the skill file to
the instruction.

## What it's for

Getting things out of your head and into a system you trust, without the system itself becoming
a chore. Separate acts, each a different mental mode: **offload** (dump), **turn into tasks**
(commit-to-action), **decide what matters** (prioritise), **decide when** (schedule-work) and
**check where today stands** (plan-today).

## How it works

### How to run the loop

Separate commands. **Run only the ones you need**; they are not a fixed sequence you must
complete.

| Command | When | Takes | Produces |
|---|---|---|---|
| **`/dump`** | Daily, or whenever your head is full | 5-15 min | A verbatim transcript. No tasks |
| **`/commit-to-action`** | After a dump | 10-20 min | Real task notes, one per thing you said |
| **`/prioritise`** | Weekly, or when the backlog shifts | 15-30 min | `priority`, `quadrant`, effort, `startable` |
| **`/schedule-work`** | Weekly | 20-30 min | `scheduled` dates and, if a calendar is connected, calendar blocks |
| **`/plan-today`** | Daily, in the morning (the meditation journal button can run it) | target 5 min | A confirmed status for every live task, and today in the calendar |

**A normal week:** dump and commit most days; prioritise and schedule once, at a fixed weekly
slot for the week ahead, together with a mid-week check that replans the rest of the current
week and sends invites for the next one. A mid-week slot (for example Wednesday afternoon)
works better than the weekend, because plans that involve other people need booking days
ahead. Record your slot in your week-structure note if you keep one.

**A normal day:** just `/dump`, then `/commit-to-action` if anything in it needs to become a
task. That is the whole daily obligation. `/plan-today` is the optional morning check.

### Why separate commands and not one

1. **The cadences genuinely differ.** Dump and commit are daily; prioritise and schedule are
   weekly. One merged command forces a weekly rhythm onto a daily act, or the reverse.
2. **Each is a different mental mode**, and the separations are deliberate: capture must never
   block on a decision, creating tasks is not judging them, and prioritising is not scheduling.
   Mixing them makes each one worse: a dump that starts asking "how important is this?" stops
   emptying your head.
3. **Running all of them at once is expensive.** A first full run from a standing start, with a
   large backlog, can take hours. A merged command would cost that on any unusual day.

What helps instead of a merger is a thin entry point: one command that runs `dump`, then offers
each following step based on state (commit if a dump is unprocessed, prioritise if tasks lack
`prioritised`, schedule if the week is unplanned). Not shipped; easy to add as a skill.

### Two axes, kept apart

`prioritise` writes `priority` (importance). `schedule-work` writes `scheduled` (commitment).
Neither decides the other's field. Why: priority never expires on its own, so if it drove the
`ToDo` view the list would fill up permanently. Dates expire; they are what should put work in
front of you. Full rule: [[_system/SYSTEM|SYSTEM]] § Capture note schema.

### The daily reconcile pass: plan-today

[[_system/skills/plan-today/SKILL|plan-today]] (component doc: [[_system/plan-today|plan-today]])
is a third cadence, distinct from both the daily pair and the weekly pair. A scheduled pre-run
on the server pre-guesses the panel, so the morning check is one click per task. It is
`schedule-work`'s Pass 0b (sweep the past) and Pass 0c (reconcile calendar against task status)
run on their own every day, reusing their logic and block conventions by pointer rather than
duplicating them:

1. Read `Inbox/` for tasks whose `scheduled` date is in the last few days (`todos.py --json`,
   the same reader every skill uses).
2. Cross-check each against its calendar block, as Pass 0c does.
3. **Flag, do not assume.** Anything not marked `done` is asked about in one pass.
4. On the answer: mark genuinely done tasks `done`; re-`scheduled` the rest to a real day, not
   silently to "today".
5. **Stop there.** No capacity report, no big-rocks pass, nothing not implicated by recent
   slippage. That boundary is what keeps it fast enough to run daily: once it grows a capacity
   report it has become `schedule-work` again.

## Gotchas

- **Do not edit a skill while a run of it is in progress.** Collect improvements, say you have
  noted them, and apply them once the run ends. Amending a process mid-flight makes the user
  follow a moving target while also doing the work. If the user explicitly asks for a change
  mid-run, end the run, amend the skill and restart cleanly.
- **Batch confirmations, never item by item.** Every skill proposes one reviewable list and
  waits. Fifty separate confirmations are worse than the mental load the loop exists to relieve.
- **Nothing vanishes silently.** Every skill has a "not becoming tasks" or "not scheduled"
  section with a one-line reason per item. If items disappear without a word, the user stops
  trusting the loop.
- **Deleting a calendar event can be refused by the permission classifier; updating one is
  not.** Repurpose the event instead: retitle and retime it into the block you would otherwise
  have created. Prefer this regardless, since it leaves one event where delete-plus-create
  leaves two, and deleting is the user's job.

## Known limitations

- `schedule-work` is only as good as the calendar it can read. Without a calendar connector it
  still works, but it plans against what the user tells it and cannot write blocks.
- **Tasks and their calendar events are not linked.** Nothing on a task records which event
  covers it, so on a re-run the skill cannot tell whether a block already exists; it only sees
  `scheduled`. That risks duplicate blocks, and orphaned events when a task moves. Fixing it
  means storing an event ID on the task. Not built; do not build it without asking.
- **No skill in the loop sweeps external sources per task.** A task can be unstartable because
  its information lives in mail rather than in the vault. A per-task mail sweep belongs to
  enrichment, not to this loop. Design note for whoever builds it: the fact that matters can sit
  in an unread thread that is over a week old, so a sweep filtered to recent or already-read
  threads will miss it.

## Decisions

### Estimates and capacity

- **A `needs-breakdown` estimate is not a number. Ask before planning around it.** The tag means
  "cannot be estimated until it is split", and its `360` placeholder can be off by several times
  in either direction (for example by silently counting parts that have no deadline). Treat it as
  unknown and ask before it anchors a week of planning.
- **Overestimate, as three mechanical rules:** round every `timeEstimate` **up** to the next half
  hour; plan a day to at most **~80% of its free hours**; treat `360`/`needs-breakdown` as
  unknown, never as six. A bias correction that is not mechanical is not a correction.
- **The 80% rule exists to force trades into the open.** When a mid-run request pushes the plan
  past its slack, say so; do not absorb it silently.
- **Capacity is hours, not task counts.** Sum `timeEstimate` against free hours. On days
  dominated by unestimated tasks, where the hour sum would be fake precision, fall back to a
  count ceiling: free hours before the end of the working day × 1.5, rounded up.
- **Reserve a surprise-work block (1 h, ideally early afternoon) and subtract it from capacity
  before placing anything.** Reactive work happens whether or not it is planned; a buffer added
  after the fact is decorative.
- **Weekly Quadrant II block: set the figure from the outstanding Quadrant II hours, with
  2 h/week as the floor,** and report the implied finish date so the user can see whether it
  clears the horizon. A fixed small block can be honoured and still finish too late.
- **Weekly hour budgets per project are not set by the skill.** Offer to set them once and let
  the user choose the numbers; North Star owns the shape of priorities.

### Asking the right questions, in the right order

- **Ask the shape of the day first, alone, and wait** (Pass 1a), then what is in it (Pass 1b).
  Answers that invalidate the whole plan come before answers that add detail. Pass 1a is a
  structured set, not one question: weekdays, weekends, travel, sport, appointments, how weekdays
  should run, how weekends should run. One "what does your day look like" flattens different
  weekday and weekend capacity into one wrong number.
- **When a run repeats a documented mistake, change the shape of the pass, not the wording of
  the reminder.** A lesson recorded as one bullet in a list is easy to read past.
- **Read working conditions from [[_system/working-conditions|working-conditions]], restate them
  in one line, and ask whether they still hold.** Do not ask what the vault already answers: say
  "these are on file, anything changed?" New conditions get written there, **each with an
  expiry**. A condition with no expiry survives into a week where it is false.
- **Ask what is missing from the calendar with specific cues:** travel, family events, anything
  involving other people, anything already agreed verbally. A generic "anything missing?"
  surfaces none of it.
- **Known commitments from Pass 1b become proposed blocks in Pass 5**, on the same terms as work
  blocks. Travel includes transfers and the days either side. Otherwise capacity maths treats a
  travel day as free.
- **A question whose answer lives only in the transcript will be asked again next week.** Every
  answer that matters must change durable state: a task, a property, a calendar block or
  working-conditions.
- **Volume without decisions is waste.** Show the rows that need a judgement; pre-filled rows
  the user only has to wave through cost reading time for nothing.

### Reconciling the calendar (Pass 0c)

Pass 0c reads the calendar back to the last run, tables every past block beside its task, and
**asks**. It cannot tell work that never happened from work that happened and was never ticked,
and the second silently inflates the backlog, so inference is banned. The answer may close a
task, which is why the write list includes `status: done`.

The table has four columns (block · task · vault says · verdict) with ✅/❓/❌ in the verdict
cell: ✅ rows only show the check ran, ❓ rows are the ask, ❌ is reserved for cases something
else in the run has already disproved. It is written into the skill as a literal example,
because a described format drifts and a copied one does not.

### Placing work

- **The week is built around the top two quadrants; everything else fills the gaps.**
- **Hard, brain-intense tasks first.** Where that conflicts with a North Star rule (a
  cognitively hard but emotionally neutral task against an emotionally demanding easy one),
  **North Star wins**: it is a stated constraint, cognitive-load ordering is a heuristic.
- **`run-up` and emotionally demanding work never go after midday; `cold` work may go
  anywhere.** Afternoon slots reliably get bumped, but a blanket no-work-after-midday ban
  collides with capacity honesty. Mapping it onto `startable` keeps the rule usable.
- **Multi-day work does not fit a single `scheduled` field.** `scheduled` = the start date, the
  session plan goes in the note body, and the calendar carries the individual blocks.
- **When the plan does not fit, prefer cutting self-imposed deadlines, and watch what that does
  over time.** Self-imposed deadlines are what strategic work has; external deadlines belong to
  admin and other people's timelines. Applied mechanically, the rule starves exactly the work
  that matters most. So apply it, say you applied it, and **if the same task is deferred twice,
  stop and say so**: it needs to be dropped outright or protected, not moved again.
- **Default to one block per task.** A calendar cell truncates, so a longer title does not
  recover the visibility that merging destroys. Merge only when two tasks are genuinely one
  sitting with one output; then name both in the title, as damage control.
- **Log why something was scheduled only when the placement is not obvious:** pulled earlier
  than the due date (booking lead time, travel, a supply running out), deferred past its due
  date because something else won, or placed against a working-hours or capacity constraint. One
  line in the task body naming the constraint. Logging every placement bloats task bodies, and
  light bodies are what keep bulk reads cheap.
- **Completeness gate: every open task has been decided about** (scheduled, explicitly deferred
  and named in the report, or `waiting: true`), not every task scheduled. Scheduling everything
  is the fantasy plan the capacity pass exists to prevent.
- **Close with a gut-check, at week scope:** proceed only if this looks like a week that could
  go well. It is the only human check on a machine-produced plan. In Pass 5.
- **Big rocks carry a done-by date and a definition of done.** Propose the whole plan in one
  pass; when starting mid-day, place today first. Re-run triggers become tasks.
- **Capacity includes course load and class prep** if you study, deadlines are checked against
  travel, and commutes get blocks. Calendar, time zone and any colour or emoji scheme (for
  example a marker for important and social blocks, a separate focus calendar for solo work) are
  configured in `schedule-work`.

### Open question: how granular the calendar is

Two philosophies conflict: time-blocking anything of 10 minutes or more, against putting only
hour-plus tasks on the calendar so it stays sparse and bookable by other people. **Surface it
when it bites, do not resolve it.** It bites the first time a day's plan is mostly sub-hour
`cold` tasks. The live options are two calendars (one sparse and shareable, one granular and
personal) or one rule revisited; put them to the user.

**Default until the user rules:** propose timed blocks for hour-plus and protected items, and
list sub-hour `cold` items loose under the day. This is the reversible choice: adding blocks
later is easy, un-learning a cluttered calendar is not.

Out of scope for the loop: health and habit tracking (it turns a scheduling session into a life
review), a separate accountability log (the vault and the session transcript already serve it),
and calendar colour rules beyond the scheme above.

### The undecided finding

**Background stress often tracks how many things are undecided, not how much there is to do.**
Undecided items are quiet by construction: they feel like fog, not tasks, so a freeform dump
rarely reaches them. And a task framed as admin can be an undecided decision in disguise (an
RSVP that is open because you have not decided whether to go), and the admin framing is exactly
why it never gets done.

What follows from it:

| Decision | Where it lives |
|---|---|
| **Two leading questions in `dump` Phase 1:** *what are you undecided about?* and *what are you avoiding that's important?* | `dump` Phase 1 |
| **A `decision: pending \| made` property**, not a new task type | [[_system/SYSTEM\|SYSTEM]] schema |
| **`commit-to-action` classifies every item it ingests** as decision-shaped or not, and names the one fact or message that would let you decide | `commit-to-action` § Classify |
| **An `Undecided` view** keyed on the property | `ToDo.base` |
| **Decisions are titled by the decision**, not its downstream admin | `commit-to-action` § Classify |
| **`due` carries the decide-by date.** No separate field | SYSTEM schema |

- **The leading questions go first because loud items surface on their own; the important
  avoided one does not.** A freeform half can run to exhaustion without reaching it. Phase 2
  keeps both as follow-ups with the already-covered marker. The ceiling is two leading
  questions; a third needs the same argument made again.
- **Where to track something is a property plus a view, not a new file.** A second store drifts
  from the task list within a week. A new task type means new views, new filters and a new drift
  surface; a property costs one line and one view.
- **Undecided is not unscheduled. Do not collapse them.** Unscheduled: the work is known, the
  date is not. `decision: pending`: the work itself is not known, because a choice has to happen
  first. A view keyed on "has no date" does not surface decisions.
- **Write refusals with their own condition.** Decisions were once deliberately not
  distinguishable from tasks, because schema additions wait until a consumer exists. The view is
  that consumer. A refusal that names its condition is cheap to revisit; a flat one is not.

### Dictation and proper nouns

- **Repair proper nouns against known vault entities, and declare every repair at readback.**
  Dictation garbles names in both directions: a silent repair can be wrong, and a faithful
  garble makes a line unusable. The declaration is the load-bearing half; only the user knows
  the true name.
- **The vault is not authoritative over the user.** A note can carry a misspelling that a repair
  then propagates into every future dump. When the user corrects a name, grep the vault for the
  wrong spelling, not just the one note.
- **Dictated answers drift out of alignment with the list they answer.** When alignment is lost,
  separate the confidently mapped rows from the guessed ones and ask only about the guesses, not
  the whole list. Echo the key-to-value mapping before writing dictated answers.

### Judgement passes render as tables

Every pass that asks the user for judgement renders as a table, so the user does not hold column
meanings in their head while judging many items. The size column carries its band definitions
in the header (`quick <30m / medium 30m-2h / long >2h / break-down ≥6h`).

### Sources and per-skill rules

- **commit-to-action:** meditation journal entries are a source kind (never edited, never
  closed). Course material is another (one task per assignment, one prep task per session, final
  courses only, about three weeks of assignments ahead). Research mail and WhatsApp before
  proposing whenever an item names a booking, trip or payment. Offer to draft the message when
  the next action is sending one.
- **prioritise:** surface stale highs before Pass 1; record timing the user volunteers.
- **If you study, keep two course rules in North Star:** assignments beat class prep, and prep
  shortens before a big rock slips.

### The reader has to emit what the placer consumes

`schedule-work` reads the backlog through `todos.py --json` and must not build a second reader.
Its placement table runs on `timeEstimate` (an int, so it sums), `quadrant`, `startable` and
`tags`, so the script emits all four. Re-check this pairing whenever either side changes.

### Two structural tensions to watch

- **Quadrant is computed as importance = the priority tier**, so a `3-normal` task can never be
  important. Genuinely important non-urgent work below `4-high` stays buried, and promoting it
  fills the global cap of 9. If important work routinely cannot fit in 9 slots, the fix is a
  larger cap or an importance signal independent of the tier. Also watch a high tier that is
  over its cap and never breaks ties: it is not earning its keep. Raise it at the next
  `prioritise` run.
- **North Star's priorities list may have no line for family or for your own planning.** High
  tasks that belong to no priority cannot be checked against the per-priority cap of 3. That
  list is the user's to write.

### Keeping the loop fast

Target: about 30 minutes for a full run. What makes it slow is specific, not general slowness:
constraints arriving in pieces, each invalidating the previous plan; questions the vault already
answers; and long lists with no decisions in them. The split by cadence (daily dump and commit,
weekly prioritise and schedule) is the change that halves the time on its own. Further options,
not adopted by default: one consolidated question block per skill, pre-filled from North Star
and answering only the diffs; making the cap advisory (report the count, do not ask what drops
unless the user asks); showing existing tasks during the dump sweep.

### One task per thing said, but split scans by stake

A dump that names fifteen people to reply to produces fifteen tasks: a batched task hides its
contents and never feels finished, while ticking off fifteen things actually discharges the
worry. A *scan* of mail or messages is different: the user never held those items in their
head, so only the ones with a date, money, a decision or a blocked person get their own task,
and the rest stay inside one batch task. Detail in `commit-to-action`.

### Row keys: short keywords, not numbers

**Every list the loop skills put in front of the user is keyed by a short keyword**, not a
number or a letter: `dump`'s cue list, `commit-to-action`'s proposal, all `prioritise` passes,
`schedule-work`'s placement list, `obsidian-todo` and `/otodos`, and ad-hoc lists. **The rule's
home is [[_system/SYSTEM|SYSTEM]] § How Claude operates**; this section keeps the reasoning.

**Why.** People answer these lists by voice, and dictation tools re-order and renumber a
dictated list on their own, so answers come back shifted by a row and get written to the wrong
tasks. Numbers also fail without dictation: after a few passes nobody remembers which number was
which task. A keyword is the word the user would say anyway and cannot be renumbered.

**The rule.** One or two words from the title, unique within the list. On a collision add a
distinguishing word (*flight ticket* / *flight forms*). Bold the key in the first column, keep
the same key for a task across every pass of a session, and echo back by key plus title.

## See also
- `_system/skills/`: the loop's `SKILL.md` files
- [[_system/SYSTEM|SYSTEM]]: task schema and the locked decisions
- [[Areas/North Star]]: priorities, the anti-list, decision rules
- [[_system/working-conditions|working-conditions]]: when work can actually be placed
- [[_system/plan-today|plan-today]]: the daily reconcile and day plan
