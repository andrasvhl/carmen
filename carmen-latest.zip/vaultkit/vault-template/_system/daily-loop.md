---
type: reference
component: daily-loop
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Daily loop: dump, commit, prioritise, schedule

**Status:** shipped with the starter vault, verified <INSTALL-DATE>. Four skills in `_system/skills/`. Referenced from
`SYSTEM.md` § Components. The skills hold the instructions; this doc holds the reasoning.

## What it's for

Getting things out of your head and into a system you trust, without the system itself becoming
a chore. Four separate acts, each a different mental mode: **offload** (dump), **turn into
tasks** (commit-to-action), **decide what matters** (prioritise), **decide when** (schedule-work).

## How it works

### How to run the loop

Four separate commands. **Run only the ones you need**; they are not a fixed sequence you must
complete.

| Command | When | Takes | Produces |
|---|---|---|---|
| **`/dump`** | Daily, or whenever your head is full | 5-15 min | A verbatim transcript. No tasks |
| **`/commit-to-action`** | After a dump | 10-20 min | Real task notes, one per thing you said |
| **`/prioritise`** | Weekly, or when the backlog shifts | 15-30 min | `priority`, `quadrant`, effort, `startable` |
| **`/schedule-work`** | Weekly | 20-30 min | `scheduled` dates and, if a calendar is connected, calendar blocks |

**A normal week:** dump and commit most days; prioritise and schedule once, at a fixed weekly
slot (for example Friday morning for the following week, about an hour). A short top-up at the
start of the week catches what the weekend changed, and a mid-week check replans the rest.

**A normal day:** just `/dump`, then `/commit-to-action` if anything in it needs to become a
task. That is the whole daily obligation.

### Why four commands and not one

1. **The cadences genuinely differ.** Dump and commit are daily; prioritise and schedule are
   weekly. One merged command forces a weekly rhythm onto a daily act, or the reverse.
2. **Each is a different mental mode**, and the separations are deliberate: capture must never
   block on a decision, creating tasks is not judging them, and prioritising is not scheduling.
   Mixing them makes each one worse: a dump that starts asking "how important is this?" stops
   emptying your head.
3. **Running all four at once is expensive.** A first full run from a standing start, with a
   large backlog, can take hours. A merged command would cost that on any unusual day.

What helps instead of a merger is a thin entry point: one command that runs `dump`, then offers
each following step based on state (commit if a dump is unprocessed, prioritise if tasks lack
`prioritised`, schedule if the week is unplanned). Not shipped; easy to add as a skill.

### Two axes, kept apart

`prioritise` writes `priority` (importance). `schedule-work` writes `scheduled` (commitment).
Neither decides the other's field. Why: priority never expires on its own, so if it drove the
`ToDo` view the list would fill up permanently. Dates expire; they are what should put work in
front of you. Full rule: [[_system/SYSTEM|SYSTEM]] § Capture note schema.

### Why the dump asks about undecided things first

A useful finding to test on yourself: **background stress often tracks how many things are
undecided, not how much there is to do.** Undecided items are quiet by construction. They do
not feel like tasks, they feel like fog, so a freeform dump rarely reaches them. That is why
`dump` opens with "what are you undecided about?" and "what are you avoiding that's important?",
and why `commit-to-action` marks decision-shaped tasks with `decision: pending` and names the
one fact or message that would let you decide.

## Gotchas

- **Do not edit a skill while a run of it is in progress.** Collect improvements, say you have
  noted them, and apply them once the run ends. Amending a process mid-flight makes the user
  follow a moving target while also doing the work.
- **Batch confirmations, never item by item.** Every skill proposes one reviewable list and
  waits. Fifty separate confirmations are worse than the mental load the loop exists to relieve.
- **Nothing vanishes silently.** Every skill has a "not becoming tasks" or "not scheduled"
  section with a one-line reason per item. If items disappear without a word, the user stops
  trusting the loop.

## Known limitations

- `schedule-work` is only as good as the calendar it can read. Without a calendar connector it
  still works, but it plans against what the user tells it and cannot write blocks.
- There is no automatic reconcile pass between runs: if a day goes off-plan, the next
  `schedule-work` run catches it (Pass 0b and 0c), not anything in between.

## Decisions

### Row keys: short keywords, not numbers

**Every list the loop skills put in front of the user is keyed by a short keyword**, not a
number or a letter: `dump`'s cue list, `commit-to-action`'s proposal, all `prioritise` passes,
`schedule-work`'s placement list, `obsidian-todo`, and ad-hoc lists.

**Why.** People answer these lists by voice, and dictation tools re-order and renumber a
dictated list on their own, so answers come back shifted by a row and get written to the wrong
tasks. Numbers also fail without dictation: after a few passes nobody remembers which number was
which task. A keyword is the word the user would say anyway and cannot be renumbered.

**The rule.** One or two words from the title, unique within the list. On a collision add a
distinguishing word (*flight ticket* / *flight forms*). Bold the key in the first column, keep
the same key for a task across every pass of a session, and echo back by key plus title.

### One task per thing said, but split scans by stake

A dump that names fifteen people to reply to produces fifteen tasks: a batched task hides its
contents and never feels finished, while ticking off fifteen things actually discharges the
worry. A *scan* of mail or messages is different: the user never held those items in their
head, so only the ones with a date, money, a decision or a blocked person get their own task,
and the rest stay inside one batch task. Detail in `commit-to-action`.

## See also
- `_system/skills/`: the four `SKILL.md` files
- [[_system/SYSTEM|SYSTEM]]: task schema and the locked decisions
- [[Areas/North Star]]: priorities, the anti-list, decision rules
- [[_system/working-conditions|working-conditions]]: when work can actually be placed
