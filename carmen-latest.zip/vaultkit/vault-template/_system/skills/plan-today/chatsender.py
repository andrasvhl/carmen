"""Send a two-minute page LinkedIn, Messenger or Instagram reply the moment the user clicks, like mailer.py.

Same contract as mailer.py, so the page's Undo window and "new in the thread" hold work unchanged:
  prepare(msg, since, force) reads the chat on vault-host for messages from others since `since`
      (the draft's time). A new one HOLDS the send unless force. Returns who it goes to, for the Undo.
  commit(id) sends the exact text, through Beeper on vault-host (tools/chat.py, text on stdin).
The click is the user's approval for that text (reference/panel.md § Approval is per action). Mac side:
ssh to vault-host, where the Beeper session lives (_system/beeper-bridge.md). Stdlib only.
PT_MAIL_DRY=1 (tests) runs everything except the final send.
"""
import json, os, secrets, subprocess, time
from datetime import datetime, timezone

VIAS = ("linkedin", "messenger", "instagram")
_pending = {}


def _box(args, stdin=None, timeout=60):
    cmd = "cd ~/automation && python3 -m tools.chat " + " ".join(args)
    r = subprocess.run(["ssh", "vault-host", cmd], input=stdin, capture_output=True, text=True,
                       timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip()[-300:] or "ssh failed")
    out = json.loads(r.stdout.strip().splitlines()[-1])
    if isinstance(out, dict) and out.get("ok") is False:
        raise RuntimeError(out.get("error") or "Beeper failed")
    return out


def _safe(chat_id):
    """Chat ids go into the remote command line; allow only id-shaped characters."""
    if not chat_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!:._-=@+" for c in chat_id):
        raise ValueError(f"not a chat id: {chat_id!r}")
    return chat_id


def prepare(msg, since=0, force=False):
    """-> {ok, id, to, cc, thread, held: [{from, when, snippet}], error}."""
    try:
        chat = _safe((msg.get("to") or "").strip())
        body = msg.get("body") or ""
        if not body.strip():
            return {"ok": False, "error": "empty message"}
        info = _box(["name", chat])
        label = f"{info.get('chat', chat)} on {info.get('network', msg.get('via', 'chat'))}"
        stamp = datetime.fromtimestamp(since or 0, timezone.utc).isoformat()
        held = [{"from": m.get("from") or "?", "when": f"{m.get('date', '')[5:]} {m.get('t', '')}",
                 "snippet": m.get("text", "")[:200]} for m in _box(["held", chat, stamp])]
    except Exception as e:  # noqa: BLE001 - shown on the page, never fatal
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:300]}
    if held and not force:
        return {"ok": False, "held": held, "to": [label], "cc": []}
    pid = secrets.token_hex(6)
    _pending[pid] = {"chat": chat, "body": body, "to": label, "t": time.time()}
    return {"ok": True, "id": pid, "to": [label], "cc": [], "thread": True}


def commit(pid):
    p = _pending.pop(pid, None)
    if not p or time.time() - p["t"] > 120:
        return {"ok": False, "error": "send expired: click Send again"}
    if os.environ.get("PT_MAIL_DRY"):
        return {"ok": True, "dry": True, "to": [p["to"]]}
    try:
        _box(["send", p["chat"]], stdin=p["body"])
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:300]}
    return {"ok": True, "to": [p["to"]]}
