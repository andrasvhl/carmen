"""Send a two-minute page email the moment he clicks (owner decision, 2026-10-12: "a click in panel
immediately to send a message via Claude"). Mail only: WhatsApp is never sent by Claude.

Two calls, from panel_server.py on the Mac and the check-in app on vault-host (Oct 31):
  prepare(msg, since, force) finds the thread (subject plus recipient, last 60 days, else the
      recipient's thread sharing 60% of the subject's words; or
      msg["thread_id"] when the caller already found it; none when msg["new_thread"]), works out the
      recipients as a reply in that thread (his `to`, everyone else on the last message in cc, never
      himself), and checks for replies from others since `since` (the draft's time). A new reply
      HOLDS the send unless force: the page shows it and he clicks again (his choice, Oct 12).
      Returns what will be sent, so the page shows To and Cc during the Undo window.
  commit(id) sends it, in the thread (In-Reply-To, References, threadId).
  pick_mailbox(subj, to, prefer) names the mailbox the conversation lives in: the thread's, else
      the one with the latest mail with them, else the draft's own `acct` (prefer).
  related(to, skip_thread) lists other mail with them in both mailboxes, for the sheet.
Credentials: the Google connector's sign-in (~/.google_workspace_mcp/credentials/<mailbox>.json,
scope gmail.send, on the Mac and on vault-host). Read only: the access token is refreshed in
memory and never written back, so the connector's file stays its own. Stdlib only.
PT_MAIL_DRY=1 (tests) runs everything except the final send.
"""
import base64, json, os, re, secrets, time, urllib.parse, urllib.request
from email.message import EmailMessage
from email.utils import getaddresses, parseaddr
from pathlib import Path

CREDS = Path.home() / ".google_workspace_mcp" / "credentials"
API = "https://gmail.googleapis.com/gmail/v1/users/me/"
MAILBOXES = ("<YOUR_EMAIL>", "<YOUR_PERSONAL_EMAIL>")
_tok, _pending = {}, {}
PUBLIC_DOMAINS = {"gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "live.com", "yahoo.com", "icloud.com",
                  "me.com", "aol.com", "gmx.de", "gmx.net", "web.de", "t-online.de", "proton.me", "protonmail.com"}


def _token(acct):
    t = _tok.get(acct)
    if t and t[1] > time.time() + 60:
        return t[0]
    c = json.loads((CREDS / f"{acct}.json").read_text(encoding="utf-8"))
    data = urllib.parse.urlencode({"client_id": c["client_id"], "client_secret": c["client_secret"],
                                   "refresh_token": c["refresh_token"], "grant_type": "refresh_token"}).encode()
    with urllib.request.urlopen(urllib.request.Request(c["token_uri"], data=data), timeout=20) as r:
        d = json.loads(r.read())
    _tok[acct] = (d["access_token"], time.time() + int(d.get("expires_in", 3000)))
    return d["access_token"]


def _api(acct, path, body=None):
    req = urllib.request.Request(API + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Authorization": "Bearer " + _token(acct), "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())


def _emails(s):
    return [a.lower() for _, a in getaddresses([s or ""]) if "@" in a]


def _hdr(m, name):
    for h in m.get("payload", {}).get("headers", []):
        if h["name"].lower() == name.lower():
            return h["value"]
    return ""


def _base_subject(s):
    return re.sub(r"^\s*((re|aw|fwd?|wg)\s*:\s*)+", "", s or "", flags=re.I).strip()


def _thread(acct, subj, to):
    base = _base_subject(subj)
    if not base:
        return None
    q = f'subject:"{base}" newer_than:60d'
    if to:
        q += " {" + " ".join(f"from:{a} to:{a} cc:{a}" for a in to) + "}"
    hits = _api(acct, "threads?" + urllib.parse.urlencode({"q": q, "maxResults": 3})).get("threads") or []
    if hits:
        return _thread_by_id(acct, hits[0]["id"])
    # A drafted subject is often reworded (Oct 31: the Avant Car draft dropped "SEAT Ibiza" and
    # missed its thread), so: their threads in the window, the one sharing most subject words.
    if not to:
        return None
    q = "newer_than:60d {" + " ".join(f"from:{a} to:{a} cc:{a}" for a in to) + "}"
    want, best = _words(base), (0.0, None)
    for h in (_api(acct, "threads?" + urllib.parse.urlencode({"q": q, "maxResults": 10})).get("threads") or []):
        t = _thread_by_id(acct, h["id"])
        got = _words(_hdr((t.get("messages") or [{}])[0], "Subject"))
        score = len(want & got) / len(want) if want else 0.0
        if score > best[0]:
            best = (score, t)
    return best[1] if best[0] >= 0.6 else None


def _words(s):
    return set(re.findall(r"\w{3,}", _base_subject(s).lower()))


def _thread_by_id(acct, tid):
    hdrs = "&".join("metadataHeaders=" + h for h in ("From", "To", "Cc", "Subject", "Message-ID", "References"))
    return _api(acct, f"threads/{urllib.parse.quote(tid)}?format=metadata&{hdrs}")


def pick_mailbox(subj, to, prefer=""):
    """The mailbox the conversation lives in (owner decision, Oct 31: with a chain or earlier mail, the
    right mailbox is chosen). -> (acct, why): the one holding the thread, the newer if both do
    ("thread"); else the one with the latest mail to or from them in a year ("earlier mail");
    else prefer ("draft"), or "" when there is nothing to go on."""
    to, found, why = _emails(to), {}, "thread"
    for acct in MAILBOXES:
        th = _thread(acct, subj, to)
        if th:
            found[acct] = max(int(m.get("internalDate", 0)) for m in th.get("messages") or [{}])
    if not found and to:
        why = "earlier mail"
        q = "newer_than:365d {" + " ".join(f"from:{a} to:{a} cc:{a}" for a in to) + "}"
        for acct in MAILBOXES:
            hits = _api(acct, "messages?" + urllib.parse.urlencode({"q": q, "maxResults": 1})).get("messages") or []
            if hits:
                found[acct] = int(_api(acct, f"messages/{hits[0]['id']}?format=minimal").get("internalDate", 0))
    if found:
        return max(found, key=found.get), why
    return (prefer, "draft") if prefer in MAILBOXES else ("", "")


def mailbox_for(subj, to):
    """The mailbox holding the thread or the latest mail with them, or "" when neither has any."""
    return pick_mailbox(subj, to)[0]


def prepare(msg, since=0, force=False):
    """-> {ok, id, acct, to, cc, subj, thread, held: [{from, when, snippet}], error}."""
    acct = (msg.get("acct") or "").strip().lower()
    if acct not in MAILBOXES:
        return {"ok": False, "error": f"unknown mailbox {acct or '(none)'}: send it from Gmail"}
    to = _emails(msg.get("to"))
    th = (None if msg.get("new_thread") else
          _thread_by_id(acct, msg["thread_id"]) if msg.get("thread_id") else _thread(acct, msg.get("subj"), to))
    cc, refs, reply_to, held = [], "", "", []
    if th:
        msgs = th.get("messages", [])
        last = msgs[-1]
        others = [m for m in msgs if acct not in _emails(_hdr(m, "From"))]
        if not to and others:
            to = _emails(_hdr(others[-1], "From"))
        everyone = _emails(_hdr(last, "From")) + _emails(_hdr(last, "To")) + _emails(_hdr(last, "Cc"))
        cc = [a for a in dict.fromkeys(everyone) if a != acct and a not in to]
        reply_to = _hdr(last, "Message-ID")
        refs = (_hdr(last, "References") + " " + reply_to).strip()
        held = [{"from": parseaddr(_hdr(m, "From"))[0] or _hdr(m, "From"), "snippet": m.get("snippet", ""),
                 "when": time.strftime("%b %-d %H:%M", time.localtime(int(m["internalDate"]) / 1000))}
                for m in others if int(m.get("internalDate", 0)) / 1000 > since]
    # The thread so far, so the sheet shows what he is answering (owner decision, Oct 31).
    history = [{"from": parseaddr(_hdr(m, "From"))[0] or _hdr(m, "From"), "mine": acct in _emails(_hdr(m, "From")),
                "snippet": m.get("snippet", ""), "when": _when(m)} for m in (th or {}).get("messages", [])[-6:]]
    if not to:
        return {"ok": False, "history": history,
                "error": f"no email address for '{msg.get('to')}' and no thread found: send it from Gmail"}
    if held and not force:
        return {"ok": False, "held": held, "to": to, "cc": cc, "history": history}
    subj = msg.get("subj") or ""
    if th and not re.match(r"^\s*re\s*:", subj, re.I):
        subj = "Re: " + _base_subject(_hdr(th["messages"][0], "Subject") or subj)
    e = EmailMessage()
    e["From"], e["To"], e["Subject"] = acct, ", ".join(to), subj
    if cc:
        e["Cc"] = ", ".join(cc)
    if reply_to:
        e["In-Reply-To"], e["References"] = reply_to, refs
    e.set_content(msg.get("body") or "")
    pid = secrets.token_hex(6)
    _pending[pid] = (acct, {"raw": base64.urlsafe_b64encode(e.as_bytes()).decode(),
                            **({"threadId": th["id"]} if th else {})}, time.time())
    return {"ok": True, "id": pid, "acct": acct, "to": to, "cc": cc, "subj": subj, "thread": bool(th),
            "thread_id": th["id"] if th else "", "history": history}


def _when(m):
    return time.strftime("%b %-d", time.localtime(int(m.get("internalDate", 0)) / 1000))


def related(to, skip_thread=""):
    """Other mail with them in the last year, from both mailboxes, newest first:
    [{acct, thread_id, subj, from, when}]. So the sheet shows where the earlier mail is."""
    to = _emails(to) if isinstance(to, str) else to
    if not to:
        return []
    # A company's whole domain, not just this address (Oct 31: Avant Car wrote from dubrovnik@ and
    # customer.service@), but never a shared provider's.
    who = list(dict.fromkeys(to + [a.split("@")[1] for a in to if a.split("@")[1] not in PUBLIC_DOMAINS]))
    q = "newer_than:365d {" + " ".join(f"from:{a} to:{a} cc:{a}" for a in who) + "}"
    out = []
    for acct in MAILBOXES:
        for h in (_api(acct, "threads?" + urllib.parse.urlencode({"q": q, "maxResults": 6})).get("threads") or []):
            if h["id"] == skip_thread:
                continue
            ms = _api(acct, f"threads/{h['id']}?format=metadata&metadataHeaders=Subject&metadataHeaders=From").get("messages") or [{}]
            m = ms[-1]
            out.append({"acct": acct, "thread_id": h["id"], "subj": _hdr(ms[0], "Subject"), "when": _when(m),
                        "from": parseaddr(_hdr(m, "From"))[0] or _hdr(m, "From"), "at": int(m.get("internalDate", 0))})
    return [{k: v for k, v in r.items() if k != "at"} for r in sorted(out, key=lambda r: -r["at"])[:8]]


def commit(pid):
    p = _pending.pop(pid, None)
    if not p or time.time() - p[2] > 600:
        return {"ok": False, "error": "send expired: click Send again"}
    acct, body, _ = p
    if os.environ.get("PT_MAIL_DRY"):  # tests: everything but the send itself
        return {"ok": True, "gmail_id": "dry-run", "thread_id": body.get("threadId"), "acct": acct, "dry": True}
    r = _api(acct, "messages/send", body)
    return {"ok": True, "gmail_id": r.get("id"), "thread_id": r.get("threadId"), "acct": acct}
