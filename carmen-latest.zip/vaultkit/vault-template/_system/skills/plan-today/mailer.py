"""Send a two-minute page email the moment the user clicks. Mail only: WhatsApp is never sent by Claude.

Two calls, both from panel_server.py:
  prepare(msg, since, force) finds the thread (subject plus recipient, last 60 days), works out the
      recipients as a reply in that thread (the draft's `to`, everyone else on the last message in cc, never
      the user), and checks for replies from others since `since` (the draft's time). A new reply
      HOLDS the send unless force: the page shows it and the user clicks again.
      Returns what will be sent, so the page shows To and Cc during the Undo window.
  commit(id) sends it, in the thread (In-Reply-To, References, threadId).
Credentials: the Google connector's sign-in on the Mac (~/.google_workspace_mcp/credentials/
<mailbox>.json, scope gmail.send). Read only: the access token is refreshed in memory and never
written back, so the connector's file stays its own. Mac only, like the panel itself. Stdlib only.
PT_MAIL_DRY=1 (tests) runs everything except the final send.
"""
import base64, json, os, re, secrets, time, urllib.parse, urllib.request
from email.message import EmailMessage
from email.utils import getaddresses, parseaddr
from pathlib import Path

CREDS = Path.home() / ".google_workspace_mcp" / "credentials"
API = "https://gmail.googleapis.com/gmail/v1/users/me/"
MAILBOXES = ("<YOUR_EMAIL>", "<YOUR_PERSONAL_EMAIL>")
_tok, _pending = {}, {}


def _token(acct):
    t = _tok.get(acct)
    if t and t[1] > time.time() + 60:
        return t[0]
    c = json.loads((CREDS / f"{acct}.json").read_text(encoding="utf-8"))
    data = urllib.parse.urlencode({"client_id": c["client_id"], "client_secret": c["client_secret"],
                                   "refresh_token": c["refresh_token"], "grant_type": "refresh_token"}).encode()
    with urllib.request.urlopen(urllib.request.Request(c["token_uri"], data=data), timeout=20) as r:
        d = json.loads(r.read())
    _tok[acct] = (d["access_token"], time.time() + int(d.get("expires_in", 3000)))
    return d["access_token"]


def _api(acct, path, body=None):
    req = urllib.request.Request(API + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Authorization": "Bearer " + _token(acct), "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())


def _emails(s):
    return [a.lower() for _, a in getaddresses([s or ""]) if "@" in a]


def _hdr(m, name):
    for h in m.get("payload", {}).get("headers", []):
        if h["name"].lower() == name.lower():
            return h["value"]
    return ""


def _base_subject(s):
    return re.sub(r"^\s*((re|aw|fwd?|wg)\s*:\s*)+", "", s or "", flags=re.I).strip()


def _thread(acct, subj, to):
    base = _base_subject(subj)
    if not base:
        return None
    q = f'subject:"{base}" newer_than:60d'
    if to:
        q += " {" + " ".join(f"from:{a} to:{a} cc:{a}" for a in to) + "}"
    hits = _api(acct, "threads?" + urllib.parse.urlencode({"q": q, "maxResults": 3})).get("threads") or []
    if not hits:
        return None
    hdrs = "&".join("metadataHeaders=" + h for h in ("From", "To", "Cc", "Subject", "Message-ID", "References"))
    return _api(acct, f"threads/{hits[0]['id']}?format=metadata&{hdrs}")


def prepare(msg, since=0, force=False):
    """-> {ok, id, acct, to, cc, subj, thread, held: [{from, when, snippet}], error}."""
    acct = (msg.get("acct") or "").strip().lower()
    if acct not in MAILBOXES:
        return {"ok": False, "error": f"unknown mailbox {acct or '(none)'}: send it from Gmail"}
    to = _emails(msg.get("to"))
    th = _thread(acct, msg.get("subj"), to)
    cc, refs, reply_to, held = [], "", "", []
    if th:
        msgs = th.get("messages", [])
        last = msgs[-1]
        others = [m for m in msgs if acct not in _emails(_hdr(m, "From"))]
        if not to and others:
            to = _emails(_hdr(others[-1], "From"))
        everyone = _emails(_hdr(last, "From")) + _emails(_hdr(last, "To")) + _emails(_hdr(last, "Cc"))
        cc = [a for a in dict.fromkeys(everyone) if a != acct and a not in to]
        reply_to = _hdr(last, "Message-ID")
        refs = (_hdr(last, "References") + " " + reply_to).strip()
        held = [{"from": parseaddr(_hdr(m, "From"))[0] or _hdr(m, "From"), "snippet": m.get("snippet", ""),
                 "when": time.strftime("%b %-d %H:%M", time.localtime(int(m["internalDate"]) / 1000))}
                for m in others if int(m.get("internalDate", 0)) / 1000 > since]
    if not to:
        return {"ok": False, "error": f"no email address for '{msg.get('to')}' and no thread found: send it from Gmail"}
    if held and not force:
        return {"ok": False, "held": held, "to": to, "cc": cc}
    subj = msg.get("subj") or ""
    if th and not re.match(r"^\s*re\s*:", subj, re.I):
        subj = "Re: " + _base_subject(_hdr(th["messages"][0], "Subject") or subj)
    e = EmailMessage()
    e["From"], e["To"], e["Subject"] = acct, ", ".join(to), subj
    if cc:
        e["Cc"] = ", ".join(cc)
    if reply_to:
        e["In-Reply-To"], e["References"] = reply_to, refs
    e.set_content(msg.get("body") or "")
    pid = secrets.token_hex(6)
    _pending[pid] = (acct, {"raw": base64.urlsafe_b64encode(e.as_bytes()).decode(),
                            **({"threadId": th["id"]} if th else {})}, time.time())
    return {"ok": True, "id": pid, "acct": acct, "to": to, "cc": cc, "subj": subj, "thread": bool(th)}


def commit(pid):
    p = _pending.pop(pid, None)
    if not p or time.time() - p[2] > 600:
        return {"ok": False, "error": "send expired: click Send again"}
    acct, body, _ = p
    if os.environ.get("PT_MAIL_DRY"):  # tests: everything but the send itself
        return {"ok": True, "gmail_id": "dry-run", "thread_id": body.get("threadId"), "acct": acct, "dry": True}
    r = _api(acct, "messages/send", body)
    return {"ok": True, "gmail_id": r.get("id"), "thread_id": r.get("threadId"), "acct": acct}
