"""Shared by build_panel.py, update_panel.py and panel_server.py.

normalise: the pre-run and the session write rows in slightly different shapes; the template
needs one. Skipping this once let a chain row break the page's live updates.

Run state: updates.json is both the live-update feed the page polls and the record of the current
run ({"run": id, "streams": expected, "sdone": finished, ...}). Every read-modify-write of it goes
through locked(), an fcntl lock on .lock next to it, and every write is an atomic replace, so
several background agents can push findings at once. A run is current while it was started today
(in the local time zone, TZ below): GET / never resets it, so a reload keeps every live update, and the next
day's first GET / starts a fresh one. A second session on the same day starts its own run with
build_panel.py --new-run, which is what keeps it from seeing the first run's answers.txt.

Plan day: the day a run plans. A run started at or after 18:00
local time plans tomorrow, else today; build_panel.py --plan-day overrides it. Stored in
updates.json as "plan_day" (YYYY-MM-DD). An evening run stays current through its plan day, so a
GET / after midnight keeps it. PLAN_TODAY_CACHE overrides the cache folder (tests, never the live run).
"""
import contextlib, fcntl, json, os, re, secrets, time
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

OUT = Path(os.path.expanduser(os.environ.get("PLAN_TODAY_CACHE") or "~/.cache/plan-today/panel"))
UPD = OUT / "updates.json"
TZ = ZoneInfo("America/Los_Angeles")
DEFAULT_STREAMS = ["delta", "q4"]
EVENING_HOUR = 18  # a run starting at or after this hour plans tomorrow


def compute_plan_day(override=None, now=None):
    """YYYY-MM-DD of the day a new run plans. override: today | tomorrow | YYYY-MM-DD | None (auto)."""
    now = now or datetime.now(TZ)
    if override in (None, "", "auto"):
        return (now.date() + timedelta(days=1 if now.hour >= EVENING_HOUR else 0)).isoformat()
    if override == "today":
        return now.date().isoformat()
    if override == "tomorrow":
        return (now.date() + timedelta(days=1)).isoformat()
    return date.fromisoformat(override).isoformat()  # ValueError on anything else


def plan_day_of(u):
    """The run's plan day as a date; older runs without one plan today."""
    try:
        return date.fromisoformat(u.get("plan_day") or "")
    except ValueError:
        return datetime.now(TZ).date()


def day_label(d):
    """'Thu Oct 8'."""
    return d.strftime("%a %b ") + str(d.day)


def _act(a):
    """One `ch` action in the template's shape {t, k, msg: {via, acct, to, subj, body}} (a q4
    row can arrive as {a, msg: {text, via: "WhatsApp"}}; unnormalised, m.body.split crashes every later update)."""
    if isinstance(a, str):
        return {"t": a, "k": "do"}
    a = dict(a)
    a["t"] = a.get("t") or a.pop("a", "") or a.get("title", "")
    m = a.get("msg")
    if isinstance(m, dict):
        m = dict(m)
        m["body"] = m.get("body") or m.pop("text", "") or ""
        m["via"] = (m.get("via") or "").lower() or ("whatsapp" if not m.get("acct") else "mail")
        a["msg"] = m
        a["k"] = a.get("k") or "draft"
    a["k"] = a.get("k") or "do"
    return a


def normalise(r):
    """One row shape for the template (a `ch` object, a numeric `e` or a string
    `q` from an agent threw inside the page and stopped every later update)."""
    if isinstance(r.get("ch"), (dict, str)):
        r["ch"] = [r["ch"]]
    if isinstance(r.get("ch"), list):
        r["ch"] = [_act(a) for a in r["ch"] if a]
    for k in ("e", "ne"):
        if isinstance(r.get(k), (int, float)) and not isinstance(r.get(k), bool):
            r[k] = f"{int(r[k])}m"
    if r.get("ctx") is not None and not isinstance(r.get("ctx"), list):
        r["ctx"] = [r["ctx"]]
    for c in r.get("ctx") or []:
        if isinstance(c, dict) and isinstance(c.get("q"), str):
            c["q"] = [c["q"]]
    for k in ("n", "s", "nx", "m", "wf"):
        if r.get(k) is not None and not isinstance(r.get(k), str):
            r[k] = str(r[k])
    c = r.get("chain")
    if isinstance(c, list):
        r["steps"], r["chain"] = c, r.get("n", "chain")
    if r.get("chain") and not r.get("steps"):
        r.pop("chain")
    for s in r.get("steps", []):
        if len(s) > 1 and not s[1]:
            s[1] = "?"
    return r


# ---------------------------------------------------------------- estimates
# Two per row: `e` the whole task (frontmatter `timeEstimate`, minutes) and `ne` the open Next step
# alone, stored inline at the end of the Next line as "(N min)" (inline, so the
# estimate moves with the step and cannot go stale when the Next is ticked or rewritten by hand).
STEP_EST = re.compile(r"\s*\((\d+(?:\.\d+)?)\s*(min|h)\)\s*$")
QUICK_MAX = 5  # minutes: a Next step at or under this is a two-minute item (one limit, 5 min; scheduling-rules rule 11)

# ---------------------------------------------------------------- R7
# A row whose only decision is reply, RSVP or skip goes straight to the two-minute page: it sits in
# the check-in panel's closed QK section (still answerable, Submit carries its guess), and quick.py
# takes it. Replies that touch the calendar (a meeting time, a dinner) do not pass. Spec: reference/panel.md
# § Which rows appear.
QK = "Straight to the two-minute page"
R7_MAX = QUICK_MAX  # the same limit for the check-in's two-minute section and the page
CAL = re.compile(r"\bcalendar\b|\bcal\b|\bclash|\bcollid|\bconflict|\boverlap|\breschedul|\bmove (?:it|the|to)\b"
                 r"|\b(?:mon|tue|wed|thu|fri|sat|sun)\w* (?:at )?\d{1,2}(?::\d\d)?\s*(?:am|pm)?\b|\b\d{1,2}:\d\d\b", re.I)


def to_quick(r):
    """R7: the next step is a message or a click of 5 min or less, guessed (or answered) today or
    soon, and it creates or moves nothing in the calendar: no `cal: 1` from the writer, and no
    calendar word or clock time in the step (the title only when there is no step). Waiting rows, chains and meditation rows
    always stay in the panel."""
    if r.get("w") or r.get("gw") or r.get("wv") or r.get("chain") or r.get("steps") or r.get("cal"):
        return False
    if (r.get("v") or r.get("g")) not in ("today", "tmrw", "soon"):
        return False
    if "meditation" in (r.get("m") or "").lower():
        return False
    ne = minutes(r.get("ne"))
    if ne is None:
        ne = split_step(r.get("nx"))[1]
    quick_row = "quick" in (r.get("bk"), r.get("bkv"))  # a "quick, no task" row has no estimate
    if not quick_row and (ne is None or ne > R7_MAX):
        return False
    # the step only, not the title (e.g. "Put the dinner in the calendar" whose step is
    # "ask a friend for the address"); a step-less row falls back to its title
    return not CAL.search(str(r.get("nx") or r.get("n") or ""))


def split_step(nx):
    """'email <PERSON> (2 min)' -> ('email <PERSON>', 2). Minutes is None without an inline estimate."""
    m = STEP_EST.search(nx or "")
    if not m:
        return (nx or "").strip(), None
    n = float(m.group(1)) * (60 if m.group(2) == "h" else 1)
    return nx[:m.start()].strip(), int(round(n))


def with_step_est(nx, mins):
    """The Next text with its inline estimate set (replacing an old one)."""
    text, _ = split_step(nx)
    if not mins:
        return text
    return f"{text} ({mins / 60:g} h)" if mins >= 120 and mins % 30 == 0 else f"{text} ({mins} min)"


def minutes(e):
    """'15m' / '2h' / '1.5 h' / '90' / 90 -> minutes (int), else None."""
    if e is None or e == "":
        return None
    if isinstance(e, (int, float)):
        return int(e) or None
    m = re.match(r"^\s*(\d+(?:\.\d+)?)\s*(h|hr|hrs|hours?|m|min|mins|minutes?)?\s*$", str(e), re.I)
    if not m:
        return None
    n = float(m.group(1)) * (60 if (m.group(2) or "m").lower().startswith("h") else 1)
    return int(round(n)) or None


def fmt_e(mins):
    """minutes -> the panel's '15m' / '2h' form."""
    return f"{mins}m" if mins < 60 else f"{mins / 60:g}h"


@contextlib.contextmanager
def locked():
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / ".lock", "a") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def write_atomic(path, text):
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{secrets.token_hex(3)}.tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def read_updates():
    try:
        return json.loads(UPD.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def write_updates(u):
    u["touched"] = time.time()
    write_atomic(UPD, json.dumps(u, ensure_ascii=False))


def run_is_current(u):
    if not u.get("run"):
        return False
    started = datetime.fromtimestamp(u.get("started", 0), TZ).date()
    today = datetime.now(TZ).date()
    return started == today or (u.get("plan_day") == today.isoformat() and (today - started).days == 1)


def since_of(prerun_text):
    """HH:MM of the pre-run's generated: line, the time the delta pass checks from."""
    g = re.search(r"^generated:\s*\S*T(\d\d:\d\d)", prerun_text, re.M)
    return g.group(1) if g else "the pre-run"


def new_run(since, streams=None, journal=None, extra=None, plan_day=None):
    """Reset the feed, delete a stale answers.txt and write a new run id. Call inside locked()."""
    now = time.time()
    rid = datetime.fromtimestamp(now, TZ).strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(2)
    u = {"run": rid, "started": now, "plan_day": plan_day or compute_plan_day(), "streams": list(streams or DEFAULT_STREAMS), "sdone": [],
         "journal": journal, "extra": extra, "seq": 0, "done": False, "since": since,
         "new": [], "changes": [],
         "status": f"Checking mail and WhatsApp since {since}, matching your meditation items…"}
    (OUT / "answers.txt").unlink(missing_ok=True)
    write_updates(u)
    return u
