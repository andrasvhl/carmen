"""Write the check-in panel's answers into the task notes, by fixed rules (owner decision, 2026-10-08).

Usage:
  python3 apply_answers.py --run <run id> [--dry-run]
      Reads ~/.cache/plan-today/panel/answers-<run id>.json (written by Submit beside the .txt)
      and the plan day from updates.json. Prints one line per write, then a FOR CLAUDE list:
      everything that needs judgement (notes that are instructions, approved Claude actions,
      soon/later dates for the day-plan table, waiting lines with no who/what).

What it writes, per row (the after-submit.md Scope table, as code):
  existing task  done/drop  → status: done / cancelled, completedDate, log "done" / "dropped"
                 today/tmrw → scheduled: that real day (SKILL.md § Definitions, Oct 13)
                 waiting    → both halves: `waiting:` plus the `- [ ] Waiting:` line (ticked when off)
                 note part "Next: …" → the open Next, verbatim; the old Next struck through
                 always     → one `## Log` line, except untouched Not today rows: nothing at all
  new row        own task   → `vt todos --add`, Next from the row, scheduled that day when today/tmrw
                 step in    → rule A (owner decision, 2026-10-08): answered today or tmrw, the step becomes
                              the parent's Next, the old Next becomes the first Then, and the parent is
                              scheduled that day; otherwise it goes in as a Then after the open steps
  every write    → the task schema check (`vt tasks`); problems are listed under FOR CLAUDE (C3, Oct 13)
                 quick/drop → nothing, but a drop goes to dropped.json (Oct 13: the same message
                              brought the row back; dropped.py, 14 days)
  estimates      open rows   → the accepted or corrected task estimate to `timeEstimate` (minutes),
                               the Next-step estimate inline at the end of the open Next, "(N min)"
                               (owner decision, 2026-10-12: "write it back"; inline so it moves with the step)
Never writes priority or quadrant.

  python3 apply_answers.py --quick --run <run id> [--dry-run]
      The two-minute page's answers (quick-answers-<run id>.json), per row:
        done      → the Next ticked, the first Then promoted to Next (none left and the task was a
                    two-minute task as a whole: closed), log line
        drop      → the step struck through as dropped, the first Then promoted, log line. The
                    step only: the task stays open (a note "drop the task" is for Claude to close it)
        not 2 min → the owner's estimate inline on the Next, scheduled <plan day>; FOR CLAUDE: place it
        sent      → the page already sent it (mailer.py, sent-<run id>.json): written as done
        sent or done with a message → FOR CLAUDE: a hold per time the final text proposes
        claude / send → FOR CLAUDE: do it / send the mail as shown (the page click is the approval),
                    then close the step with --close
  python3 apply_answers.py --close "<task title>" [--step "<what was done>"] [--dry-run]
      After Claude sent the mail or did the step: the same write as "done" above.
        untouched → FOR CLAUDE: one batched slot today; the Next stays open, so it comes back


Why: applied by hand, the answers took a dozen tool calls (most of a run),
and a "step in" for today landed as a Then at the bottom, under the step it had to come before.
"""
import json, os, re, subprocess, sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sweep  # parse_fm, _set_scheduled, _add_log, FM, TZ

import panel_rows as pr  # noqa: E402
import dropped  # noqa: E402  (Oct 13: dropped taskless rows are remembered for 14 days)

PANEL = pr.OUT  # honours PLAN_TODAY_CACHE (tests)
INBOX = Path(os.environ.get("PT_INBOX", sweep.INBOX))
VT = Path.home() / "automation/bin/vt"
NEXT = re.compile(r"^- \[ \] Next:\s*", re.M)


def set_key(text, key, value):
    """Set (or add) one scalar frontmatter key."""
    m = sweep.FM.match(text)
    nl = "\r\n" if "\r\n" in m.group(0) else "\n"
    lines = m.group(1).splitlines()
    for i, l in enumerate(lines):
        if re.match(rf"^{key}\s*:", l):
            lines[i] = f"{key}: {value}"
            break
    else:
        lines.append(f"{key}: {value}")
    start = "﻿" if text.startswith("﻿") else ""
    return start + "---" + nl + nl.join(lines) + nl + "---" + nl + text[m.end():]


def next_block(text):
    """(start, end) of the checkbox lines directly under `## Next action`, or None."""
    m = re.search(r"^## Next action[ \t]*\r?\n", text, re.M)
    if not m:
        return None
    i = m.end()
    j = i
    for line in text[i:].splitlines(keepends=True):
        if not line.startswith("- "):
            break
        j += len(line)
    return i, j


def insert_steps(text, line, first, demote=True):
    """Put a checkbox line into the Next action block: before the first open step (first=True;
    with demote, the old Next becomes a Then) or after the open steps. Creates the block under
    the frontmatter if missing."""
    nb = next_block(text)
    if not nb:
        end = sweep.FM.match(text).end()
        return text[:end] + "\n## Next action\n" + line + "\n" + text[end:]
    i, j = nb
    block = text[i:j]
    if first:
        if demote:
            block = NEXT.sub("- [ ] Then: ", block, count=1)
        m = re.search(r"^- \[ \] ", block, re.M)  # before the first open step
        k = m.start() if m else len(block)
        block = block[:k] + line + "\n" + block[k:]
    else:
        block = block + ("" if block.endswith("\n") or not block else "\n") + line + "\n"
    return text[:i] + block + text[j:]


def set_next(text, nx, stamp):
    """The owner's `Next:` becomes the open Next verbatim; the old one is struck through."""
    m = NEXT.search(text)
    if m:
        old_line = text[m.start():text.find("\n", m.start()) if "\n" in text[m.start():] else len(text)]
        old = old_line[m.end() - m.start():].strip()
        if old == nx:
            return text, False
        new = f"- [ ] Next: {nx}\n- ~~Next: {old}~~ (replaced by the owner, {stamp})"
        return text.replace(old_line, new, 1), True
    return insert_steps(text, f"- [ ] Next: {nx}", first=True), True


def set_next_est(text, mins):
    """Put the Next-step estimate inline on the open Next line ("(N min)"), replacing an old one."""
    m = re.search(r"^(- \[ \] Next:[ \t]*)(.*)$", text, re.M)
    if not m or not mins:
        return text, False
    new = pr.with_step_est(m.group(2), mins)
    if new == m.group(2).strip():
        return text, False
    return text[:m.start(2)] + new + text[m.end(2):], True


def write_estimates(text, r):
    """The row's task and Next-step estimates into the note; returns (text, log bits)."""
    bits = []
    fm = sweep.parse_fm(text) or {}
    e = pr.minutes(r.get("e"))
    if e and e != pr.minutes(fm.get("timeEstimate")):
        text = set_key(text, "timeEstimate", e)
        bits.append(f"estimate {pr.fmt_e(e)}" + (", guess accepted" if r.get("eg") and r.get("e") == r.get("e0") else ""))
    ne = pr.minutes(r.get("ne"))
    if ne:
        text, ch = set_next_est(text, ne)
        if ch:
            bits.append(f"next step {pr.fmt_e(ne)}")
    return text, bits


def promote_then(text):
    """After the open Next is closed: the first open Then becomes the Next. False if none is left."""
    m = re.search(r"^- \[ \] Then:[ \t]*", text, re.M)
    if not m:
        return text, False
    return text[:m.start()] + "- [ ] Next: " + text[m.end():], True


def set_waiting(text, on, wf):
    text = set_key(text, "waiting", "true" if on else "false")
    has_open = re.search(r"^- \[ \] Waiting:", text, re.M)
    if on and not has_open:
        return insert_steps(text, f"- [ ] Waiting: {wf or 'who, on what?'}", first=True, demote=False), not wf
    if not on:
        text = re.sub(r"^- \[ \] Waiting:", "- [x] Waiting:", text, flags=re.M)
    return text, False


def split_note(note):
    """Note parts: `Next: …` parts are next steps, everything else is an instruction."""
    nexts, rest = [], []
    for part in [p.strip() for p in re.split(r"\s+·\s+", note or "") if p.strip()]:
        (nexts if re.match(r"^next\s*:", part, re.I) else rest).append(part)
    return [re.sub(r"^next\s*:\s*", "", n, flags=re.I) for n in nexts], rest


def close_step(text, how, stamp):
    """Close the open Next (done: ticked; drop: struck through) and promote the first Then.
    Returns (text, promoted)."""
    m = re.search(r"^- \[ \] Next:[ \t]*(.*)$", text, re.M)
    if not m:
        return text, False
    line = f"- [x] Next: {m.group(1)}" if how == "done" else f"- ~~Next: {m.group(1)}~~ (dropped, {stamp})"
    text = text[:m.start()] + line + text[m.end():]
    return promote_then(text)


WRITTEN = []  # every task note this run wrote, for the schema check (C3, the owner Oct 13)


def schema_check(todo, dry=False):
    """The vault rule is Edit/Write only, because the schema hook fires on those alone. Scripts
    write too, so they run the same check (`vt tasks <file>`) on what they wrote and hand any
    problem to the session, which fixes it with Edit (owner decision, Oct 13: option C3)."""
    paths = sorted({str(p) for p in WRITTEN})
    if dry or not paths:
        return
    out = subprocess.run([str(VT), "tasks", *paths], capture_output=True, text=True).stdout
    name = None
    for line in out.splitlines():
        if line and not line.startswith(" "):
            name = line.strip()
        elif line.strip().startswith(("✗", "?")) and name:
            todo.append(f"schema · {name}: {line.strip()[1:].strip()} (fix with Edit)")


def finish_step(p, v, step, stamp, now, todo):
    """done / drop on one task note: (new text, log line). Shared by --quick and --close."""
    text = p.read_text(encoding="utf-8")
    task = p.stem
    text, promoted = close_step(text, v, stamp)
    log = f"- {stamp} · {'done' if v == 'done' else 'dropped'} on the two-minute page · {step}"
    if not promoted:
        whole = pr.minutes((sweep.parse_fm(text) or {}).get("timeEstimate"))
        if v == "done" and (whole is None or whole <= pr.QUICK_MAX):
            text = set_key(set_key(text, "status", "done"), "completedDate", now.date().isoformat())
            log += " · task closed"
        else:
            text = insert_steps(text, "- [ ] Next: Open the task and name the next step", first=True, demote=False)
            todo.append(f"{task}: no step left after '{step}': name the next one")
    return sweep._add_log(next_first(text), log)


def next_first(text):
    """The open Next line goes to the top of the Next action block (SYSTEM.md § Capture note
    schema: the open Next is the block's first line, above ticked steps)."""
    nb = next_block(text)
    if not nb:
        return text
    i, j = nb
    lines = text[i:j].splitlines(keepends=True)
    k = next((n for n, l in enumerate(lines) if l.startswith("- [ ] Next:")), None)
    if not k:
        return text
    line = lines.pop(k)
    return text[:i] + line + "".join(lines) + text[j:]


def main_close(argv, dry):
    title = argv[argv.index("--close") + 1]
    step = argv[argv.index("--step") + 1] if "--step" in argv else "sent / done by Claude"
    p = INBOX / f"{title}.md"
    if not p.exists():
        print(f"task note not found: {title}")
        return 1
    now = datetime.now(sweep.TZ)
    todo = []
    text = finish_step(p, "done", step, now.strftime("%b ") + str(now.day), now, todo)
    print(("would write  " if dry else "ok  ") + f"{title} → done: {step}")
    if not dry:
        p.write_text(text, encoding="utf-8")
        WRITTEN.append(p)
    schema_check(todo, dry)
    for t in todo:
        print("FOR CLAUDE: " + t)
    return 0


def main_quick(run, dry):
    """The two-minute page's answers (quick.py), by the rules in the docstring."""
    data = json.loads((PANEL / f"quick-answers-{run}.json").read_text(encoding="utf-8"))
    upd = json.loads((PANEL / "updates.json").read_text(encoding="utf-8"))
    plan = upd.get("plan_day") if upd.get("run") == run else None
    plan = plan or datetime.now(sweep.TZ).date().isoformat()
    now = datetime.now(sweep.TZ)
    stamp = now.strftime("%b ") + str(now.day)
    todo, batch, writes, gone = [], [], 0, []
    for r in data["rows"]:
        v, step, task = r.get("v") or "", r.get("n", ""), r.get("task") or r.get("n", "")
        if r.get("note"):
            todo.append(f"{step} ({v or 'untouched'}): note · {r['note']}")
        if v == "send":
            m = r.get("msg") or {}
            todo.append(f"{step}: SEND APPROVED (as shown, re-read the thread first; then --close \"{task}\") · mail {m.get('acct', '')} "
                        f"to {m.get('to', '')} | subject: {m.get('subj', '')} | text: {m.get('body', '')}")
        elif v == "claude":
            todo.append(f"{step}: Claude does it (then --close \"{task}\") · " + ("; ".join(a.get("t", "") for a in r.get("acts") or [] if not a.get("msg")) or step))
        for a in r.get("cdo") or []:
            todo.append(f"{step}: Claude does it (switched on) · {a}")
        if v in ("sent", "done") and r.get("msg") and r["msg"].get("body") and r.get("hold", True):
            m = r["msg"]
            todo.append(f"{step}: HOLDS · any day or time this {m.get('via')} to {m.get('to', '')} proposes gets a hold "
                        f"on the main calendar, 'Hold: {task} (proposed)' · text: {m['body']}")
        if not v:
            batch.append(step)
            if r.get("msg") and r.get("edited"):
                todo.append(f"{step}: untouched but edited · save as a draft only · {r['msg'].get('body', '')}")
        p = INBOX / f"{r.get('lk') or task}.md"
        if not p.exists():  # Oct 13: rows from new tasks carry no lk, only task; every write was skipped
            if v == "not 2 min":
                todo.append(f"{step}: not 2 min ({r.get('ev') or 'no estimate'}), no task behind it: place it in today's plan")
            if v == "drop":  # Oct 13: remembered, so the same message does not bring it back
                gone.append(r)
            continue
        text = p.read_text(encoding="utf-8")
        if v in ("done", "drop", "sent"):  # sent: the page already sent the mail (mailer.py)
            how = "drop" if v == "drop" else "done"
            save_to = (p, finish_step(p, how, step + (" (mail sent from the page)" if v == "sent" else ""), stamp, now, todo),
                       f"{task} → {v}: {step}")
        elif v == "not 2 min":
            mins = pr.minutes(r.get("ev"))
            if mins:
                text, _ = set_next_est(text, mins)
            fm = sweep.parse_fm(text) or {}
            if (sweep._date(fm.get("scheduled")) or "9999") > plan:
                text = sweep._set_scheduled(text, plan)
            todo.append(f"{task}: not 2 min ({pr.fmt_e(mins) if mins else 'no estimate'}): place '{step}' in today's plan")
            save_to = (p, sweep._add_log(text, f"- {stamp} · not a two-minute step"
                                        + (f", {pr.fmt_e(mins)}" if mins else "") + " · two-minute page"),
                       f"{task} → not 2 min" + (f" ({pr.fmt_e(mins)})" if mins else ""))
        else:
            continue
        writes += 1
        print(("would write  " if dry else "ok  ") + save_to[2])
        if not dry:
            save_to[0].write_text(save_to[1], encoding="utf-8")
            WRITTEN.append(save_to[0])
    print(f"\n{writes} notes {'to write' if dry else 'written'}.")
    remember(gone, run, PANEL / f"quick-answers-{run}.json", "two-minute page", dry)
    schema_check(todo, dry)
    if batch:
        todo.append(f"untouched, one batched slot on the plan day ({plan}; they come back with the next run): " + " · ".join(batch))
    if todo:
        print("\nFOR CLAUDE:")
        for t in todo:
            print("- " + t)
    return 0


def main(argv):
    if "--close" in argv:
        return main_close(argv, "--dry-run" in argv)
    run = argv[argv.index("--run") + 1]
    if "--quick" in argv:
        return main_quick(run, "--dry-run" in argv)
    dry = "--dry-run" in argv
    data = json.loads((PANEL / f"answers-{run}.json").read_text(encoding="utf-8"))
    upd = json.loads((PANEL / "updates.json").read_text(encoding="utf-8"))
    if upd.get("run") != run:
        print(f"WARNING  answers are for run {run}, the current run is {upd.get('run')}")
    plan = data.get("plan_day") or upd.get("plan_day")
    now = datetime.now(sweep.TZ)
    stamp = now.strftime("%b ") + str(now.day)
    todo, writes, gone = [], 0, []

    def save(p, text, msg):
        nonlocal writes
        writes += 1
        print(("would write  " if dry else "ok  ") + msg)
        if not dry:
            p.write_text(text, encoding="utf-8")
            WRITTEN.append(p)

    for r in data["rows"]:
        v, title = r.get("v"), r.get("n", "")
        if r.get("gn") == "Not today" and not r.get("c") and not r.get("note"):
            continue  # 1 (owner decision, Oct 13): seen and left alone; the answers file is the record, no log, no date question
        # today / tmrw are real dates, whatever day the run plans (owner decision, Oct 13: "today" on an
        # evening run read as Wednesday)
        day = {"today": now.date().isoformat(), "tmrw": (now.date() + timedelta(days=1)).isoformat()}.get(v)
        nexts, instr = split_note(r.get("note"))
        if instr:
            todo.append(f"{title}: note to apply · {' · '.join(instr)}")
        for a in r.get("acts") or []:
            todo.append(f"{title}: approved action · {a}")

        if r.get("new"):  # a row with no task behind it
            bk = r.get("bkv")
            if v == "drop":
                gone.append(r)  # Oct 13: remembered for 14 days (dropped.py)
            if v in ("done", "drop") or bk == "quick":
                continue
            if bk == "own" and (INBOX / f"{title}.md").exists():
                todo.append(f"{title}: own task already exists, not created again")
                continue
            if bk == "own":
                nx = (nexts[0] if nexts else r.get("nx")) or "Open the task and name the next step"
                cmd = [str(VT), "todos", "--add", title, "--next", nx]
                if day:
                    cmd += ["--scheduled", day]
                print(("would run  " if dry else "ok  ") + f"new task  {title}")
                if not dry:
                    subprocess.run(cmd, check=True, capture_output=True)
                    p = INBOX / f"{title}.md"
                    if p.exists():
                        WRITTEN.append(p)
                        t2, eb = write_estimates(p.read_text(encoding="utf-8"), r)
                        p.write_text(sweep._add_log(t2, f"- {stamp} · created from the check-in panel · "
                                                    + " · ".join([v or "no answer"] + eb)), encoding="utf-8")
                if v in ("soon", "later"):
                    todo.append(f"{title}: new task, {v}: date for the day-plan table")
                continue
            if bk == "step":
                target = r.get("stv")
                if target == "__other" or not target:
                    todo.append(f"{title}: step in other · {r.get('stx') or 'no instruction'}")
                    continue
                p = INBOX / f"{target}.md"
                if not p.exists():
                    todo.append(f"{title}: step target not found · {target}")
                    continue
                text = p.read_text(encoding="utf-8")
                step = nexts[0] if nexts else title
                step = pr.with_step_est(step, pr.minutes(r.get("ne")) or pr.minutes(r.get("e")))
                if day:  # rule A
                    text = insert_steps(text, f"- [ ] Next: {step}", first=True)
                    fm = sweep.parse_fm(text) or {}
                    if (sweep._date(fm.get("scheduled")) or "9999") > day:
                        text = sweep._set_scheduled(text, day)
                    log = f"- {stamp} · step added as the Next, {v} · {step} · check-in panel"
                else:
                    text = insert_steps(text, f"- [ ] Then: {step}", first=False)
                    log = f"- {stamp} · step added, {v} · {step} · check-in panel"
                save(p, sweep._add_log(text, log), f"step in  {target} ← {step}" + ("  (as Next)" if day else ""))
                continue
            todo.append(f"{title}: new row with no 'becomes' ({v})")
            continue

        p = INBOX / f"{r.get('lk') or title}.md"
        if not p.exists():
            todo.append(f"{title}: task note not found")
            if v == "drop":
                gone.append(r)
            continue
        if not v:  # no answer and no guess (Oct 13 review: this crashed the loop halfway)
            todo.append(f"{title}: no answer and no guess, left as it is")
            continue
        text = p.read_text(encoding="utf-8")
        bits = [("dropped" if v == "drop" else v) + ("" if v != r.get("g") else ", guess accepted")]
        if v in ("done", "drop"):
            # A drop is `cancelled`, so it never counts as done work (owner decision, 2026-10-12)
            closed_as = "cancelled" if v == "drop" else "done"
            text = set_key(set_key(text, "status", closed_as), "completedDate", now.date().isoformat())
            text = re.sub(r"^- \[ \] Next:", "- [x] Next:", text, count=1, flags=re.M)
        elif day:
            text = sweep._set_scheduled(text, day)
        else:
            todo.append(f"{title}: {v}: date for the day-plan table")
        dq = r.get("dq") if isinstance(r.get("dq"), dict) else None
        if dq and r.get("dqv") == "accept" and v not in ("done", "drop"):
            # the due date follows the remaining work (owner decision, Oct 13): written only by the owner's answer
            if dq.get("to"):
                text = set_key(text, "due", dq["to"])
            else:
                text = re.sub(r"^due:.*\n", "", text, count=1, flags=re.M)
            bits.append(f"due {dq.get('from') or ''} → {dq.get('to') or 'cleared'}".replace("due  →", "due →"))
        elif dq and r.get("dqv") == "keep":
            bits.append(f"due {dq.get('from') or ''} kept (still owed)")
        if r.get("wv") != r.get("w0"):
            text, ask = set_waiting(text, bool(r.get("wv")), r.get("wf"))
            bits.append("waiting" if r.get("wv") else "not waiting")
            if ask:
                todo.append(f"{title}: waiting set, write who and on what in the Waiting line")
        for nx in nexts:
            text, changed = set_next(text, nx, stamp)
            if changed:
                text = sweep._add_log(text, f"- {stamp} · Next set by the owner · {nx}")
        if v not in ("done", "drop"):
            text, eb = write_estimates(text, r)
            bits += eb
        text = sweep._add_log(text, f"- {stamp} · {' · '.join(bits)} · check-in panel")
        save(p, text, f"{title} → {bits[0]}")

    print(f"\n{writes} notes {'to write' if dry else 'written'}.")
    remember(gone, run, PANEL / f"answers-{run}.json", "check-in", dry)
    schema_check(todo, dry)
    if todo:
        print("\nFOR CLAUDE:")
        for t in todo:
            print("- " + t)
    return 0


def remember(rows, run, src, via, dry):
    """Dropped rows with no task note → dropped.json (the vault, both machines), dated by the
    Submit (the answers file's mtime), so a later apply does not move the drop date."""
    if not rows:
        return
    try:
        when = datetime.fromtimestamp(src.stat().st_mtime, sweep.TZ)
    except OSError:
        when = None
    new = dropped.record(rows, run, when, via, dry=dry)
    for e in new:
        print(("would remember  " if dry else "remembered  ") + f"{e['title']} (dropped, 14 days)")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
