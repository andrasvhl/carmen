"""Dropped-row memory (owner decision, 2026-10-13: "only for like 2 weeks").

A row with no task note behind it (a new row from mail or WhatsApp, `nw: 1` / `new: true`) that he
answers drop left no trace, so the next pre-run or the delta agent proposed it again from the same
message: "Move coffee with Laszlo to next week" (run 20261009-084801-5fe4) came back on Oct 13 as
"Set a coffee with Laszlo". Now:
  record()  apply_answers.py (check-in Submit and --quick) appends every dropped taskless row to
            dropped.json, beside this file inside the vault so vault-host's 08:00 pre-run and the
            agents see it too. Entries older than WINDOW days are pruned on every write and
            ignored on read.
  check()   build_panel.py and update_panel.py hide a new taskless row that strongly matches an
            entry, unless the person wrote after the drop: then the row shows with
            lc "you dropped this on Oct 13; new message since". Every decision, near misses
            included, goes to the caller's log (match.json "dropped", suppressed.json).
Strong match (conservative: a wrong hide loses a real request, a miss costs one click): at least
one shared name token (a ctx `who` or a draft's `to` only, Oct 13: never title words) AND
at least one shared topic token that is not a name and not a generic verb or channel word.
"Laszlo" + "coffee" matches; "Laszlo" alone, or "coffee" alone, does not. Nicknames ("Laci") do
not match "Laszlo": a miss, by design. PT_DROPPED=<file> points it elsewhere (tests).
Spec: reference/panel.md § Which rows appear.
"""
import json, os, re
from datetime import datetime, timedelta
from pathlib import Path

import panel_rows as pr

HERE = Path(__file__).resolve().parent
PATH = Path(os.environ.get("PT_DROPPED") or HERE / "dropped.json")
WINDOW = 14  # days (owner decision, Oct 13)
# Words that say what to do or where, never what it is about: a shared "send" or "WhatsApp" is not
# the same topic. A bigger list means fewer hides, which is the safe side.
GENERIC = set("""
reply answer send sent set move moved put write text tell ask add check pick message whatsapp mail
email gmail calendar cal time times two three slot slots call new plan planning follow update week
weekend day days invite invitation confirm accept decline open find book schedule meet meeting talk
make give share post read back team group club chat thread offer rsvp note link click yes quick
early late later soon first last morning evening afternoon night delete draft fix sort see take date dates
monday tuesday wednesday thursday friday saturday sunday mon tue wed thu fri sat sun
""".split())
NOT_NAME = GENERIC | {"gsb", "stanford", "you", "your", "zoom", "imessage", "slack"}
MONTHS = {m: i for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split(), 1)}
QLINE = re.compile(r"^\s*([^,\"]{1,60}?),\s*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2})"
                   r"(?:,?\s+(\d{1,2}):(\d\d))?", re.I)
MDATE = re.compile(r"\b(?:(today|yesterday)|(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2}))\b", re.I)


def _bp():
    import build_panel  # lazy: build_panel imports this module too
    return build_panel


def _msgs(r):
    out = [r.get("msg")] if isinstance(r.get("msg"), dict) else []
    for k in ("qa", "ch", "acts"):
        out += [a["msg"] for a in r.get(k) or [] if isinstance(a, dict) and isinstance(a.get("msg"), dict)]
    return out


def keys(r):
    """(names, topic) token sets of a row. Title and step only for the topic: ctx stories mention
    everything and would make every row look alike."""
    bp = _bp()
    title = r.get("task") or r.get("n") or ""
    text = title + ". " + (r.get("nx") or (r.get("n") if r.get("task") else "") or "")
    toks = bp._tokens(text)
    # Names come only from who wrote (ctx `who`) and who a draft goes to (msg `to`), never from
    # capitalised words in the title (owner decision, Oct 13: "Future Authoring" was read as two people).
    # A row with neither has no names and is never hidden: conservative on purpose.
    names = set()
    for c in r.get("ctx") or []:
        who = re.sub(r"\(.*?\)", " ", c.get("who", "") if isinstance(c, dict) else "")
        if not re.match(r"\s*(you|your)\b", who, re.I):
            names |= {t for t, _, _ in bp._tokens(who)}
    for m in _msgs(r):
        to = m.get("to") or ""
        if "@" not in to:
            names |= {t for t, _, _ in bp._tokens(to)}
    names -= NOT_NAME
    topic = {t for t, _, _ in toks} - names - NOT_NAME
    return names, topic


def _shared(a, b):
    bp = _bp()
    return sorted({h for t in a if (h := bp._hit(t, set(b)))})


def _dt(mon, day, hh, mm, ref):
    try:
        d = datetime(ref.year, MONTHS[mon[:3].lower()], int(day), int(hh or 0), int(mm or 0), tzinfo=pr.TZ)
    except ValueError:
        return None
    return d.replace(year=d.year - 1) if d > ref + timedelta(days=1) else d


def last_incoming(r, ref):
    """(datetime, has_time) of the newest message someone else wrote, from the row's ctx quotes
    ("Laszlo, Oct 8 19:27: ...", not "You, ...") and its `m` line ("New task · WhatsApp Oct 8",
    "... yesterday", relative to ref). None if the row carries no date."""
    best = None
    for c in r.get("ctx") or []:
        for q in (c.get("q") or []) if isinstance(c, dict) else []:
            m = QLINE.match(q) if isinstance(q, str) else None
            if not m or re.match(r"\s*(you|ich|me)\s*$", m.group(1), re.I):
                continue
            d = _dt(m.group(2), m.group(3), m.group(4), m.group(5), ref)
            if d and (best is None or d > best[0]):
                best = (d, m.group(4) is not None)
    line = r.get("m") or ""
    if "meditation" not in line.lower():
        for m in MDATE.finditer(line):
            if m.group(1):
                d = (ref - timedelta(days=1 if m.group(1).lower() == "yesterday" else 0)).replace(hour=0, minute=0, second=0, microsecond=0)
            else:
                d = _dt(m.group(2), m.group(3), None, None, ref)
            if d and (best is None or d > best[0]):
                best = (d, False)
    return best


def _ref_of(run, fallback):
    """The run's start as a datetime (run ids are 20261013-161103-xxxx), for "today" in `m`."""
    try:
        return datetime.strptime(run[:15], "%Y%m%d-%H%M%S").replace(tzinfo=pr.TZ)
    except (TypeError, ValueError):
        return fallback


def load(now=None, path=None):
    """Entries still inside the window."""
    now = now or datetime.now(pr.TZ)
    try:
        data = json.loads(Path(path or PATH).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    cut = (now - timedelta(days=WINDOW)).date().isoformat()
    return [e for e in data.get("dropped", []) if (e.get("dropped") or "") >= cut]


def entry(r, run, when, via):
    names, topic = keys(r)
    li = last_incoming(r, _ref_of(run, when))
    return {"title": r.get("task") or r.get("n", ""), "lk": r.get("lk") or None,
            "step": r.get("nx") or (r.get("n") if r.get("task") else "") or "",
            "names": sorted(names), "topic": sorted(topic), "m": r.get("m") or "",
            "msg_date": li[0].isoformat(timespec="minutes") if li else "",
            "dropped": when.date().isoformat(), "dropped_at": when.isoformat(timespec="minutes"),
            "run": run, "via": via}


def record(rows, run, when=None, via="check-in", path=None, dry=False):
    """Append the dropped taskless rows; prune the window; one write. Returns the new entries."""
    when = when or datetime.now(pr.TZ)
    path = Path(path or PATH)
    old = load(when, path)
    have = {(e["title"], e["run"]) for e in old}
    new = [entry(r, run, when, via) for r in rows]
    new = [e for e in new if (e["title"], e["run"]) not in have]
    if not dry and (new or old != _raw(path)):
        pr.write_atomic(path, json.dumps({"window_days": WINDOW, "dropped": old + new},
                                         ensure_ascii=False, indent=1) + "\n")
    return new


def _raw(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8")).get("dropped", [])
    except (OSError, ValueError):
        return None


def eligible(r, has_task=None):
    """A row with no task note behind it that is not his own meditation item."""
    if not (r.get("nw") or r.get("new")) or "meditation" in (r.get("m") or "").lower() or r.get("q4"):
        return False
    return not (has_task and has_task(r))


def check(r, entries, now=None):
    """The decision for one row: None (no entry shares a name), or a log record with action
    "hide", "show" (new message since the drop) or "keep" (name only, a near miss)."""
    now = now or datetime.now(pr.TZ)
    names, topic = keys(r)
    best = None
    for e in entries:
        sn = _shared(names, e.get("names", []))
        if not sn:
            continue
        st = [t for t in _shared(topic, e.get("topic", [])) if t not in sn]
        rec = {"row": r.get("n", ""), "dropped": e["title"], "on": e["dropped"], "run": e.get("run"),
               "names": sn, "topic": st, "action": "keep" if not st else "hide"}
        if st:
            li = last_incoming(r, now)
            at = datetime.fromisoformat(e["dropped_at"]) if e.get("dropped_at") else None
            if li and at and (li[0] > at if li[1] else li[0].date() > at.date()):
                rec.update(action="show", newer=li[0].isoformat(timespec="minutes"))
        if best is None or (rec["action"] != "keep", len(st)) > (best["action"] != "keep", len(best["topic"])):
            best = rec
    return best


def apply(rows, entries, log, now=None, has_task=None):
    """Filter a row list: hidden rows go, shown ones get the lc line. Appends to log."""
    if not entries:
        return rows
    out = []
    for r in rows:
        rec = check(r, entries, now) if eligible(r, has_task) else None
        if rec:
            log.append(rec)
            if rec["action"] == "hide":
                continue
            if rec["action"] == "show":
                d = datetime.fromisoformat(rec["on"]) if len(rec["on"]) == 10 else None
                line = f"you dropped this on {d.strftime('%b ') + str(d.day) if d else rec['on']}; new message since"
                r["lc"] = line + (f" · {r['lc']}" if isinstance(r.get("lc"), str) and r["lc"] else "")
        out.append(r)
    return out
