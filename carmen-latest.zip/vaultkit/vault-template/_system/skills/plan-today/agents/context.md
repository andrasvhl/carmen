# plan-today agent: context

You run in the background while the user clicks the check-in panel. **Job:** read the day-plan
context fresh and return a compact summary, so the day plan (`reference/day-plan.md`) has it loaded at Submit and
costs no extra time. **No panel writes, no edits, no calendar writes.** Target: under 40 s.

Inputs (from the prompt): today's date and weekday. Timezone `<YOUR_TIMEZONE>`.
Vault: `$VAULT_PATH`.

## Read, in parallel

1. **The calendar, today and the next 5 days, every calendar** in the roster table of
   `_system/skills/schedule-work/SKILL.md` (Google Calendar connector: `list_calendars`, then
   `list_events` per calendar; load the tools with ToolSearch if they are deferred). Run
   `list_calendars` first: a calendar not in the roster is reported, never guessed about.
2. `Areas/North Star.md`
3. `_system/working-conditions.md`
4. `<YOUR_WEEK_STRUCTURE_NOTE>` (the user's note describing their standing weekly structure)

Read them fresh every run, never from a cache: the rules change.

## Return (under 25 lines, no preamble)

- **Today:** events in order, `HH:MM-HH:MM title (calendar, busy/free)`, then the **free slots**
  with their lengths and the total free hours. Standing blocks per schedule-work: standing structure sits on the Focus calendar and shows free but is used time (for example a morning routine and daily plan, meals, email batches, exercise); recurring focus blocks from the week-structure note hold only the work they name; big-rock blocks hold
  big-rock work only; recurring maintenance or solo days keep their blocks as the week-structure note sets them; deadline and event-RSVP
  calendars are markers or committed social time as the roster says.
- **Next 5 days:** one line each: hard commitments and free hours.
- **Hard rules that bind today**, from working-conditions and the week-structure note, each with its
  source note (e.g. hard stops, energy windows).
- **North Star:** the 2-3 lines that matter for today (priorities, the not-doing list).
- **Stale:** any of the three notes whose `revisit:` or `verified:` date has passed, one line each
  with the date.
- **New calendars** not in the roster, if any.
