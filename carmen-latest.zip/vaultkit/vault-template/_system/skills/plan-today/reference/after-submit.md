# plan-today reference: while the user clicks and after Submit

Part of the [[_system/skills/plan-today/SKILL|plan-today]] skill, split out of SKILL.md so the button reads only the fast lane. **Read when:** preloaded while the user clicks, with Week Structure (`context_read.sh plan`), so the Submit
writes start at once. Words like plan day, chase date and two-minute item mean what
[[_system/skills/plan-today/SKILL#Definitions|SKILL.md § Definitions]] says.

## While the user clicks: the background pass

Already running from the Fast lane, finished by the time the user submits:

- **Calendar against messages** (the `delta` agent): flag any calendar entry that mail or WhatsApp
  contradicts (a lunch moved by message but still blocked; an invite answered in chat but not in
  Calendar).
- **A calendar not in schedule-work's roster** (seen in calendar.txt) is a question for
  the user (what is it for, does it block), asked once, then added to the roster.
- **Meditation items** (the meditation agent): dedupe against open and done tasks (`Inbox/`, `Archive/Inbox/`)
  and earlier journal entries, enrich, name the next physical step. Research online only where a
  step needs outside facts (hours, prices, policies), and cite it.
- **After Submit, write** (this is recording the user's answers, not a judgement). **First run
  `python3 ~/.claude/skills/plan-today/apply_answers.py --run <run id>`**: it reads
  `answers-<run id>.json`, which Submit posts beside the text, and does every mechanical write below
  (done/drop, `scheduled` for the *today* and *tmrw* answers on their real days, both waiting
  halves, `Next:` notes verbatim, own tasks, step-in placement, the log lines). Its FOR CLAUDE list is what is left: notes that are instructions,
  approved Claude actions, soon/later dates for the day-plan table, waiting lines without who/what.
  Do only those by hand. Why: doing these writes by hand takes a dozen calls, most of the run, and
  misplaces steps. **The scripts check what they write**: `apply_answers.py` and `sweep.py --apply` run the task schema check (`vt tasks
  <file>`) on every note they write and list the violations (`apply_answers.py` under FOR CLAUDE,
  `sweep.py` under SCHEMA); fix those with Edit, the tool the schema hook watches. The rules it applies:
  - the panel answers, per the Scope table;
  - **"Becomes"** (without it, new rows stay panel-only because nothing asks).
    Submit lists every open row without a task as `title → own task / step in: <task> / quick, no
    task`. **Submit is the confirmation; write without asking again.** *own task*: create it with
    `vt todos --add`, one task per outcome, the row's next step as Next and the related bits as
    `## Steps` checkboxes. *step in*: add the step and a log line to that
    task. **Answered *today* or *tmrw*, the step becomes the parent's `Next:`, the old Next becomes
    the first Then, and the parent is scheduled that real day (the plan day for the plan day's
    answer: *today* on a morning run, *tmrw* on an evening run); otherwise it goes in as a Then
    after the open steps** (rule A: otherwise a step that has to come first lands as a Then, so the
    parent stays unscheduled while the step sits in that day's calendar). *other (…)*: follow the user's instruction. *quick, no task*: no note; it goes to the two-minute page, and if left there it is named in the plan day's
    batched slot. A row answered *drop* or *done* gets nothing. The journal's anxious and excited
    answers still go through `commit-to-action` at the end.
  - **one `## Log` line per row the user changed, or whose guess Submit applied outside Not today**; an
    untouched Not today row gets nothing: no log line, no date question, no two-minute page, no
    batched slot. The line goes at the bottom of the body, newest last:
    `- Oct 5 · not done, kept → Oct 7 · <PERSON> replied Oct 4 (WhatsApp), waiting on their date`.
    Date · answer · the key finding with its source. One line, so bulk reads stay cheap.
    **Read yesterday's line before guessing:** the next morning's guess starts from it.
  - research that changes what to do next goes into the task's `## Next action` block, not the log.
- **The plan-day sweep: no task stays scheduled on or before the plan day unless it is meant for
  it** (tasks answered *later*, and ones that never reached the panel, otherwise keep their old
  date and clutter the cockpit's today view; an evening run must check the plan day, not only
  today, and a hand-rolled grep misses tasks). Run
  `python3 ~/.claude/skills/plan-today/sweep.py --day <plan day>` after Submit: every open task
  with `scheduled` on or before the plan day, with due, waiting and build tag. **These tasks are
  already weighed in the day plan** (`reference/day-plan.md` § 4 ranks them with the plan day's
  answers, *today* on a morning run and *tmrw* on an evening run); the sweep writes the
  verdicts the plan agreed. Propose a date for
  each one that is not in the agreed plan: *soon* from the day plan's table
  (`reference/day-plan.md`), *later* the date the user confirms (default: next week's Tuesday), *waiting*
  its chase date, a blocked task no date at all (both SKILL.md § Definitions), a `build`
  task no date (Monday brief). That includes tasks that never made
  the panel. **Show the list in the plan message, before any calendar block is written**, and apply
  it only on the user's ok: `sweep.py --apply <json>` with `[{"title", "scheduled" (date or null), "log"}]`
  writes `scheduled` and one log line per task, never `due`, priority, quadrant or timeEstimate.
  **Nothing is moved silently.** **The check:** after applying, `sweep.py --day <plan day>` lists
  only the plan's tasks, apart from tasks whose `due` has passed, which say so in one line.
- **Work done directly in the session leaves a closed task note** (otherwise a fix made in one run
  has no task and the next run proposes it again). Any panel row with no task
  that Claude handled, or that the user did during the run ("Claude handles" vault actions, a quick fix,
  an automation change): create it with `vt todos --add`, set `status: done`, and add one log line
  naming what was done and where (commit, file). The builder and the meditation agent match closed tasks
  from the last 14 days. *Quick, no task* items that are only messages stay without a note.
- **Reading a row's note: next step versus instruction.** A note can hold
  both, separated by ` · ` or new sentences. Sort every part before writing anything:
  - **Next step:** a part starting `Next:` (the panel's "→ note" button writes it, the user edits it).
    It becomes the task's open `- [ ] Next:` line **verbatim, in the user's words and language**, plus a log
    line `- <date> · Next set by the user · <text>`. For a new row it is the new task's Next. It is
    recorded, not acted on.
  - **Instruction:** everything else. It tells Claude how to handle the row and is **applied, not
    copied into the task**: scheduling ("has to be scheduled for tomorrow" → `scheduled:` tomorrow,
    and it counts for the day plan), estimates ("estimate is 2h" → `timeEstimate`), waiting ("waiting
    on <PERSON>" → both halves of waiting), status facts ("already sent", "done yesterday"), where it
    belongs ("make it a step in <task>"), or work for Claude ("draft the reply"). Each applied
    instruction gets one log line saying what was done.
  - **Both in one part** ("next is calling the dentist tomorrow"): split it. The action (call the dentist) is the
    Next, the timing (tomorrow) is the instruction.
  - **Unclear** whether a part is a next step or an instruction: treat it as an instruction and
    name it in the summary after Submit, so the user can correct it in one line.
  - The note never overrides the scope table: an instruction to send, pay or delete still needs its
    own switch in the panel or the user's yes in chat.
- **The second move.** A task whose log shows it moved twice gets one question: *break it down,
  or drop it?* (scheduling-rules § Hard work: anything already pushed twice.)

**Check the run id first.** Submit text starts `Check-in answers (run <id>)`. If `<id>` is not the
current run in `~/.cache/plan-today/panel/updates.json`, the answers were given on an older panel
(the user submitted from the "a new run has started" notice): say so in one line and ask whether to
apply them as they are or to recheck the changed rows first.

## The two-minute page

Goal: the quick overview lets the user finish ten two-minute tasks within five minutes.
Built in `quick.py` (its docstring is the spec), `quick.html` (the check-in
panel's own styles and helpers, so it looks and behaves the same), served by `panel_server.py`.

1. **Submit already built it.** POST /submit.json wrote `quick-<run id>.json`: every open
   two-minute item (SKILL.md § Definitions) plus every "quick, no task" row. Waiting rows only when
   answered *today* or *tmrw* (the chase); untouched Not today rows never.
   Ordered inside each channel by priority, then the shortest step, then confident drafts. **Tell
   the user in one line, with the link,** in the same message as the day plan:
   `[Two-minute page](http://localhost:8765/quick)`.
2. **Start its watcher** at the same time as the check-in watcher's work, `run_in_background: true`:
   `F=~/.cache/plan-today/panel/quick-answers-<run id>.txt; while [ ! -f $F ]; do sleep 1; done; cat $F`
3. **Draft what has no draft, in one push.** `python3 quick.py --list` marks `[no draft]` rows and
   `[needs slot]` rows: drafts from the pre-run and the agents, which never name a time.
   For each `[needs slot]` row, pick one slot by the time check below, put it in place of
   `[slot]` in the body, set `msg.slots`, drop `needs_slot`, and push it with the rest.
   Each that is a message gets a row replace with `msg` (the thread's language and tone; WhatsApp
   `via: whatsapp`, mail `via: mail` with `acct`, LinkedIn / Messenger / Instagram `via: linkedin` etc.
   with the chat_id as `to`); the rest stay one-liners, with `acts` where Claude
   can do it. One call: `python3 quick.py '{"changes": [{"n": ..., "row": {...}}]}' --done`.
   **Any time a draft proposes is checked first**: free in every calendar
   (schedule-work's roster), with the door-to-door length from durations and the buffers from
   scheduling-rules, allowed by Week Structure and working-conditions; time zones named both ways.
   If that day's calendar has not been read yet, read it first, then propose one slot; never ask
   for their options instead (rule (a)).
   Each offered slot also goes into the draft's `msg.slots`: `[{start, end, title}]` (local time, length from durations), so the page shows the holds Claude will put in the calendar.
   **Drafting rules** (drafts that break these get rewritten before sending). Every draft, here and in the delta and meditation agents:
   - **(a) Propose one concrete slot, don't ask.** "Sunday evening?" beats "when works for you?". The
     slot passes the time check above and Week Structure (including days and mornings it reserves).
     When an instruction in the user's note conflicts with Week Structure, draft the Week Structure side
     and flag the note.
   - **(b) Re-read the thread right before the page is shown** (`fetch_delta.sh`, ~10 s), and
     re-draft or mark `lc` any row whose thread got a message after the draft.
   - **(c) Reply to whoever has the ball, on the channel they used last.** Read the last message
     to see who is waiting on whom.
   - **(d) WhatsApp drafts follow the user's WhatsApp style guide note**:
     short, several quick lines, the user's nicknames for that person, a "sorry" when replying late; no polished
     one-liners, no "Super excited" or 🙏 unless the guide shows it for that person.
   - **(e) An ask on the user's time** (a panel, an event, a volunteer slot) **defaults to a polite no**
     unless it serves a quarter win ([[Areas/North Star|North Star]] § Input from Week Structure);
     the row says which, so the user flips it in one click.
   Give each pushed row its `hist` (the last 5 messages, `[[who, verbatim line]]`) for "see more". With
   nothing to draft, still `--done`, so the page stops saying "drafting".
4. **On the user's Submit there:** `python3 apply_answers.py --quick --run <run id>` writes done, drop and
   "not 2 min" (the user's estimate inline, scheduled the plan day). Its FOR CLAUDE list holds the rest:
   - **LinkedIn, Messenger and Instagram replies are sent by the page too** (group Chat,
     `chatsender.py`), the same way as mail below, and logged in the same `sent-<run id>.json`.
   - **Mail is already sent by the page** (one click sends): `mailer.py` finds the
     thread, shows To and Cc for an 8 s Undo, and holds the send when someone replied since the
     draft. Rows come back as `sent` and are written as done; `sent-<run id>.json` records each.
   - **Claude does it:** do it, then `--close` the same way. Deleting or RSVPing follows the
     outward-action rules.
   - **Holds** (a suggested time slot creates a blocker): for every
     message sent or copied (done), read the final text and put a hold on the main calendar
     (`<YOUR_EMAIL>`) for each day and time it offers: title `Hold: <task> (proposed)`,
     the door-to-door length from durations, description naming the message. The send or copy is
     the user's approval for these. When the other person picks one, declines, or a time zone was
     misread, the pre-run or the delta agent sees the reply and proposes the fix as `ch` actions
     on that task's row: move the picked hold (k `calendar`) and delete the others (k `delete`,
     the user's switch; schedule-work § calendar). `reference/background.md`, *Stale holds*.
   - **Not 2 min:** place it in the day plan with the user's estimate.
   - **Untouched:** one batched slot in the day plan (scheduling-rules rule 11). The Next stays
     open and `scheduled` the plan day, so the next pre-run brings it back.
   - **WhatsApp is never sent by Claude** (for now; whether plan-today may send WhatsApp messages is an open decision task): the user copied it.
