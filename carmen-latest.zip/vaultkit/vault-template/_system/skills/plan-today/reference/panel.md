# plan-today reference: the check-in panel

Part of the [[_system/skills/plan-today/SKILL|plan-today]] skill. It is split out of SKILL.md so the
button reads only the fast lane. **Read when:** checking the render, building or pushing rows, or
when the panel misbehaves. The pre-run reads this file for the row fields.
Words like plan day, chase date and two-minute item mean what
[[_system/skills/plan-today/SKILL#Definitions|SKILL.md § Definitions]] says.

## Two-minute page

A second page, served at `/quick` once the user submits. It lists the two-minute items (5 min or
less, SKILL.md § Definitions), grouped Email / WhatsApp / Other, each with its text ready. **It is
lean on purpose**, because the check-in panel carries far more than this page needs: the step, the
task it moves, the text, the buttons. It is built and run as in `reference/after-submit.md` § The
two-minute page; the spec is in `quick.py`.

## Which rows appear

**Only rows that need a decision now:** overdue, `due` or `scheduled` through the plan day plus
one, or something new arrived on it since the last run. **A waiting row appears on its chase date
or when a message changed it, never earlier.** Everything else goes into a closed
"Not today (N)" section at the bottom, still answerable; Submit applies only the rows the user
changed there.

**Built on the Mac only** (`regroup` in `build_panel.py`, the `#ntd` section in `panel.html`). The
vault-host pre-run still sends every live task, and the builder regroups its rows from the task
notes' current dates on every build:
- **Plan day, real day and the groups:** SKILL.md § Definitions. The bar shows "Planning Thu Oct 8".
- **Stays in the groups:** meditation rows, "New from mail and WhatsApp", rows with no task, rows
  the pre-run or an agent flags as newly waiting (`gw`), and any task row that is overdue, due
  through the plan day plus one, or (not waiting) scheduled through the plan day plus one. A
  waiting row needs its chase date on or before the plan day; with no chase date it stays (it
  needs one).
- **Goes to "Not today":** every other task row, and rows closed since the pre-run (nothing to
  decide). Each keeps its home group in `og`; a live update that changes such a row moves it there.
- **Not news:** a waiting state changed in the task note (the user's own write). Messages since the
  pre-run reach the panel through the delta agent's live updates.

**Three row rules** keep the panel to a target of 20-30 rows. Built in `build_panel.py`
(`regroup`, `chain_projects`), `panel_rows.to_quick`, `update_panel.py` and `quick.py`:
- **R1, one row per project chain.** Three or more open rows of one project (a note in
  `Projects/`) become one chain row, titled by the next step; the user's answer applies to that
  step, and the others follow as later. A row that is already a step of a chain row is never shown
  on its own, including when the builder would re-add a chain's steps as "New since the pre-run".
- **R2, build items never show.** A task tagged `build` (frontmatter `tags:` list or inline
  `#build`) belongs to the Monday brief ([[_system/build-backlog|build-backlog]]).
- **R7, replies go straight to the two-minute page.** A row whose next step is a message or a
  click of 5 min or less, guessed today or soon, and that creates or moves nothing in the calendar
  sits in a closed "Straight to the two-minute page (N)" section: still answerable, Submit carries
  its guess, and `quick.py` takes it. Calendar means `cal: 1` on the row, or a calendar word or a
  clock time in its Next (the title only when there is no Next). Waiting, chain and meditation
  rows always stay.
- **Untouched "Not today" rows get no write:** no log line, no date question, no two-minute page
  and no batched slot; the run's answers file is the record that they were seen. Only rows the
  user changed there are applied.
- **Chase dates and blocked rows:** SKILL.md § Definitions, *chase date* and *blocked*.
- **Not adopted yet:** R3 drop the Not today section, R4 tomorrow only for deliverables, R5
  proven-done rows as a one-line closing list, R6 new low-stakes later items filed without a row,
  R8 a hard cap of 25.

**A dropped row with no task stays gone for 14 days**, so a dropped suggestion does not come back
as a reworded row. `apply_answers.py` (Submit and `--quick`) writes every dropped taskless row to
`dropped.json` in this skill folder (the vault, so vault-host sees it); entries past 14 days are
pruned. `build_panel.py` and `update_panel.py` hide a new taskless row that matches one, unless
that person wrote after the drop: then it shows with the unsure line "You dropped this on <date>;
new message since".
**Match** (`dropped.py`, conservative): a shared name (a ctx `who` or a draft's `to` only; never
capitalised title words, which would read a multi-word title as people) and a shared topic word
that is neither a name nor a generic verb or channel word. Nicknames miss. Meditation rows are
never hidden. Every decision, near misses included, is logged: `match.json` → `dropped` (build),
`suppressed.json` (live pushes). The delta and meditation agents read `dropped.json` too.

## The check-in panel

**How it is rendered: in the browser pane, built by script.** Typing the 51 KB template inline
into `show_widget` costs about a minute per run, so the panel never passes through Claude's
output. The Fast lane fires all of this; what each part does:
1. **Build.** The server builds the page itself on GET /; `python3
   ~/.claude/skills/plan-today/build_panel.py --new-run [--streams delta,q4] [--journal <entry>]`
   resets a run. It merges the entry's "Two things" items (bare rows in the user's own words) with
   the pre-run's json block, matches each meditation item to a task deterministically (clear
   matches merged into the task's row, still with a pending "adding status and next step" line;
   unclear ones stay bare rows with "matching to your tasks"), normalises chain rows (the same
   `panel_rows.normalise` that `update_panel.py` applies), and writes `titles.txt` (every row's
   exact title, `group | title`: never retype a title) and `match.json` (per item: the chosen task,
   or candidates with scores) to `~/.cache/plan-today/panel/`. It resets `updates.json` and deletes
   any stale `answers-<run id>.txt`. About a second. Nothing has to be written before it.
2. **Serve and open:** the server runs permanently as a LaunchAgent (installed by
   `install_panel_server.sh`), so the session starts no server: it opens `http://localhost:8765/`
   with `mcp__Claude_Browser__preview_start` `url` (SKILL.md fast lane, step 3). If this session
   already shows the panel, `navigate` so the new run loads. **Only if the URL does not load**
   (`curl -s localhost:8765/health` is not `plan-today-panel`): run `install_panel_server.sh`, then
   open again.
3. **The watcher.** The user's Submit POSTs the answers to the server, `answers-<run id>.txt`
   appears, the background command exits and the app wakes the session with the answers as its
   output. **The user types nothing.** Then delete `answers-<run id>.txt`. If the user writes in
   chat instead, read the file directly.
4. **Live updates.** The page polls `updates.json` every 3 s, showing "Checking mail and WhatsApp
   since HH:MM…" at the top. Every write goes through `python3
   ~/.claude/skills/plan-today/update_panel.py <json> --stream <delta|q4> [--done]`
   (concurrency-safe, cumulative; each stream sends `--done` once, also with nothing found, so the
   top line can say "Nothing new since HH:MM"). The JSON is `{"new": [[group, [row, …]]],
   "changes": […]}`, with four change types:
   - `{"n": exact title, "note": "Update 10:12: <PERSON> declined (WhatsApp)", "g": new guess, "w":
     0/1, "lc": 0}`: re-guesses a row **only if the user has not touched it**; otherwise it adds
     the amber line "You already answered this row: check it" and keeps the user's answer.
     `"lc": 0` clears the unsure flag when the update is the evidence.
   - `{"n": title, "row": {full row}, "note": "Matched: …"}`: swaps the row in place for the
     enriched or matched one, keeping the user's answer and note if they already clicked it.
   - `{"n": title, "drop": 1, "note": …}`: removes a duplicate if the user has not touched it
     (otherwise it only flags it). **List drops before the row changes that recreate the same
     title**, since rows are found by title.
   - new rows (under `new`) appear with a blue "new" tag.
   Submit ends with "Live updates applied: N, check complete / still running". If it says still
   running, or an agent lands after Submit, show what it found in chat as a short keyed list and
   the user answers by key.
5. **Check it rendered:** run `document.querySelectorAll('.row').length` through
   `mcp__Claude_Browser__javascript_tool` and compare it with the line count of `titles.txt`. If
   they differ, read the console errors and fix the builder, not the rows by hand.

**Fallback: the inline widget.** Use it if the browser pane is not available. Call
`mcp__visualize__read_me` once (it must come before the first `show_widget` of a session; do not
mention it to the user), then read the built `index.html`, or `panel.html` with `__ROWS__`
replaced, and pass it as `widget_code` to `mcp__visualize__show_widget`. There, Submit arrives as
the user's next message ("Check-in answers: …") through the host's `sendPrompt`. The template only
installs its own POST `sendPrompt` when the host has none, so the same file works in both places.
**Never rewrite the template inline:** change the file, so every run uses the same panel.

**Only in the Claude desktop app.** The browser pane, `show_widget` and `sendPrompt` exist there
and nowhere else (not the plain CLI, not vault-host, not Telegram). Without them, use the
keyed-table fallback at the end of this step.

**The rows** replace `__ROWS__` in `panel.html` (next to this file), whichever way it is rendered:
an array of `[groupName, [row, …]]`. Row fields, each only when there is data:

| Field | Meaning |
|---|---|
| `n` | title (a new candidate gets a proposed task title) |
| `p` | priority colour `H` / `N` / `Z`; `u: 1` if urgent |
| `e` | the whole task's remaining time, `"15m"` / `"2h"`, from `timeEstimate`; `eg: 1` marks it "(guess)" |
| `ne` | **the open Next step alone**, from a `(N min)` at the end of the Next line; `neg: 1` marks it "(guess)". A 3 h task whose next step is one email has `ne: "2m"`. `ne` of 5 min or less makes the step a two-minute item (SKILL.md § Definitions), so it goes to the two-minute page (§ Two-minute page). Guesses come from [[_system/scheduling/durations\|durations]] where the type matches, else a guess x 1.5; both are editable in the row and written back on Submit |
| `g` | the guess: `today` / `soon` / `later` / `done` / `drop`; "today" here means the plan day (SKILL.md § Definitions, guess) |
| `w` | 1 if the task is `waiting: true`; `gw: 1` if the pre-run or an agent finds it is now waiting |
| `m` | line 1: "Scheduled Oct 1 · Due Oct 2", or "New task · WhatsApp Oct 4", or a short origin |
| `s` | line 2, **Status:** **one sentence, 30 words max**: the current state and who has the ball, with its source in brackets. History, timestamps and quotes go in `ctx`, never here; no bookkeeping ("waiting state changed", "planned at the check-in"). Must agree with `w`/`wf`. The panel shows the first sentence and folds the rest behind "more" |
| `wf` | **Waiting for:** what unblocks it, on every waiting row |
| `nx` | line 3, **Next:** the next physical step; `ng: 1` marks it "(guess)" |
| `ov` | an **Overall** line inside see more, when the pre-run sees a pattern (e.g. something that runs against the user's week structure) |
| `ctx` | see-more blocks: `{who, t: story, q: [verbatim lines]}` or plain strings |
| `wb` | who is waiting on whom, shown at the end of see more |
| `lk` / `nw` | existing task name / 1 if no task exists yet |
| `bk` | **what a row without a task becomes** (rows with `nw` or meditation rows only): `own` (one task per outcome, steps inside: real work, a waiting state, or more than a day), `step` (a checkbox in an existing outcome task: it belongs to one), `quick` (a two-minute item with no follow-up and no task: it goes to the two-minute page, and if left there into the plan day's batched slot). Guess it on every such row |
| `st` / `sx` | with `bk: step`: the suggested parent task's exact title, and up to 3 alternatives (same project, person or trip). The dropdown shows these, then "other: tell Claude…" with a free-text field |
| `chain`, `steps` | a dependency chain: `[[title, estimate], …]` |
| `lc` | **unsure guess**: `1` or a short reason ("no evidence either way"). The guessed button shows "?" and is outlined instead of filled, plus an amber line, so the user's eye goes there. Set it whenever the evidence is thin, a fact rests on one summary, or sources disagree |
| `ch` | **Claude can handle this**: a draft written before Submit (pre-run, background agents) never names a time: `[slot]` in the body and `msg.needs_slot: 1`, and the session adds one checked slot on the two-minute page. Distinct actions, one per thing, `{t: what exactly, k: "draft" / "vault" / "research" / "calendar" / "send" / "rsvp" / "delete", msg: {via: "mail", "whatsapp", "linkedin", "messenger" or "instagram", acct, to, subj, body}}`; for the three Beeper chats `to` is the chat_id and there is no `acct` or `subj`. `calendar` moves one of the user's own blocks or holds, a safe action (e.g. a stale `Hold: … (proposed)`, `reference/background.md` *Stale holds*); `send`, `rsvp` and `delete` are outward. Shows "Let Claude handle this" and a folded "what Claude would do" with a switch per action; any message is rendered editable only inside that fold |
| `cal` | `1` when the row's next step creates, moves or clashes with a calendar entry (a time offered, an invite to place, a slot inside a standing block). Keeps the row in the panel instead of R7's two-minute section |
| `dq` | **a passed or outdated due date, re-derived**: `{from, to, why}`, `to` empty to clear. Set it when `due` has passed or the step it guarded is ticked or settled: `to` is the next real deadline found in the note or the messages (with its source in `why`), empty when none is left; leave `dq` out when the guarded step is still open and owed (the row stays overdue on purpose). Shows as one line "Due: was Oct 8, move to Nov 10 (<source>)" with *move / clear* and *keep*; Submit writes `due` only through this answer. What counts as a due and what is a chase date: SKILL.md § Definitions |

Empty groups are skipped. Every row has the six answers, a **waiting / not waiting** toggle and a
**note for Claude** field; there is one free-text box and Submit at top and bottom. Submit sends
back only changed rows and notes; every other row outside Not today is its guess accepted, and an
untouched Not today row gets nothing (§ Which rows appear). **Obsidian links do not open from the
panel** (sandbox): name the task as text, never link it.
Rules:

- **One row per task, prefilled with Claude's guess.** The user changes only what is wrong; Submit
  with no clicks accepts every guess except on untouched Not today rows, which get nothing. The
  guess for each row follows schedule-work Pass 0c's logic: evidence that it happened → *done*;
  nothing and still relevant → *today* or *soon*.
- **Answers:** *today* · *tmrw* (real days; a guess's "today" is the plan day: SKILL.md
  § Definitions) · *soon* (within the next three days) · *later* · *done* · *drop*. The plan day's
  answer is the day-plan candidate (a candidate, not a promise: the day plan cuts it). Every row
  has a **waiting / not waiting** toggle, prefilled from `waiting:` or the evidence the pre-run and
  the agents found; notes are instructions to apply on Submit (e.g. "estimate is 2h").
- **Groups:** in the order of SKILL.md § Definitions, *the groups*; "New from mail and WhatsApp"
  holds someone waiting on the user with no task yet, and the last two sections are closed. **A
  meditation item that matches an existing task appears once, in the top group**, with the
  existing task's title, "From today's meditation" as its line, and the user's full wording as a
  `ctx` block under *see more* (a quote under the title is too long). Meditation items are read
  from the entry at button time; they need no research to be shown.
- **Inside a group:** urgent first (title in red, "urgent"), then by priority. Priority is a
  coloured dot: red `4-high`, amber `3-normal`, grey lower or untriaged.
- **Each row reads top to bottom:** dates or origin · **Status:** with source · **Waiting for:**
  on waiting rows · **Next:** with "(guess)" where inferred; then *see more* and *show order*.
  *See more* gives enough to act without opening the thread: the overall line, a story per person,
  the last messages verbatim, and who is waiting on whom.
- **Dependency chains** (several open tasks in one project that build on each other): one row,
  titled by the next step, with a folded, reorderable order. The answer applies to step 1; the
  other steps follow as *later*. Order comes from the project note; if it gives none, use the
  titles and say the order is a guess. *(How dependencies are modelled in general is open: see the
  open decision task about modelling dependencies between tasks.)*
- **"Let Claude handle this"** is offered only where Claude is confident it can do the task on its
  own: every step uses tools it has (mail, calendar, vault, web research), nothing is missing, and
  it is not a money, legal or personal decision. **One action per thing**: an RSVP, a stale
  calendar block and a reply are three actions, not one. Messages are drafted in full and shown
  only when the user unfolds "what Claude would do", editable there.
- **Approval is per action, and it is the click.** "Let Claude handle this" switches on the safe
  actions (draft, research, vault, the user's own calendar blocks and holds). **Outward actions
  (send, RSVP, delete, pay) run only where the user switched that action on itself**, with its
  exact content in view; switching one on also switches on the row's button. On Submit, run the
  switched-on actions as background subagents while the day plan happens; a mail the user switched
  on is sent **unchanged** from the mailbox shown, in its thread. An edited message the user did
  not switch on is saved as a draft.
  **Stale check before every outward action:** drafts are written by the pre-run and approved
  later. Right before sending, re-read the thread since the pre-run's `generated:` time; before an
  RSVP or delete, re-read the event. **If anything new arrived or the event changed, hold that
  action**, show what changed in one line, and ask again. Never send a reply that answers an older
  state of the thread.
  **LinkedIn, Messenger and Instagram replies are sent like mail:** the user's Send click on the
  two-minute page, through Beeper on vault-host (`chatsender.py`,
  [[_system/beeper-bridge|beeper-bridge]]), with the same Undo and stale hold.
  **WhatsApp is never sent by Claude**: shown to copy, because sending from the user's number
  through the unofficial client risks a ban ([[whatsapp-source]] § Ban risk). The user decides if
  that changes.
- **Dates relative when close:** "yesterday", "today", "tomorrow" for those three days, otherwise
  "Oct 8". **A due time is shown with today's and tomorrow's dates** ("due tomorrow 10:00"), read
  from the task body or Canvas when the property holds only a date. Never numeric month-day.
  Relative to the real day the panel is shown, so the pre-run writes them for the day it runs for.
- **A row guessed *done* says what proves it in Status, and its Next is "Mark as done".** Submit
  with the guess accepted then closes it.
- **One slim sticky bar:** the plan day's count (*today*, or *tmrw* on an evening run), hours
  planned + unestimated, soon, reviewed (changed, Claude and notes only when above 0), a one-word
  live state (updating / up to date / N new), legend behind ?, "+ note" for the whole check-in, and
  the only Submit. The page scrolls, not an inner box. **Each task is a card; clicking its title
  folds it to one line** (the folded line shows the user's answer on the right; titles never shift,
  measured; the priority dot sits at the start of the line under the title, not beside it; open
  cards carry no extra control, so the text keeps its width) with the current answer, so the user
  can mark what they have processed ("x / N reviewed"). Folding is for the user only and changes
  nothing in Submit. No auto-fold.

If the panel cannot render, fall back to a keyed table in chat (keys, not numbers: [[SYSTEM]]
§ Key every list) and ask for the exceptions only.

**Answers survive reloads**, because a run reset from another session reloads the open page and
would otherwise lose every click. The page saves each answer, note, "becomes" choice and fold to
localStorage, keyed by the run id, and restores them by row title after a reload **within the same
run**, with a "Restored N answers … start fresh" notice. A new run never restores old answers
(they may be outdated); answers of older runs are deleted on load. **If a new run starts while the
user has answered rows**, the page does not reload: it shows "A new run has started. Your N
answers belong to the old one: Submit them first, or load the new run (drops them)". Submit clears
the cache and carries the run id. **Never start a new run (`--new-run`) while a panel is open in
another session.**

**Next goes to the note.** An editable Next could silently override a newer one from a live
update, so Next stays plain text and always shows the latest suggestion. Its "→ note" link copies
`Next: <text>` into the row's note, where the user confirms or edits it next to any instructions;
no update ever touches the note. How the note is read after Submit (next step versus instruction):
`reference/after-submit.md`.
