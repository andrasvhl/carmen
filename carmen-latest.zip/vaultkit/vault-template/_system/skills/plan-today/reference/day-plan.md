# plan-today reference: must-do check, the day plan, then work or the week

Part of the [[_system/skills/plan-today/SKILL|plan-today]] skill. It lives outside SKILL.md so the button reads only the fast lane. **Read when:** preloaded while the user clicks, with the scheduling docs (`context_read.sh scheduling`).

## 4. Must-do check, then the plan day's plan

**Everything here is for the plan day** from the build line
([[_system/skills/plan-today/SKILL#Definitions|SKILL.md § Definitions]]). Ask one line,
naming the day: **"Anything that has to happen <today | tomorrow | on <weekday> <date>> that the panel
didn't show? Anything unusual about it?"** Nothing else is asked: durations come from
[[_system/scheduling/durations|durations]], placement from
[[_system/scheduling/scheduling-rules|scheduling-rules]] (both preloaded with `context_read.sh scheduling`). Then plan:

- **One candidate list:** the plan day's answers (*today* on a morning run, *tmrw* on an evening
  run) plus every task `sweep.py --day <plan day>` lists
  (scheduled on or before the plan day), run now rather than only after the plan. Rank them
  together by due, quadrant, priority and North Star; the ranking decides what gets in, the week
  structure note decides where each goes (scheduling-rules rule 6). Place into the plan day's real
  free slots by scheduling-rules (x 1.5 on guesses only, 15 min gaps, 30 after hard work, max ~8
  timed items with fixed commitments counted, at most 3 important, energy peaks), against the calendar. **Say the
  arithmetic:** free hours, hours asked for, what does not fit. **Every carried-over task gets a
  verdict in the table:** placed, or deferred with a date and a reason, so no task is pushed
  by the sweep without being weighed. Overflow goes to *soon* with a proposed date.
- **Rule check, before the plan is shown.** Check the
  draft against scheduling-rules and the week structure note (its weekly rules and the plan
  day's section in its day-by-day part, preloaded with `context_read.sh plan`).
  Above the plan, **only what breaks, 1 to 3 lines**, each naming the rule and its fix:
  "<rule>: <hard task> at 15:00 is hard work in the energy dip; move to <day> 11:00". Most important
  first; more than three means the plan is wrong, so redraft rather than list. **Always one more
  line, even when nothing breaks: big-rock hours this week** (Mon-Sun, planned or already held)
  against the weekly big-rock floor and target in the week structure note, e.g. "Big rocks: 3.5 h of 5 h floor". Count the
  big-rock work inside `❗ Big rocks`, the focus blocks and `❗` blocks whose `Task:` is a
  big rock; `❗ Weekly plan`, `❗ Build` and `❗ Maintenance` do not count.
  Nothing broken: "Rules: ok" plus the big-rock line. A rule the user overrides is their call: note it,
  do not ask again. Not fed into the panel's `ov` line, which the pre-run builds per row; this
  runs on the drafted plan.
- **Two-minute items** (5 min or less, SKILL.md § Definitions), including the next step of a
  larger task: done in the two-minute batch, not scheduled (scheduling-rules rule 11), **on the
  two-minute page** (`reference/after-submit.md` § The two-minute page). Leave those steps out of
  the timed plan. What the user leaves untouched there gets one batched slot on the plan day; what they
  mark "not 2 min" comes back with their estimate and is placed like any other plan-day item.
- **Misses in bulk:** propose new dates for everything moved to *soon* or *later*, ordered by
  dependency, in one table. The user corrects by key. The same message carries the plan-day sweep's list
  (`reference/after-submit.md`), before any calendar block is written.
- Meditation items get a verdict each: **now**, or **slot HH:MM**.
- **Once the user agrees, write the plan day's calendar blocks** by schedule-work's block conventions
  (which calendar, busy or free, title prefixes, `Task:` line, the standing blocks that must not be
  moved), and apply the sweep. The plan day only.

Keep this to 2-3 minutes: no capacity report for the week, no big-rocks pass beyond the rule
check's one line.

## 5. Then: work, or the week

Suggest one of two, based on the plan just agreed: **start a task now** (name it; a reading counts,
where only the user acts), or **continue to the week**, which runs `schedule-work` as a proposal the user
approves. Never re-plan the week silently.

**When working a task together:** research,
pre-fill, draft and do the part Claude can do; nothing is sent without the user's yes. **End every reply
in this phase with the still-open meditation items as bullets:** key in bold, current state and next step in a few words.

## 6. Commit the rest

Ask at the end, always: anything clearly actionable in the journal's anxious and excited answers
goes to `commit-to-action` with this entry as the source (its § A journal entry). Meditation items
already became tasks or steps on Submit (`reference/after-submit.md`, *"Becomes"*; SKILL.md
§ Scope). Pure feelings stay in the journal.
