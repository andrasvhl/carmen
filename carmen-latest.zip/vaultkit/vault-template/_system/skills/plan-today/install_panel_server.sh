#!/usr/bin/env bash
# Install (or reinstall) the always-on plan-today panel server as a macOS LaunchAgent.
#
#   install_panel_server.sh            install and start
#   install_panel_server.sh --remove   stop and remove
#
# The server (panel_server.py) listens on 127.0.0.1:8765 only, builds the check-in panel on every
# GET /, and receives Submit on POST /submit. Running it permanently means a session only opens
# http://localhost:8765/ and never starts a server or collides on the port (a leftover
# server from another chat costs time). Mac only, by design: the panel is shown
# in the Claude desktop app's browser pane.
set -euo pipefail
LABEL="com.example.plan-today-panel"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
HERE="$(cd "$(dirname "$0")" && pwd -P)"
PY="$(command -v python3)"
LOG="$HOME/Library/Logs/plan-today-panel.log"
DOMAIN="gui/$(id -u)"

launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
if [ "${1:-}" = "--remove" ]; then
    rm -f "$PLIST"
    echo "removed $LABEL"
    exit 0
fi
# Free the port if an ad-hoc server (started by a session's preview_start) still holds it.
pid="$(lsof -nP -tiTCP:8765 -sTCP:LISTEN 2>/dev/null || true)"
[ -n "$pid" ] && kill $pid 2>/dev/null && sleep 1
mkdir -p "$HOME/Library/LaunchAgents" "$HOME/.cache/plan-today/panel"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array>
    <string>$PY</string><string>$HERE/panel_server.py</string><string>8765</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ProcessType</key><string>Background</string>
  <key>StandardOutPath</key><string>$LOG</string>
  <key>StandardErrorPath</key><string>$LOG</string>
</dict></plist>
PL
launchctl bootstrap "$DOMAIN" "$PLIST"
for i in $(seq 20); do
    [ "$(curl -s --max-time 1 http://127.0.0.1:8765/health)" = "plan-today-panel" ] && { echo "running: $LABEL on 127.0.0.1:8765 ($PY)"; exit 0; }
    sleep 0.5
done
echo "installed, but /health did not answer; see $LOG" >&2
exit 1
