"""Build the plan-today check-in panel as a standalone page for the browser pane.

Usage:
  python3 build_panel.py --new-run [--streams delta,q4] [--journal <entry.md>]
                         [--plan-day today|tomorrow|YYYY-MM-DD] [extra.json]
      Start a run: reset updates.json, delete a stale answers.txt, write a new run id, and prebuild
      titles.txt and match.json (journal defaults to today's entry). Prints one line,
      `<run id> · plan day Thu Oct 8 · q4 pending <N>` (SKILL.md's fast lane parses it). About
      0.1 s. GET / on panel_server.py then serves the panel for this run.
      Plan day (2026-10-07): tomorrow if the run starts at or after 18:00 America/Los_Angeles, else
      today; --plan-day overrides it. Rows are selected for the plan day: a task scheduled on it gets
      a row, "Scheduled <day>" names it. "Overdue" and the relative date labels stay relative to
      the real date. Set PLAN_TODAY_CACHE=<dir> to build into another cache folder (tests).
  python3 build_panel.py [--journal <entry.md>] [extra.json]
      Start a run and build now (the old way, still works): writes index.html, titles.txt and
      match.json, prints every row's exact title and the match table. --journal and extra.json are
      remembered in the run, so a GET / or a reload rebuilds the same panel.

GET / on panel_server.py calls build_current(): it builds from the current pre-run page plus
today's meditation entry (America/Los_Angeles), starting a run first if none is current.

--journal reads the entry's "Two things I can do today" list. Each item is matched against the
open tasks (Inbox/*.md, type: action, status not done) on shared words, read directly from disk.
A clear match becomes that task's row (and absorbs the pre-run's row for it); anything unclear stays
a bare row in his words with the top candidates as step-in suggestions (st/sx). match.json records
every decision for the session's Q4 pass. Rows come from the fenced json block in
_system/claude/plan-today-prerun.md. extra.json (optional, rare): {"groups": [[group, [row, ...]],
...], "drop": [row titles to remove]}; its groups go in front of the pre-run's groups of the same
name, and a row in "drop" is removed wherever it is.
"""
import json, math, re, sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import panel_rows as pr  # noqa: E402
from panel_rows import normalise, OUT, TZ  # noqa: E402

HERE = Path(__file__).resolve().parent
VAULT = HERE.parents[2]
PRERUN = VAULT / "_system/claude/plan-today-prerun.md"
JOURNAL_DIR = VAULT / "Areas/Personal/Meditation Journal"
MED = "From today's meditation"
NEWMSG = "New from mail and WhatsApp"
NOT_TODAY = "Not today"  # closed section at the bottom (2026-10-07, reference/panel.md § Which rows appear)
CLOSED = ("done", "cancelled", "dropped")
HEAD = ("<!doctype html><meta charset=utf-8><title>Check-in</title><style>"
        ":root{--text-primary:#1f1f1e;--text-secondary:#5f5e5a;--text-muted:#888780;--border:#d3d1c7;--surface-2:#fff;--page-bg:#f6f5f1}body{background:var(--page-bg)}"
        "@media (prefers-color-scheme:dark){:root{--text-primary:#f1efe8;--text-secondary:#b4b2a9;"
        "--text-muted:#888780;--border:#444441;--surface-2:#2c2c2a;--page-bg:#1f1f1e}}"
        "body{font-family:-apple-system,system-ui,sans-serif;max-width:1100px;margin:0 auto;padding:0 8px 75vh;overflow-anchor:none}"
        ".sr-only{position:absolute;left:-9999px}</style>")

# ---------------------------------------------------------------- matching meditation items to tasks
# Conservative on purpose: a wrong merge hides his item under the wrong task, a missed one costs the
# Q4 pass a few seconds. Tuned on the Oct 6 entry (match.json shows the scores).
CLEAR_MIN, CLEAR_RATIO, CLEAR_GAP, PLAUSIBLE, BODY_W = 6.0, 1.8, 3.0, 2.5, 0.4
STOP = set("""
a about after again all also am an and any are as at be been before being but by can could did do does
doing done for from get got had has have he her here him his how i if in into is it its just let like me
more most my no not now of off on once only or our out over own same she should so some still such than
that the their them then there these they this those through to too under until up very was we were
what when where which while who why will with would you your yours today tomorrow tonight yesterday
next step steps source log task tasks waiting oct sep nov dec jan feb mar apr may jun jul aug
der die das den dem des ein eine einen einem einer eines und oder aber auch noch nicht nur schon sehr
ich du er sie es wir ihr mich mir dich dir sich mein meine meinen meinem meiner dein sein ihre unser
ist bin bist sind war waren wird werden wurde hat habe haben hatte kann können konnte muss müssen soll
sollte sollen will wollen mag mach machen mache gemacht zu zum zur im in an am auf aus bei mit nach von
vor für über unter um bis durch ohne gegen wie wo was wer wann warum dass daß ob wenn weil denn als so
da dann dort hier heute morgen gestern jetzt bald immer wieder mal einfach echt wirklich wrsl wahrscheinlich
geht gehen weg ins ums vom beim aufs dich euch uns ihm ihn eigentlich gerade ganz ganze ganzen viel viele mehr weniger weiß wissen gut best besten beste lang lange
alles etwas nichts kein keine keinen dabei davor danach dazu damit darum deswegen oder sowie bzw etc
""".split())
SYN = {  # German and variant spellings onto one English token
    "weihnachten": "christmas", "weihnachts": "christmas", "xmas": "christmas",
    "familie": "family", "familien": "family", "eltern": "family", "zuhause": "home", "hause": "home",
    "flüge": "flight", "flug": "flight", "fluege": "flight", "flights": "flight",
    "anrufen": "call", "anrufe": "call", "anruf": "call", "rufe": "call", "telefonieren": "call",
    "lesen": "read", "gelesen": "read", "verkaufen": "sell", "verkauft": "sell", "verkauf": "sell", "sold": "sell",
    "entscheiden": "decide", "entscheidung": "decide", "decision": "decide",
    "gruppe": "group", "bett": "bed", "bedtime": "bed", "schlafen": "sleep", "tickets": "ticket",
    "reise": "trip", "reisen": "trip",
    "airb": "airbnb", "platz": "spot", "nachhaken": "follow", "schicken": "send", "senden": "send",
    "schreiben": "write", "bezahlen": "pay", "zahlen": "pay", "überweisen": "transfer", "buchen": "book",
    "wochenende": "weekend", "freunde": "friend", "abendessen": "dinner", "absagen": "cancel",
    "jahresplan": "best year", "rennen": "run", "gerannt": "run", "lauf": "run", "laufen": "run",
    "nachrichten": "message", "messages": "message", "termin": "appointment",
}
WORD = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿß0-9]+(?:'[a-z]+)?")


def _canon(w):
    w = w.lower().removesuffix("'s")
    return SYN.get(w, w)


def _tokens(text):
    """[(canonical token, capitalised mid-sentence or all caps)], stopwords and short bits removed."""
    out, start = [], True
    for m in WORD.finditer(text):
        raw = m.group(0)
        proper = (raw.isupper() and len(raw) > 1) or (raw[:1].isupper() and not start)
        for c in _canon(raw).split():
            if len(c) >= 3 and c not in STOP and not c.isdigit():
                out.append((c, proper, raw[:1].isupper()))
        start = bool(re.match(r"\s*[.!?:\n#]", text[m.end():m.end() + 3]))
    return out


def _hit(tok, vocab):
    if tok in vocab:
        return tok
    if len(tok) >= 4:
        for v in vocab:
            a, b = sorted((tok, v), key=len)  # plurals and stubs ("ticket"/"tickets"), not "push"/"pushover"
            if len(a) >= 4 and b.startswith(a) and len(a) >= 0.65 * len(b):
                return v
    return None


CLOSED_DAYS = 14  # recently closed tasks are matched too (2026-10-06: a fix done that morning was re-proposed)


def open_tasks():
    """Open action tasks, plus tasks closed in the last CLOSED_DAYS days (flagged closed), read
    straight from Inbox/ and Archive/Inbox/ (no vt: this runs on every GET /)."""
    tasks = []
    cutoff = datetime.now(TZ).timestamp() - CLOSED_DAYS * 86400
    paths = list((VAULT / "Inbox").glob("*.md"))
    if (VAULT / "Archive" / "Inbox").exists():
        paths += [p for p in (VAULT / "Archive" / "Inbox").glob("*.md") if p.stat().st_mtime >= cutoff]
    for p in paths:
        try:
            text = p.read_text(encoding="utf-8").lstrip("﻿")
        except OSError:
            continue
        m = re.match(r"---\s*\n(.*?)\n---\s*\n?", text, re.S)
        if not m:
            continue
        fm = m.group(1)
        ty = re.search(r"^type:\s*['\"]?([\w-]*)", fm, re.M)
        st = re.search(r"^status:\s*['\"]?([\w-]*)", fm, re.M)
        closed = (st and st.group(1) in ("done", "dropped", "cancelled")) or "Archive" in p.parts
        if not ty or ty.group(1) != "action" or (closed and p.stat().st_mtime < cutoff):
            continue
        body = re.sub(r"\[\[[^\]]*\]\]", " ", text[m.end():])[:400]  # links name other tasks
        tt, bt = _tokens(p.stem), _tokens(body)
        tasks.append({"title": p.stem, "closed": bool(closed),
                      "closed_on": datetime.fromtimestamp(p.stat().st_mtime, TZ).strftime("%b %-d") if closed else "",
                      "tv": {t for t, _, _ in tt}, "bv": {t for t, _, _ in bt},
                      "proper": {t for t, pp, _ in tt + bt if pp}})
    return tasks


def match_items(items, tasks):
    """Score each item against every task; returns one record per item."""
    n = len(tasks) or 1
    df = {}
    for t in tasks:
        for k in t["tv"] | t["bv"]:
            df[k] = df.get(k, 0) + 1
    idf = lambda k: math.log((n + 1) / (df.get(k, 0) + 1)) + 0.3  # noqa: E731
    out = []
    for it in items:
        toks, seen = [], set()
        for k, _, proper in _tokens(it):  # the first 8 content words say what to do; the rest is context
            if k not in seen:
                seen.add(k); toks.append((k, proper, 1.0 if len(toks) < 8 else 0.5))
        scored = []
        for t in tasks:
            s, ts, shared = 0.0, 0.0, []
            for k, proper, wpos in toks:
                v = _hit(k, t["tv"])
                place = 1.0 if v else BODY_W
                v = v or _hit(k, t["bv"])
                if not v:
                    continue
                bonus = 1.5 if v in t["proper"] else 1.0  # a name in the task ("CAPS", "<COACHING_PROJECT>"), whatever his case
                s += idf(v) * wpos * place * bonus
                ts += idf(v) * wpos * bonus if place == 1.0 else 0
                shared.append(v)
            if s > 0:
                scored.append((round(s, 2), round(ts, 2), t["title"], shared))
        scored.sort(key=lambda x: -x[0])
        out.append({"text": it, "candidates": [{"title": ti, "score": sc, "title_score": tsc, "shared": sh}
                                               for sc, tsc, ti, sh in scored[:5]]})
    return out


def _clear(c):
    if not c or c[0]["score"] < CLEAR_MIN:
        return False
    second = c[1]["score"] if len(c) > 1 else 0.0
    second_t = c[1]["title_score"] if len(c) > 1 else 0.0
    # well above the runner-up overall, or a clear gap that comes from the title itself (the runner-up
    # is often the umbrella task whose body mentions everything: "Plan the offsite" vs "Book the venue")
    return c[0]["score"] - second >= CLEAR_GAP and (c[0]["score"] >= CLEAR_RATIO * second
                                                     or c[0]["title_score"] >= 2 * max(second_t, 1.0))


# ---------------------------------------------------------------- rows
def journal_items(path):
    p = Path(path) if Path(path).is_absolute() else VAULT / path
    text = p.read_text(encoding="utf-8")
    m = re.search(r"^##\s*Two things I can do today.*?$(.*?)(?=^##\s|\Z)", text, re.M | re.S)
    if not m:
        return []
    items = []
    for line in m.group(1).splitlines():
        s = line.strip()
        if re.match(r"^(\d+[.)]|[-*])\s+", s):
            items.append(re.sub(r"^(\d+[.)]|[-*])\s+", "", s))
        elif s and items:
            items[-1] += " " + s
    return [i.strip() for i in items if i.strip()]


def bare_row(it):
    short = re.split(r"(?<=[.!?])\s| und | and ", it, maxsplit=1)[0]
    short = short if len(short) <= 60 else short[:58].rsplit(" ", 1)[0].rstrip(",;:") + " …"
    row = {"n": short, "nw": 1, "p": "N", "g": "today", "q4": 1, "m": MED, "pend": "matching to your tasks…"}
    if short != it:  # the full wording goes into see more, not under the title (2026-10-06)
        row["ctx"] = [{"who": "Your meditation", "t": "„" + it + "“"}]
    return row


TAKE = ("s", "nx", "ng", "wf", "g", "w", "gw", "e", "eg", "ne", "neg", "p", "u", "lc", "ov", "wb", "ch")


def meditation_rows(items, groups, tasks):
    """Rows for the meditation group; removes pre-run rows they absorb. Returns (rows, match records)."""
    recs, rows, taken = match_items(items, tasks), [], set()
    closed = {x["title"]: x["closed_on"] for x in tasks if x.get("closed")}
    for i, (it, rec) in enumerate(zip(items, recs), 1):
        c, rec["i"] = rec["candidates"], i
        chosen = c[0]["title"] if _clear(c) else None
        if chosen and chosen in taken:
            chosen, rec["note"] = None, "clear match already taken by an earlier item"
        if chosen and chosen in closed:
            taken.add(chosen)
            row = {"n": chosen, "lk": chosen, "p": "N", "g": "done", "q4": 1,
                   "m": MED + " · closed task", "s": f"Already done: the task was closed on {closed[chosen]} [task note]",
                   "nx": "Mark as done", "ctx": [{"who": "Your meditation", "t": "„" + it + "“"}]}
            rec.update({"decision": "matched closed", "needs_enrichment": False, "chosen": chosen, "row": chosen})
            rows.append(row)
            continue
        if chosen:
            taken.add(chosen)
            row = {"n": chosen, "lk": chosen, "p": "N", "g": "today", "q4": 1,
                   "m": MED + " · existing task", "ctx": [{"who": "Your meditation", "t": "„" + it + "“"}],
                   "pend": "adding status and next step…"}
            key = chosen.lower()
            for g in list(groups):
                hit = [r for r in groups[g] if key in ((r.get("n") or "").lower(), (r.get("lk") or "").lower())]
                if hit:
                    src = hit[0]
                    row.update({k: src[k] for k in TAKE if k in src})
                    row["ctx"] += src.get("ctx", [])
                    groups[g] = [r for r in groups[g] if r is not src]
                    rec["merged_prerun"] = g
                    break
            rec["decision"] = "matched"
            # A pre-run row already carried status and next step: the row is finished at render
            # time, so the Q4 pass skips it (2026-10-06 dry run: 4 of 5 rows were re-done for 2 min).
            if row.get("s") and row.get("nx"):
                row.pop("pend", None)
                rec["needs_enrichment"] = False
            else:
                rec["needs_enrichment"] = True
        else:
            rec["needs_enrichment"] = True
            row = bare_row(it)
            plaus = [x["title"] for x in c if x["score"] >= PLAUSIBLE][:3]
            if plaus:
                row["st"], row["bk"] = plaus[0], "own"
                if plaus[1:]:
                    row["sx"] = plaus[1:]
            rec["decision"] = "unclear" if plaus else "no candidate"
        rec["chosen"], rec["row"] = chosen, row["n"]
        rows.append(row)
    return rows, recs


# ---------------------------------------------------------------- freshness (2026-10-06)
# The pre-run is written at 08:00; a run at 15:00 would show tasks as they stood then. Messages
# are covered by the delta fetch; this covers the task notes themselves: rows for tasks closed or
# moved since get folded and marked, waiting / next-step changes are taken over, and tasks that
# entered the panel set since the pre-run get a row. Pure file reads, a few ms.

def _fm(text):
    m = re.match(r"---\s*\n(.*?)\n---\s*\n?", text, re.S)
    if not m:
        return None, text
    fm, last = {}, None
    for line in m.group(1).splitlines():
        if last and re.match(r"\s+-\s+", line):  # a YAML list item ("tags:\n  - build"): Oct 13,
            item = re.sub(r"^\s+-\s+", "", line).strip().strip("'\"")  # build tasks were missed
            fm[last] = (fm[last] + ", " if fm[last] else "") + item
            continue
        k, _, v = line.partition(":")
        if _ and k and not k.startswith(" "):
            last = k.strip()
            fm[last] = v.strip().strip("'\"")
    return fm, text[m.end():]


def _where(body):
    """Where a task stands, from its own note: the first Current-context bullet (the pre-run's),
    else the last Log line; one sentence, 30 words max (owner decision, Oct 13: rows new since the pre-run
    said "no message check behind this guess" three times and never where the task stood)."""
    cc = re.search(r"^## Current context\s*\n(.*?)(?=^## |^%%|\Z)", body, re.M | re.S)
    line = ""
    if cc:
        line = next((l[2:] for l in cc.group(1).splitlines() if l.startswith("- ")), "")
    if not line:
        lg = re.search(r"^## Log\s*\n(.*?)(?=^## |\Z)", body, re.M | re.S)
        logs = [l[2:] for l in lg.group(1).splitlines() if l.startswith("- ")] if lg else []
        line = logs[-1] if logs else ""
    line = re.sub(r"\*\*|\[\[(?:[^\]|]*\|)?([^\]]*)\]\]", r"\1", line).strip()
    line = re.sub(r"^[A-Z][a-z]{2} \d{1,2} · (?:[\w-]+ [A-Z][a-z]{2} \d{1,2}, \w+: )?", "", line)  # log prefix
    line = line[:1].upper() + line[1:]
    m = re.match(r"(.+?[.!?])(?:\s|$)", line)
    line = m.group(1) if m else line
    w = line.split()
    return " ".join(w[:30]) + ("…" if len(w) > 30 else "")


def task_states():
    """Title -> state for every action note in Inbox/, plus the titles archived in Archive/Inbox/."""
    out = {}
    for p in (VAULT / "Inbox").glob("*.md"):
        try:
            fm, body = _fm(p.read_text(encoding="utf-8").lstrip("\ufeff"))
        except OSError:
            continue
        if not fm or fm.get("type") != "action":
            continue
        nx = re.search(r"^- \[ \] Next:\s*(.+)$", body, re.M)
        wf = re.search(r"^- \[ \] Waiting:\s*(.+)$", body, re.M)
        out[p.stem] = {"status": fm.get("status", ""), "scheduled": fm.get("scheduled", "")[:10],
                       "due": fm.get("due", "")[:10], "waiting": fm.get("waiting", "").lower() == "true",
                       "priority": fm.get("priority", ""), "est": fm.get("timeEstimate", ""),
                       "build": "build" in fm.get("tags", "") or bool(re.search(r"(^|\s)#build\b", body)),
                       "nx": pr.split_step(nx.group(1))[0] if nx else "", "nxe": pr.split_step(nx.group(1))[1] if nx else None,
                       "wf": wf.group(1).strip() if wf else "",
                       "projects": re.findall(r"\[\[([^\]|#]+)", fm.get("projects", "")),
                       "where": _where(body),
                       # 3 (Oct 13): a Waiting line that names another task is "blocked by" it
                       "blocked_by": (re.findall(r"\[\[([^\]|#]+)", wf.group(1)) or [None])[0] if wf else None}
    archived = {p.stem for p in (VAULT / "Archive" / "Inbox").glob("*.md")} if (VAULT / "Archive" / "Inbox").exists() else set()
    return out, archived


def _day(iso):
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
    except ValueError:
        return iso
    today = datetime.now(TZ).date()
    delta = (d.date() - today).days
    return {0: "today", 1: "tomorrow", -1: "yesterday"}.get(delta, d.strftime("%b %-d"))


PRIO = {"4-high": "H", "3-normal": "N", "2-low": "Z", "1-none": "Z"}


def group_names(pday):
    """Date-group names for a plan day: (scheduled on the plan day, due or scheduled the day after).
    On a morning run the first is "Scheduled today"; on an evening run it names the day."""
    today = datetime.now(TZ).date()
    plan = ("Scheduled today" if pday == today else  # owner decision, Oct 13: say "tomorrow" on an evening run
            "Scheduled tomorrow" if pday == today + timedelta(days=1) else "Scheduled " + pr.day_label(pday))
    return plan, "Due or scheduled " + _day((pday + timedelta(days=1)).isoformat())


def freshen(groups, since_label, pday):
    """pday: the plan day (a date). A task scheduled on or before it counts as scheduled "today"."""
    states, archived = task_states()
    today = datetime.now(TZ).date().isoformat()
    plan_iso = pday.isoformat()
    nxt = (pday + timedelta(days=1)).isoformat()
    soon = (pday + timedelta(days=3)).isoformat()
    g_plan, g_next = group_names(pday)
    seen = set()
    for g in groups:
        for r in groups[g]:
            key = r.get("lk") or r.get("n") or ""
            seen.add(key)
            # the steps of a chain row are on the panel too (Oct 13: the six Best Year steps behind
            # "Do Future Authoring day 2" were added again as six "New since the pre-run" rows)
            seen.update(st[0] for st in (r.get("steps") or r.get("chain") or []) if isinstance(st, list) and st)
            st = states.get(key)
            if st is None:
                if key in archived and not r.get("nw"):
                    r.update({"g": "done", "s": f"Closed since the pre-run at {since_label} (archived)",
                              "fold": 1, "fresh": "closed"})
                    r.pop("lc", None)
                continue
            if st["status"] in CLOSED:
                r.update({"g": "done", "s": f"Closed since the pre-run at {since_label} [task note]",
                          "nx": "Nothing left", "fold": 1, "fresh": "closed"})
                r.pop("lc", None)
                continue
            sch, due = st["scheduled"], st["due"]
            if sch and sch > plan_iso and not (due and due <= plan_iso) and not st["waiting"] and r.get("g") == "today":
                r.update({"g": "soon" if sch <= soon else "later",
                          "s": f"Moved to {_day(sch)} since the pre-run at {since_label} [task note]",
                          "fold": 1, "fresh": "moved"})
                r.pop("lc", None)
                continue
            if bool(r.get("w")) != st["waiting"]:
                r["w"] = 1 if st["waiting"] else 0
                r.pop("gw", None)
                # no bookkeeping line in Status any more (owner decision, Oct 13: status lines too long)
            # the grey line's dates come from the note now, not the 08:00 snapshot (Oct 13: a trip task still
            # said "Due Oct 8" after the due moved to Nov 10)
            rest = [b for b in (r.get("m") or "").split(" · ") if b and not re.match(r"(Due|Scheduled)\b", b)]
            dates = [f"Due {_day(st['due'])}" if st["due"] else "", f"Scheduled {_day(st['scheduled'])}" if st["scheduled"] else ""]
            r["m"] = " · ".join([d for d in dates if d] + rest)
            if st["wf"] and st["waiting"]:
                r["wf"] = st["wf"]
            if st["nx"] and st["nx"] != r.get("nx"):
                r["nx"], r["ng"] = st["nx"], 0
            elif not st["nx"] and st["waiting"] and st["wf"] and not re.match(r"\s*(wait|chase)", r.get("nx") or "", re.I):
                # Next ticked, ball with them (Oct 13, Hans Jacob): say when to chase, not "Waiting for" twice
                who = st["wf"].split(",")[0].strip()
                r["nx"] = (f"Chase {who} on {_day(st['scheduled'])} if nothing comes" if st["scheduled"]
                           else f"Set a chase date for {who}")
                r["ng"] = 0
    added = 0
    for title, st in states.items():
        if title in seen or st["build"] or st["status"] in CLOSED:
            continue
        sch, due = st["scheduled"], st["due"]
        if not ((sch and sch <= nxt) or (due and due <= nxt) or st["waiting"]):
            continue
        grp = ("Overdue" if (due and due < today) or (sch and sch < today and not st["waiting"]) else
               "Waiting" if st["waiting"] else ("Scheduled today" if plan_iso == today else "Left over from today") if sch == today else
               g_plan if sch and sch <= plan_iso else g_next)
        bits = [f"Scheduled {_day(sch)}" if sch else "", f"Due {_day(due)}" if due else ""]
        row = {"n": title, "lk": title, "p": PRIO.get(st["priority"], ""), "g": "today" if (sch and sch <= plan_iso) else "soon",
               "w": 1 if st["waiting"] else 0, "m": " · ".join([b for b in bits if b]),  # no "New since the pre-run" label (owner decision, Oct 13: not valuable)
               "s": (st["where"] + " [task note]") if st["where"] else "",
               "nx": st["nx"] or (("Wait for " + st["wf"]) if st["wf"] else "Open the task and name the next step"),
               "ng": 0 if (st["nx"] or st["wf"]) else 1,
               "fresh": "new"}
        if st["wf"]:
            row["wf"] = st["wf"]
        groups.setdefault(grp, []).append(row)
        added += 1
    return added, states


# ---------------------------------------------------------------- row filter (2026-10-07)
# owner decision, Oct 7, after an evening run where 5 of 7 waiting rows had chase dates Oct 10-13: only
# rows that need a decision now stay in the groups; the rest go into a closed "Not today (N)"
# section, still answerable. Regroups the pre-run's rows on the Mac from the task notes' current
# dates; the vault-host pre-run is unchanged. Spec: reference/panel.md § Which rows appear.

def _home(st, today, pday):
    """The group a task-backed row belongs in, from its current dates."""
    sch, due, w = st["scheduled"], st["due"], st["waiting"]
    g_plan, g_next = group_names(pday)
    if (due and due < today) or (sch and sch < today and not w):
        return "Overdue"
    if w:
        return "Waiting"
    if sch == today:  # an evening run: what today did not get to (Oct 13: "today" read as the plan day)
        return "Scheduled today" if pday.isoformat() == today else "Left over from today"
    if sch and sch <= pday.isoformat():
        return g_plan
    return g_next


def needs_now(st, today, pday):
    """Overdue, due or scheduled through the plan day plus one. A waiting row only from its chase
    date (`scheduled`) or a due date through the plan day plus one, never earlier. A waiting row
    with no chase date stays visible: it needs one."""
    sch, due, w = st["scheduled"], st["due"], st["waiting"]
    plan, nxt = pday.isoformat(), (pday + timedelta(days=1)).isoformat()
    if due and due <= nxt:
        return True
    if w:
        return not sch or sch <= plan
    return bool(sch and sch <= nxt)


def regroup(groups, states, pday):
    """Move each task-backed row to the group its current dates say, or to NOT_TODAY with its home
    group in "og" (a live update that changes it moves it back there). Rows closed since the
    pre-run go to NOT_TODAY too: nothing to decide (an evening run showed seven of them on top).
    Meditation rows, new rows from messages, rows without a task and rows the pull flags as newly
    waiting (`gw`, message evidence) stay. A waiting state changed in the task note is his own
    write, not news. Returns the new groups dict."""
    today = datetime.now(TZ).date().isoformat()
    out = {}
    for g, rows in groups.items():
        for r in rows:
            st = states.get(r.get("lk") or r.get("n") or "")
            news = bool(r.get("gw")) and not (st and st["waiting"])  # once the note says waiting, it is not news
            target = g
            if g not in (MED, NOT_TODAY) and r.get("fresh") == "closed":
                target, r["og"] = NOT_TODAY, g
            # C (owner decision, Oct 13): a "New from mail and WhatsApp" row that is a task by now is sorted
            # like any task (Hans Jacob, waiting until Sun, sat there as new)
            elif g not in (MED, NOT_TODAY) and st and st["status"] not in CLOSED:
                home = _home(st, today, pday)
                if news or needs_now(st, today, pday):
                    target = home
                else:
                    target, r["og"] = NOT_TODAY, home
            if st and st["build"] and g != MED:
                continue  # R2 (owner decision, Oct 13): build items live in the Monday brief, never here
            blk = states.get(st["blocked_by"]) if st and st.get("blocked_by") else None
            if blk and blk["status"] not in CLOSED and g != MED:
                # 3 (owner decision, Oct 13): blocked by an open task, so no date and no row, until the blocker
                # closes or the task's own due is 14 days out ("the entire thing needs a due date")
                left = (datetime.fromisoformat(st["due"]).date() - pday).days if st["due"] else None
                if left is None or left > BLOCKED_WARN:
                    continue
                r["ov"] = (r.get("ov", "") + f" Blocked by {st['blocked_by']}, and due in {left} days: chase the blocker or start what you can.").strip()
            if target not in (MED, NOT_TODAY) and pr.to_quick(r):
                target, r["og"] = pr.QK, target  # R7 (owner decision, Oct 13)
            out.setdefault(target, []).append(r)
    return chain_projects(out, states)


# ---------------------------------------------------------------- R1 (owner decision, 2026-10-13)
# One row per project chain: open tasks of one project (a note in Projects/) that show up three or
# more times become one chain row, titled by the next step; his answer applies to that step and the
# others follow as later. The pre-run builds chains itself when it sees one; this is the fallback,
# and it also folds a row that already sits inside a chain's steps. Oct 13: Future Authoring day 2
# plus six Best Year steps were seven rows.
CHAIN_MIN = 3
BLOCKED_WARN = 14  # days before its due date a blocked task shows again
CHAIN_SKIP = (MED, NEWMSG, NOT_TODAY, pr.QK, "Waiting")


def _project_notes():
    d = VAULT / "Projects"
    return {p.name for p in d.iterdir() if p.is_dir()} | {p.stem for p in d.glob("*.md")} if d.exists() else set()


def chain_projects(groups, states):
    in_chain = {st[0] for rows in groups.values() for r in rows for st in (r.get("steps") or []) if st}
    for g in groups:  # a row that is already a step of a chain row is dropped
        groups[g] = [r for r in groups[g] if r.get("steps") or (r.get("lk") or r.get("n")) not in in_chain]
    projects = _project_notes()
    by = {}
    for g, rows in groups.items():
        if g in CHAIN_SKIP:
            continue
        for r in rows:
            st = states.get(r.get("lk") or r.get("n") or "")
            proj = next((p for p in (st or {}).get("projects", []) if p in projects), None)
            if proj and not r.get("steps"):
                by.setdefault(proj, []).append((g, r))
    for proj, members in by.items():
        if len(members) < CHAIN_MIN:
            continue
        # head: overdue first, then the earliest date, then priority; the order of the rest is a guess
        rank = {"Overdue": 0}
        def key(m):
            st = states.get(m[1].get("lk") or m[1].get("n")) or {}
            return (rank.get(m[0], 1), st.get("scheduled") or "9999", {"H": 0, "N": 1}.get(m[1].get("p"), 2))
        members.sort(key=key)
        hg, head = members[0]
        head["steps"] = [[m[1].get("lk") or m[1]["n"], m[1].get("e") or "?"] for m in members]
        head["chain"] = head.get("n")
        head["ov"] = ((head.get("ov") or "") + f" One row for the {len(members)} open {proj} tasks (R1): your answer "
                      "applies to the first step, the others follow as later. Order is a guess from the dates.").strip()
        drop = {id(m[1]) for m in members[1:]}
        for g in groups:
            groups[g] = [r for r in groups[g] if id(r) not in drop]
    return groups


def order(names, pday):
    g_plan, g_next = group_names(pday)
    first = [MED, "Overdue", "Scheduled today", "Left over from today", g_plan, "Waiting", g_next, "Due in the next 3 days", NEWMSG]
    last = [g for g in (pr.QK, NOT_TODAY) if g in names]
    return ([g for g in dict.fromkeys(first) if g in names] +
            [g for g in names if g not in first and g not in last] + last)


def auto_entry(u):
    """B (owner decision, Oct 13): a run planning a later day takes no journal unless one was passed: this
    morning's meditation items already had their run (an evening run showed CAPS, flights, Sam prep
    and Alia again, all handled)."""
    return today_entry() if pr.plan_day_of(u) <= datetime.now(TZ).date() else None


def today_entry():
    p = JOURNAL_DIR / (datetime.now(TZ).strftime("%Y-%m-%d") + ".md")
    return str(p) if p.exists() else None


def journal_sig(text):
    """Same as plan_today_prerun.journal_sig: which entry the pre-run's meditation group was built from."""
    import hashlib
    return hashlib.sha1(text.strip().encode("utf-8")).hexdigest()[:12]


def prerun_read_entry(prerun, journal):
    """Since Oct 31 the pre-run reads today's entry and fills the meditation group with judgment.
    Its rows stand while the entry is unchanged; any edit since falls back to the matcher."""
    j = (prerun or {}).get("journal") or {}
    p = Path(journal) if Path(journal).is_absolute() else VAULT / journal
    try:
        return bool(j.get("sig")) and j["sig"] == journal_sig(p.read_text(encoding="utf-8"))
    except OSError:
        return False


def estimates(groups, states):
    """Every row carries `e` (whole task) and `ne` (its Next step) where the task note has them:
    the note wins over the model's guess, and a guess keeps its eg/neg flag. A "(N min)" the model
    copied into nx is split off into ne. Rows still without one show as unestimated (2026-10-12)."""
    for rows in groups.values():
        for r in rows:
            nx, inl = pr.split_step(r.get("nx"))
            if inl:
                r["nx"] = nx
            st = states.get(r.get("lk") or r.get("n") or "") or {}
            est = pr.minutes(st.get("est"))
            if est:
                r["e"] = pr.fmt_e(est); r.pop("eg", None)
            elif pr.minutes(r.get("e")) is None:
                r.pop("e", None); r.pop("eg", None)
            step = st.get("nxe") if st.get("nx") and st.get("nx") == r.get("nx") else None
            step = step or inl
            if step:
                r["ne"] = pr.fmt_e(step); r.pop("neg", None)
            elif pr.minutes(r.get("ne")) is None:
                r.pop("ne", None); r.pop("neg", None)


def build(run, journal=None, extra=None):
    """Build the panel for `run` (an updates.json dict). Writes index.html, titles.txt, match.json.
    Returns (html, data, match records)."""
    page = PRERUN.read_text(encoding="utf-8")
    m = re.search(r"```json\n(.*?)\n```", page, re.S)
    prerun = json.loads(m.group(1)) if m else {}
    groups = {g: list(r) for g, r in prerun.get("rows", [])}
    recs = []
    gm = re.search(r"^generated:\s*(\S+)", page, re.M)
    gen_dt = None
    if gm:
        try:
            gen_dt = datetime.fromisoformat(gm.group(1))
        except ValueError:
            gen_dt = None
    since_label = gen_dt.strftime("%H:%M") if gen_dt else "the pre-run"
    if gen_dt and gen_dt.date() != datetime.now(TZ).date():
        since_label = gen_dt.strftime("%b %-d %H:%M")
    pday = pr.plan_day_of(run)
    _, states = freshen(groups, since_label, pday)
    if journal and not prerun_read_entry(prerun, journal):
        items = journal_items(journal)
        mrows, recs = meditation_rows(items, groups, open_tasks() if items else [])
        groups[MED] = mrows   # a pre-run group from an older version of the entry is dropped
    if extra:
        drop = set(extra.get("drop", []))
        for g in groups:
            groups[g] = [r for r in groups[g] if r.get("n") not in drop]
        for g, r in extra.get("groups", []):
            groups[g] = list(r) + groups.get(g, [])
    # Oct 13 (the owner: "only for like 2 weeks"): a taskless row he dropped in the last 14 days stays
    # hidden unless the person wrote since; decisions in match.json "dropped" (dropped.py)
    import dropped
    dlog, gone = [], dropped.load()
    for g in list(groups):
        if g != MED:
            groups[g] = dropped.apply(groups[g], gone, dlog,
                                      has_task=lambda r: (r.get("lk") or r.get("n") or "") in states)
    estimates(groups, states)  # before regroup: R7 reads the step estimate (Oct 13: Kati's 5 min was missed)
    groups = regroup(groups, states, pday)
    for g in groups:
        for r in groups[g]:
            normalise(r)
    data = [[g, groups[g]] for g in order(list(groups), pday) if groups[g]]
    tpl = (HERE / "panel.html").read_text(encoding="utf-8")
    age_h = round((datetime.now(TZ) - gen_dt).total_seconds() / 3600, 1) if gen_dt else None
    live = ("<script>window.PT_LIVE=1;window.PT_RUN=" + json.dumps(run.get("run", "")) +
            ";window.PT_PRERUN=" + json.dumps({"t": since_label, "age_h": age_h}) +
            ";window.PT_PLAN=" + json.dumps({"iso": pday.isoformat(), "label": pr.day_label(pday),
                                            "today": pday == datetime.now(TZ).date()}) + "</script>")
    html = HEAD + live + tpl.replace("__ROWS__", json.dumps(data, ensure_ascii=False))
    OUT.mkdir(parents=True, exist_ok=True)
    pr.write_atomic(OUT / "index.html", html)
    titles = "\n".join(f"{g} | {r.get('n', '')}" for g, rs in data for r in rs)
    pr.write_atomic(OUT / "titles.txt", titles + "\n")
    pr.write_atomic(OUT / "match.json", json.dumps({"run": run.get("run"), "journal": journal, "items": recs, "dropped": dlog},
                                                   ensure_ascii=False, indent=1))
    return html, data, recs


def start_run(streams=None, journal=None, extra=None, plan_day=None):
    head = PRERUN.read_text(encoding="utf-8")[:400] if PRERUN.exists() else ""
    with pr.locked():
        return pr.new_run(pr.since_of(head), streams, journal, extra, plan_day)


def build_current():
    """For GET /: the current run's panel, starting a run if none is current."""
    with pr.locked():
        u = pr.read_updates()
        if not pr.run_is_current(u):
            head = PRERUN.read_text(encoding="utf-8")[:400] if PRERUN.exists() else ""
            u = pr.new_run(pr.since_of(head))
    journal = u.get("journal") or auto_entry(u)
    return build(u, journal, u.get("extra"))


def match_table(recs):
    lines = []
    for r in recs:
        c = r["candidates"]
        lines.append(f"{r['i']}. {r['decision'].upper():12} {r['text'][:70]}")
        lines.append(f"   -> {r['chosen'] or '(bare row: ' + r['row'] + ')'}"
                     + (f"  [absorbed pre-run row from {r['merged_prerun']}]" if r.get("merged_prerun") else ""))
        for x in c[:3]:
            lines.append(f"      {x['score']:6.2f}  {x['title'][:70]}  ({', '.join(x['shared'][:6])})")
    return "\n".join(lines)


def main(argv):
    args = list(argv)
    streams = journal = plan_day = None
    if "--plan-day" in args:
        i = args.index("--plan-day"); plan_day = pr.compute_plan_day(args[i + 1]); del args[i:i + 2]
    if "--streams" in args:
        i = args.index("--streams"); streams = [s for s in args[i + 1].split(",") if s]; del args[i:i + 2]
    if "--journal" in args:
        i = args.index("--journal"); journal = args[i + 1]; del args[i:i + 2]
    quiet = "--new-run" in args
    args = [a for a in args if a != "--new-run"]
    extra = json.loads(Path(args[0]).read_text(encoding="utf-8")) if args else None
    if quiet:  # start the run and prebuild (titles.txt, match.json); GET / serves the same panel
        u = start_run(streams, journal, extra, plan_day)
        _, _, recs = build(u, journal or auto_entry(u), extra)
        pending = sum(1 for r in recs if r.get("needs_enrichment"))
        if pending == 0:  # nothing for the q4 agent: close its stream, launch no agent (2026-10-06)
            import subprocess
            subprocess.run([sys.executable, str(HERE / "update_panel.py"), "{}", "--stream", "q4", "--done"],
                           capture_output=True, text=True)
        print(f"{u['run']} · plan day {pr.day_label(pr.plan_day_of(u))} · q4 pending {pending}")
        return
    u = start_run(streams, journal, extra, plan_day)
    _, data, recs = build(u, journal, extra)
    print(OUT / "index.html", sum(len(r) for _, r in data), "rows · run", u["run"], "· plan day", pr.day_label(pr.plan_day_of(u)))
    if recs:
        print("MEDITATION MATCHES (also in match.json):\n" + match_table(recs))
    print("ROW TITLES (exact, for row changes):\n" + (OUT / "titles.txt").read_text(encoding="utf-8").rstrip())


if __name__ == "__main__":
    main(sys.argv[1:])
