"""Serve the plan-today check-in panel to the desktop app's browser pane.

GET / (or /index.html) builds the panel on the spot (build_panel.build_current: the current pre-run
page plus today's meditation entry, for the current run, starting one if none exists today) and
serves it, so opening http://localhost:8765/ is the whole build step (2026-10-06). Any other GET
serves ~/.cache/plan-today/panel/ (updates.json, which the page polls). GET /health answers
"plan-today-panel". POST /submit writes the panel's answers to answers-<run id>.txt in that folder,
atomically, so a background watcher in the Claude session picks them up without the owner typing
anything. Binds to 127.0.0.1 only. Everything is sent with Cache-Control: no-store.

Two-minute page (2026-10-12, quick.py): POST /submit.json also writes quick-<run>.json, the steps
under ~2 min from those answers, so the page is ready the moment the user submits. GET /quick[?run=<id>]
builds it. POST /quick.json writes quick-answers-<run>.json (for apply_answers.py --quick) and POST
/quick-submit writes quick-answers-<run>.txt (the watcher's wake file, taken from "(run X)").
POST /send/prepare and /send/commit send a two-minute email at once (mailer.py; Oct 12): prepare
finds the thread, the recipients and any reply since the pre-run, commit sends after the page's
Undo window. Every send is recorded in sent-<run>.json.
"""
import json, re, http.server, importlib, os, sys, threading, traceback
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import panel_rows  # noqa: E402
import build_panel  # noqa: E402
import quick  # noqa: E402
import mailer  # noqa: E402
import chatsender  # noqa: E402

D = str(panel_rows.OUT)
_lock, _mt = threading.Lock(), {}


def _fresh_builder():
    """Reload the builder when its files changed, so an edited builder needs no server restart."""
    global build_panel, quick
    mt = {f: (HERE / f).stat().st_mtime for f in ("build_panel.py", "panel_rows.py", "quick.py")}
    if _mt and mt != _mt:
        importlib.reload(panel_rows)
        build_panel = importlib.reload(build_panel)
        quick = importlib.reload(quick)
    _mt.update(mt)
    return build_panel


class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k):
        super().__init__(*a, directory=D, **k)

    def _send(s, code, body, ctype):
        s.send_response(code)
        s.send_header("Content-Type", ctype)
        s.send_header("Content-Length", str(len(body)))
        s.end_headers()
        s.wfile.write(body)

    def do_GET(s):
        path = s.path.split("?", 1)[0]
        if path == "/health":
            return s._send(200, b"plan-today-panel", "text/plain")
        if path in ("/", "/index.html", "/quick"):
            try:
                with _lock:
                    if path == "/quick":
                        _fresh_builder()
                        m = re.search(r"run=([0-9A-Za-z-]+)", s.path)
                        html = quick.build(m.group(1) if m else None)
                    else:
                        html = _fresh_builder().build_current()[0]
                return s._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            except Exception:
                err = traceback.format_exc()
                sys.stderr.write(err)
                return s._send(500, ("plan-today panel build failed:\n\n" + err).encode("utf-8"), "text/plain; charset=utf-8")
        super().do_GET()

    def do_POST(s):
        if s.path in ("/send/prepare", "/send/commit"):
            return s._send_mail()
        if s.path not in ("/submit", "/submit.json", "/quick.json", "/quick-submit"):
            s.send_error(404)
            return
        body = s.rfile.read(int(s.headers.get("Content-Length", 0))).decode("utf-8", "replace")
        if s.path == "/submit.json":
            # The same answers as structured rows, for apply_answers.py (2026-10-08). Posted before
            # the text, so it exists by the time the session's watcher wakes on the .txt.
            try:
                data = json.loads(body)
                run = re.sub(r"[^0-9A-Za-z-]", "", data.get("run", "")) or "unknown"
            except ValueError:
                return s._send(400, b"bad json", "text/plain")
            panel_rows.write_atomic(Path(D) / f"answers-{run}.json", body)
            try:  # the two-minute page, ready at the same moment (2026-10-12)
                with _lock:
                    _fresh_builder()
                    quick.start(data)
            except Exception:
                sys.stderr.write(traceback.format_exc())
            return s._send(200, b"ok", "text/plain")
        if s.path == "/quick.json":
            try:
                run = re.sub(r"[^0-9A-Za-z-]", "", json.loads(body).get("run", "")) or "unknown"
            except ValueError:
                return s._send(400, b"bad json", "text/plain")
            panel_rows.write_atomic(Path(D) / f"quick-answers-{run}.json", body)
            return s._send(200, b"ok", "text/plain")
        if s.path == "/quick-submit":
            m = re.search(r"\(run ([0-9A-Za-z-]+)\)", body[:200])
            panel_rows.write_atomic(Path(D) / f"quick-answers-{m.group(1) if m else 'unknown'}.txt", body)
            return s._send(200, b"ok", "text/plain")
        # One file per run: each session's watcher waits only for its own run, so an old or
        # foreign session never wakes on someone else's Submit (2026-10-06: a test Submit woke five
        # idle dry-run sessions that all watched the shared answers.txt).
        m = re.search(r"\(run ([0-9A-Za-z-]+)\)", body[:200])
        run = m.group(1) if m else "unknown"
        panel_rows.write_atomic(Path(D) / f"answers-{run}.txt", body)
        s._send(200, b"ok", "text/plain")

    def _send_mail(s):
        try:
            d = json.loads(s.rfile.read(int(s.headers.get("Content-Length", 0))).decode("utf-8"))
            if s.path == "/send/prepare":
                head = build_panel.PRERUN.read_text(encoding="utf-8")[:400] if build_panel.PRERUN.exists() else ""
                g = re.search(r"^generated:\s*(\S+)", head, re.M)
                since = datetime.fromisoformat(g.group(1)).timestamp() if g else 0
                msg = d.get("msg") or {}
                sender = chatsender if msg.get("via") in chatsender.VIAS else mailer
                out = sender.prepare(msg, since, bool(d.get("force")))
            else:
                pid = d.get("id", "")
                out = (chatsender if pid in chatsender._pending else mailer).commit(pid)
                if out.get("ok"):
                    run = re.sub(r"[^0-9A-Za-z-]", "", d.get("run", "")) or "unknown"
                    f = Path(D) / f"sent-{run}.json"
                    with panel_rows.locked():
                        log = json.loads(f.read_text(encoding="utf-8")) if f.exists() else []
                        log.append({"n": d.get("n"), "task": d.get("task"), "at": datetime.now().isoformat(timespec="seconds"), **out})
                        panel_rows.write_atomic(f, json.dumps(log, ensure_ascii=False, indent=1))
        except Exception as e:
            sys.stderr.write(traceback.format_exc())
            out = {"ok": False, "error": f"{type(e).__name__}: {e}"[:300]}
        return s._send(200, json.dumps(out).encode("utf-8"), "application/json")

    def end_headers(s):
        s.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(s, *a):
        pass


if __name__ == "__main__":
    os.makedirs(D, exist_ok=True)
    http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1]) if len(sys.argv) > 1 else 8765), H).serve_forever()
