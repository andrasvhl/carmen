"""Push findings into the open check-in panel (adopted 2026-10-06; streams 2026-10-06).

Usage: python3 update_panel.py [delta.json | - | '<inline json>'] [--stream <name>] [--done]
  The payload is a file, "-" for stdin, or inline JSON (cheap for one finding):
    {"new": [[group, [row, ...]], ...],
     "changes": [{"n": exact row title, "note": "Update 10:12: Alex declined (WhatsApp)",
                  "g": new guess, "w": 0/1 waiting, "lc": 0 to clear the unsure flag (all optional)},
                 {"n": title, "row": {full row}, "note": ...},   # replace the row in place
                 {"n": title, "drop": 1, "note": ...}]}          # remove a duplicate
  --stream <name>  which background pass this is (the run expects "delta" and "q4" unless
                   build_panel.py --new-run --streams said otherwise). --done marks only that
                   stream finished; the panel says "up to date" once every expected stream is.
  --done without --stream marks the whole run finished (the old behaviour).
  No payload with --done just closes the stream.
The page polls ~/.cache/plan-today/panel/updates.json every 3 s. Updates are cumulative: each call
appends and bumps seq under a lock (several agents may call at once), and the page applies only what
it has not seen, also after a stream's --done. New rows get a "new" tag. A change re-guesses a row
only if the owner has not touched it yet; otherwise it adds the amber line and keeps the user's answer.
"""
import json, sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import panel_rows as pr  # noqa: E402


def parse(argv):
    args, stream, done = list(argv), None, False
    if "--stream" in args:
        i = args.index("--stream"); stream = args[i + 1]; del args[i:i + 2]
    if "--done" in args:
        done = True; args.remove("--done")
    d = {}
    if args:
        a = args[0]
        if a == "-":
            d = json.loads(sys.stdin.read() or "{}")
        elif a.lstrip().startswith("{"):
            d = json.loads(a)
        else:
            d = json.loads(Path(a).read_text(encoding="utf-8"))
    return d, stream, done


QUOTES = Path.home() / ".cache" / "plan-today" / "quotes.json"


def expand_quotes(rows):
    """ctx q entries may be message ids from delta.txt ("w3.2", "m1.1"); swap in the verbatim
    line from quotes.json so quotes are exact and the model never retypes them (2026-10-06)."""
    if not rows:
        return
    try:
        qmap = json.loads(QUOTES.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    for r in rows:
        for c in r.get("ctx") or []:
            if isinstance(c, dict) and isinstance(c.get("q"), list):
                c["q"] = [qmap.get(x.strip(), x) if isinstance(x, str) else x for x in c["q"]]


SUPPRESSED = pr.OUT / "suppressed.json"


def hide_dropped(d):
    """A new taskless row the user dropped in the last 14 days
    is not pushed unless the person wrote since (then it carries the lc line). Every decision is
    appended to suppressed.json, so a wrong hide can be found (dropped.py)."""
    import dropped
    gone = dropped.load()
    if not gone or not d.get("new"):
        return
    inbox = Path(__file__).resolve().parents[3] / "Inbox"
    log = []
    d["new"] = [[g, dropped.apply(rows, gone, log, has_task=lambda r: bool(r.get("lk")) and (inbox / f"{r['lk']}.md").exists())]
                if g != "From today's meditation" else [g, rows] for g, rows in d["new"]]
    d["new"] = [[g, rows] for g, rows in d["new"] if rows]
    if log:
        try:
            old = json.loads(SUPPRESSED.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            old = []
        u = pr.read_updates()
        stamp = datetime.now(pr.TZ).isoformat(timespec="seconds")
        pr.write_atomic(SUPPRESSED, json.dumps((old + [dict(x, at=stamp, panel_run=u.get("run")) for x in log])[-200:],
                                               ensure_ascii=False, indent=1))
        for x in log:
            if x["action"] != "keep":
                print(f"dropped row {x['action']}: {x['row']} (dropped {x['on']} as {x['dropped']})")


def main(argv):
    d, stream, done = parse(argv)
    expand_quotes([r for _, rows in d.get("new", []) for r in rows] +
                  [c["row"] for c in d.get("changes", []) if isinstance(c.get("row"), dict)])
    for _, rows in d.get("new", []):
        for r in rows:
            pr.normalise(r)
            if not r.get("g"):  # every row carries a guess
                r["g"], r["lc"] = "soon", r.get("lc") or "no guess from the agent"
    hide_dropped(d)
    # R7 (owner decision, 2026-10-13): new rows that are only a quick reply go to the closed two-minute section
    routed, quick_rows = [], []
    for g, rows in d.get("new", []):
        keep = [r for r in rows if not pr.to_quick(r)]
        quick_rows += [dict(r, og=g) for r in rows if pr.to_quick(r)]
        if keep:
            routed.append([g, keep])
    if quick_rows:
        routed.append([pr.QK, quick_rows])
    if "new" in d:
        d["new"] = routed
    for c in d.get("changes", []):
        if isinstance(c.get("row"), dict):
            pr.normalise(c["row"])
    with pr.locked():
        u = pr.read_updates()
        if not pr.run_is_current(u):  # pushing before any run: start one so GET / keeps these rows
            pre = Path(__file__).resolve().parents[2] / "claude/plan-today-prerun.md"
            u = pr.new_run(pr.since_of(pre.read_text(encoding="utf-8")[:400]) if pre.exists() else "the pre-run")
        u["new"] = u.get("new", []) + d.get("new", [])
        u["changes"] = u.get("changes", []) + d.get("changes", [])
        u["seq"] = u.get("seq", 0) + 1
        expected = u.get("streams") or pr.DEFAULT_STREAMS
        sdone = set(u.get("sdone", []))
        if done:
            sdone |= {stream} if stream else set(expected)
        u["sdone"] = sorted(sdone)
        u["done"] = set(expected) <= sdone
        n_new = sum(len(r) for _, r in u["new"])
        n_chg = len(u["changes"])
        since = u.get("since", "the pre-run")
        found = f"{n_new} new, {n_chg} updated since {since}" if (n_new or n_chg) else f"Nothing new since {since}"
        left = [s for s in expected if s not in sdone]
        u["status"] = found + ("." if u["done"] else f". Still checking ({', '.join(left)})…")
        pr.write_updates(u)
    print(u["status"], "seq", u["seq"])


if __name__ == "__main__":
    main(sys.argv[1:])
