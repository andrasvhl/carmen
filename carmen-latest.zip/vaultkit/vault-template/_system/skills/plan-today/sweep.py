"""The plan-day sweep for plan-today (owner decision, 2026-10-07): no task stays scheduled on or before the
plan day unless it is meant for it.

Usage:
  python3 sweep.py --day YYYY-MM-DD [--json]
      Lists every open task in Inbox/ (type: action, status not done/cancelled/dropped) with
      `scheduled` on or before that day: title, scheduled, due, waiting, build tag. Read-only.
  python3 sweep.py --apply <file.json>
      Takes [{"title": exact task title, "scheduled": "YYYY-MM-DD" or null, "log": "text"}, ...].
      Writes the frontmatter `scheduled` (null removes it) and one `## Log` line `- <Mon D> · <log>`
      at the bottom of the note (creates `## Log` if missing). Never touches due, priority, quadrant
      or timeEstimate. Prints one line per task; exits 1 if any title was not found.

Why its own script: a hand-rolled grep missed tasks in the sweep. Frontmatter is parsed
per line here (BOM, CRLF, quotes, inline comments, dates with a time, block lists), with no
dependency on PyYAML (not installed on the Mac).
"""
import json, re, sys
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

VAULT = Path(__file__).resolve().parents[3]
INBOX = VAULT / "Inbox"
TZ = ZoneInfo("America/Los_Angeles")
CLOSED = {"done", "cancelled", "canceled", "dropped"}
FM = re.compile(r"\A﻿?---[ \t]*\r?\n(.*?)\r?\n---[ \t]*(?:\r?\n|\Z)", re.S)


def _scalar(v):
    v = v.strip()
    if v[:1] in "'\"" and v[-1:] == v[:1] and len(v) >= 2:
        return v[1:-1]
    return re.sub(r"\s+#.*$", "", v).strip()


def parse_fm(text):
    """Frontmatter as {key: str or [str]}; None if the note has none."""
    m = FM.match(text)
    if not m:
        return None
    out, key = {}, None
    for line in m.group(1).splitlines():
        line = line.rstrip("\r")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        item = re.match(r"^\s+-\s*(.*)$", line) or re.match(r"^-\s+(.*)$", line)
        if item and key:
            if not isinstance(out.get(key), list):
                out[key] = [] if out.get(key) in ("", None) else [out[key]]
            out[key].append(_scalar(item.group(1)))
            continue
        kv = re.match(r"^([A-Za-z_][\w-]*)\s*:\s*(.*)$", line)
        if kv:
            key, v = kv.group(1), kv.group(2)
            if v.strip().startswith("[") and v.strip().endswith("]"):
                out[key] = [_scalar(x) for x in v.strip()[1:-1].split(",") if x.strip()]
            else:
                out[key] = _scalar(v)
    return out


def _date(v):
    if isinstance(v, list):
        v = v[0] if v else ""
    m = re.match(r"\d{4}-\d{2}-\d{2}", (v or "").strip())
    return m.group(0) if m else ""


def _tags(fm):
    t = fm.get("tags", [])
    return [x.lstrip("#").lower() for x in (t if isinstance(t, list) else re.split(r"[,\s]+", t)) if x]


def open_tasks(day):
    rows = []
    for p in sorted(INBOX.glob("*.md")):
        try:
            text = p.read_text(encoding="utf-8")
        except OSError:
            continue
        fm = parse_fm(text)
        if not fm or str(fm.get("type", "")).lower() != "action":
            continue
        if str(fm.get("status", "")).lower() in CLOSED:
            continue
        sch = _date(fm.get("scheduled"))
        if not sch or sch > day:
            continue
        body = text[FM.match(text).end():]
        rows.append({"title": p.stem, "scheduled": sch, "due": _date(fm.get("due")) or None,
                     "waiting": str(fm.get("waiting", "")).lower() == "true",
                     "build": "build" in _tags(fm) or bool(re.search(r"(^|\s)#build\b", body)),
                     "status": fm.get("status", "")})
    return sorted(rows, key=lambda r: (r["scheduled"], r["title"].lower()))


def _set_scheduled(text, value):
    m = FM.match(text)
    nl = "\r\n" if "\r\n" in m.group(0) else "\n"
    lines = m.group(1).split(nl) if nl in m.group(1) else m.group(1).splitlines()
    out, done, skip = [], False, False
    for line in lines:
        if skip and re.match(r"^\s+-", line):
            continue  # an old block-list value under scheduled:
        skip = False
        if re.match(r"^scheduled\s*:", line):
            if value:
                out.append(f"scheduled: {value}")
            done, skip = True, True
            continue
        out.append(line)
    if value and not done:
        out.append(f"scheduled: {value}")
    start = "﻿" if text.startswith("﻿") else ""
    return start + "---" + nl + nl.join(out) + nl + "---" + nl + text[m.end():]


def _add_log(text, line):
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = text.rstrip("\r\n").split(nl)
    idx = [i for i, l in enumerate(lines) if re.match(r"^##\s+Log\s*$", l)]
    if not idx:
        return nl.join(lines) + nl + nl + "## Log" + nl + line + nl
    i = idx[-1] + 1  # end of the Log section: the next heading of level 1-2, or the end
    while i < len(lines) and not re.match(r"^#{1,2}\s", lines[i]):
        i += 1
    j = i
    while j > idx[-1] + 1 and not lines[j - 1].strip():
        j -= 1
    lines.insert(j, line)
    return nl.join(lines) + nl


def apply(items):
    today = datetime.now(TZ).date()
    stamp = today.strftime("%b ") + str(today.day)
    missing, written = 0, []
    for it in items:
        title, value, log = it.get("title", ""), it.get("scheduled"), (it.get("log") or "").strip()
        if value:
            value = date.fromisoformat(str(value)[:10]).isoformat()
        p = INBOX / f"{title}.md"
        if not title or not p.exists():
            print(f"NOT FOUND  {title}")
            missing += 1
            continue
        text = p.read_text(encoding="utf-8")
        if not FM.match(text):
            print(f"NO FRONTMATTER  {title}")
            missing += 1
            continue
        text = _set_scheduled(text, value)
        if log:
            text = _add_log(text, f"- {stamp} · {log}")
        p.write_text(text, encoding="utf-8")
        written.append(str(p))
        print(f"ok  {title} → {value or 'unscheduled'}")
    # scripts run the same task schema check the Edit hook runs (C3, the owner Oct 13)
    if written:
        import subprocess
        vt = Path.home() / "automation" / "bin" / "vt"
        out = subprocess.run([str(vt), "tasks", *written], capture_output=True, text=True).stdout.strip()
        if out:
            print("\nFOR CLAUDE (schema, fix with Edit):\n" + out)
    return 1 if missing else 0


def main(argv):
    if "--apply" in argv:
        f = argv[argv.index("--apply") + 1]
        return apply(json.loads(Path(f).read_text(encoding="utf-8")))
    if "--day" not in argv:
        print(__doc__, file=sys.stderr)
        return 2
    day = date.fromisoformat(argv[argv.index("--day") + 1]).isoformat()
    rows = open_tasks(day)
    if "--json" in argv:
        print(json.dumps(rows, ensure_ascii=False, indent=1))
        return 0
    print(f"{len(rows)} open tasks scheduled on or before {day}")
    for r in rows:
        bits = [f"sch {r['scheduled']}", f"due {r['due']}" if r["due"] else "",
                "waiting" if r["waiting"] else "", "build" if r["build"] else ""]
        print(f"- {r['title']}  ({' · '.join(b for b in bits if b)})")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
