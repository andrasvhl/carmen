"""The two-minute page: every step under ~2 min, ready to do in one sitting (owner decision, 2026-10-12).

PRFAQ: "Quick overview allows me to finish 10 2-minute tasks within 5 minutes." After Submit on the
check-in panel, Claude plans the day and this page is ready at the same time: one row per step,
grouped Email / Chat (LinkedIn, Messenger, Instagram) / WhatsApp / Other, the text that would be sent printed and editable. Email: "Send via
Claude" sends it at once (mailer.py: in its thread, 8 s Undo, held when someone replied since). WhatsApp: copy the text, he sends it (Claude
never sends WhatsApp, for now). Other: a one-liner, plus "Let Claude do this" where Claude can.
Every row: done, drop (the step only, never the task), or "not 2 min" with his own estimate (it
becomes work for today's plan), plus a note for Claude. Done, drop and sent fold the row at once;
"see more" shows the last 5 messages.
Spec: reference/panel.md § Two-minute page; rule: _system/scheduling/scheduling-rules.md rule 11.

The same architecture as the check-in panel, on purpose:
- quick.html is a template like panel.html: the builder injects panel.html's <style> block and its
  shared JS helpers (between /*shared>*/ and /*<shared*/), so the cards look and behave the same and
  the two pages cannot drift apart.
- quick-<run>.json is both the page's data and its live feed, like updates.json: every write goes
  through panel_rows.locked() and an atomic replace; the page polls it every 3 s and applies each
  change once (rows he already touched keep his answer and get an amber line).
- panel_server.py writes it on POST /submit.json (select() below), serves GET /quick, and takes the
  answers on POST /quick.json (structured, for apply_answers.py --quick) and POST /quick-submit
  (the text, for a session without the host's sendPrompt).

Usage (the main session, right after the check-in Submit):
  python3 quick.py --list [--run <id>]          rows on the page; "no draft" marks Other rows
  python3 quick.py '<json>' | file | - [--done] push changes: {"changes": [{"n": row title,
                                                "row": {full row}, "note": "..."}, {"n", "drop": 1}],
                                                "new": [row, ...]}; --done ends "Claude is drafting"
Order: priority, then the shortest step, then confident drafts first (order_key; the page keeps
it for pushed rows). Row fields: p (H|N|Z), u, lc (unsure draft), n (the step, as he will do it), task (the task title, or the row title for a taskless
row), lk, new, bkv, stv, grp (Email | Chat | WhatsApp | Other), m, s, ne, msg {via, acct, to, subj, body},
acts [{t, k, msg?}] (what Claude would do, the message itself included), then (the task's next step
after this one, from its first open Then, only when that is itself "(2 min)" or less), hist [[who, verbatim line], ...] (the last 5 messages, for "see
more"; a pushed row may carry its own), fresh.
"""
import json, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import panel_rows as pr  # noqa: E402

HERE = Path(__file__).resolve().parent
CHAT_VIAS = ("linkedin", "messenger", "instagram")  # Beeper, sent like mail (chatsender.py)
GROUPS = ("Email", "Chat", "WhatsApp", "Other")


def path(run):
    return pr.OUT / f"quick-{re.sub(r'[^0-9A-Za-z-]', '', run or '') or 'unknown'}.json"


def _qrow(r):
    """A check-in answer row -> a two-minute row, or None when it is not a two-minute item."""
    v = r.get("v")
    if r.get("gn") == "Not today" and not r.get("c"):
        return None  # untouched Not today rows get nothing (owner decision, Oct 13)
    # Waiting rows only when the chase is today (Oct 12 dry run: a trip and a friend were
    # waiting rows guessed today whose two-minute step was the nudge itself)
    if v in ("done", "drop", "later") or (r.get("wv") and v not in ("today", "tmrw")):
        return None
    quick_new = bool(r.get("new")) and r.get("bkv") == "quick"
    ne = pr.minutes(r.get("ne"))
    if not quick_new and not (ne and ne <= pr.QUICK_MAX) and not pr.to_quick(r):  # R7, Oct 13: up to 5 min
        return None
    qa = r.get("qa") or []
    msg = next((a["msg"] for a in qa if a.get("msg")), None)
    grp = "Other" if not msg else "WhatsApp" if msg.get("via") == "whatsapp" else "Chat" if msg.get("via") in CHAT_VIAS else "Email"
    step = pr.split_step(r.get("nx") or "")[0] or r.get("n", "")
    step = re.sub(r"\s*\((?:drafts?|text) ready\)", "", step).strip()  # the page shows the draft itself
    row = {"n": step if step != r.get("n") else r.get("n", ""), "task": r.get("lk") or r.get("n", ""),
           "lk": r.get("lk"), "new": bool(r.get("new")), "bkv": r.get("bkv"), "stv": r.get("stv"),
           "grp": grp, "m": r.get("m", ""), "s": r.get("s", ""), "ne": r.get("ne") or "2m",
           "p": r.get("pr") or "", "u": bool(r.get("u")), "lc": bool(r.get("lc")),
           "acts": [{"t": a.get("t", ""), "k": a.get("k", ""), **({"msg": 1} if a.get("msg") else {})} for a in qa]}
    after = then_step(r.get("lk"))
    if after:
        row["then"] = after
    if msg:
        row["msg"] = msg
    hist = history(r.get("ctx"))
    if hist:
        row["hist"] = hist
    return row


def then_step(lk):
    """The task's step after this one (its first open Then), so the page shows where it goes next."""
    if not lk:
        return ""
    try:
        text = (HERE.parents[2] / "Inbox" / f"{lk}.md").read_text(encoding="utf-8")
    except OSError:
        return ""
    m = re.search(r"^- \[ \] Then:\s*(.+)$", text, re.M)
    if not m:
        return ""
    step, mins = pr.split_step(m.group(1))
    # only a follow-up that is itself a two-minute step (owner decision, Oct 12): "only follow-up tasks
    # that can be done within 2 mins"
    return step if mins and mins <= pr.QUICK_MAX else ""


HIST_MAX = 5  # "see more": the messages leading up to this step, up to 5 (owner decision, Oct 12)


def history(ctx):
    """The last HIST_MAX verbatim lines from the row's ctx blocks, each [who, line]."""
    out = []
    for c in ctx or []:
        if isinstance(c, dict):
            out += [[c.get("who", ""), q] for q in c.get("q") or [] if isinstance(q, str) and q.strip()]
    return out[-HIST_MAX:]


def order_key(q):
    """owner decision, Oct 12: by priority (urgent first), then the shortest step, then the drafts Claude is
    surest of. Inside each channel group, so all WhatsApps are still done in one go."""
    return (0 if q.get("u") else 1, {"H": 0, "N": 1}.get(q.get("p"), 2),
            pr.minutes(q.get("ne")) or pr.QUICK_MAX, 1 if q.get("lc") else 0)


def select(answers):
    """Rows for the page from the posted check-in answers. Titles are made unique."""
    out, seen = [], set()
    for r in answers.get("rows", []):
        q = _qrow(r)
        if not q:
            continue
        if q["n"] in seen:
            q["n"] = f"{q['n']} ({q['task']})"
        seen.add(q["n"])
        out.append(q)
    return sorted(out, key=order_key)


def start(answers):
    """Write quick-<run>.json from the check-in answers (POST /submit.json). Returns the row count."""
    run = answers.get("run", "")
    rows = select(answers)
    with pr.locked():
        pr.write_atomic(path(run), json.dumps({"run": run, "plan_day": answers.get("plan_day", ""),
                                               "rows": rows, "seq": 0, "changes": [], "new": [],
                                               "done": False}, ensure_ascii=False))
    return len(rows)


def read(run):
    try:
        return json.loads(path(run).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def current_run(run=None):
    return run or pr.read_updates().get("run", "")


def build(run=None):
    """The page for `run` (default: the current check-in run)."""
    run = current_run(run)
    d = read(run)
    panel = (HERE / "panel.html").read_text(encoding="utf-8")
    style = re.search(r"<style>.*?</style>", panel, re.S).group(0)
    helpers = re.search(r"/\*shared>\*/(.*?)/\*<shared\*/", panel, re.S).group(1)
    tpl = (HERE / "quick.html").read_text(encoding="utf-8")
    head = pr_head().replace("<title>Check-in</title>", "<title>Two-minute page</title>")
    live = "<script>window.PT_RUN=" + json.dumps(run) + ";window.PT_QUICK=" + json.dumps(
        {"ready": d is not None, "plan_day": (d or {}).get("plan_day", "")}) + "</script>"
    rows = (d or {}).get("rows", [])
    return head + live + (tpl.replace("__STYLE__", style).replace("/*__HELPERS__*/", helpers)
                          .replace("__ROWS__", json.dumps(rows, ensure_ascii=False)))


def pr_head():
    import build_panel  # the same page head (colours, dark mode) as the check-in panel
    return build_panel.HEAD


def push(d, run=None, done=False):
    run = current_run(run)
    with pr.locked():
        q = read(run)
        if q is None:
            raise SystemExit(f"no two-minute page for run {run}: Submit the check-in first")
        for c in d.get("changes", []):
            if isinstance(c.get("row"), dict):
                via = (c["row"].get("msg") or {}).get("via")
                c["row"].setdefault("grp", "Email" if via == "mail" else "Chat" if via in CHAT_VIAS
                                    else "WhatsApp" if c["row"].get("msg") else "Other")
        q["changes"] = q.get("changes", []) + d.get("changes", [])
        q["new"] = q.get("new", []) + d.get("new", [])
        q["seq"] = q.get("seq", 0) + 1
        q["done"] = q.get("done") or done
        pr.write_atomic(path(run), json.dumps(q, ensure_ascii=False))
    return q


def rows_now(q):
    """The rows as the page shows them after every change (for --list)."""
    rows = {r["n"]: r for r in q.get("rows", [])}
    for c in q.get("changes", []):
        if c.get("drop"):
            rows.pop(c.get("n"), None)
        elif isinstance(c.get("row"), dict):
            rows.pop(c.get("n"), None)
            rows[c["row"]["n"]] = c["row"]
    for r in q.get("new", []):
        rows.setdefault(r["n"], r)
    return list(rows.values())


def main(argv):
    args = list(argv)
    run = None
    if "--run" in args:
        i = args.index("--run"); run = args[i + 1]; del args[i:i + 2]
    if "--list" in args:
        q = read(current_run(run))
        if q is None:
            print("no two-minute page yet for this run")
            return 0
        for r in rows_now(q):
            flag = "" if r.get("msg") or r["grp"] != "Other" else "  [no draft]"
            if (r.get("msg") or {}).get("needs_slot") or "[slot]" in (r.get("msg") or {}).get("body", ""):
                flag += "  [needs slot]"  # Oct 13: drafts from before Submit leave the time to the session
            print(f"{r['grp']:8} | {r['n']} | task: {r['task']} | {r.get('ne', '')}{flag}")
        return 0
    done = "--done" in args
    args = [a for a in args if a != "--done"]
    d = {}
    if args:
        a = args[0]
        d = json.loads(sys.stdin.read() or "{}") if a == "-" else json.loads(a) if a.lstrip().startswith("{") \
            else json.loads(Path(a).read_text(encoding="utf-8"))
    q = push(d, run, done)
    print(f"two-minute page: seq {q['seq']}, {len(rows_now(q))} rows" + (", drafting done" if q["done"] else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
