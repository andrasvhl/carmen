#!/usr/bin/env bash
# Day-plan context for plan-today, read while the user clicks. Four parts so each
# tool output stays under the ~30 KB limit; run all four as parallel calls in ONE message:
#   context_read.sh calendar [YYYY-MM-DD]   every calendar from the plan day on (waits for the fetch).
#       The plan day is the argument, else the current run's plan_day in updates.json, else today
#       (an evening run plans tomorrow, so its calendar starts tomorrow).
#   context_read.sh rules      North Star
#   context_read.sh scheduling _system/scheduling/ (working-conditions, scheduling-rules, durations) + reference/day-plan.md
#   context_read.sh plan       Week Structure + reference/after-submit.md
set -uo pipefail
V="$HOME/Obsidian/<VAULT_NAME>"
S="$HOME/.claude/skills/plan-today"
C="$HOME/.cache/plan-today/calendar.txt"
show() { echo "==== $1"; cat "$1"; echo; }
case "${1:-}" in
  calendar)
    for i in $(seq 25); do [ -n "$(find "$C" -mmin -3 2>/dev/null)" ] && break; sleep 1; done
    [ -n "$(find "$C" -mmin -3 2>/dev/null)" ] || echo "(calendar.txt is stale or missing: the fetch has not landed)"
    today="$(TZ=America/Los_Angeles date +%Y-%m-%d)"
    U="${PLAN_TODAY_CACHE:-$HOME/.cache/plan-today/panel}/updates.json"
    day="${2:-$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("plan_day") or "")' "$U" 2>/dev/null)}"
    [[ "$day" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]] && [[ ! "$day" < "$today" ]] || day="$today"
    echo "==== calendar, plan day $day onward (earlier days omitted; today is $today)"
    # Keep calendar headers and event lines dated on the plan day or later.
    awk -v d="$day" '/^###/ {print; next} /^- [0-9]{4}-[0-9]{2}-[0-9]{2}/ { if (substr($2,1,10) >= d) print; next } {print}' "$C" ;;
  rules) show "$V/Areas/North Star.md" ;;
  scheduling) for f in working-conditions scheduling-rules durations; do show "$V/_system/scheduling/$f.md"; done; show "$S/reference/day-plan.md" ;;
  plan)  show "$V/Areas/Personal/Week Structure.md"; show "$S/reference/after-submit.md" ;;
  *) echo "usage: context_read.sh calendar [YYYY-MM-DD]|rules|scheduling|plan" >&2; exit 2 ;;
esac
