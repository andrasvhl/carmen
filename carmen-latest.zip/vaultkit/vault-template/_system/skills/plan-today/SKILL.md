---
name: plan-today
description: Run the user's morning planning after the daily meditation: check where every live task stands, agree today's plan and put it in the calendar, in under 30 minutes, ideally 20. Use when the user presses "Work through with Claude" on a Meditation Journal entry, or says "plan today", "plan my day", "morning run", "meditation run", "work through my journal", or "what does today look like". Pulls mail, WhatsApp and vault changes in parallel, shows a one-click check-in panel with a prefilled guess per task, then fits today into the calendar. Owns the meditation journal flow. Does NOT decide importance (that is `prioritise`) and does not plan the week unless the user asks at the end (that is `schedule-work`).
---

# Plan today

The morning run, started from the meditation. **Its job is to put the plan before the doing.**
A common failure is starting to execute on the anxiety-producing meditation items without checking
the day's plan first, and rushing instead of prioritising. So this skill makes the user see where
everything stands and agree today **before** any task gets worked.

## Fast lane

**Two short messages, nothing read, researched or planned before them**, not even the rest of this
file. **Tools in a message only start once the whole message is written**, so message 1 holds only
what puts the panel on screen, and everything else goes in message 2. Panel in about 10 s.

**Message 1, three parallel calls:**

1. **Build**, one Bash call in the foreground (about 0.2 s):
   `python3 ~/.claude/skills/plan-today/build_panel.py --new-run --streams delta,q4 --journal "<entry>"`
   (`<entry>` is the `File:` line of the button's prompt; leave `--journal` out when the user typed
   "plan today"). It prints `<run id> · plan day <Thu Oct 8> · q4 pending <N>`; with N = 0 it has
   already closed the `q4` stream, so **no meditation agent is launched** (an agent with nothing to
   do still costs time and tokens). Add `--plan-day today|tomorrow|YYYY-MM-DD` only when the user
   names another day (§ Definitions, plan day).
2. **Fetch**, Bash with `run_in_background: true`: `~/.claude/skills/plan-today/fetch_delta.sh`
   (about 10 s). Its output ends with `new messages <N>`; with N = 0 it has closed the delta stream
   itself and prints `NOTHING NEW` (the delta agent then stops after its first step).
3. **Open the panel:** `mcp__Claude_Browser__preview_start` with `url` `http://localhost:8765/`.
   The server runs permanently as a LaunchAgent (installed by `install_panel_server.sh`), so no
   server is started and no port can collide. It builds the page on every GET /; a page loaded a
   moment before the new run sees the new run id and reloads itself. **Only if the URL does not
   load** (`curl -s localhost:8765/health` is not `plan-today-panel`): run
   `install_panel_server.sh`, then open again.

**Message 2, right after, in parallel:**

4. **The watcher**, Bash with `run_in_background: true`:
   `F=~/.cache/plan-today/panel/answers-<run id>.txt; while [ ! -f $F ]; do sleep 1; done; cat $F`
   with `<run id>` from the build's output. **Only this run's file**: Submit writes
   `answers-<run id>.txt`, so an old or foreign session never wakes on someone else's Submit.
5. **The delta agent**, always (`run_in_background: true`): `subagent_type: plan-today-delta`,
   prompt `Inputs: today <YYYY-MM-DD>.` It starts now and its first read waits for the fetch
   (launching it only when the fetch's notification reaches the session costs time, because
   notifications land between the session's own turns). If the fetch found nothing, the agent sees
   NOTHING NEW and stops after one step.
6. **The meditation agent, only if the build said `q4 pending` > 0** (`run_in_background: true`):
   `subagent_type: plan-today-q4`, prompt `Inputs: entry <entry path>, today <YYYY-MM-DD>.`

The agents' instructions are their definitions (`agents/delta.md`, `agents/q4.md` in this folder,
the only copies, linked into `~/.claude/agents/`), so they start knowing the job. The model is each
file's `model:` line. **If the types are missing** (links not installed), fall back to
`general-purpose` with `Follow ~/.claude/skills/plan-today/agents/<delta|q4>.md. Inputs: …`.

**Only after message 2**, the three opening lines to the user, nothing more:

> Pulling mail, WhatsApp and vault changes now. You'll get one panel: every task that needs a
> decision now, with my guess already clicked. Change only what's wrong, then we fit <today |
> tomorrow> into the calendar.

`<today | tomorrow>` names the plan day. Which rows show: `reference/panel.md` § Which rows appear.

**Then, while the user clicks:** check the panel rendered (`reference/panel.md`, render check:
`.row` count = lines in titles.txt); check the pre-run's `generated:` date, and if it is not today,
say so in one line and run the full pull (`reference/background.md`; an evening run uses that
morning's pre-run, which is fine). The context reads happen now, in **one message of four parallel
Bash calls by the session itself**: `~/.claude/skills/plan-today/context_read.sh calendar`,
`… rules`, `… scheduling` and `… plan` (calendar from the plan day, read from the run, to 5 days
ahead from the fetch, every calendar in the account; North Star; working-conditions
(`_system/working-conditions.md`), scheduling-rules and durations (`_system/scheduling/`) with
`reference/day-plan.md`; the week-structure note with `reference/after-submit.md`; all preloaded so
nothing is read at Submit). Several parts because a single output over about 30 KB is saved to a
file and costs extra reads, and one call per calendar is far slower. So the day plan
(`reference/day-plan.md`) costs no extra time at Submit. A calendar in calendar.txt that is not in
schedule-work's roster is a question for the user (`reference/after-submit.md`). The delta and
meditation agents push into the panel themselves; their reports need no action unless one says
`FETCH FAILED`: then tell the user in one line that the panel shows the pre-run state, and close
the stream with `update_panel.py <empty json> --stream delta --done`.

**The agents' model** (for example Sonnet or Haiku) is the user's choice. Until it is set, leave
`model` out so they inherit the session's.

**Why a fast lane:** with agents launched only after the panel and fetches done by agents through
many tool calls, the panel takes about 25 s and updates take minutes. Now the fetch is one script,
started in the first message beside the panel, and agents only judge.

Vault root: `$VAULT_PATH`

**Target: under 30 minutes in total, ideally 20.** About 10 s to the check-in panel (background
done in 30-45 s, while the user clicks), 10 s for the must-do check, 2-3 min for the day plan.
Every design choice below serves that number; if a run takes longer, that is the first thing to fix
(see *Improving this skill*).

Decision record: [[_system/daily-loop|daily-loop]].

## Definitions

One meaning per word, in every file of this skill; the other files link here instead of restating
these.

- **Real day:** the date the run happens on. The *today* and *tmrw* answers are real days, and
  "overdue" and the relative date labels count from it.
- **Plan day:** the day a run plans: tomorrow when it starts at or after 18:00 local time, else
  today; `--plan-day` overrides it. The must-do question, the sweep, the day plan and its calendar
  blocks are for the plan day.
- **Guess** (`g`): Claude's prefilled answer on a row (today / soon / later / done / drop). The word
  "today" in a guess means the plan day, so it shows as *tmrw* on an evening run.
- **Waiting:** the ball is with someone else: `waiting: true` plus a `- [ ] Waiting: <who>, on
  <what>` line in `## Next action`, always written together (§ Scope). A waiting row shows on its
  chase date or when a message changed it.
- **Chase date:** a waiting task's `scheduled`, from the task itself ("follow up on <date>") or when
  a reply is reasonably due, never a batch slot; a new message on it re-derives it.
- **Blocked:** a Waiting line that names another task (`[[…]]`): no date and no row; it comes back
  when the blocker closes or the blocked task's own `due` is 14 days out, as "Blocked by X, due in
  N days".
- **Due:** a real external deadline only; a date someone owes the user is a chase date. A passed or
  settled due is re-derived through the user's `dq` answer on the card, the only way Submit writes
  `due`.
- **Two-minute item:** a next step of 5 min or less (scheduling-rules rule 11). In the check-in, the
  ones that are only a message or a click sit in the closed "Straight to the two-minute page"
  section (R7); after Submit they are on the two-minute page (`/quick`).
- **The groups**, in this order: From today's meditation · Overdue · Scheduled today, or Left over
  from today on a run that plans a later day · Scheduled tomorrow or Scheduled <plan day> (only on
  such a run) · Waiting · Due or scheduled <the day after the plan day> · New from mail and
  WhatsApp · Straight to the two-minute page · Not today. Empty groups are skipped.
- **Pre-run:** the server job `plan_today_prerun`, which writes the plan-today pre-run page each
  morning at 08:00. When the page is not from today, the session runs the **full pull** instead
  (`reference/background.md`).
- **Background agents:** *delta* (mail, WhatsApp and calendar since the pre-run; `agents/delta.md`,
  stream `delta`) and *meditation* (the journal's items; `agents/q4.md`, stream id `q4`).

## Scope

| Writes | Only when |
|---|---|
| `status: done` / `cancelled` | the user answered *done* (`done`) or *drop* (`cancelled`, log line says `dropped`) in the panel. Both set `completedDate`. Dropped work must not count as done work; every cockpit view and script treats `cancelled` as closed |
| `waiting` | the user toggled the waiting button. **Always write both halves together** (otherwise a task can say "waiting" in its text while `waiting: false`): `waiting: true` plus a `- [ ] Waiting: <who>, on <what>` line in `## Next action`, or `waiting: false` and that line ticked. A row the pre-run flags `waiting_mismatch` gets both halves fixed by the user's answer |
| `scheduled` | from the user's panel answers, the day plan the user approved, and the plan-day sweep the user okayed (`sweep.py --apply`) |
| `due` | only through the user's `dq` answer on the card (*move / clear* or *keep*; `reference/panel.md`, field `dq`), never from a date someone owes the user (§ Definitions, due) |
| one `## Log` line per row the user changed, or whose guess Submit applied outside Not today | after the user submits the panel. An untouched Not today row gets nothing: no log line, no date question, no two-minute page, no batched slot |
| `## Next action` steps | the user's `Next:` note, or the pre-run or a background agent found the next step changed. **The pre-run already ticks steps the data proves done and sets very certain next steps**; check the task note before writing the same change twice |
| `## Current context` | **never by the session**: the pre-run owns it and replaces it each morning ([[plan-today]] § Task writes before Submit) |
| calendar blocks for the plan day | after the user agrees the day's plan |
| new task notes for new rows (meditation items, mail and WhatsApp) | on Submit, by the user's "becomes" answer: Submit is the confirmation (`reference/after-submit.md`, *"Becomes"*) |
| new task notes from the journal's anxious and excited answers | at the end, through `commit-to-action`, propose-then-confirm (`reference/day-plan.md` § 6) |

**Never writes `priority` or `quadrant`.** Those are `prioritise`'s. **Estimates** are the one
exception to "the user's answers only": Submit writes each row's accepted or corrected task
estimate to `timeEstimate` (minutes) and its Next-step estimate inline on the Next line,
`(N min)`, through `apply_answers.py`. *Soon* is a date within the next three days, not a priority
bump. **Never edits the journal entry.**

## The run

**After Submit, `apply_answers.py --run <run id>` does the mechanical writes**; only its FOR CLAUDE
list is handled by hand. Details in `reference/after-submit.md`.

**The flow is meditation → check-in panel → Submit → day plan and the two-minute page, side by
side.** Submit writes the two-minute page at the same moment (`http://localhost:8765/quick`,
`quick.py`): every two-minute item (§ Definitions), by channel, with the text ready. The user can
open it before or after agreeing the plan. `reference/after-submit.md` § The two-minute page has
the session's part.

The fast lane above starts everything. The rest lives in `reference/`, read only when its step
comes (so that nothing after the fast lane is weighed before the first call):

1. **Background work** (pre-run use, the delta and meditation agents, what each finding carries,
   the full pull if the pre-run is not from today): [[_system/skills/plan-today/reference/background|reference/background.md]].
2. **The check-in panel** (build, serve, live updates, row fields, panel rules, the keyed-table
   fallback): [[_system/skills/plan-today/reference/panel|reference/panel.md]].
3. **While the user clicks and after Submit** (what to write, log lines, "becomes", the plan-day
   sweep, outward actions with their stale check): [[_system/skills/plan-today/reference/after-submit|reference/after-submit.md]].
   **Preloaded while the user clicks** (fast lane, *Then, while the user clicks*), so nothing is
   read at Submit.
4. **Must-do check, the day plan, then work or the week, then commit the rest** (preloaded with
   the scheduling docs, `context_read.sh scheduling`):
   [[_system/skills/plan-today/reference/day-plan|reference/day-plan.md]].

## Improving this skill

**Standing convention, applies to every skill in this vault.** When the user pushes back on how a
run went, or changes something proposed, **treat it as design input rather than a correction to
apply silently**: convert it into concrete, specific options and let the user choose. Quiet
compliance wastes the most valuable moment a skill gets: right after it has been used for real.
Ground proposals in what actually happened in that run rather than in general reasoning; offer the
review after a real run rather than waiting to be asked; and record each adopted change in the
skill file with its reason, so a later reader doesn't quietly revert it. **Never edit a skill while
a run of it is in progress**: collect the improvements, say so, and apply them once the run ends;
amending the process mid-flight makes the user follow a moving target while doing the work.

**Specific to this skill: time the run.** Report the minutes at the end of every run. Over 30
minutes is a defect; name the step that ate the time.

**End every run with a retro:** right after the run time, ask two questions, *what worked, what
didn't*. Each answer becomes a change here or in the reference file that owns it, applied after the
run. Rejected alternatives: asking only on runs over 5 min, and a retro box in the panel.

**Retro log:** one entry per run in the skill's history note in `reference/`.
