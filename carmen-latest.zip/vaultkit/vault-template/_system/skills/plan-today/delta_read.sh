#!/usr/bin/env bash
# Inputs for the plan-today delta agent, in parts that each stay under the ~30 KB tool-output
# limit (2026-10-06: one 82 KB read was saved to a file and cost the agent 5 extra calls).
# Run ALL parts as parallel calls in ONE message:
#   delta_read.sh messages 1|2|3   titles + the lossless message digest, 25 KB pages (waits for the fetch)
#   delta_read.sh rows             the pre-run rows, one line each: group | title | guess | Status | Next
#   delta_read.sh calendar         every calendar, today to 5 days ahead, descriptions cut to 80 chars
set -uo pipefail
P="$HOME/.cache/plan-today"
V="$HOME/Obsidian/<VAULT_NAME>"
wait_fresh() { for i in $(seq 25); do [ -n "$(find "$1" -mmin -3 2>/dev/null)" ] && return 0; sleep 1; done; return 1; }
case "${1:-}" in
  messages)
    page="${2:-1}"
    wait_fresh "$P/delta.txt" || { echo "FETCH FAILED: delta.txt missing or stale after 25 s"; exit 0; }
    if [ "$page" = 1 ]; then
      echo "=== TITLES (exact, use verbatim)"; cat "$P/panel/titles.txt"
      grep -q "^NOTHING NEW" "$P/fetch.out" 2>/dev/null && echo "=== NOTHING NEW: the fetch closed the delta stream; report and stop"
    fi
    python3 - "$P/delta.txt" "$page" <<'PY'
import sys
t = open(sys.argv[1], encoding="utf-8").read()
n, size = int(sys.argv[2]), 25000
pages = [t[i:i + size] for i in range(0, len(t), size)] or [""]
print(f"=== MESSAGES page {n} of {len(pages)}")
print(pages[n - 1] if n <= len(pages) else "(no such page)")
PY
    ;;
  rows)
    python3 - "$V/_system/claude/plan-today-prerun.md" <<'PY'
import json, re, sys
t = open(sys.argv[1], encoding="utf-8").read()
m = re.search(r"```json\n(.*?)\n```", t, re.S)
print("=== PRE-RUN ROWS (group | title | guess, waiting | Status | Next)")
for g, rs in (json.loads(m.group(1))["rows"] if m else []):
    for r in rs:
        print(f"{g} | {r.get('n', '')} | {r.get('g', '')}{', waiting' if r.get('w') else ''} | {r.get('s', '')} | {r.get('nx', '')}")
PY
    ;;
  calendar)
    wait_fresh "$P/calendar.txt" || { echo "(calendar.txt missing or stale)"; exit 0; }
    today="$(TZ=America/Los_Angeles date +%Y-%m-%d)"
    echo "=== CALENDAR $today onward"
    awk -v d="$today" '/^###/ {print; next} /^- [0-9]{4}-[0-9]{2}-[0-9]{2}/ { if (substr($2,1,10) >= d) { n=split($0,a," \\| "); out=a[1]; for(i=2;i<=n;i++){ s=a[i]; if(i==n && length(s)>80) s=substr(s,1,80)"…"; out=out" | "s } print out } }' "$P/calendar.txt" ;;
  *) echo "usage: delta_read.sh messages 1|2|3 | rows | calendar" >&2; exit 2 ;;
esac
