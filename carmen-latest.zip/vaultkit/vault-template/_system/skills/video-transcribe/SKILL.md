---
name: video-transcribe
description: Transcribe course videos, lectures, podcasts or any audio/video file into text offline by running `vt transcribe`, in any of ~99 languages with the spoken language auto-detected, and write the text straight into the `> [!quote]- Transkript` callouts of vault notes. Use whenever the user wants a video or audio transcribed, asks what a lesson or recording actually said, points at a Kajabi/Wistia/YouTube/Vimeo link and wants the content in the vault, or asks to fill in or backfill empty transcript callouts. Also use when the user asks whether a course has been transcribed yet, or why a callout is still empty. Runs on the Mac only, by decision.
---

# Video transcription

## What this does

Runs `~/automation/bin/vt transcribe`. All logic is in Python; this file exists to run
it, read its output, and keep the guardrails. **Never re-implement any of it inline**:
no ad-hoc `curl` for the media, no calling `whisper-cli` by hand, no editing a
`Transkript` callout with a text edit. The callout writer refuses to overwrite content
that is already there, and that guard only protects the user if it is the thing doing the
writing.

- **Code:** `~/automation/tools/transcribe/`
- **Cache:** `~/.local/state/automation/transcribe/`, one directory per source
- **Model:** `~/.local/share/automation/whisper/`, 547 MB, not in git, re-downloadable
- **Chain:** yt-dlp grabs → ffmpeg decodes to 16 kHz mono → whisper.cpp transcribes

**Nothing leaves the machine except the media fetch.** whisper.cpp is local. That is the
reason this is not an API: personal material (a private course, a private recording)
has no business on someone's server.

## The commands

```bash
~/automation/bin/vt transcribe doctor                   # is the toolchain ready
~/automation/bin/vt transcribe do wistia:<VIDEO_ID>     # transcribe, print the text
~/automation/bin/vt transcribe do ~/Downloads/x.mp4     # a local file
~/automation/bin/vt transcribe do https://...           # a page, or a direct media URL
~/automation/bin/vt transcribe run manifest.json        # transcribe + fill notes
~/automation/bin/vt transcribe run manifest.json --dry-run
~/automation/bin/vt transcribe holes "Projects/.../Module 1.md"   # empty callouts
~/automation/bin/vt transcribe status                   # what the cache holds
~/automation/bin/vt transcribe prune                    # drop audio, keep transcripts
```

`doctor`, `holes`, `status` and `run --dry-run` write nothing to the vault. Run them freely.

Flags worth knowing: `--model large-v3` escalates quality when a transcript reads badly,
`--cookies chrome` handles a page gated behind a login, `--force-write` replaces a callout
that already has content, `--force-transcribe` ignores the cache.

## How to use it

**One video, quick answer.** `vt transcribe do <spec>` and read the output. A spec is a
Wistia id (`wistia:<VIDEO_ID>`), a local path, a direct media URL, or a page URL that
yt-dlp can find a video on. Do not run this to answer a question about a lesson already
transcribed: read the callout in the note instead.

**A whole course.** Write a manifest, then `run` it. The manifest is a JSON list:

```json
[{"note": "Projects/<YOUR_COURSE>/Module 1.md",
  "heading": "Lesson 1: Welcome",
  "source": "wistia:<VIDEO_ID>"}]
```

`note` is relative to the vault; `heading` matches the note's heading, with or without
its `⬜`; `source` is any spec. **Always `--dry-run` first**: it transcribes and reports
what it would write without touching a note.

The manifest exists because the mapping from a video to the place it belongs is knowledge
the tool cannot derive. Kajabi lesson pages are behind a login and name no Wistia id in
any stable way, so somebody has to write it down, and writing it down makes the run
reviewable before it edits many notes.

**Finding the work.** `vt transcribe holes <note>` lists the headings in a note whose
`Transkript` callout is still empty. That is how a backfill is scoped.

**A one-off link (a YouTube video, a podcast, anything not part of a course).** `do` prints
to the terminal and creates nothing. There is no `capture` command, deliberately (see
*Where this is going*). So before you transcribe:

**Ask whether the user wants a note, and propose where it goes in the same breath.** Not an
open question: name a destination and let the user redirect:

- **Default to `Inbox/`**, like anything else entering the vault. That is the answer unless
  the material obviously belongs to an existing project.
- **When it clearly belongs somewhere, say so and still offer the Inbox.** A video from a
  programme already in the vault belongs beside the other programme notes; a lecture belongs
  near its course. Propose that folder, name it explicitly, and make clear `Inbox/` is the
  fallback.
- **Never invent a new folder** to hold a transcript.

The note itself: `type: reference`, a `captured:` timestamp, the source URL, the detected
language, and the transcript in a `> [!quote]- Transkript` callout, so it matches the course
notes and `holes` can see it.

A transcript printed to a terminal that the user wanted kept is a re-run. A note written
somewhere the user did not expect is cleanup. Both are cheap to avoid by asking once, with a
proposal.

## Guardrails

- **Never fill a callout that already has content** without saying so and getting a yes.
  A transcript is cheap to regenerate; a paragraph the user typed is not. The tool refuses
  by default; `--force-write` is the user's call, not yours.
- **Report the counts the tool prints** rather than paraphrasing them, and surface the
  failures. A run that says `3 failed` has three lessons with an empty callout.
- **Whisper invents text on silence, and turbo loops.** A lesson that is mostly music or a
  long pause can produce a fluent, confident, wrong paragraph, and the turbo model gets
  stuck repeating a clause (see Model choice). Skim a transcript before treating it as the
  source of truth, especially a short one.
- **Never paste a transcript into a note by hand.** Add it to the manifest and re-run.
- **`prune` after a big course.** The audio is ~2 MB a minute and it is not needed once
  the transcript exists.

## Mac-only, deliberately

**This breaks the standing rule in [[_system/vps-vault-host|vps-vault-host]] that
unattended work must survive the MacBook being shut, and the exception is taken
knowingly.** The vault host (<SERVER>) is a small VPS: 2 vCPU, 3.7 GB RAM. `large-v3` does
not fit in that memory at all, and `large-v3-turbo` runs below realtime on two Intel cores:
a 2.5 hour course would take 5 to 8 hours and pin the box. Transcription is a job the user
kicks off and watches, not one that has to run while they travel.

The code itself is portable (it lives in `~/automation`, hardcodes no machine paths, and
resolves the vault through `runner.config`), so this is a capacity decision, not a
structural one. If the server is ever upgraded, `doctor` is the only thing that needs to
change. It currently prints a warning when run on the box.

## Language

**Default is `auto`.** whisper.cpp detects the spoken language itself and every run reports
what it heard, in the `--- 145 chars, en, 3s` line and in `meta.json` as `language:`. The
same model covers ~99 languages; there is no single-language build.

Measured on matched en/de/fr samples: correct every time, p > 0.999, and a real lesson
re-transcribed under `auto` came out byte-identical to the pinned-language run.

**Pin it with `--language de` (or the relevant code) when detection could plausibly slip**:
a very short clip, one with heavy background music, or a speaker code-switching
mid-sentence. Being wrong about the language is worse than most errors here: whisper does
not fail, it produces confident nonsense. `meta.json` records both the detected `language:`
and the `language_mode:` that was asked for, so a bad run is diagnosable after the fact.

## Model choice

Default is **`large-v3-turbo-q5_0`**. On an Apple Silicon Mac it runs at roughly 7x
realtime including the download. Escalate with **`--model large-v3-q5_0`**, about 3x slower.
Any whisper.cpp GGML model name works: the tool downloads it on first use.

**Turbo loops, at least on German speech, and it is not rare.** On a first real run, about
a third of turbo transcripts contained a decoder loop: a clause repeating three to eight
times (for example "and then you, and then you, and then you").
Re-running those at `large-v3-q5_0` removed every loop, and turbo did not read better on
any lesson.

So the honest guidance is: **turbo for a first pass, then screen for loops and re-run the
offenders at `large-v3-q5_0`.** Screening is worth automating if this happens again; the
signal is a repeated multi-word clause, and the test has to ignore a chunk that is one word
repeated, because speech genuinely does that (a speaker saying "very, very, very small" is
not the decoder). Guided exercises also repeat by design, so compare the two models per
lesson rather than assuming the bigger one always wins.

## Where this is going

**This should not be maintained in the long run.** Transcription is a commodity: the right
shape is an MCP server or a managed service someone else keeps working, not 770 lines of
Python plus three brew formulae plus a 547 MB model on a laptop. This tool exists because
it was needed and nothing off-the-shelf was wired up. Treat it as the stopgap it is.

**So do not grow it.** One feature was deliberately not built rather than forgotten:

- **A `capture` command** that creates a note from a bare URL. Adding surface area to
  something meant to be replaced is the wrong direction. Handle a one-off link by asking,
  as above.

**Do not confuse maintenance burden with capability.** The argument for replacing this tool
is maintenance burden; it does not argue against capabilities the existing weights already
have, such as multi-language support (see *Language*).

**When the replacement question comes up, evaluate rather than assume**: this has not been
researched, and "an MCP exists for this" is a guess until someone checks. The requirement
that matters is the one that ruled out an API in the first place: this material can be
personal or private, and a service that retains or trains on uploads is disqualified no
matter how convenient.

## Improving this skill

**Standing convention, applies to every skill in this vault.** When the user pushes back on
how a run went, or changes something proposed to them, **treat it as design input rather
than a correction to apply silently**: convert it into concrete, specific options and let
the user choose. Quiet compliance wastes the most valuable moment a skill gets: right after
it has been used for real. Ground proposals in what actually happened in that run rather
than in general reasoning; offer the review after a real run rather than waiting to be
asked; and record each adopted change in the skill file with its date and reason, so a
later reader doesn't quietly revert it. **Never edit a skill while a run of it is in
progress**: collect the improvements, say so, and apply them once the run ends.

### Adopted changes

- **yt-dlp, not a hand-rolled Wistia client.** It ships Wistia extractors plus ~1800
  others and removed more code than it added. The cost taken knowingly: extractors break
  and want an occasional `brew upgrade yt-dlp`.
- **Shared flags go on every subparser** via `parents=[common]`, so
  `vt transcribe do --model X <spec>` works in the order anyone would type it. **Do not
  redirect stderr away in a batch loop**: a run that prints `FAILED` repeatedly and nothing
  else is a wasted round trip.
- **Default language is `auto`, not a pinned language.** Detection was verified on en/de/fr
  before the default moved, with the previously pinned path checked for regression.
- **Wispr Flow is ruled out.** It is a dictation app (microphone in, text into the focused
  field) with no file input, and its API is enterprise-gated and shaped for live 16 kHz
  voice. Do not revisit it, and do not build on the reverse-engineered community SDK.
