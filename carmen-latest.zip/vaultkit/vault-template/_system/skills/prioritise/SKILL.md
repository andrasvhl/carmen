---
name: prioritise
description: Work through the user's open Obsidian tasks and decide what actually matters, writing priority, effort and quadrant. Use when the user says "prioritise", "prioritize", "let's do priorities", "what matters", "run prioritisation", or asks to sort out their backlog. Decides importance only; it never schedules anything or picks what they do today, which is the separate schedule-work skill. v1 is the user deciding with the skill enforcing the caps; suggesting priorities comes in a later version.
---

# Prioritise

The third act of the daily loop. `dump` empties the user's head, `commit-to-action` turns that
into tasks, and this decides **what matters**.

Vault root: the folder holding the vault's `CLAUDE.md` (`$VAULT_PATH` if set).

## Scope: two axes, kept apart

**This skill decides importance. It never decides timing.**

| Axis | Field | Set by | Answers |
|---|---|---|---|
| Importance | `priority` | **this skill** | What matters? |
| Commitment | `scheduled` | `schedule-work` | When does it happen? |

That split is what makes the cockpit work: `priority` is deliberately not a trigger for the
`ToDo` view because it never expires on its own, which only works if something *else* drives
dates.

**Writes:** `priority`, `timeEstimate`, `quadrant`, `prioritised`, `startable`, the tags
`blocking-someone` and `needs-breakdown`, and `due` **only where a genuine deadline surfaces**.
A deadline is a fact about the world; a commitment is a choice.

**Never decides:** `scheduled` (that is `schedule-work`'s only lever). The one exception is timing
the user volunteers (see Pass 1). And **never `tasknotes_manual_order`**: drag order is the
user's, and drag wins outright. A skill that writes drag order fights them in their own cockpit.

## The caps

**9 high globally. Maximum 3 per North Star §2 priority.**

The popular numbers (Ivy Lee's six, the "5/25" rule) have shaky attribution; what is actually
supported is that **the limit is the mechanism and the digit is arbitrary.** Start with 9 and 3
(three most important tasks per priority, across about three priorities). If the user has a
working number of their own, theirs wins: change it here.

**The cap unit is a North Star §2 priority, NOT an `Areas/` folder.** A broad area like Personal
holds the user's most important relationship work *and* errands *and* admin. Capping that folder
at 3 would lump the top priority in with replying to invitations. The cap is a session rule, not
a stored field, so this costs nothing.

**Warn, never refuse.** If they want 12 high, say so plainly and ask what drops: *"that's 12;
which 3 go to normal?"* A cap they can silently exceed is not a cap, but a skill that overrules
the user is worse.

## The scale, and what each end means

| Value | Meaning |
|---|---|
| `4-high` | The capped top tier. Scarce by construction |
| `3-normal` | Real work, not now. **The pool the pull system draws from** |
| `2-low` | Real, but weak |
| `1-none` | **Explicitly not this horizon**; ties to [[Areas/North Star]] §3, the not-doing list |

Giving `1-none` a meaning matters: it is the default on every capture and otherwise carries no
information.

## Three passes

Five indicators across fifty tasks is 250 answers, which would make prioritisation more painful
than the mental load it exists to relieve. Split it.

### Pass 0: surface stale highs first

Before Pass 1, list every `4-high` task whose `due` or `scheduled` has passed. They hold cap
slots whether or not they are still true. Ask: still high, lower, or re-date?

**If North Star is stale or still the empty template, enforce only the global cap of 9** and say
the per-priority cap cannot be checked until North Star §2 is filled in.

### Pass 1: fast sort, one judgement each

Present **all** unprioritised tasks as a single list. **Two marks per task:**

1. A **priority tier**: `4-high` · `3-normal` · `2-low` · `1-none`
2. **Urgent: yes or no.** One word. It is what makes `quadrant` real, and **urgent with no date
   is the flag that generates one.**

**Offer the real values, but map whatever the user actually says.** People answer "High /
Medium / Low", where *Medium* is not a stored value. Mapping is fine; do not make them speak in
`3-normal`. What must not drift is the written data and the echo-back:

- **Only ever store the four real values.**
- **Echo the stored value when confirming**, so a bad mapping is visible immediately:
  *"Medium → `3-normal`"*, not just "got it."

**Show any existing `due` date next to each task.** Without it the user judges importance against
date pressure they cannot see, and reads "has a deadline" as "is important", which is exactly the
confusion the two-axis split exists to prevent.

**Also collect "does this need a date?" here, as a yes/no, for every tier.** Pass 1 is fast, so
the flag is cheap; concrete dates come in Pass 2 or `schedule-work`. A `3-normal` item needing a
date (a flight, an RSVP, a reply) would otherwise never be asked, and dates are what drive the
cockpit.

**Render Pass 1 as a table, always**, one row per task, every input needed to judge it as its own
column, answer columns blank:

| Key | Task | Area | Due | Flags | Tier → | Urgent? | Needs date? |
|---|---|---|---|---|---|---|---|

`Flags` carries what changes the judgement and nothing else: overdue, `decision`, `waiting`,
untriaged, "gates X". Pre-filled urgency guesses are marked in the row, not explained beside it.

**This pass checks the next action; it does not author it.** Every task carries a next action as
a checkbox at the top of the body ([[_system/SYSTEM|SYSTEM]] § Capture note schema). A task
without a clear next step is not well defined, unless it is waiting (`waiting: true` plus a
`- [ ] Waiting: ...` line), which counts as its step. Do not rewrite an existing one. For every
row the `Flags` cell shows one of two things:

| Note has | Flags cell shows |
|---|---|
| `- [ ] Next: email the venue ...` | `next: email the venue` (a few words) |
| nothing (and not waiting) | **`⚠ no next action`** |

Detect it by looking for an unchecked checklist item in the body; the convention is
`- [ ] Next: ...`. Surfacing the existing one matters as much as flagging a missing one: it puts
the action in front of the user at the moment they judge the task.

**Why the check lives here.** Tasks reach the vault through several inflows (desktop capture,
mobile capture, `commit-to-action`), and only `commit-to-action` classifies decisions at all.
Pass 1 is the only pass that walks the whole backlog, so it is the only place that catches every
inflow. The rule itself lives in `commit-to-action` § Every task carries its next physical
action; read it there, do not restate it here, and do not let the two drift.

For a `⚠` row, **propose a next action in the row** so they only confirm or correct it, and write
the confirmed step as `## Next action` / `- [ ] Next: ...` directly under the frontmatter, never
lower in the body. If they cannot name one, that is the finding: the task is blocked on something
not yet identified, and a vague item cannot be dismissed.

**Key every row with a short keyword, never a number or letter** (dictation renumbers lists; rule
in [[_system/SYSTEM|SYSTEM]] § How Claude operates). One or two words from the title, the word
the user would say anyway, unique, bold in the first column; echo back by key plus title.

**Echo the mapping before writing, whenever answers were dictated as a list.** Show key → tier →
urgent as one table and wait for a yes. Dictated answers can come back shifted by a row, writing
tiers onto the wrong tasks. The echo costs one message; a wrong write costs three.

**Timing the user volunteers is recorded, not deferred.** People answer "high, and do it today"
in one breath. Write `scheduled` for those and say so in one line: the two-axis rule forbids this
skill *deciding* timing, not recording timing the user dictated.

This is what ranks everything. A partially ranked backlog leaves an unranked pool that poisons
every later pass.

### Pass 2: indicators, on the `4-high` items only

Four questions each, on roughly a dozen items rather than fifty:

1. **Is there a real deadline?** → `due`, if genuine
2. **Rough size: quick, medium, or long?** → `timeEstimate`
3. **Can it be done cold, or does it need a run-up?** → **`startable: cold` or `run-up`**. The
   difference between a task you can drop into a gap between meetings and one that needs a
   protected block. **`schedule-work` depends on this**, so it has to be a field, not prose.
4. **Is someone waiting on YOU?** → tag `blocking-someone`. High leverage, usually cheap to
   clear. **Ask it in exactly that direction**: the mirror case, where the user is blocked on
   someone else, is `waiting: true`. Two states, two fields; never conflate them.

**Render Pass 2 as a table, one row per `4-high` item, one column per indicator.** Do not ask
four abstract questions and expect the user to hold them across a dozen items. **The size column
header carries the band definitions inline**, so they are not guessing what the words mean:

| Key | Task | Due | Size: quick <30m / medium 30m-2h / long >2h / break-down ≥6h | Cold or run-up | Someone waiting on you? |
|---|---|---|---|---|---|
| **report** | Write the quarterly report | - | | | |
| **dentist** | Book the dentist | 12 Mar | | | |

Reuse the Pass 1 keys, so a task keeps one name all session. They answer tersely by key
(*"report: none, long, run-up, no"*) and can skip any slot; leave a skipped field unset rather
than guessing. Pre-fill only what is already known, shown as filled so they can correct it.

### Pass 3: cap check

Count against 9 global and 3 per North Star priority. Report both. If either is exceeded, name
what is over and ask what drops.

## Quadrant: urgency is asked, importance is the priority tier

Inferring urgency from "has a due date within two weeks" fails: a task with no date can then
never be urgent, so most of the backlog lands in `neither` and the field does no work. *"Urgent
and not yet written down"* is exactly the state that matters. **So urgency is asked in Pass 1,
as one word per task.**

| | urgent | not urgent |
|---|---|---|
| **`4-high`** | `urgent-important` | `important-not-urgent` |
| **anything else** | `urgent-not-important` | `neither` |

- **Importance is the tier they already gave**; do not ask twice.
- **Urgency is the user's call**, not derived from a date.
- **Compute the quadrant and show it back.** Silent writes confuse; the computation is fine.
- **Pre-fill the urgency guess where a near date already exists** and let them correct
  exceptions. Pre-filling is not inferring: they still own the answer.

**Urgent with no date is the important output.** Those go on a *needs a date* list, collected
before Pass 2. That is how felt urgency becomes something the cockpit can act on.

**Values are plain speakable labels**, no decoding:
`urgent-important` · `important-not-urgent` · `urgent-not-important` · `neither`

## Re-running: three modes

**Default: unprioritised tasks only.** A full pass every time means it stops being run.

**Pull from normal when high has room.** As high items get completed, `3-normal` items should rise
to replace them. **The cap provides this for free**: if high is at 6, three slots are open, so
surface `3-normal` candidates to fill them. A work-in-progress limit doubles as the resurfacing
mechanism.

**Full re-pass**, on request. Staleness is judged from `prioritised:`.

## Schema

`prioritised: <ISO datetime>` records when priority was last set, so a later pass can tell a
priority set today from one set six weeks ago. `startable` takes `cold` or `run-up`.

**`startable` is a plain frontmatter property, not a registered TaskNotes user field.** Bases can
filter and display it either way; registering it in Settings → TaskNotes → user fields is
optional and would make it inline-editable.

**`timeEstimate` is in minutes** (TaskNotes native). **The bands are TaskNotes' own**:
`timeEstimateCategory` is generated by TaskNotes into the `.base` files it manages, so a parallel
set of cutoffs would be a second definition of the same thing and would be overwritten on the
next regeneration.

| Band | Range | Write |
|---|---|---|
| **Quick** | < 30 min | `15` |
| **Medium** | 30 min to 2 h | `60` |
| **Long** | > 2 h | `180` |
| **Break down** | ≥ 6 h | `360`: **a flag, not a band; see below** |

**"Break down" is an instruction, not a size.** A task estimated at twenty hours is not badly
estimated, it is **under-decomposed**: the estimate is unknowable until it is split. So:

- Write `360` as a floor, and treat it as provisional.
- **Add the tag `needs-breakdown`**, so the mark survives the session. A tag rather than a new
  field: it is filterable and `file.tags` is already a column in `ToDo.base`. It means precisely
  **"this cannot be estimated until it is broken down."**
- Say so in the run summary. Do not invent the subtasks; it becomes a scoping task, or
  `schedule-work` gives it a breakdown session. A six-hour-plus task will not be started as-is,
  whatever priority it carries.

**Break-down sits on top of TaskNotes' scale, it does not replace it.** A ≥6h task is still
`Long` to TaskNotes; the flag is this skill's.

Do not invent precision the user did not offer: the bands are the point, not the numbers.

## v1 versus later versions

**v1 is the user deciding; the skill records and enforces.** Do not suggest priorities yet. A
later version will suggest them, and indicators 1 to 3 are exactly its inputs, so do not shortcut
the indicators to save time.

## Why this skill is shaped the way it is

Decision record for all four loop skills: [[_system/daily-loop|daily-loop]]. This file is
instructions; that one is reasoning.

## Improving this skill

When the user pushes back on how a run went, or changes something you proposed, **treat it as
design input rather than a correction to apply silently.** Convert it into concrete, specific
options and let them choose.

- **Ground every proposal in what actually happened in the run.**
- **Offer the review after a real run**, rather than waiting to be asked.
- **Record each adopted change in this file with its date and reason.**

**Do not edit this skill while a run is in progress.** Each mid-run change can be correct while
the cumulative effect is a moving target the user has to follow while also doing the work.
Collect improvements, say you have noted them, and **apply them after the run ends.**

## Notes

- **Enrichment is pluggable either side of this skill.** Do not build enrichment logic in here.
- **Effort banding lives here; deep subtask breakdown does not.**
- **Dependency ordering is out of scope for v1.** A lower-priority task that unblocks a higher one
  should arguably go first, and `blockedBy` exists for it, but across mostly independent personal
  tasks it adds friction for little gain.
- Read tasks with the fast reader, one pass: `~/automation/bin/vt todos --json`
- Priorities and the cap unit: [[Areas/North Star]] §2. Schema: [[_system/SYSTEM|SYSTEM]].
