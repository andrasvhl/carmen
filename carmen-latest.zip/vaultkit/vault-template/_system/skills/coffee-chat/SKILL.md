---
name: coffee-chat
description: Book 30, 45 or 60 minute 1:1 coffee chats with the user's contacts, one person or several at once (always separate 1:1s, never a group chat). Use whenever the user says "coffee chat with X", "grab coffee with X", "coffee chats with X, Y and Z", "find time with X", "book 1:1s with X, Y and Z", "set up chats with these people", or names people they want to meet. Runs `vt coffee`, which finds the person's email in the CRM (Gmail fallback) and checks both calendars plus the user's week structure in one call, then offers 2-3 slots and a ready-to-send message per person. Creates the Google Calendar invites only after the user picks. For dinners with a whole WhatsApp group use `freetime` instead.
---

# coffee-chat

## What this does

One command finds the slots:

```bash
~/automation/bin/vt coffee "<name or unique part>" --duration 45
```

Defaults: next 10 days from tomorrow, **Tue/Thu/Fri only**, 11:00-17:00 local time, 45 min,
3 options, one per day. Flags: `--duration 30|45|60`, `--days N`, `--from YYYY-MM-DD`,
`--weekdays tue,wed,thu,fri`, `--start/--end HH:MM`, `--options N`, `--email` (skip the lookup,
one person only), `--json`.

**Several people:** `vt coffee <name1> <name2> <name3>` books **separate 1:1s in one go**,
never a group chat. Each person gets their own options, and a slot offered to one person is never
offered to another, so the user can confirm them all at once. Name problems (ambiguous, not
found) are reported for everyone together; fix them all, rerun.

Code: `~/automation/tools/coffee.py`, built on `tools/freetime.py` (same token, same CRM lookup and write-back).

It checks every calendar that blocks the user (main, any secondary account, imported event
calendars) and the other person's free/busy, then scores each free slot by fit with the week:
right after a class or event (already nearby) first, then lunch 12:00-13:00, then free
afternoons, and it avoids the user's low-energy window. The rules come from the user's
week-structure note and [[_system/working-conditions|working-conditions]]; if either has
changed (new term, `revisit:` passed), update the defaults in `coffee.py` before trusting the
output.

## How to run it

1. **Map the user's words to flags.** "quick coffee" → 30, "coffee" → 45, "lunch" or "proper
   chat" → 60. "next week" → `--from <next Monday> --days 7`. If no length was given, use 45 and
   say so.
2. **Run it, then pull the user's real day around each option**: Calendar MCP `list_events` on
   the primary calendar for the option days (`timeZone: "<YOUR_TIMEZONE>"`, `orderBy:
   startTime`). The result is large, so filter the saved file with jq to timed events between
   09:30 and 18:30 on those days. **Show the options as a table with Before and After
   columns** (the user's nearest event each side, with its end/start time, or "free until X"),
   plus the other person's next busy block where it is tight. Do this on every run: the user
   needs the shape of the day, not just a free gap. Say explicitly that both calendars were
   checked. If it says `ambiguous`, show the names and ask which; never guess by which match
   has an email. If the other person's calendar is blank or not readable, say the slots only
   reflect the user's own calendar.
3. **If there are fewer than 2 options**, rerun once wider (`--days 14`, then add `wed`) and
   say what you widened. Never offer Monday unless the user asks.
4. **Draft the message** the user will send themselves, in the language they use with that
   person (check `crm_languages`), short and casual, with the slot filled in once they pick:
   > Hi <First name>! Just sent you an invite for Fri at 12. Lmk if it works for you!
5. **Stop and wait for the user's pick.** Picking a slot is their yes to send the invite. With
   several people they pick one slot per person ("<PERSON> 1, <PERSON> 2"); one message per person.

## Creating the invite (after the user picks)

Calendar MCP `create_event`, on the user's primary calendar:

- `summary`: `<First name> x <YOUR_FIRST_NAME> chat`, e.g. `<PERSON> x <YOUR_FIRST_NAME> chat`.
  No emoji
- `startTime` / `endTime` local, no offset, `timeZone: "<YOUR_TIMEZONE>"`
- `attendees`: the other person's email (the user is added automatically as organizer). Several
  people means one event per person, created in parallel
- `location`: `<DEFAULT_LOCATION>` unless the user says otherwise; state the default when offering
- `availability: AVAILABILITY_BUSY`, `notificationLevel: ALL` (Google emails the invite)
- The calendar may add a Google Meet link automatically; harmless for an in-person chat

Then confirm in one line (who, when, where) and give the final message text, ready to paste.
Do not send the message yourself; WhatsApp or text is the user's click.

## Setup and failure modes

- **Token:** shared with `freetime`, `~/.config/vt/google.json`. Missing or revoked → `vt
  freetime --auth`.
- **Email missing from the CRM:** the Gmail fallback runs automatically (quoted and unquoted
  name search, since headers may carry a middle name). If it still finds nothing, search Gmail
  by surname yourself before asking the user.
- **Not in the CRM, no Gmail match** → ask for the email and pass `--email`; then add it to
  their CRM note (`crm_email`) so the next run is a lookup. Gmail finds are recorded
  automatically and printed as "Recorded in CRM"; relay that line.
- **All-day busy on their side** usually means travel or an out-of-office; the tool already
  skips those days.
- Runs from the machine where the token lives.

## Improving this skill

**Standing convention, applies to every skill in this vault.** When the user pushes back on how a run went, or changes something proposed to them, **treat it as design input rather than a correction to apply silently**: convert it into concrete, specific options and let them choose. Quiet compliance wastes the most valuable moment a skill gets: right after it has been used for real. Ground proposals in what actually happened in that run rather than in general reasoning; offer the review after a real run rather than waiting to be asked; and record each adopted change in the skill file with its date and reason, so a later reader doesn't quietly revert it. **Never edit a skill while a run of it is in progress**: collect the improvements, say so, and apply them once the run ends; amending the process mid-flight makes the user follow a moving target while doing the work. **Copy this clause into every new skill as an `## Improving this skill` section**: a short duplicated block is more reliable than a pointer that may not get followed.

## History

- Multiple people means separate 1:1s booked in one go, never a group chat. Do not add a group
  mode.
