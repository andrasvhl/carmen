# Price sources: what to query, which price to trust

Read by the `travel` skill before searching (SKILL.md Step 3).

## Which price to trust

**The deal page (the seller's own price for that fare) > the airline's site > Kayak and Google
Flights result cards > `vt flights` (Skiplagged / Kiwi search results).**

`vt flights` finds the candidates. Kayak, Google Flights and the airline confirm them into option
records (SKILL.md § The option record). A price that was never confirmed on a deal page is not shown.
Kiwi.com is a fine *seller* (book through it when it is cheapest), but its search fare
often leaves out the bag (`no bag`) and sometimes shows combinations that are gone on click.
Never take a price from an ad card, a "from $X" header or a cheapest-deal headline.

## Sources

| Source | What it adds | How | Blind spots |
|---|---|---|---|
| **`vt flights`** (Skiplagged + Kiwi) | Whole grid of airports × days in one call; hidden-city; self-transfer; included bags; cheapest per airport pair and per day | `~/automation/bin/vt flights search …` and `vt flights calendar ORIG DEST DAY` | No Southwest. Not the airline's own price. Skiplagged rate-limits to about 7 calls a minute, so a big grid takes 2 to 3 minutes |
| **Skiplagged and Kiwi tools** (`mcp__skiplagged__*`, `mcp__kiwi__*`), when loaded | Single searches, Skiplagged's flex calendars and "anywhere" search | Call the tool directly | Same data as `vt flights` |
| **Kayak** | Main confirmation source: every seller's price per fare brand, bag rules, self-transfer bundles named | § Kayak below | Hides 2-stop results when the ≤1-stop filter is set, so the cheapest fare can be missing: run once without the filter |
| **Google Flights** | Broad airline coverage including Southwest; the **price insight** (low / typical / high, typical range, history graph); market selection | Built-in browser: `https://www.google.com/travel/flights?q=Flights+from+<ORIG>+to+<DEST>+on+YYYY-MM-DD+one+way&gl=US&curr=USD`. Add `+returning+YYYY-MM-DD`, `+business+class`, `+2+passengers`. Repeat with the destination country's `gl` | **The `?q=` search is unreliable**: an airport code can resolve to a town with a similar name, and searches from some regions return "Oops, something went wrong". Check the resolved airports on the page; fall back to Kayak. Multi-city and premium economy need the form. If bot detection appears, use Claude in Chrome. Never solve a CAPTCHA |
| **Airline sites** | The real price, fare rules, student fares, bag fees | <YOUR_HOME_CARRIERS>, lufthansa.com (student fares through Travel ID, desktop only), flytap.com (stopovers), ryanair.com, wizzair.com, easyjet.com, transavia.com, southwest.com | One airline at a time |
| **<YOUR_LOYALTY_PROGRAM>** | Award space and the cash co-pay | The program's award booking site (the user must be signed in) | Login needed |
| **Seats.aero** (free tier) | Award space for your program and its partners up to 60 days out | seats.aero | Cached and up to a day old; Pro is a paid tier (see the playbook) |
| **Roame** (free tier) | Check your program is a listed one; free live search ±3 days, SkyView over the next 60 days | roame.travel in the browser, free account | Free tier limited to 60 days ahead; paid $12.99/mo |
| **PointsYeah** (free tier) | Broad award search with alerts, about 80 % of paid features free | pointsyeah.com, free account | Check that your program is covered before relying on it |

## Kayak

Works in the built-in browser with the pane hidden.

**URLs**, with airport codes (comma lists work, `PAR` means all Paris airports):
- `https://www.kayak.com/flights/<ORIG>-<DEST1>,<DEST2>,PAR/YYYY-MM-DD?sort=price_a`
- `&fs=stops=-2` at most 1 stop; `stops=0` nonstop. **This hides 2-stop results**, so run once
  without it.
- **Multi-city and open-jaw:** chain the legs in the path, e.g.
  `https://www.kayak.com/flights/<ORIG>-<DEST1>,PAR/YYYY-MM-DD/<DEST1>,PAR-<DEST2>/YYYY-MM-DD?sort=price_a`.
  Check on the page that every leg was read as intended before trusting the price.
- Append to `fs` with `;`: `virtualinterline=-virtualinterline` hides self-transfer combinations;
  `landing=0000,1600@YYYYMMDD` sets an arrival window; `takeoff=1700,2359` a departure window.
  Example: `&fs=stops=-2;landing=0000,1600@YYYYMMDD`.

**Reading results** (they load in about 15 s):
- Result cards are `.Fxw9-result-item-container`.
- Expand a card's segment details (times, connections, each leg's duration) by dispatching a click
  on its `.yuAt` element. Real clicks fail while the pane is hidden.
- Open the deal list by dispatching a click on the card's "Select" button. Read the
  `[role=dialog]` text between "Choose a fare" (fare brands with their bag rules) and "Step 2"
  (sellers with prices; the "Airline" label marks airline-direct).
- Self-transfer cards are labelled "Self-transfer hack" and name the only seller that bundles them.

## Ground transport

| Need | Source |
|---|---|
| **Connections and times, any European rail or bus, door to door** | `vt trains journeys` (Transitous: DB, SNCB, SNCF, NS, ÖBB, SBB, Flix, city transit; no fares; timetables to the next published change) |
| **Ferries, with fares** | `vt ferries search` (Ferryhopper; also the `mcp__ferryhopper__*` tools when loaded) |
| Germany and cross-border rail fares | bahn.de in the browser (with the user's railcard set in the search, if they have one). Its API blocks scripts (Akamai `OPS_BLOCKED`); never try to get around that |
| France, the TGV | sncf-connect.com |
| London, Brussels, Amsterdam high-speed | eurostar.com |
| Local buses and trains | <YOUR_LOCAL_TRANSIT_SITE> |
| Long-distance buses | flixbus.com, flibco.com (airport shuttles) |
| An unfamiliar region, every mode at once | rome2rio.com |
| Drive times | Google Maps |
| Getting to your home airports | <YOUR_LOCAL_RAIL_AND_TRANSIT_SITES>, and a live Uber or Lyft estimate |

## When a source fails

- Skiplagged returns HTTP 429: `vt flights` waits, retries and reports what was still refused.
  Fill the gap from Google Flights for those pairs rather than re-running the whole grid.
- Kiwi errors: Skiplagged and Google Flights cover the same ground, except self-transfer combinations.
- Google Flights blocked: Claude in Chrome, then Kayak.
- "No results" can mean no service at all. Check the airport's Wikipedia page ("Airlines and
  destinations") before telling the user a route does not exist.
- **Never present a single scraped price as the market.** If only one source answered, say so
  and label the price low-confidence.
