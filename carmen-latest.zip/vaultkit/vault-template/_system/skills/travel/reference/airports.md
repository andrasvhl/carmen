# Airports and ground legs from your bases

Read by the `travel` skill to build the candidate set (SKILL.md Step 2). Drive times are OSRM
routing estimates from each town's centre, without traffic. Add a margin at peak times, and check
Google Maps when a margin decides the answer. Transit times are approximate, so confirm the fare
and time on the operator's site before quoting them. Who can drive the user is in the Travel
Profile note, §2.

**Never assume a trip starts at a base.** Ask where each leg starts and ends (SKILL.md Step 1).
These tables only supply the ground leg once the user has confirmed the place. Real drive times
can run shorter than OSRM on long drives, so check Google Maps at the actual time of day before
quoting a leave time.

For a destination that is not one of your bases, build the same table on the fly: every airport
within about 4 to 5 hours by train, bus or pickup, using Rome2Rio and the rail operator.

---

## <YOUR_HOME_TOWN> (<BASE_DESCRIPTION, e.g. family home>)

<WHO_CAN_DRIVE_AND_HOW_FAR>. <PREFERRED_AIRPORT_AND_WHEN>.

| Airport | Drive | km | Main airlines | Without a lift |
|---|---|---|---|---|
| <IATA> <AIRPORT_NAME> | <HOURS> h | <KM> | <AIRLINES> | <TRAIN_OR_BUS_OPTION, or "poor"> |

Just over the drive limit, so ask before counting on a drive: <IATA> <AIRPORT_NAME> <HOURS> h, ...

## <YOUR_SECOND_BASE> (<BASE_DESCRIPTION>)

If there is no car (Travel Profile §2), get a live Uber or Lyft estimate for each airport; never
assume a price.

| Airport | Drive | km | Transit |
|---|---|---|---|
| <IATA> <AIRPORT_NAME> | <HOURS> h | <KM> | <TRANSIT_ROUTE_AND_TIME, or "none practical"> |

Note which airport has the long-haul flights, which smaller airports often have cheaper domestic
fares, and any airline that no search tool covers (sources.md).

## <FORMER_BASE_OR_HUB_CITY> (kept for trips via that city)

| Airport | Drive | km | Train |
|---|---|---|---|
| <IATA> <AIRPORT_NAME> | <HOURS> h | <KM> | <TRAIN_ROUTE_AND_TIME> |

Price trains with any rail discount card the user holds (Travel Profile). Where an airline puts
the train to the airport on the flight ticket, see playbook § 13.
