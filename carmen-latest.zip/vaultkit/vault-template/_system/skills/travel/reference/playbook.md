# Travel playbook: hacks, Miles & More, buy timing

The `travel` skill reads this file on every run. Airline rules change. Before a recommendation depends on a rule, confirm it on the airline's own page. If a rule has changed, fix it here in the same session.

---

## Hacks

Go through every item on every trip. For each one, write on the trip page whether it applied and what it saved. "Not applicable" is a fine answer. "Not checked" is not.

### 1. More airports at both ends
This is the core of the skill, and the grid in SKILL.md Step 2 covers it. Price the ground leg to and from each airport (airports.md). A $60 fare saving at an airport 3 hours away is not a saving if the train there costs $70.

### 2. Arrive early
Search arrivals on the day and up to 2 days before it. This is the standing rule. On peak dates the day before is often much cheaper.

### 3. Positioning flight
Book a cheap short-haul on its own ticket to a hub where the long-haul is much cheaper. From a European origin, typical hubs are AMS, CDG, FRA, MAD, LIS, LHR and IST. It is a separate ticket, so allow at least 3 hours, or a night, before the long-haul. Assume the bag has to be checked in again.

### 4. Hidden-city (skiplagging)
Buy A → C via B and get off at B, because A → C is cheaper than A → B. `vt flights` flags these fares `HIDDEN-CITY`. Rules for the user:
- **Carry-on only.** A checked bag goes on to C.
- **One-way only.** Missing a leg cancels the rest of the ticket, including the return.
- **No Miles & More number on the booking.** Airlines can take away miles and status.
- If the flight is cancelled, the airline rebooks the user to C, not to B.
- The user needs a passport and any visa that C requires. On an international ticket, check-in may ask for proof of onward travel.
- American Airlines enforces against hidden-city tickets most actively. In the EU it is a contract matter, not a crime: Lufthansa sued a passenger and later dropped the appeal.
- Use it only when the saving is large. The default threshold is 30 % and $150 below the best regular fare (Travel Profile §4).

### 5. Self-transfer and virtual interlining
These are separate tickets on different airlines, which Kiwi builds and `vt flights` flags as `self-transfer`. Use them if the user accepts them (Travel Profile), and note whether that acceptance includes checked bags. Make them safe:
- Allow at least 2.5 hours inside Schengen, and at least 4 hours when there is a border to cross or a bag to check in again.
- Avoid the last flight of the day as the second leg.
- Kiwi's Guarantee covers a missed connection only on bookings made through Kiwi.
- A transit visa may be needed for landside transfers (US, UK, China).
- **Always also price the halves separately** from the best sellers, adding a bag fee for each leg, and compare the total against the bundle. Separate tickets often beat the bundle by a wide margin. Name the backup flight in case the first leg is late.
- Present it as **2 tickets** and name who bundles it. Never present it as one ticket.

### 6. Round trip, two one-ways, or mixed airlines
Price all three for every return trip. Round trips often win on long-haul legacy carriers. One-ways and mixed airlines often win on short-haul and with budget airlines, and each leg can then be changed on its own.

### 7. Throwaway return
When a round trip is cheaper than the one-way the user needs, buy the round trip and skip the return. Skipping the *last* segment is the low-risk form. The hidden-city rule about the Miles & More number applies here too.

### 8. Open-jaw and multi-city
Fly into one city and out of another instead of returning to the starting point (for a trek: in at the start, out at the end). Price it as one multi-city ticket and also as separate one-ways.

### 9. Free stopovers on cash tickets
- **TAP:** free stopover in Portugal at its hubs, up to 10 days. Book on flytap.com, not through an agent.
- **Icelandair:** free stopover in Reykjavík, 1 to 7 days. Cheaper fares may cap the length.
- **Turkish:** a free Istanbul hotel night or two on qualifying tickets, applied for after booking. The conditions vary.
- **Qatar:** Doha stopover hotels from about $14 a night through Discover Qatar.
- **Finnair:** no formal programme, but Helsinki stops are easy to book as multi-city.
- Singapore Airlines stopped paid stopovers on cash tickets.

A stopover turns a connection into a second destination for the same fare. Offer one when a route goes through one of these hubs anyway.

### 10. Market and currency
The same flight can cost less in another country's market. On Google Flights, set `&gl=` to the departure country and then to the destination country. On airline sites, switch the country selector (for example a South American airline priced in its local currency, or a European airline by country). Before recommending a fare in a foreign currency, check the card's foreign-exchange fee.

### 11. Student fares
These apply if the user is a student (Travel Profile).
- **Lufthansa Group** (LH, LX, OS, SN): student fares for students aged 16 and up. Students verify through a free Travel ID account on lufthansa.com (the desktop site, not the app), and the verification is valid for one year. The fares usually include 2 × 23 kg bags and easier changes. They are not always the cheapest, and they are not offered within Europe. Routes to and from the US have been listed both as included and as excluded, so check on the booking page.
- **Air France / KLM** Youth and Student fares: students aged 25 to 29, economy only, 2 free bags, free changes. Minimum stays apply. **Not valid on trips departing the US, Canada or Mexico.**
- **BYOjet for Students** (formerly StudentUniverse): ages 18 to 25 only.

Check student fares when the trip is long-haul and the user needs a bag. The free bags alone can make them the best deal.

### 12. Budget-airline airports
Secondary airports near your bases (in Europe, for example Charleroi (CRL) or Beauvais (BVA)) are served by Ryanair, Wizz and Transavia, and metasearch sites price these airlines badly. Check the airline's own site and add the bag and seat fees. airports.md has the drive time to each airport.

### 13. Train instead of a plane, and train to the plane
- If the train takes less than about 5 hours, compare it against flying, door to door. City-centre stations usually make the train the better choice.
- **BahnCard 50** (if the user holds one): 50 % off DB Flexpreis, 25 % off Sparpreis. It applies to DB tickets, including the German leg of cross-border trips.
- **Lufthansa Express Rail / Rail&Fly:** a DB train to FRA on the same ticket as the flight, so the ticket covers a late train.

### 14. Bags
A basic fare plus a paid bag can beat the standard fare, or cost more. Price the bags the user will actually carry. Budget-airline bag fees are often higher at the airport than online. When a Kiwi fare is marked `no bag`, add the airline's bag fee.

### 15. Flexible destination
If the destination is open (a weekend away, a reunion city), use Skiplagged's "anywhere" search (`sk_destinations_anywhere`) or Google Flights Explore.

### 16. Day of the week
Tuesday and Wednesday departures cost about 13 % less than weekend departures. The day you book on hardly matters.

### 17. Pair legs across trips (back-to-back and nested round trips)
A round trip is often much cheaper than a single one-way, so build round trips from legs of **different trips**. Example: the user needs a one-way flight from Europe to the US now and has a trip back to Europe a few months later. Booking the flight now as one leg of a round trip and the later flight as the other leg costs much less than two one-ways.
- **Inputs:** the pairing scan (SKILL.md, Read first, item 6). Only trips the user has confirmed.
- **Shapes:**
  - This trip's leg plus the opposite-direction leg of a later trip, on one ticket.
  - Two overlapping round trips (nested): A → B now with B → A at the end, plus B → A → B in the middle.
  - Open-jaws, when the later trip starts or ends somewhere else.
- **What breaks it:**
  - Legs must be flown **in order**. Missing the outbound cancels the return.
  - Most tickets are valid for **12 months** from the first flight, and some fares have a shorter maximum stay (3 or 6 months). Read the fare rules.
  - The ticket is priced in the country of the **first** departure, so price the pairing in both directions. An origin in South America or Asia is often much cheaper than Europe or the US.
  - If the later trip's date is not fixed, choose a fare with cheap date changes and say what a change costs.
  - If the later trip is cancelled, skipping the **last** leg loses only that leg. That is the low-risk case. Never pair so that the uncertain trip is the *first* leg.
- **How to present it:** put it in the combinations table with the legs of both tickets, the trip each leg belongs to, and how certain that trip is.

---

## After booking

- **US 24-hour rule:** for flights to or from the US booked at least 7 days before departure, the airline must allow free cancellation within 24 hours, or a free 24-hour hold. Use it to lock in a fare and keep looking.
- **Price drops:** US airlines give a credit for the difference on non-basic fares. Lufthansa Group and budget airlines generally do not. Re-check booked trips (SKILL.md § Re-checking a booked trip).
- **EU261:** €250, €400 or €600, depending on distance, for an arrival 3 or more hours late, a cancellation with less than 14 days' notice, or denied boarding. It covers flights departing the EU on any airline, and flights into the EU on EU airlines.
- **Schedule changes:** a significant schedule change usually opens a free rebooking or a refund. That sometimes beats the original booking.

---

## Miles & More

This section uses Miles & More as the worked example of a loyalty program. If the user collects with a different program, rewrite it for theirs and keep the same tests.

This section covers the user's airline program (Travel Profile §3, which also records the balance and status).

- **Airlines:** Lufthansa, SWISS, Austrian, Brussels Airlines, Croatia, LOT and Air Dolomiti earn and redeem miles directly. Awards on other Star Alliance airlines (United, Air Canada, TAP, Turkish, ANA, Singapore and others) are booked through the same account.
- **Pricing:** award prices on Lufthansa Group flights have been dynamic since June 2025, with no published chart. Since May 27, 2026, award tickets come in Light / Classic / Flex, like cash fares. Flex awards can carry very high cancellation fees.
- **Surcharges are the catch.** Long-haul awards on Lufthansa Group carry fuel surcharges of several hundred dollars each way (reports put business class at €350 to €400 each way), so always compare the **total cash co-pay**. Short- and medium-haul awards within Europe have low taxes and are usually the best use of miles.
- **Value test:** (cash fare − award cash co-pay) ÷ miles. At 1.2 US cents per mile or more, redeeming is a good use. Under 1.0 cent, pay cash and keep the miles. Published valuations put Miles & More at 1.2 to 1.3 cents.
- **Mileage Bargains:** discounted awards released each month. They have been thin in 2026 (Brussels, LOT and ITA; Lufthansa, SWISS and Austrian reportedly do not offer them). They cannot be changed or refunded, and taxes are not discounted.
- **Stopovers:** up to 2 stopovers or open-jaws per round-trip award that spans 3 regions.
- **Holds:** up to 5 days by phone, free. A fee of about $20 applies when the booking is completed by phone.
- **Expiry:** miles expire 36 months after they were earned, at the end of that quarter, unless the user holds status or a qualifying Miles & More credit card.
- **Earning:** add the user's Miles & More number to every Star Alliance cash ticket, **except hidden-city and throwaway bookings**. For how many miles a ticket earns, see § Earning miles on cash tickets below.
- **Finding seats without the Miles & More site:** Star Alliance airlines release the same "saver" award seats to every partner program. A seat on Lufthansa, SWISS, Austrian, Brussels, TAP, Turkish or another member airline that shows up on united.com (award search works without signing in), or in any tool that covers United or Aeroplan, can almost always be booked with Miles & More too. There are two limits:
  - **The price is not the Miles & More price.** United and Aeroplan show their own miles and their own (low) surcharges. Read the Miles & More price and its fuel surcharges on miles-and-more.com.
  - **It undercounts Lufthansa Group flights.** Miles & More members see extra Lufthansa, SWISS and Austrian seats that are never released to partners, including Lufthansa First. So "no space on United" does not mean "no space with Miles & More".
- **Where to search:** miles-and-more.com (the user must be signed in). Seats.aero shows Miles & More award space for free up to 60 days ahead.
- **Seats.aero Pro** ($9.99 a month or $99.99 a year) is **not worth it yet**. Its value is searching 25+ programs at once for someone with transferable points. With one program, the Miles & More site covers the same award space. Reconsider if the user's balance passes about 60,000 miles or the user gets a transferable points currency.

### Earning miles on cash tickets

Every option in the results table shows the miles it earns (SKILL.md § The option record).

- **Tickets issued by a Lufthansa Group airline** (ticket number starting 220 for Lufthansa, 724 for SWISS, 257 for Austrian, 082 for Brussels), including tickets bought through an agency:
  - Earning is **revenue-based: 4 award miles per euro** of the fare plus the airline's own surcharges, **excluding government taxes, seats and extra bags**.
  - With any status it is 6 miles per euro (5 on Luxair, Eurowings and Discover).
  - Take the split between fare and taxes from the booking page. If only the total is visible, estimate the taxes and mark the figure "estimated".
- **Check every segment's airline against the Miles & More partner list. Never assume.** Earning depends on the airline that operates and markets each flight, segment by segment. On a mixed itinerary, only the segments that credit to Miles & More earn miles. Current partners (source: wheretocredit.com; confirm a new or doubtful one on miles-and-more.com/row/en/earn/airlines.html):
  - **Star Alliance, all credit to Miles & More:** Aegean (A3), Air Canada (AC), Air China (CA), Air New Zealand (NZ), ANA (NH), Asiana (OZ), Austrian (OS), Avianca (AV), Brussels (SN), Copa (CM), Croatia (OU), EgyptAir (MS), Ethiopian (ET), EVA (BR), ITA (AZ), LOT (LO), Lufthansa (LH), Shenzhen (ZH), Singapore (SQ), South African (SA), SWISS (LX), TAP (TP), Thai (TG), Turkish (TK), United (UA).
  - **Partners outside Star Alliance:** Air Astana (KC), Air Dolomiti (EN), Air India (AI), Cathay Pacific (CX, oneworld), Discover (4Y), Edelweiss (WK), Eurowings (EW), LATAM (LA), Luxair (LG), Olympic (OA), Thai Smile (WE). Some sources list Condor: verify before counting it.
  - **Every other airline earns 0 Miles & More miles.** This includes Air France/KLM, Delta, American, British Airways, Iberia, Qatar, Emirates, GOL, Azul and JetSMART, and all budget airlines such as Ryanair, Wizz and easyJet. If a free program (Flying Blue, AAdvantage) would earn a lot on a long-haul flight, say so in one line.
- **How much a partner flight earns:** distance × the Miles & More earning percentage for the booking class. Look it up at `https://www.wheretocredit.com/en/<airline code>/<booking class>` (row "Miles & More") or with the Miles & More mileage calculator. The booking class comes from the deal page or the fare details. The cheapest classes often earn 0 to 25 %, and some classes earn nothing even on a partner airline: write "0 (class X does not earn)" rather than leaving the figure out. Lufthansa Group flights on a ticket issued by another airline (for example, a United ticket with a Lufthansa leg) also earn this way, not per euro.
- **Value:** count each earned mile as 1.2 US cents, the same figure used for redeeming.

---

## Buy timing

The skill's verdict is one of: Buy now, Book by <date>, or Wait and watch.

**Evidence, strongest first:**

1. **This trip's own watch history** (the trip's flight-watch status note): its low, its median and its trend.
2. **Google Flights price insight:** "low / typical / high" for this route and date, the typical price range, and the price-history graph on the results page.
3. **`vt flights calendar ORIG DEST DAY`:** today's cheapest fare for each day in a window of about 30 days around the date. It shows whether the chosen day is a peak.
4. **Typical booking windows:**
   - US domestic: cheapest about 1 to 3 months out. Google's median low is 39 days before departure, usually between 22 and 57 days.
   - International: 2 to 8 months out. US to Europe has been cheapest 72 or more days out. Google's figure for Europe is about 90 days.
   - Christmas: the low has been about 56 days before departure. Thanksgiving: about 34 days. **2026 holiday fares are running 12 to 18 % higher, and the advice is to book early.**
   - Fares tend to step up as the advance-purchase thresholds close at 21, 14 and 7 days.
5. **Scarcity:** few seats left at the price, or the last flight of the day.

**Verdict rules of thumb:**
- At or below the low end of Google's typical range, or at the watch's low → **Buy now**.
- A holiday peak (Dec 18 to 24, Jan 2 to 4, the Sunday after Thanksgiving) inside its booking window → **Buy now**. These fares rarely fall.
- In the typical range with more than 8 weeks to go → **Wait and watch**. Set a target price at the low end of the range and a "book by" date when the window closes.
- A fare to or from the US, 7 or more days out → buying now and keeping the 24-hour cancellation as a safety net is often the best of both.

State the evidence in one line, for example: "Buy now: $744 is under Google's typical $780 to $1,050, and Dec 25 fares have risen steadily since 56 days out."
