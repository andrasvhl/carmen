---
name: send-to-speechify
description: Upload documents to the user's Speechify library so they can listen to them on their phone: course readings, cases, PDFs, articles. Use whenever the user says "send to Speechify", "put this on Speechify", "I want to listen to tomorrow's readings for <class>", or wants readings as audio for a commute or the evening. Uploads through the Speechify web app in the user's Chrome; the library syncs to their phone.
---

# send-to-speechify

**Read [[_system/speechify|speechify]] first.** It owns the route, the plan limits and the traps.
This file is only the steps.

## How to run it

1. **Find the file(s).** Course readings per [[_system/kindle|kindle]] § Course readings; if the
   course has no dated Class Prep, count the session from the user's <YOUR_SCHOOL> calendar
   ([[_system/speechify|speechify]] § Gotchas). Otherwise the path the user gives.
2. **Check room.** Read `https://app.speechify.com/library` in the user's Chrome. If it says
   Speechify needs sign-in, stop and give the user the link. If the free 5-file cap would be
   exceeded, say which files would not fit and ask what to drop.
3. **Upload one file at a time:** library page, click **Add**, `find` the file input,
   `file_upload` with a single path. Repeat per file.
4. **Verify** on the library page that every file is listed, then close the tab.
5. **Reply in two or three lines:** what is in the library, for which session, and anything that
   could not be fetched (with its link).

No confirmation step: the request is the authorization, and the library is the user's own.

## Improving this skill

**Standing convention, applies to every skill in this vault.** When the user pushes back on how a run went, or changes something proposed to them, **treat it as design input rather than a correction to apply silently**: convert it into concrete, specific options and let the user choose. Quiet compliance wastes the most valuable moment a skill gets: right after it has been used for real. Ground proposals in what actually happened in that run rather than in general reasoning; offer the review after a real run rather than waiting to be asked; and record each adopted change in the skill file with its date and reason, so a later reader doesn't quietly revert it. **Never edit a skill while a run of it is in progress**: collect the improvements, say so, and apply them once the run ends; amending the process mid-flight makes the user follow a moving target while doing the work. **Copy this clause into every new skill as an `## Improving this skill` section**: a short duplicated block is more reliable than a pointer that may not get followed.

## History

- The skill works from the vault the same way the Kindle route does.
