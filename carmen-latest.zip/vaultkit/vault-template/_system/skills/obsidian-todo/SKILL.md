---
name: obsidian-todo
description: Instantly list or add the user's Obsidian to-dos by running `vt todos` against Inbox/ (notes whose type property is action). Reads the same views as the ToDo.base cockpit (ToDo / Triage / Unscheduled). Use whenever the user asks for their to-dos, tasks, what's on their plate, what's due, what needs triaging, or what's sitting unscheduled (e.g. "what are my to dos?", "show my tasks", "anything due today?", "what needs triaging?"), AND whenever they ask to add, capture, or remind themselves of a task (e.g. "add X to my to-do list", "remind me to Y", "I need to do Z"). Always use this instead of reading task files one by one.
---

# Obsidian to-do

## What this does

Runs `~/automation/bin/vt todos` against `Inbox/`, the vault's one task database (`type: action`
notes). Reads YAML frontmatter across the whole folder in one pass for listing, and can also write
a new note in the vault's capture schema, so "add a to-do" lands in the same place as any other
capture.

- **Task folder:** `Inbox/` in the vault. `vt` finds the vault from `$VAULT_PATH` (see
  `SETUP-NOTES.md`).
- **The cockpit is `ToDo.base` at the vault root, and it is the authority.** `vt todos` mirrors
  its view filters so there is exactly one definition of "active" in the system. It is a fast
  reader of the cockpit, never a second opinion.
- See `_system/SYSTEM.md` for the full architecture and `_system/task-cockpit.md` for the task
  engine.

## The views (mirrored from `ToDo.base`)

| View | Filter | What it means |
|---|---|---|
| `todo` | `(due is set OR (scheduled is set AND scheduled <= today)) AND status != "done"` | The daily driver. A date is the only membership trigger; priority deliberately is not, because unlike a date it never expires |
| `triage` | `status == "inbox"` | Captured but **not yet triaged**. Not ordinary active tasks |
| `unscheduled` | no `due`, no `scheduled`, `status != "inbox"`, not done (recurring: not completed today) | The Someday bucket, triaged work only |
| `all` | `status != "done"` | Everything live, flat |

**Status vocabulary:** `inbox` = untriaged · `open` = triaged and real · `in-progress` · `done`.
**Priority scale:** `1-none` / `2-low` / `3-normal` / `4-high`. `waiting` is a **boolean field**
(waiting on a person or an external event), not a status: a waiting task stays in `ToDo`.

## How to use it: listing

```bash
~/automation/bin/vt todos                    # ToDo + Triage + Unscheduled (default)
~/automation/bin/vt todos --view todo        # the ToDo view only
~/automation/bin/vt todos --view triage      # untriaged captures
~/automation/bin/vt todos --view unscheduled # the Someday bucket
~/automation/bin/vt todos --view all         # every not-done task, flat
~/automation/bin/vt todos --json             # all four views, machine-readable
```

**`--json` rows** carry `name`, `status`, `urgent`, `waiting`, `priority`, `due`, `scheduled`,
`recurrence`, `complete_instances`, `project`, `timeEstimate`, `quadrant`, `startable`, `tags`,
`path`. `timeEstimate` is an int or null, so hours can be summed without parsing; list-valued
fields such as `projects` and `tags` are flattened to a comma-joined string. The other loop
skills (such as `schedule-work`, whose placement rules run on these fields) read the backlog
through this, never through a second reader: **if a skill needs a new field, add it to
`todos.py` in the same change.**

## How to use it: adding

```bash
~/automation/bin/vt todos --add "Text of the task" \
  [--urgent] [--due 2026-01-20] [--scheduled 2026-01-15] \
  [--priority 3-normal] [--project "Project Name"]
```

Only `--add "text"` is required. The note is written with the capture schema: `type: action`,
`captured`, `status: inbox`, and `priority` always explicit (`1-none` by default). The body opens
with `## Next action` / `- [ ] Next: <text>`, because every task carries a next action as a
checkbox at the top (`_system/SYSTEM.md` § Capture note schema). If the text is not yet a
physical step, sharpen that line right after adding.

- `--urgent` writes `urgent: true`, `priority: 4-high` **and `scheduled: <today>`**. The date is
  what actually gets it into the ToDo view; the flag alone would not.
- `--due` is for **real deadlines only**. Use `--scheduled` for "the day I intend to work on it":
  it matches `scheduled <= today`, so an unfinished item persists tomorrow instead of rendering
  overdue.
- `--project` is the exact title of an existing project or area note, used to build the wikilink.

Only the Python standard library is needed, no `pip install`.

## After running

**Listing:** relay the script's own grouping: ToDo first, then Triage, then Unscheduled. Don't
re-rank or re-categorise; the point is that these groups match what the user sees in the cockpit.
Offer to filter by project or open a specific task.

**Acting on the list.** Never add numbers or letters to the relayed list. If the user wants to act
on several tasks (mark done, reschedule, pick some), or you present a subset for them to choose
from, key the rows with short keywords and echo back by keyword plus title (dictation renumbers
lists; rule in `_system/SYSTEM.md` § How Claude operates). **Marking a task done or rescheduling
it also moves its calendar blocks:** search for future blocks whose `Task:` line points at it,
then delete or move them in the same step and say so (`_system/SYSTEM.md` § How Claude operates).

**Adding:** confirm what was created in one line (title, plus any flags set). Don't ask for fields
the user didn't mention; enrichment (project, context, due, quadrant) can happen later and never
blocks capture.

**Project linking.** One exception to "don't ask": if the task obviously belongs to an existing
project note, set `--project` yourself. Check the `Areas/` and `Projects/` listings; it costs one
`ls`. If it is *not* obvious, leave it unset and say so in the confirmation line ("no project
set"), so it is visible rather than silently missing.

**Do not interrogate the user mid-capture.** The strict "ask when unsure" rule lives in
`commit-to-action`, which has a proposal step where questions belong. This path is instant
capture, and capture must never block. Confident link, or none plus a note.

## Gotchas

- **`ToDo.base` is the source of truth for view filters.** If a filter changes there, mirror it in
  `~/automation/tools/todos.py` (`v_todo` / `v_triage` / `v_unscheduled`). Two divergent
  definitions of "active" is the failure this design exists to prevent. **Never hand-edit `.base`
  files**: Obsidian silently rewrites them. Read them, and change them through Obsidian's UI.
- **Don't treat `status: inbox` as an ordinary active task.** It means untriaged, and it is
  deliberately excluded from `Unscheduled`.
- If the task folder ever moves, the path comes from `runner/config.py` in `~/automation`, which
  resolves it per machine.
- Each task is a markdown file; its body holds detail the script doesn't print. Read the file for
  that.
- The frontmatter parser is line-based, not a full YAML parser. It handles `key: value` and block
  lists (`projects:` then indented `- "[[X]]"`), which covers the whole schema; nested maps or
  multi-line values won't parse.

## Where this lives

Source of truth is `_system/skills/obsidian-todo/` in the vault, symlinked to
`~/.claude/skills/obsidian-todo`. The symlink is the only machine-local part; recreate it on a new
machine with:

```bash
ln -s "$VAULT_PATH/_system/skills/obsidian-todo" ~/.claude/skills/obsidian-todo
```

The `otodos` slash command (`_system/claude/commands/otodos.md`) shells out to the same script for
a fast single-turn listing. It points at the vault path, so update it if the script ever moves.
