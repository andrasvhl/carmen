---
name: send-to-kindle
description: Send documents to the user's Kindle by email: course readings, cases, PDFs, epubs, articles, any file. Use whenever the user says "send to my Kindle", "put this on my Kindle", "send tomorrow's readings for <class> to my Kindle", or wants something to read on the Kindle. The address and sending account are fixed in the kindle component doc; never search Gmail for a kindle.com address.
---

# send-to-kindle

**Read [[_system/kindle|kindle]] first.** It owns the address, the sending account and the traps.
This file is only the steps.

## How to run it

1. **Find the file(s).** For course readings, follow [[_system/kindle|kindle]] § Course readings
   (find tomorrow's session from the Class Prep note, then the binaries via `canvas_file_path`).
   For anything else, use the path the user gives or locate it in the vault.
   **Check every reading the Class Prep names, not just the module's files.** Library-link
   readings are downloaded through the user's Chrome per the same section; only pause if
   <YOUR_SCHOOL> asks the user to sign in.
2. **Stage them:** `cp <files> ~/.workspace-mcp/attachments/`.
3. **Send** with `mcp__gws__send_gmail_message`: `user_google_email` and sender
   `<YOUR_EMAIL>`, `to` the address in the kindle doc, `include_signature: false`, one
   `{"path", "filename", "mime_type"}` attachment per file. Subject and body per the doc's convention.
4. **Delete the staged copies.**
5. **Reply in two or three lines:** what was sent, to which session, and any reading that could
   not be fetched (with its link) so the user can get it themselves.

No confirmation step: the request to send is the authorization, and the recipient is the user's own device.

## Improving this skill

**Standing convention, applies to every skill in this vault.** When the user pushes back on how a run went, or changes something proposed to them, **treat it as design input rather than a correction to apply silently**: convert it into concrete, specific options and let the user choose. Quiet compliance wastes the most valuable moment a skill gets: right after it has been used for real. Ground proposals in what actually happened in that run rather than in general reasoning; offer the review after a real run rather than waiting to be asked; and record each adopted change in the skill file with its date and reason, so a later reader doesn't quietly revert it. **Never edit a skill while a run of it is in progress**: collect the improvements, say so, and apply them once the run ends; amending the process mid-flight makes the user follow a moving target while doing the work. **Copy this clause into every new skill as an `## Improving this skill` section**: a short duplicated block is more reliable than a pointer that may not get followed.
