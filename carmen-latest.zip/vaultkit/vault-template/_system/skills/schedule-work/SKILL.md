---
name: schedule-work
description: Decide when the user's prioritised Obsidian tasks actually happen, writing `scheduled` across the coming week to week and a half. Use when the user says "schedule", "schedule my work", "plan my week", "when am I doing this", "let's do scheduling", "what does my week look like", or asks how the next few days should go. Reads their calendar if a connector is available, asks what is missing from it, states the capacity gap in hours, protects important-not-urgent time, and creates calendar blocks once they approve the plan. Does NOT decide what matters; that is `prioritise`.
---

# Schedule work

The **fourth and final act** of the daily loop. `dump` empties the user's head,
`commit-to-action` turns that into tasks, `prioritise` decides **what matters**, and this decides
**when it happens**.

Vault root: the folder holding the vault's `CLAUDE.md` (`$VAULT_PATH` if set).

**Named `schedule-work`, not `schedule`**: other tools ship a `schedule` skill for cron-like
routines, and a name collision makes the wrong one fire.

## Scope: two axes, kept apart

**This skill decides timing. It never decides importance.**

| Axis | Field | Set by | Answers |
|---|---|---|---|
| Importance | `priority` | `prioritise` | What matters? |
| Commitment | `scheduled` | **this skill** | When does it happen? |

`priority` is deliberately not a trigger for the `ToDo` view because it never expires on its own,
so **something else has to drive dates, and this skill is that something.**

**Writes:** `scheduled`, plus `status: done` when Pass 0c establishes that a past block's work was
actually completed and simply never ticked. Closing a task on the user's explicit say-so is
recording a fact, not deciding importance. Never close one on inference.

**Never writes:** `priority`, `quadrant`, `timeEstimate`, `tasknotes_manual_order`. Drag order is
the user's alone.

**Writes calendar events, but only after the user approves the plan**, and only if a calendar
connector is available. **Do not write events as a side effect of planning.** Propose the plan,
get a yes, then write. Without a connector, output the plan as text (Pass 5) and say creating the
events is theirs.

### Block conventions

| | |
|---|---|
| Protected work: important-not-urgent, and anything with an immovable date | busy |
| Everything else | free, so the calendar stays bookable |
| Sub-hour tasks | **No block of their own.** Batch them into one block whose title and description name every item in it |
| Meals | Count them as used time in the capacity maths, whether or not they are on the calendar |
| Standing recurring blocks the user already has (lunch, a morning routine, a weekly slot for big rocks) | Do not place them again each run, and never move or delete the series. Place the work as separate blocks inside them, titled by their contents as usual. Anything else that lands in a standing slot is a conflict to name, never a free slot |

**A batch block is named by its contents, never just "Admin".** The title lists the items, short
form, joined with `+`: *"Dentist call + flight refund + library books"*. The description carries
the full task titles. A block called "Admin" hides what it holds until opened.

**Every block links to its task.** The description ends with one line per task:
`Task: obsidian://open?vault=<VaultName>&file=<URL-encoded path, no .md>`. A batch block carries
one line per item. **The link runs one way, event to task**: the task note stores no event id,
because ids go stale on every reschedule. To find a task's blocks, search the calendars for its
URL-encoded filename. A block with no `Task:` line is a standing anchor (lunch, a class), not task
work. This is what lets any session close a task's blocks when the task closes
(`_system/SYSTEM.md` § How Claude operates).

**Standing principle: things should be explicit in the calendar, not implicit.** If time is
committed, it has an entry: meals, sport, travel, batches of small work. A day whose real shape
only exists in a plan document is a day the calendar misrepresents, and the capacity maths built
on it is wrong. This does *not* license a block per fifteen-minute task; that is what the batch
rule is for.

**A block is written in the language of its task note.** Read the note, match it, and do not
translate. A block whose title does not match its note is not findable by search and reads as a
different task.

**Always set the time zone explicitly** on every event, and say which zone. Events are stored
correctly either way but can *display* hours off when the user travels, which looks like a broken
plan. Recurring events created in another zone can show at odd hours: flag them for the user.

**Which calendars:** read every calendar in [[_system/working-conditions|working-conditions]] §
Calendar roster, for Pass 0 and Pass 0c, not just the main one. Re-check with `list_calendars` at
the start of every run, because calendars get added; a new one is a question for the user: what
is it for, and does it block time? Write only to calendars the roster marks writable.

**The blocking calendars are also copied in code:** `BLOCKING_CALENDARS` in
`~/automation/jobs/plan_today_prerun.py` (the busy view that day-plan drafts are checked against).
Change both when a calendar starts or stops blocking.

**Deleting calendar events is the user's job, not this skill's**, unless they approve it for the
run. Say which to remove and why.

## What `scheduled` actually does to the cockpit

- `ToDo` membership is `due` is set **or** `scheduled <= today()`. So **a task scheduled for next
  Thursday does not appear until Thursday.** Scheduling a week ahead does not clutter today.
- `Unscheduled` (the Someday bucket) is *no due, no scheduled, not done*. **Writing `scheduled`
  removes a task from Someday.** Do not scatter dates across the backlog to look productive:
  every date written is a commitment that will surface.
- **A `scheduled` date that passes does not expire.** `scheduled <= today()` keeps matching
  forever, so an over-full week silently accumulates in `ToDo` as arrears. This is the main way
  this skill can quietly make the cockpit worse, and Pass 0b exists to counter it.

## Horizon: a week to a week and a half, not a day

Plan **today through roughly today + 10 days**, at **date granularity**. Time of day exists only
in the proposed blocks, never in frontmatter: `scheduled` is a date. A single-day plan re-derived
every morning is exactly the thing that stops getting run; a dependable picture of *the week* is
what removes the background worry.

Bound the horizon by [[Areas/North Star]] §1 if it sets an end date.

## The passes

### Pass 0: read the world, one pass each

1. **The backlog.** `~/automation/bin/vt todos --json`. Same definition of "active" the cockpit
   uses. Do not build a second one.
2. **[[Areas/North Star]]** (§1 horizon, §2 priorities as the tie-break order, §5 decision rules),
   **then [[_system/working-conditions|working-conditions]]**, which holds when work can actually
   be placed and the calendar roster. If either file's `revisit` date has passed, say so in one
   line and continue. If working-conditions is still the empty template, Pass 1a fills it.
   **Then [[_system/scheduling/scheduling-rules|scheduling-rules]]**: *how* each block is placed
   (length multiplier, gaps, daily item cap, durations by task type, carry-over verdicts), with
   durations in [[_system/scheduling/durations|durations]]. It is shared with plan-today's day
   plan, so a day and a week are placed the same way. Skip any Pass 1 question its duration table
   already answers.
3. **The calendar**, for the whole horizon, read-only: every calendar in the roster. **Unanswered
   invitations** and **provisional holds** (ask the user once how they mark holds that are not
   confirmed, for example a `Hold:` title prefix, and record it in working-conditions) get one line
   each asking whether they count. Do not plan around unconfirmed holds silently: a provisional
   hold that looks like a conflict distorts the whole plan. Deadline feeds (for example a course
   assignment calendar) are markers, not blocks: count the work behind them in Pass 2, including
   preparation time that is not on the calendar at all.

**If the calendar cannot be read, say so plainly and continue** on what the user tells you. Never
silently plan blind.

### Pass 0b: sweep the past first

**Before placing anything new, list every task whose `scheduled` date is already in the past.**
For each: re-place it, or clear the date back to Someday. Without this, every run adds to a pile
of stale commitments and `ToDo` becomes a graveyard the user stops opening. Do it first because
arrears are real load: capacity computed without them is fiction.

### Pass 0c: reconcile past calendar blocks against task status

*Also runs daily:* [[_system/skills/plan-today/SKILL|plan-today]] applies this pass's logic every
morning, since the last morning, as its check-in panel. A weekly run therefore usually finds little
left to reconcile.

Pass 0b sweeps dates inside the vault. It never asks whether the calendar block actually happened.
Those are different failures, and only the second is silent:

- **Block happened, task not ticked**: the backlog overstates the work. Re-planning it wastes a
  slot, and the user loses the credit for having done it.
- **Block passed, work did not happen**: real arrears, and the reason usually matters more than
  the fact. A block skipped because it was blocked on a decision is not the same as one skipped
  because the day ran out.

**Read the calendar back to the last run** (typically 2-3 days, never more than the previous
horizon) and line each past block up against its task. **Output one table in this shape**, verdict
marked with a symbol so the rows needing the user are findable at a glance:

```
| Calendar block              | Task                | Vault says       | Verdict                       |
|-----------------------------|---------------------|------------------|-------------------------------|
| Tue, 09:00-11:00 Report     | Write the report    | `done`           | ✅ consistent                 |
| Wed, 14:00-15:00 Flights    | Book flights        | open, due Thu    | ❓ **did this block happen?** |
| Thu, 10:00-11:00 Venue      | Book the venue      | open             | ❌ didn't happen: still deciding |
| (no block)                  | Reply to landlord   | open, sched. Mon | ❓                            |
```

- **✅ needs no answer**; it shows the check ran.
- **❓ is the ask.** One table, answered in one pass.
- **❌ only where something else in the run already proves it** (for example a booking that cannot
  have happened because the decision gating it is still open). Never assert ❌ from a hunch.
- **Include rows with no block at all** where `scheduled` has passed: that is Pass 0b's output
  folded into the same table.

**Ask, do not infer.** **Marking a task `done` from their answer is allowed and expected**; say
which ones you closed.

**Look forward too.** For every task now `done`, or whose `scheduled` moved, search the horizon
ahead for blocks whose `Task:` line points at it. A future block for a closed task is stale by
definition: list it with the verdict `🗑 stale, future`. Deleting is still the user's, unless the
task was closed in this session at their word, in which case the block goes with the task.

### Pass 1: ask what is missing from the calendar

**This is a gate. Do not plan past it.** An empty or thin calendar does not mean an empty life:
it means **the calendar under-represents reality**, and scheduling against it produces a fantasy
plan with confident-looking numbers.

**Ask in two stages, in this order. The order is the whole point.** Answers that invalidate the
whole plan (when the day starts and ends) must be asked before answers that merely add detail.
Asked the other way round, two sentences ("my day starts at 09:30", "evenings are taken") can
invalidate most of a finished plan.

#### Pass 1a: the shape of the day

Ask this alone, first, and wait. **Ask it as a structured set, not one open question**: a single
"what does your day look like?" produces a long answer that still has to be taken apart by hand.
If [[_system/working-conditions|working-conditions]] already holds answers, show them and ask only
what changed.

| Key | Question |
|---|---|
| **weekdays** | When does the day start and end, and when is lunch? |
| **weekends** | Same, and how much of a weekend day is actually work? |
| **travel** | Anything in the horizon that eats days, including transfers and the days either side? |
| **sport** | What does exercise actually cost in hours, and when do you prefer it? |
| **appointments** | Anything fixed with another person in it? |
| **weekday shape** | How do you want weekdays to run: mornings for what, evenings free or working? |
| **weekend shape** | Same question, for weekends? |

Weekdays and weekends are asked separately on purpose: "6 h a weekday, 3 h a weekend day" flattened
into one number is wrong for both.

If what the user says differs from working-conditions, their answer wins and the file is stale:
say so.

**Then multiply out loud before going further:** *"That is N hours a day, M days, so H hours gross
before commitments."* A plan whose gross capacity was never stated cannot be sanity-checked.

#### Pass 1b: what is in the day

Only now, state what you found and ask for the contents:

> Your calendar has **N events** between today and <date>. What is real but not in there?

Then a short, blunt, all-at-once list (same shape as `dump`'s sweep, for the same reason: they
scan and answer in one pass):

- **Fixed commitments**: appointments, calls, anything with another person in it
- **Travel**: travel days, transfers, and the days either side that are effectively gone
- **Family and household**: anything that eats a morning
- **Social plans**: anything with a time on it already agreed
- **Anything in the next 10 days you already know will happen**

#### Committed time missing from the calendar becomes a block

**The answers to 1b have to become calendar events**, not just session constraints. A commitment
known for days and held only in conversation stays invisible to every capacity calculation, and it
is gone the moment the session ends. So **propose these as blocks alongside the work blocks in
Pass 5**, on the same terms: one reviewable list, written only after approval.

- **Travel eats more than the trip.** Ask for the transfer and the days either side, and block
  those too. An evening flight is not a free afternoon.
- **Busy for all of it.** These are immovable by definition.
- **Do not re-block what is already there.** Check the calendar first.

#### What to do with the rest of the answers

Take them as constraints for this session. **This skill creates no task notes.** But **durable
working conditions get written to [[_system/working-conditions|working-conditions]]**, not to
`Inbox/`:

- **Every condition carries an expiry.** "Day ends 18:30" might be true for a week; "day starts
  09:30" for a month. A condition without an expiry gets carried into a week where it is false.
- **Propose the write, do not slip it in.** One line at the end, naming what you would record and
  until when.

#### Pass 1c: something to look forward to

**Ask directly:** *"Is there something this week, or next, you're genuinely looking forward to? If
not, let's put one in."* A week that is entirely obligations and avoided things is not a neutral
outcome; one or two things to look forward to change how the whole week feels.

- **If yes, it becomes a block** like anything in Pass 1b: check it is actually on the calendar.
- **If no, do not skip it.** Propose one concrete, schedulable thing (a dinner, a call with a
  specific friend, a film) rather than a vague aspiration.
- **Pre-scheduling social plans for next week is in scope.** Raise it rather than waiting.

It sits before the capacity report because it has to compete for real hours like everything else;
asked after, it gets discarded for lack of room.

### Pass 2: the capacity report, in hours, before any placement

**Mandatory, and it comes before the plan.** An over-full list is the expected default, not a
personal failure, and saying so plainly is part of the job.

Report four numbers:

1. **Committed hours** in the horizon: calendar plus whatever Pass 1 surfaced.
2. **Free hours** left, per day and in total.
3. **Work outstanding**, in hours, from `timeEstimate`. Break out `4-high` separately.
4. **The gap**, stated as a rate, because a rate is what someone can feel:

> **30 h of `4-high` work, 18 h of it due within 8 days: that is 2.5 h a day, every day,
> including weekends, on high-priority work alone.**

Say the equivalent of that sentence every run, recomputed.

#### The 80% rule: never plan the last fifth of the capacity

**Allocate at most 80% of the free hours. The remaining fifth is the plan's tolerance for being
wrong**, and every plan is wrong somewhere. A back-to-back calendar has nowhere to overflow when a
task runs long.

- Compute the ceiling explicitly: *"49 h free, so this plan stops at 39 h."* State both numbers.
- **When a request pushes the plan past the ceiling, say what has to come out.** Do not absorb it
  silently. The user may spend the last fifth deliberately; they must not spend it by accident.
- **The reserved fifth gets its own blocks**, named `Buffer`, free, spread across the week (about
  one per working day) rather than banked at the end: an overrun on Tuesday cannot be absorbed by a
  Friday buffer. Unbooked time is invisible time, and invisible time gets filled.

**Then stop and let the user react before placing anything.** The honest number sometimes changes
what they want scheduled.

### Pass 2b: name the week's big rocks, before anything gets placed

**Before Pass 3 places a single block, name the week's big rocks: at most four or five, named, and
confirmed.** The work that would make the week a failure if it slipped, not everything merely
scheduled. Pull from `important-not-urgent` items and the hardest deadlines.

- **Cap at 4-5.** If more qualify, that is the finding: ask what drops.
- **Every big rock carries a done-by date and a definition of done.** "Trips" means nothing until
  it is "flights booked and hotel cancelled, by Sunday". Ask when it is not self-evident, write
  both into the task, and say plainly when a rock depends on someone else.
- **Check deadlines against travel.** For every trip in or just beyond the horizon, list
  deliverables due during it or the day after, and pull them before departure.
- Show the list, then wait. Pass 5's closing report echoes it back.

### Pass 3: place, in this order of precedence

**Every block obeys [[_system/scheduling/scheduling-rules|scheduling-rules]]** (length, gaps, daily
cap, energy placement).

**The week is built around the top two quadrants, and everything else fills the gaps.** Place every
`urgent-important` item first, then every `important-not-urgent` item, and only then the rest. The
steps below govern *how* each item is placed:

**a. Protected important-not-urgent blocks, first.** Important-not-urgent work loses by default to
louder urgent noise unless it is actually scheduled: schedule your priorities, do not just
prioritise your schedule. **Nothing with a deadline will ever lose to them, which is exactly why
they go first.** Protecting this time is arguably the most valuable thing this skill does.

**b. Breakdown sessions for `needs-breakdown` items.** **Never schedule a `needs-breakdown` task
whole.** Its `360` is a floor, not an estimate, and a six-hour undecomposed block is a placeholder
that will not be started. Schedule a **45-60 minute session to break it down**, and say so in the
block title. Do not invent the subtasks here.

**c. Deadline-forced items.** `scheduled` falls **on or before `due`**. Where a deadline cannot be
met with the hours available, **say it will be missed** rather than placing it on its due date and
calling it planned.

**d. `run-up` work into protected blocks** in the energy peaks working-conditions reserves for
demanding work. These need a block; they do not fit gaps.

**e. `cold` work into the gaps.** Short, openable tasks fill the space between commitments.
Front-load tasks tagged `blocking-someone`: cheap, high leverage, and someone else is stalled.

**f. Stop when the hours run out**, not when the list runs out. Everything left over goes into
Pass 5's deferred list by name. Silently unplaced is the failure mode.

**Show the whole plan in one pass, early.** A plan that arrives in pieces takes many rounds to
settle. If the run starts after the morning, propose and create today's blocks first (they are
needed within the hour), then the rest of the horizon as one list.

### Pass 4: write `scheduled`, and only `scheduled`

Show the proposed placement **as one reviewable list, grouped by day**, and wait. Never task by
task.

**Key every row with a short keyword, never a number or letter** (dictation renumbers lists; rule in
`_system/SYSTEM.md` § How Claude operates). Echo back by key plus title.

Then write `scheduled: YYYY-MM-DD` on the confirmed ones. Nothing else changes.

### Pass 5: the blocks, then the report

**Output the week as text the user can read and act on.** Per day: what is already in the
calendar, then the proposed blocks with times, then the loose `cold` items with no fixed slot.
Something they could copy into a calendar by hand in two minutes. **If a calendar connector is
available and they approve, create the blocks** following the conventions above; otherwise say
creating them is theirs.

Then the closing report:

- **The important goals of the week, first**: the big rocks from Pass 2b, three to five lines.
  What the user should be able to read in five seconds and know the week points at the right things.
- **What got scheduled**, by day, with the daily hour load.
- **What did not**, by name, with a one-line reason. **Not optional**: if items vanish silently
  the user stops trusting the output.
- **Waiting items** (`waiting: true`), listed separately and never placed as work; their
  `scheduled` holds the chase date (shared with plan-today).
- **The gap restated**, one line.
- **The gut-check, two questions:**
  1. *"Does this week match the priorities you actually have right now?"*, checked against the
     big-rocks list, not the plan in isolation.
  2. *"Zooming out: are the things that matter most actually on track, not just this week's slice
     of them?"* This catches the same important thing being deferred week after week, which a
     single-week check cannot see.

  If either answer is no, the plan is wrong, not the user.

### Pass 6: reconcile and confirm, before the session ends

**A session is finished when the calendar and the vault say the same thing, and the user has said
the plan works.** Plans change several times mid-session (a block moves, an appointment arrives),
and every change can silently invalidate a date already written to a note.

1. **Reconcile vault against calendar.** For every task that got a `scheduled` date this session,
   confirm a block still exists on that date. Where a block moved day, rewrite `scheduled`. Where
   a block was dropped, decide with the user: re-place, or clear back to Someday. Multi-session
   tasks keep `scheduled` at the **start** date and their session plan in the body.
2. **Report the drift explicitly, even when there is none.** *"23 notes carry dates; all 23 still
   match a block"* takes one line. Silence is not agreement.
3. **Ask the closing questions:** *"Does this schedule work? Be honest. What's missing? Are the
   important things in there?"* This asks whether the plan is **correct** (right days, nothing
   double-booked, nothing missing), separate from the Pass 5 gut-check about whether the week can
   go *well*.

**Name what needs the user's hand**: events this skill may not delete, conflicts it could not
resolve, days that exceed their own stated limits.

## What drives placement

| Field | Effect |
|---|---|
| `startable: run-up` | Needs a protected block in an energy peak from working-conditions. **Never in the dip** |
| `startable: cold` | Fits a gap between commitments. The filler pool |
| `startable` unset | Default `timeEstimate <= 30` to `cold`; ask one word for the rest, only for tasks being placed |
| `timeEstimate` | Block length: **x 1.5, rounded up to 15 min**, or the task type's door-to-door duration when [[_system/scheduling/durations\|durations]] has one (x 1.5 only on guesses, per scheduling-rules) |
| `timeEstimate: 360` + `needs-breakdown` | Unknown, not six hours. Schedule a breakdown session |
| `quadrant: important-not-urgent` | Gets a named protected block, placed first |
| `quadrant: urgent-not-important` | Batch into one low-energy slot; never give it the best hours |
| `due` | Hard ceiling on `scheduled`. Missable, but say so out loud |
| `priority` | Ordering within a competing slot only. **Never rewritten here** |
| `waiting: true` | Never placed as work; `scheduled` is its chase date. Listed separately |
| tag `blocking-someone` | Front of the `cold` queue |

**A booking deadline is not the travel date: pull it forward.** A "book flight" task whose `due`
equals the travel day is useless, and prices rise meanwhile. This skill may move a `due` earlier
for this reason: it is correcting a book-by date, not inventing a deadline. Say so.

## Why this skill is shaped the way it is

Decision record for all four loop skills: [[_system/daily-loop|daily-loop]].

## Improving this skill

When the user pushes back on how a run went, or changes something you proposed, **treat it as
design input rather than a correction to apply silently.** Convert it into concrete, specific
options and let them choose.

- **Ground every proposal in what actually happened in the run.**
- **Offer the review after a real run**, rather than waiting to be asked.
- **Record each adopted change in this file with its date and reason.**

**Do not edit this skill while a run is in progress.** Collect improvements, say you have noted
them, and **apply them after the run ends.** Expect the first few runs to correct Pass 1's
questions, the capacity format and the block conventions to fit the user's life.

## Notes

- **On demand**, like the other loop skills. Not scheduled.
- **Reading tasks:** `~/automation/bin/vt todos --json`
- **Never edit `ToDo.base` or any `.base` file from this skill.** Obsidian rewrites them.
- Horizon: [[Areas/North Star]] §1. Working conditions and calendars:
  [[_system/working-conditions|working-conditions]]. Placement rules:
  [[_system/scheduling/scheduling-rules|scheduling-rules]]. Two-axis rule and schema:
  `_system/SYSTEM.md`.
