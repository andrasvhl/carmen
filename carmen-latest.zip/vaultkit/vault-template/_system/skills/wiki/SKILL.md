---
name: wiki
description: Build, read and maintain the user's LLM wiki in `Wiki/`, the small compiled layer of what the user knows and has concluded, derived from their own notes. Use when the user says "ingest my notes into the wiki", "ingest <folder or note>", "add this to the wiki", "update the wiki", "what's pending in the wiki", "re-ingest", "lint the wiki", "check the wiki", or asks "what do I know about X", "what have I concluded about X", "what do my notes say about X", "what's my view on X", or asks for advice where their own past thinking matters. Also use before answering any question about the user's own knowledge, opinions or practices. Does NOT record atomic facts about the user (preferences, dates, numbers): those go to the profile layer via Master Profile. Never edits an article by hand on request: corrections go to the source note, then a re-ingest.
---

# Wiki

## What this does

Four workflows over `Wiki/`: **query** (answer from the wiki first, log what it could not
answer), **ingest** (compile new notes into articles, with a review stop), **re-ingest** (bring
articles up to date with sources that changed), and **lint** (check the wiki still holds its
rules). The rules and their reasons live in `_system/schema.md`; read it before the first ingest
in a session. This file is the procedure.

**The invariant, which every step below serves:** the wiki is derived, never authored. Every
claim in an article traces to a source note in `wiki_sources`. Nobody edits an article by hand,
including Claude when the user asks for a quick fix: the fix goes into the source, then that
source is re-ingested.

## Query: "what do I know about X"

1. **Say you are checking the wiki**, then read `Wiki/index.md` whole.
2. Read every article the index points to that bears on X, and follow their `wiki_sources` when
   a claim needs the user's exact words.
3. Answer. Cite articles as Obsidian links, and keep two things visibly apart: **what the user's
   own notes say** and **what Claude adds from general knowledge**. Never present the second as
   the first.
4. **If the wiki could not fully answer**, append a gap to `Wiki/log.md`:
   ```
   ## [YYYY-MM-DD] gap | <the question, in a line>

   What the wiki had, what was missing, and where in the vault it might live.
   ```
   Then continue down the lookup order in `CLAUDE.md` § Always true (profile, Vault Map, search
   the vault, then the web). A gap logged is the wiki's to-do list; do this every time, without
   asking.
5. **If the answer is a new synthesis worth keeping**, offer to file it back (§ Filing an answer
   back). Do not file it without a yes.

## Ingest: "ingest <slice> into the wiki"

1. **Fix the slice.** What the user named, or what `Wiki/_pending.md` lists. If they say "my
   notes" with no scope, propose a slice of ten to forty notes on one theme and confirm. Never
   the whole vault at once.
2. **Read every note in the slice**, and `Wiki/index.md`, and any existing article the slice
   plausibly touches.
3. **Judge each note** against `schema.md` § What is not a source: asserts something? text
   rather than a container? knowledge rather than logistics? for compiling rather than only for
   reading? Skip any note pointing to a credential, and stop to ask before recording anything
   about a named third party's health, finances or relationships.
4. **Step A: present the map, then stop.** A short table, keyed by article slug (not numbers):

   | Article | Claim in one line | Fed by | New or amended |
   |---|---|---|---|

   Then: what was merged and why; what failed the stub bar (two sources, or one plus an existing
   vault note) and is being held; what was rejected and under which test. **Wait for the user to
   approve or change the structure.** If they have said before that they trust the structural
   calls, say so and continue, but still show the map.
5. **Step B: write.**
   - Each article in the format in § Article template. Filename is the slug, kebab-case.
   - `wiki_origin: ingest`, `wiki_ingested: <today>`, every source in `wiki_sources` as a quoted
     wikilink. A source that feeds nothing still gets registered (next point).
   - `Wiki/index.md`: one line per new page, updated line for an amended one, in the right
     section. Move anything now covered out of "Not yet ingested".
   - Links both ways between related articles, as navigation only.
   - `Wiki/_sources.md`: a row for **every note read**, distilled or not, with its hash:
     ```bash
     shasum -a 256 "$VAULT_PATH/<path>" | cut -c1-12
     ```
     Distilled notes go in `## Ingested` (`| `path` | `hash` | <today> | slug, slug |`); the
     rest in `## Considered and not ingested` with the reason (`navigation`, `empty`,
     `container only`, `logistics`, `read, not distilled`, `stub bar, held on <slug>`). A note
     already registered gets its row updated, never a second row. Set `last_run:` in its
     frontmatter to now.
   - `Wiki/log.md`: append `## [YYYY-MM-DD] ingest | <slice>` with counts (read, rejected,
     distilled, articles written, articles amended) and any structural call the user made.
6. **Lint** the pages touched (§ Lint, first three checks), then report in a few lines: pages
   written, pages amended, held candidates, and anything that needs the user's judgement.

## Re-ingest: "ingest what's pending" / "update the wiki"

1. Read `Wiki/_pending.md`. If it is older than two days, recompute what changed yourself from
   `_sources.md` (hash every registered file and compare), since the server job may be down.
2. **Changed since it was distilled:** for each source, find what changed (the vault's git
   history if it has one, otherwise compare the source against the articles it feeds) and read
   those articles. Ask one question per article: does this change the claim? Then no change,
   amend, or propose a new article (which goes through Step A). Update the row's hash and date.
3. **Judged not-a-source but changed:** re-judge it. It may have grown into a real source.
4. **Registered but gone:** if the file moved, fix the row's path (and the `wiki_sources` links).
   If it was deleted, every claim resting only on it comes out of its articles.
5. **Cited but never registered:** add the row.
6. **New candidates:** treat as an ingest slice (Step A applies).
7. Append `## [YYYY-MM-DD] reingest | <what>` to `log.md`.

## Filing an answer back

Only with the user's yes. One test: can every claim in it be traced to something already in the
vault?

- **Yes, and the connection is what is new:** write the page with `wiki_origin: query`, citing
  the original sources (never other wiki pages as evidence). The stub bar still applies.
- **The user said something new in this conversation:** capture it to `Inbox/` as a
  `type: learning` note in the user's own words first (`vt todos --add` is for tasks; write a
  learning note directly with the Inbox schema), then ingest it.
- **It came from Claude** (general knowledge, web research): it is not the user's knowledge.
  It goes in only if the user deliberately captures it as a source.

## Lint: "lint the wiki"

Run all checks, then report findings grouped by check. **Fix only structure** (links, index,
registry rows); for anything about content, name the source that needs fixing and let the user
decide.

1. **Traceability.** Every article has `wiki_sources` (the structural files `index.md`,
   `Wiki.md`, `log.md`, `_sources.md`, `_pending.md` are exempt). Spot-check three claims per
   article against their sources; more for `wiki_origin: query` pages.
2. **Registry.** Every `wiki_sources` entry has a row in `_sources.md`; every row's file exists;
   every hash matches (`shasum`).
3. **Links.** No broken wikilinks in either direction.
4. **No wiki-as-evidence.** No article supports a claim only by pointing at another article.
5. **Contradictions** between articles: quote both sides, flag in both articles' tensions
   section on the next re-ingest of their sources. Never smooth over.
6. **Staleness.** Sections resting on a situation that has since moved on.
7. **Size.** `index.md` under 200 lines; articles failing the stub bar.
8. **Orphans:** report only. Never add links just to connect them.

Append `## [YYYY-MM-DD] lint | <summary>` to `log.md`.

## Article template

```markdown
---
type: wiki
wiki_origin: ingest
wiki_ingested: 2026-01-15
wiki_sources:
  - "[[Resources/Learning/Spaced repetition|Spaced repetition]]"
  - "[[Inbox/Flashcards stopped working after week three]]"
---

# Fixed slot beats intention

**Every review habit that lasted had a fixed daily slot; every one that relied on remembering
did not.** One or two sentences of argument.

## What the sources say

> Missed four days, deck went from 40 to 300 due. Only works if it's the first thing at 8:00.
> — [[Inbox/Flashcards stopped working after week three]]

The user's own words, quoted verbatim in the language they wrote them, each attributed. Say
whether each point was concluded by the user or read somewhere.

## How it connects

- [[another-article]]: one line on the connection. Navigation, not evidence.

## Tensions

Where sources disagree: quote both, say so. Omit the section if there are none.

## See also
```

## Rules

- **Never hand-edit an article on request.** "Change the wiki to say X" means: find the source,
  propose the edit to the source, then re-ingest. Why: a hand-edited page silently stops being
  reconstructible, and the whole wiki is only cheap to restructure while every page is.
- **Keep it small.** Fewer, denser articles. The index is read whole before every query; that
  only works while it stays short.
- **Atomic facts are not wiki material.** "Prefers morning study" is a profile fact (route via
  Master Profile). The wiki holds the synthesis, and links to the profile note rather than
  restating it.
- **Never put a password, PIN, recovery code or credential pointer in the wiki.**
- **Quotes stay verbatim, in the language the user wrote them.** Never translate or tidy a
  quoted source; the article's own prose can be in whatever language the vault uses.
- **Key every list the user answers by slug or keyword, never numbers** (`SYSTEM.md` § How
  Claude operates).

## Improving this skill

When the user pushes back on how a run went, or changes something proposed to them, **treat it
as design input rather than a correction to apply silently**: turn it into concrete options and
let them choose. Ground proposals in what actually happened in the run, offer the review after a
real run rather than waiting to be asked, and record each adopted change here with its date and
reason, so a later reader does not quietly revert it. A change to a rule (not just a procedure
step) also goes into `_system/schema.md`. **Never edit this skill while a run of it is in
progress**: collect the improvements, say so, and apply them once the run ends.
