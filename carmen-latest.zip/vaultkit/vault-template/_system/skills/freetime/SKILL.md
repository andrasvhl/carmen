---
name: freetime
description: Find when most of a group of the user's contacts (classmates, colleagues, friends) are free, in one fast script call. Use whenever the user asks when a WhatsApp group (or a set of people) is free, wants to find a time for a dinner, drinks or meeting with several people, asks "who's free", "when can the book club do dinner", "find a slot for the team", or wants calendars compared. Runs `vt freetime`, which reads the group's members from WhatsApp, resolves them to email addresses via the CRM (Gmail fallback, written back to the CRM), and pulls everyone's free/busy in one request. Never resolve members or query calendars one by one by hand; that is what this replaces.
---

# freetime

## What this does

One command, about 10 seconds:

```bash
~/automation/bin/vt freetime "<group name or unique part>"
```

Defaults: next 14 days from tomorrow, weekdays, 18:30 to 22:30 in <YOUR_TIMEZONE>, 2-hour slot. Flags:
`--days N`, `--from YYYY-MM-DD`, `--start HH:MM`, `--end HH:MM`, `--duration MIN`,
`--weekends`, `--top N`, `--no-save`, `--json`. Code: `~/automation/tools/freetime.py`.

Pipeline: WhatsApp group members (WAHA on <SERVER>, one ssh round trip) → CRM
`Areas/People` by phone, then by name → Gmail headers for anyone left → Google Calendar
`freeBusy` for everyone at once → per-evening best slot, preferring slots the user can make.

## How to run it

1. **Map the user's words to the group.** Pass their phrasing as the query; the script matches any
   unique substring, ignoring case, spaces and accents. If it reports `ambiguous`, show the
   candidates and ask which. **Do not guess between similarly named groups** (e.g. two class
   years or two cohorts of the same community): picking the wrong one is the easiest mistake to make.
2. **Translate the user's constraints into flags** ("lunch" → `--start 11:30 --end 14:00 --duration 60`;
   "this week" → `--days 7`; "weekend brunch" → `--weekends`). State the window you used.
3. **Present the table as printed, then the gaps.** Lead with the recommended evening and
   why (most people *and* a window long enough for the event). Always relay the blank,
   no-access and unresolved lists: a slot is only as good as the calendars behind it.
4. **Offer the next step**: a drafted group message with one or two options. Never send it
   without the user's explicit yes (WhatsApp polls are broken in WAHA, so plain text).

## Reading the output honestly

- **Blank ≠ free.** A member with no busy block anywhere in the window, daytime included,
  is reported as blank and excluded from counts. It almost always means a hidden or unused
  calendar.
- **"Resolved from Gmail this run"** names are matched on first + last name in mail
  headers. They are written to the CRM automatically (additive only: an email or phone is
  appended, never replaced; new notes only where no file exists). Say in one line what was
  recorded, per the vault's record-durable-facts rule.
- **First-name-only members** (WhatsApp pushname like "Sam") are never guessed. If the user
  tells you who they are, add their email to their CRM note with `crm_email`, and
  the next run picks them up.
- Calendar free does not mean socially free. Say so if the margin between options is small.

## Setup and failure modes

- **Token:** `~/.config/vt/google.json`, scopes `calendar.freebusy` + `gmail.readonly`,
  separate from the gws MCP's token. Missing or revoked → run `vt freetime --auth`
  (the user signs in once in the browser).
- **WhatsApp read failed** → WAHA session or ssh to <SERVER> is down; see
  [[_system/whatsapp-bridge|whatsapp-bridge]] § Reading WhatsApp.
- **No calendar access** for a person → their org hides free/busy; nothing to fix here.
- Runs from the Mac (interactive only, not unattended). On <SERVER> it reads WAHA
  locally, but the token lives on the Mac.
- Identities live in the CRM person notes, not a separate cache, and the free/busy scope is
  what makes this one script call instead of one calendar query per person.

## Improving this skill

**Standing convention, applies to every skill in this vault.** When the user pushes back on how a run went, or changes something proposed to them, **treat it as design input rather than a correction to apply silently**: convert it into concrete, specific options and let the user choose. Quiet compliance wastes the most valuable moment a skill gets: right after it has been used for real. Ground proposals in what actually happened in that run rather than in general reasoning; offer the review after a real run rather than waiting to be asked; and record each adopted change in the skill file with its date and reason, so a later reader doesn't quietly revert it. **Never edit a skill while a run of it is in progress**: collect the improvements, say so, and apply them once the run ends; amending the process mid-flight makes the user follow a moving target while doing the work. **Copy this clause into every new skill as an `## Improving this skill` section**: a short duplicated block is more reliable than a pointer that may not get followed.

## History
