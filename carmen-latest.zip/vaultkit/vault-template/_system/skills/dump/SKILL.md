---
name: dump
description: Run a verbal brain dump, the offloading half of a daily check-in. Use whenever the user says "dump", "brain dump", "let's do a dump", "do a check-in", "empty my head", "here's what's on my mind", or starts listing things they are worried about forgetting. Captures everything they say verbatim into a dated note in the Obsidian Inbox, offers a blunt cued sweep afterwards, and stops. Does NOT create tasks; that is the separate commit-to-action skill.
---

# Dump

The offloading half of the daily check-in. The other half is `commit-to-action`, which turns a
dump into real tasks. **These are deliberately separate. This skill never creates tasks.**

Vault root: the folder holding the vault's `CLAUDE.md` (`$VAULT_PATH` if set).

## What this is actually for

**This is an offloading exercise, not a task-collection exercise.** What the user is buying is
an emptier head. The list is a byproduct.

What goes in here is best described as *things on my mind that weigh on me and that I need to
do.* Worry is the retrieval cue, and that drives every rule below.

Two consequences that override any instinct to be helpful:

1. **Completeness beats precision.** 90% captured roughly is worth far more than 60% captured
   cleanly. Never trade coverage for structure.
2. **Not everything said is a task.** Some items are worries with no available action, some are
   decisions rather than to-dos, some are already handled. Do not reshape any of it. Sorting
   happens in `commit-to-action`, not here.

## Hard prohibitions

**Throughout Phases 1 and 2, you must not:**

- Ask a clarifying question about anything the user has said
- Comment on, react to, or evaluate any item
- Offer advice, solutions, encouragement, or reassurance
- Rank or reorder items
- Create any task note, or edit any existing note
- Suggest what they might have meant
- Respond at length to an interesting item

**Why this is a prohibition list and not a style note:** default helpful behaviour destroys a
dump. Answering item three while the user is still trying to remember item seven costs them item
seven. Silence is the feature. The most common failure of this skill is being useful too early.

The recall aids in Phase 1 and the already-covered markers in Phase 2 are the **only**
exceptions, and both serve completeness rather than organising anything.

## Phase 1: freeform dump

**Lead with two questions, then go freeform:**

> **1. What are you undecided about?** Include anything that looks like a reply or an RSVP but
> is really a decision you have not made yet.
> **2. What are you avoiding that's important?**
>
> Then freeform: whatever else is on your mind, in any order.

Ask all of it in one message and let them answer in whatever order they like. Do not wait for an
answer to the first before they start talking.

**Why the undecided question comes first.** Background stress often tracks how many things are
*undecided*, not how much there is to do. Undecided items are quiet by construction: they do not
feel like tasks, they feel like fog, so the freeform half does not reach them. An RSVP that sits
for weeks is usually not open because nobody replied; it is open because the user has not
decided whether to go.

**The two questions overlap but are not the same; do not merge them.** Avoidance is emotional
resistance. Undecided is a missing choice. An RSVP can be undecided without being avoided;
homework can be avoided while being entirely decided.

**Why avoidance is up front too.** It is the highest-yield cue in the whole skill. Loud items
come out on their own; the important avoided one does not, and a freeform dump typically runs
its course without reaching it.

**The cost is real: this makes Phase 1 less freeform.** Everything after these two questions is
still hands-off. **Questions at the top are not the same as reacting to what the user says.** Two
is the ceiling: do not add a third.

Then **stay out of the way.** People dictate in several bursts rather than one monologue, so
expect multiple messages.

Between bursts, acknowledge in **at most a few words**, never referencing content. `Got it.`
`Keep going.` That is the entire allowed response. It exists only so they know it is recording.

### Two recall aids: offer when they stall, or whenever they ask

**A. Running readback.** A compact bulleted list of what has been captured so far, in their
words, in the order said. No grouping, no interpretation. It answers "what have I already
said?" so they can scan instead of re-derive, which also cuts duplicates in Phase 2.

**B. Broad pointers.** Deliberately wide buckets, meant only to shake something loose:

> people · commitments · money · body · travel · home · work · anything with a date

**Offer these only when they pause, stall, or ask.** Never interrupt a flowing dump with them.

### Ending Phase 1

**Ask explicitly; do not wait for them to say "done".** People run dry without ever signalling
the end, then have to ask for the next step themselves.

> Ready for the sweep?

If they want to keep going, stay in Phase 1 and ask again later. They can also decline the
sweep and go straight to Phase 3.

## Phase 2: cued sweep

**Present all cues at once, as one list keyed by short keywords**, never numbers (dictation
renumbers lists; rule in `_system/SYSTEM.md` § How Claude operates). Bold key first, then the
cue, so they can answer *"avoiding: ..."*. All at once works better than one at a time: they
scan the list and work down it at their own pace, with no round trips.

The freeform dump catches what is loud. The sweep catches what is quiet, and the quiet items are
often exactly what generates background stress, because they never surface on their own. The
sweep regularly produces *more* high-stakes items than the freeform half.

**Build the list like this:**

1. **Read `Areas/North Star` §2** and use its current priorities as the first cues (one keyword
   each). Never hardcode them: reading the file means the sweep tracks priorities as they
   change. If the file's `revisit` date has passed, say so in one line and continue anyway. If
   North Star is still the empty template, skip this step and say so in one line.
2. **Then always these six generic cues**, which pull loose what the priority cues miss:
   - **undecided**: What are you still undecided about? *(Asked in Phase 1 too; here it is a
     follow-up with the already-covered marker, not a repeat.)*
   - **waiting**: Who's waiting on you?
   - **promised**: What have you promised someone?
   - **avoiding**: What have you been avoiding?
   - **admin**: Money and admin
   - **deadlines**: Anything with a deadline in the next 7 days

**Mark what they have already covered.** Against any cue they already spoke to, append a very
short reminder of what they said: a few words, their words, enough to recognise. They then add
only what is new. This is a recall aid, not a reorganisation: it never changes what gets written.

**Be blunt.** Do not soften the cues, cushion them, or apologise for asking. *"What have you
been avoiding?"* is the least comfortable question and the most useful one. Ask it plainly.

Same prohibitions apply throughout: capture the answers, react to none of them.

## Phase 3: write, read back, stop

**1. Write the transcript** to `Inbox/Dump YYYY-MM-DD HHMM.md`:

```yaml
---
type: dump
captured: 2026-01-15T16:33
status: inbox
---
```

Then their words, under two headings: `## Free dump` and `## Sweep`. Within the sweep, label each
block with the cue that pulled it. Keeping the two phases separate is provenance, not
interpretation: sweep items are the ones they *forgot*, and over time that shows what
chronically drops out of their head.

**Verbatim means verbatim.** Preserve the wording exactly. You may repair obvious dictation
punctuation, and proper nouns under the rule below; nothing else. Never reword, reorder,
summarise, merge, or drop anything, including items that seem trivial, contradictory, or already
handled. Fidelity is the whole point, because `commit-to-action` re-reads this file.

**Repair garbled proper nouns, but declare every repair at readback.** Dictation mangles names
at a high rate.

- Repair a name only when a **known vault entity** makes it unambiguous: a project folder, an
  area note, a person note. Otherwise write what was said and leave it.
- **List every repair at readback**, as a short line under the bulleted list:
  `Repaired: "Akme" → Acme`. The user vetoes or corrects it there. This is the only reaction to
  content permitted in Phase 3, because only the user knows the true name.
- **Never treat the vault as authoritative over the user.** The vault itself can carry a typo.
  When they correct a name, fix the transcript **and** search the vault for the wrong spelling.

**Some duplication between the two sections is expected and fine.** Do not deduplicate:
`commit-to-action` resolves overlaps when it creates tasks.

`status: inbox` marks the dump unprocessed. `commit-to-action` sets it to `done` once it has been
turned into tasks.

**2. Read back** a flat bulleted list of everything heard, in their words, no grouping and no
interpretation. Then the repair line, if any. Then ask exactly one question:

> Anything missing?

This is both the check that the capture was faithful and the moment they actually get to let go
of the list. Add anything they add, and rewrite the note.

**3. Stop.** Offer, in one line, that `commit-to-action` is the next step, then wait. **Do not
run it, and do not create tasks.** They chain them when they want to; they stay two separate acts.

## Why this skill is shaped the way it is

Decision record for all four loop skills: [[_system/daily-loop|daily-loop]]. This file is
instructions; that one is reasoning.

## Improving this skill

When the user pushes back on how a run went, or changes something you proposed, **treat it as
design input rather than a correction to apply silently.** Convert it into concrete, specific
options and let them choose. Complying quietly wastes the most valuable moment a skill gets: the
one right after it has been used for real.

- **Ground every proposal in what actually happened in the run.** "The sweep produced more
  high-stakes items than the freeform half" beats "the sweep seems useful."
- **Offer the review after a real run**, rather than waiting to be asked.
- **Record each adopted change in this file with its date and reason**, so a later reader does
  not quietly revert it.
- **Never edit this skill while a run is in progress.** Collect improvements and apply them after.

## Notes

- **Email, messages and other sources deliberately do not feed this skill.** The dump stays
  purely what is in the user's head; the moment it also reviews an inbox it becomes an admin
  session and loses its offloading character. External sources are inputs to
  `commit-to-action` instead.
- Daily dumps accumulating in `Inbox/` is fine and expected.
- Task schema and vault conventions: `_system/SYSTEM.md`. Priorities: `Areas/North Star.md`.
