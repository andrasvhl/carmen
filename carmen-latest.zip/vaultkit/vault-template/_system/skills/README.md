---
type: reference
component: skills-conventions
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Skills: conventions

**How skills are written and maintained in this vault.** Read this before creating or editing
any skill. It lives inside `_system/skills/` so it is where you already are when the rule
applies.

## Where skills live

**Source of truth is `_system/skills/<name>/SKILL.md`, symlinked into `~/.claude/skills/<name>`.**
Never author a skill directly under `~/.claude/` and plan to move it later.

```bash
ln -s "$VAULT_PATH/_system/skills/<name>" ~/.claude/skills/<name>
```

Why: the vault syncs and is backed up; `~/.claude/` is local to one machine, so a skill written
there silently diverges from every other copy. The full rule lives in
[[_system/SYSTEM|SYSTEM]] § Skills and capture paths.

**If you find a skill still living only in `~/.claude/`, do not silently migrate it: create a
task.** A move is usually also a correctness review of code written against an older schema.

**Skills read the task backlog through `vt todos --json`, never by reimplementing it.** One
definition of "active task", mirrored from `ToDo.base`. Two definitions drift, and then two
skills disagree about what is on the list.

## Writing a skill

- **The `description:` decides when it fires.** List the phrases the user actually says
  ("dump", "plan my week"), and say what the skill does NOT do, so a neighbouring skill wins
  when it should.
- **Instructions in the skill, reasoning nearby.** Keep the "why" next to each rule it explains
  (one or two sentences), so a later editor does not quietly delete a rule that looks arbitrary.
  Longer decision records go in a component doc (for the loop skills, [[_system/daily-loop|daily-loop]]).
- **Address the user as "the user"**, and keep personal details (names, calendars, accounts)
  out of the skill. They belong in profile notes or [[_system/working-conditions|working-conditions]],
  which the skill reads.

## Improving a skill after it runs

**Every skill carries a self-improvement clause.** When the user pushes back on how a run went,
or changes something proposed to them, **treat it as design input rather than a correction to
apply silently**: convert it into concrete, specific options and let them choose. Quiet
compliance wastes the most valuable moment a skill gets: right after it has been used for real.
Ground proposals in what actually happened in that run rather than in general reasoning; offer
the review after a real run rather than waiting to be asked; and record each adopted change in
the skill file with its date and reason, so a later reader does not quietly revert it. **Never
edit a skill while a run of it is in progress**: collect the improvements, say so, and apply
them once the run ends. **Copy this clause into every new skill as an `## Improving this skill`
section**: a short duplicated block is more reliable than a pointer that may not get followed.

## The skills shipped here

`dump` · `commit-to-action` · `prioritise` · `schedule-work` · `obsidian-todo` · `wiki`.
Optional, with its kit module: `canvas-archive` (the kit's `modules/canvas/README.md`; design in
[[_system/canvas-archive|canvas-archive]]). Link it only if you use that module.
Plus the `otodos` slash command in `_system/claude/commands/`. Design reasoning for the first
four is in [[_system/daily-loop|daily-loop]]; for `wiki`, in [[_system/schema|schema]].

## See also
- [[_system/SYSTEM|SYSTEM]]: owns the skills-live-in-the-vault decision
- [[_system/daily-loop|daily-loop]]: why the four loop skills are shaped as they are
- [[Claude Master Router]]: routes here
