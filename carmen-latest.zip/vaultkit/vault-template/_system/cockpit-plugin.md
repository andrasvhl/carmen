---
type: reference
component: cockpit-plugin
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Cockpit plugin: one-click task review layout

**Status:** built, shipped in `.obsidian/plugins/cockpit/`, verified <INSTALL-DATE>.
Referenced from `SYSTEM.md` § Components.

## What it's for

Getting to the daily review surface in one click, at full main-area width: three views of
`ToDo.base` laid out together, and back to whatever you had open the moment you click a task.
Optional: TaskNotes' own "Open tasks view" command opens `ToDo.base` too, one view at a time.

## How it works

| Action | Result |
|---|---|
| Click the ribbon icon (dashboard) | The main area becomes the Cockpit: **Today** and **Waiting** side by side on top, **As scheduled** across the bottom |
| Click a note while in the Cockpit | The previous layout comes back and the note opens full-size in a new tab |
| Click the ribbon icon again | Leave the Cockpit |

Two commands, both bindable to a hotkey: **Cockpit: Toggle Cockpit** and **Cockpit: Close
Cockpit**.

It is a mode over the main area only: it reads Obsidian's layout, swaps the main area, and puts
it back on exit. It never touches the sidebars or the ribbon. It makes no network requests, runs
no commands, and writes no files except its own settings.

## Setup / rebuild

Shipped as two files, `main.js` and `manifest.json`, in `.obsidian/plugins/cockpit/`, and listed
in `.obsidian/community-plugins.json`. No build step, not from the store.

1. Settings → Community plugins: Restricted mode off (turn on community plugins).
2. **Cockpit** appears under Installed plugins. Make sure its toggle is on.
3. Click the dashboard icon in the ribbon.

If the folder is missing (for example you copied only some template files into an existing
vault), copy `.obsidian/plugins/cockpit/` from the kit's `vault-template/` and enable it.

## Config

**Settings → Cockpit:**

| Setting | Default | Meaning |
|---|---|---|
| Base file | `ToDo.base` | Vault-relative path, including `.base` |
| Top-left view | `Today` | Required |
| Top-right view | `Waiting` | Empty means one pane across the top |
| Bottom view | `As scheduled` | Empty means no bottom pane |

View names must match the names inside the base exactly (any view in `ToDo.base` works:
`ToDo`, `Triage`, `Unscheduled`, ...). Changes apply the next time you open the Cockpit.

**To turn it off:** Settings → Community plugins → Cockpit toggle off. To remove it, delete
`.obsidian/plugins/cockpit/` and its line in `community-plugins.json`.

## Gotchas

- **Renaming a view in `ToDo.base` breaks its pane** until you update the name in Settings →
  Cockpit: the pane can show a different view of the base, and leaving the Cockpit by clicking
  a note stops working reliably because the plugin cannot find that pane.
- After editing `main.js`, toggle the plugin off and on: Obsidian does not reload plugin code.
- Failures show a notice and a console error starting `Cockpit:`, never a silent no-op.

## Known limitations

- **The saved layout is memory-only.** Quitting Obsidian while in the Cockpit loses the snapshot,
  so you reopen into the Cockpit split. Leave it before quitting.
- **The `bases` view type and its `{file, viewName}` state are undocumented**, read off
  `workspace.json` rather than public API. If a future Obsidian release renames them, the panes
  open empty: a one-line fix in `main.js`.

## Decisions

**A small plugin, not Obsidian's Workspaces core plugin.** A saved workspace stores the whole
layout including the ribbon's hidden items, so loading one silently restores old ribbon state.
Workspaces also has no command that loads a named workspace in one click; every route needs a
picker or two more plugins. One self-contained file avoids both.

## See also

- [[task-cockpit]]: the task system this lays out
- [[claude-task-launcher-plugin]]: the other shipped local plugin
- [[_system/SYSTEM|SYSTEM]]: the hub
