# SYSTEM: the productivity stack (Obsidian + Claude)

Routed here from [[Claude Master Router]]. This file covers the productivity system: capture,
the Inbox, the task schema and the cockpit. Cross-project Claude behaviour lives in
`~/.claude/CLAUDE.md`; vault-wide rules live in `CLAUDE.md` at the vault root.

**This file is a hub.** It holds the locked architecture decisions, the task schema, vault-wide
gotchas and one status line per component. Full detail for any component lives in its own doc
in `_system/`: go there, and update *there*, not here. If a section below grows past a
paragraph, that is the signal it belongs in a component doc.

---

## How Claude operates

**Documentation standard.** Every component doc in `_system/` follows
[[_component-doc-template]]: fixed frontmatter (`component`, `stage`, `verified`; never
`status:`, which is reserved for tasks), a status line under the H1, and a fixed section order.
Four rules matter most:

1. **`verified:` is a date and is mandatory**: when the doc's claims were last checked against
   the real system, not when the file was last touched.
2. **One name per concept:** *Gotchas* for traps that cost time, *Known limitations* for
   capability boundaries.
3. **Present tense above the fold, superseded material under `## History`.**
4. **This file gets one line per component.** Detail goes in the component doc.

`~/automation/bin/vt docs` checks every component doc against the template. Optionally, run it
as a Claude Code hook after every edit (see `SETUP-NOTES.md`), so a session that breaks the
standard is told while it can still fix it.

**Key every list the user answers with short keywords, never numbers or letters.** Applies to
every task or organisation list put in front of the user for a response: all the loop skills
(`dump`, `commit-to-action`, `prioritise`, `schedule-work`), `obsidian-todo`, and ad-hoc lists.
Why: people answer these lists by voice, and dictation tools renumber dictated lists on their
own, so answers land on the wrong rows. A keyword is the word the user would say anyway and
cannot be renumbered. One or two words from the title, unique within the list (on a clash add a
word: *flight ticket* / *flight forms*), bold in the first column, the same key for a task
across a whole session, and echo back by key plus title. Reasoning: [[daily-loop]] § Row keys.

**Closing a task closes its calendar blocks.** If `schedule-work` created calendar blocks, each
block's description carries a `Task: obsidian://open?...` line pointing at its task. So when a
task is marked `done`, cancelled, or has its `scheduled` date moved, search the calendars for its
encoded filename and delete or move every *future* block in the same step, and say which blocks
changed. Past blocks stay as the record. Why: otherwise blocks for cancelled work sit on the
calendar and eat capacity that does not exist.

**Never classify an incoming message by sender pattern alone.** When scanning mail or messages
for things that matter, "this looks like a recurring digest" is not grounds to dismiss it. Some
institutional senders (a school's deadline digest, a billing office, a tax office) are
deadline channels whose mail looks routine by design. **Rule of thumb:** if a message contains a
*Deadlines*, *Action required* or *Time sensitive* section, open it regardless of sender. And
never exclude whole mail categories (Promotions, Social, Updates) from a triage search: personal
invitations from event platforms land in Promotions. Judge items after reading their headers,
never by excluding envelopes before seeing them.

## Architecture decisions (locked)

- **Note-per-task, not a single task file.** The only setup satisfying three requirements at
  once: attachments (a note is a container, so a PDF can be dragged in), a real database (Bases
  turns a folder into an editable table), and drag-and-drop ordering (a list view writes back to
  frontmatter). Reading many small task files is cheap for Claude as long as task bodies stay
  light.
- **ONE database: the Inbox.** Every capture is a note in `Inbox/` with a `type` property.
  "Tasks" is NOT a separate folder; it is a Base view filtered to `type: action`. A captured
  action appears in the task list instantly because the task list is just a filter of the inbox.
  Splitting actions from everything else is filtering, not moving files. A separate `Tasks/`
  folder would add a move step with no benefit.
- **Before inventing any frontmatter property, read [[frontmatter-properties]].** Reserved names
  are read by software, and repurposing one breaks it silently. **`status:` is tasks only**
  (`inbox` / `open` / `done`); documents use **`stage:`**. Before this split existed, any query
  filtering on `status` without also filtering `type` silently mixed tasks and documents.
  **`snake_case`** for anything new.

### Capture note schema

- **Capture note schema** (reference: `Inbox/_Inbox Template.md`):
  ```
  ---
  type: ""            # "" (untriaged) | action | todo | learning | idea | reference | dump
  captured: 2026-01-15T14:22   # ISO local time to the minute
  status: inbox
  priority: 1-none
  ---
  <content in the body>
  ```
  Every capture path writes `priority` explicitly: `1-none` normally, and on urgent captures
  all three of `urgent: true`, `priority: 4-high` and **`scheduled: <today>`** (see below).
- **Every task carries a next action, as a checkbox, at the top of the body.** The layout:
  ```
  ---
  <frontmatter>
  ---

  ## Next action
  - [ ] Next: <one physical step>
  - [ ] Then: <optional, ordered, max three open lines>

  <quoted fragment, facts, status notes, Source: line>
  ```
  - **Definition of a well-defined task:** it has a clear next physical step as an open
    checkbox (`- [ ] Next: ...`), **or** it is waiting on someone or something
    (`waiting: true` plus `- [ ] Waiting: <who>, <on what>`). Anything else is **not well
    defined**, whatever its priority or date, and gets flagged at triage until it has one.
  - **Directly under the frontmatter**, before everything else, so it shows first when the note
    opens and in the cockpit's checklist column.
  - **Always a checkbox** (`- [ ]`), never prose.
  - **Every writer follows it:** `commit-to-action`, triage passes, hand edits. Updating a task
    means ticking and adding steps in that top block, never a new checklist further down.
  - **If no next action can be named, that is the finding, not a blank:** propose one and ask.
    Raw captures (quick-add, `vt todos --add`) arrive without a sharpened one; they get it at
    triage, and `prioritise` Pass 1 flags every task still missing one.
  - Why: a task you open and do not know how to start gets read and put down again. Naming the
    physical step converts an unbounded worry into something dismissible.
- **Two axes, kept apart: `priority` is importance, `scheduled` is commitment.** The
  `prioritise` skill writes `priority` and never decides `scheduled`; `schedule-work` writes
  `scheduled` and never `priority`. Priority is deliberately **not** a trigger for showing up in
  the `ToDo` view: unlike a date it never expires, so it would either clutter the list forever
  or need manual demotion every evening. Something else has to drive dates, and that is
  `schedule-work`. Neither skill ever writes `tasknotes_manual_order`; drag order is the
  user's alone.
  - **`prioritised: <ISO datetime>`**: when priority was last set. Lets a later pass tell a
    stale priority from a fresh one.
  - **`startable: cold | run-up`**: whether a task can be opened and started immediately, or
    needs thinking time first. **The scheduling skill's key input**: it is the difference
    between something that fits a gap and something needing a protected block.
  - **`decision: pending | made`**: marks a task whose real work is a **choice**, not
    execution. `pending` means no next physical action exists yet because the choice is not
    made; `made` means only follow-through remains. **Absent means the task is not
    decision-shaped**, which is most tasks. Consumer: the `Undecided` view in `ToDo.base`.
    **Undecided is not the same as unscheduled**: unscheduled means the work is known and the
    date is not; `decision: pending` means the work itself is not yet known. **`due` carries the
    decide-by date**, no separate field: the deadline that matters is when the choice has to
    exist, usually well before the event.
  - **Someone waiting on the user is the tag `blocking-someone`; the user waiting on someone
    else is `waiting: true`.** Two different states; do not conflate them.
  - **`quadrant`** uses plain speakable labels, not Q1-Q4: `urgent-important` /
    `important-not-urgent` / `urgent-not-important` / `neither`. **Importance is the `priority`
    tier; urgency is asked, not inferred.** Deriving urgency from "has a due date soon" fails:
    a task with no date can then never be urgent, and "urgent but not yet written down" is
    exactly the state that matters. Asking costs one word per task and makes
    *urgent-with-no-date* the trigger that generates a date.
  - **High priority is capped: 9 globally, max 3 per [[Areas/North Star]] §2 priority.** The
    limit is the mechanism and the exact digit is arbitrary; change the numbers in
    `prioritise` if yours differ. The cap unit is a North Star priority, **not** an `Areas/`
    folder: otherwise a broad area like Personal would cap its most important item together
    with every errand.
- **Urgent sets a date, not just a flag.** Without it an urgent capture never reaches the
  cockpit, because `ToDo` membership is "has a due date, or `scheduled` today or earlier".
  `scheduled` rather than `due` because `ToDo` matches `scheduled <= today()`, so an unfinished
  urgent item persists tomorrow without ever rendering overdue. **`due` stays reserved for real
  deadlines.**
- **Urgency is a one-way ratchet.** Claude may flag "this looks time-sensitive, confirm?" but
  never downgrades an existing `urgent: true` or `priority: 4-high`. The user's call only.

### Skills and capture paths

- **Skills live in the vault, not in `~/.claude/`.** Source of truth is
  `_system/skills/<name>/SKILL.md`; each is symlinked into `~/.claude/skills/<name>` so Claude
  Code can find it. Why: the vault syncs across devices and is backed up with your notes, so a
  skill written once works everywhere, while a `~/.claude/` copy is machine-local and silently
  diverges. Side benefit: skills are readable and editable as normal notes in Obsidian.
  - **The symlink is the only machine-local part**, so recreate it when a new machine joins:
    `ln -s "$VAULT_PATH/_system/skills/<name>" ~/.claude/skills/<name>`.
  - The `otodos` slash command lives in `_system/claude/commands/` and is linked into
    `~/.claude/commands/` the same way.
- **Capture paths.** The shipped one is `vt todos --add "text"` (or just asking Claude to "add
  X to my to-dos", which runs it). Anything else that writes a correctly shaped note into
  `Inbox/` works too: a Raycast or Alfred script on desktop, an Apple Shortcut using Obsidian's
  URI scheme on the phone. **Every capture path must write byte-identical notes** to the
  schema above, so the views never have to cope with two shapes. On mobile, pass the note
  content via the clipboard (`clipboard=true`), never inside the URL: long URLs truncate
  silently on iOS.
- **Capture must never block.** No capture path asks clarifying questions. Enrichment (project,
  due, quadrant) happens later, at triage.

## Components: status, one line each

**Standing rule: when a component changes, update its doc, not this table.** This table should
only ever need a one-line status edit.

| Component | Status | Doc |
|---|---|---|
| Daily loop (dump → commit → prioritise → schedule) | Shipped with the template | [[daily-loop]] |
| Task cockpit (TaskNotes + `ToDo.base` + `TaskNotes/Views/`) | Shipped, TaskNotes settings included; TaskNotes itself installed from the store (`SETUP-NOTES.md` § 3) | [[task-cockpit]] |
| Cockpit button (local plugin) | Shipped in `.obsidian/plugins/cockpit/`, on once community plugins are on | [[cockpit-plugin]] |
| Claude Task Launcher (local plugin) | Shipped in `.obsidian/plugins/claude-task-launcher/`; desktop launch needs the Claude Desktop app | [[claude-task-launcher-plugin]] |
| Fast task reader/writer (`vt todos`) | Shipped in the kit's automation repo | `_system/skills/obsidian-todo/SKILL.md` |
| Frontmatter property registry | Shipped | [[frontmatter-properties]] |
| Personal context layer (Master Profile + sub-profiles) | Template only; fill in by use | [[_system/profile-convention\|profile-convention]] |
| Working conditions and calendar roster | Template only; fill in on first `schedule-work` run | [[working-conditions]] |
| LLM wiki (`Wiki/`, compiled from the owner's notes) | Structure only; first ingest by the user, drift job optional on the server | [[schema]] |

**Standing rule: anything that needs regular checking afterwards gets a `revisit:` date or a
line here in the same session it is built.** Scheduled jobs, credentials and judgements with a
shelf life all rot silently, and a doc describing the thing is not a substitute for a date that
forces a look.

## Task cockpit

**The live cockpit is `ToDo.base` at the vault root**, rendered by the TaskNotes plugin, which
identifies tasks by property (`type: action`) and so reads the same notes in `Inbox/` with no
separate folder. `Inbox/Inbox.base` is the triage view over every capture; `TaskNotes/Views/`
holds TaskNotes' calendar, agenda, kanban and relationship views. Two small local plugins ship
with the vault: the **Cockpit** ribbon button (Today, Waiting and As scheduled in one layout)
and the **Claude Task Launcher** (a "Work in Claude" button on each task). `vt todos` reads the
same views from the command line.

Views, settings, gotchas and how the pieces fit: [[task-cockpit]]. The plugins:
[[cockpit-plugin]], [[claude-task-launcher-plugin]].

## Gotchas: vault-wide

Component-specific gotchas live in the component docs. These apply across the whole vault.

- **Infrastructure facts get documented once, in their `_system/` component doc; every other
  doc links to it, never restates it.** A restated copy goes stale the day the component
  changes, and nobody updates the copy. After changing a component's status, search the vault
  for the component name and check every file that mentions it.
- **A `.base` file is a view, not a database.** It stores no data, just filter, sort and
  display config over notes living elsewhere. This is also why capture is unaffected by
  whatever renders the cockpit: capture writes plain files, and the view is a swappable lens.
- **Don't hand-edit `.base` files or a plugin's `data.json`**, even though they are plain YAML
  or JSON. Obsidian silently rewrites and reformats them, so a correct edit can be reverted
  before you test it. Change them through Obsidian's UI (Settings for plugin config, the Base's
  own Sort / Filter toolbar for views). Plain notes are safe to edit directly.
- **TaskNotes' "Create files" and "Update files" buttons (Settings → General → View Commands)
  are destructive.** They regenerate the target `.base` from defaults and overwrite it, with no
  undo. To point a command at `ToDo.base`, type the full path **including `.base`** and press
  neither button. Copy `ToDo.base` somewhere outside the vault before touching that panel.
- **Don't reintroduce a separate Tasks folder.** One inbox database; tasks are a filtered view.
- **The project link field is `projects`, plural.** There is no singular `project`. If a
  singular one appears, a capture path is writing the wrong shape: fix the writer.
- **Don't put code projects (anything with `node_modules`) inside the vault.** It wrecks
  Obsidian indexing and sync.
- **A bulk import (from Notion or elsewhere) pollutes the property namespace.** Obsidian's
  property registry is vault-global, so an imported `Status` or `Priority` column can shadow
  the real lowercase field and make it unselectable in every Bases picker, silently. If you
  import, namespace the imported keys (`notion_status`), never lowercase them: lowercasing
  merges two unrelated fields. Use an underscore, never a hyphen: Base formulas read
  `notion-status` as subtraction.
- **Obsidian Sync does not sync plugin settings unless you turn that on.** "Active community
  plugin list" syncs *which* plugins are on; "Installed community plugins" syncs their files
  *and settings*. Without the second, each device runs its own TaskNotes config and they drift,
  which looks like a plugin bug ("Task not found" on the phone). Enable it on the main computer
  first, let it upload, then on the phone.
- **Preserve `urgent` as the user's call**: Claude never downgrades a high-priority or urgent
  item, only flags "confirm urgency?".
- **Verify tool and plugin facts by search**, not from memory: plugins change quickly.
- **Populate project tasks just in time.** Only the current stage of a project gets real task
  notes in `Inbox/`, not the whole roadmap upfront. A backlog of tasks for work months away
  buries what matters now.
