# SYSTEM: the productivity stack (Obsidian + Claude)

Routed here from [[Claude Master Router]]. This file covers the productivity system: capture,
the Inbox, the task schema and the cockpit. Cross-project Claude behaviour lives in
`~/.claude/CLAUDE.md`; vault-wide rules live in `CLAUDE.md` at the vault root.

**This file is a hub.** It holds the locked architecture decisions, the task schema, vault-wide
gotchas and one status line per component. Full detail for any component lives in its own doc
in `_system/`: go there, and update *there*, not here. If a section below grows past a
paragraph, that is the signal it belongs in a component doc.

---

## How Claude operates

**Build ideas wait for the build backlog.** When the user raises an idea for a new agent, skill,
automation or tool mid-session, capture it into the build backlog and say so in one line,
instead of starting to build it: a note in `Inbox/` with `type: idea`, `#build` as the first
body line, `priority: 3-normal` (or `4-high` if the user says so), and **no date**, which keeps
it out of the cockpit. The Raycast form and the phone Shortcut both have a "Build backlog" option
that writes exactly this. Any existing note can join by carrying the `build` tag, whatever its
`type`. Once a week the `build_brief` job turns the backlog into one brief task for a standing
build block in the calendar. Exception: something that already exists is broken and blocks the
user; fix that now. Detail in [[build-backlog]].

**When a step looks finished for now, update the task without being asked.** In any session,
with or without a skill: as soon as the work on a task reaches a natural pause (a message sent,
a decision made, a step done, now waiting on someone), write it into the task note in the same
turn: tick the done steps, set the new `Next:` or `Waiting:` line, record decisions and their
reasons in the body, and add a `## Log` line. **When the Next is ticked, the first `Then:`
becomes the Next and `scheduled` moves to the new Next's date** (or is cleared if it has none),
and the task's calendar blocks follow (next paragraph). Then say in one line what changed. Do not
wait to be asked to update the task.

**Closing a task closes its calendar blocks.** A task and its calendar blocks are linked one
way: each block's description carries `Task: obsidian://open?...&file=<encoded path>`
([[_system/skills/schedule-work/SKILL|schedule-work]] § block conventions). So in any session,
with or without a skill, when a task is marked `done`, cancelled, or has its `scheduled` moved,
**search the calendars `schedule-work` writes to for its encoded filename and deal with every
future block in the same step**: delete it if the task is done or cancelled, move it if the task
moved, and say which blocks changed. Past blocks stay as the record. When a task is renamed with
`vt move`, update the `Task:` line in its future blocks too, or the search stops finding them.
Why: otherwise blocks for cancelled work sit on the calendar and eat capacity that does not
exist.

**Class tasks carry their readings as direct links.** Any task for an assignment or class prep,
created or edited in any session, with or without a skill, lists every assigned reading as a
checkbox under `## Next action` with a direct link to it (archive note URI plus the original
URL). Format and edge cases: [[_system/skills/commit-to-action/SKILL|commit-to-action]] § Canvas.

**Documentation standard.** Every component doc in `_system/` follows
[[_component-doc-template]]: fixed frontmatter (`component`, `stage`, `verified`; never
`status:`, which is reserved for tasks), a status line under the H1, and a fixed section order.
When writing or editing a component doc, apply it. Four rules matter most:

1. **`verified:` is a date and is mandatory**: when the doc's claims were last checked against
   the real system, not when the file was last touched.
2. **One name per concept:** *Gotchas* for traps that cost time, *Known limitations* for
   capability boundaries. Not "Notes", "Risks", "Backlog" or "What this does NOT do".
3. **Present tense above the fold, superseded material under `## History`.** Never stack
   resolved diagnostic history in the reading path.
4. **This file gets one line per component.** Detail goes in the component doc.

**Enforced at write time:** a Claude Code hook runs `vt docs --hook` after every edit to a
`_system/` doc and returns violations to the editing session, so a session that breaks the
standard is told while it can still fix it (setup in `SETUP-NOTES.md`). `~/automation/bin/vt docs`
checks every component doc on demand, and `inventory` re-checks daily. Details:
[[_component-doc-template]] § Enforcement.

`mcp-instructions.md` (an agent prompt) is deliberately exempt: do not reshape it into the
template.

**Key every list the user answers with short keywords, never numbers or letters.** Applies to
every task or organisation list put in front of the user for a response: all the loop skills
(`dump`, `commit-to-action`, `prioritise`, `schedule-work`), `obsidian-todo`, and ad-hoc lists.
Why: people answer these lists by voice, and dictation tools renumber dictated lists on their
own, so answers land on the wrong rows. A keyword is the word the user would say anyway and
cannot be renumbered. One or two words from the title, unique within the list (on a clash add a
word: *flight ticket* / *flight forms*), bold in the first column, the same key for a task
across a whole session, and echo back by key plus title. Reasoning: [[daily-loop]] § Row keys.

**Never classify an incoming message by sender pattern alone.** When scanning, triaging or
enriching from any inbound channel, "this looks like a recurring automated digest" is not
grounds to dismiss it. Some institutional senders (a school's deadline digest, an international
office, a billing office, a health portal's secure-message notice, an academic advisor) are
deadline channels whose mail looks routine by design. **Rule of thumb:** if a message contains a
*Must Know*, *Deadlines*, *Action required* or *Time sensitive* section, open it regardless of
sender.

**Never exclude a Gmail category in a triage query.** No `-category:promotions`,
`-category:social`, `-category:updates`, or `-list:*`. Personal invitations arrive through
platforms that carry `List-Unsubscribe` headers and therefore land in Promotions (Paperless
Post, Partiful, Luma, Evite, Punchbowl, Calendly, Doodle, Google Forms). Excluding them silently
drops invitations and RSVP reminders. Judge items after reading their headers, never by
excluding envelopes before seeing them.

**All mailboxes, always.** If the user has more than one mailbox (for example a school or work
address and a personal one), each carries a different part of their life. Scanning one is not
scanning their mail. See [[gmail-mcp]].

## Architecture decisions (locked)

- **Note-per-task, not a single task file.** The only setup satisfying three requirements at
  once: attachments (a note is a container, so a PDF can be dragged in), a real database (Bases
  turns a folder into an editable table), and drag-and-drop ordering (a list view writes back to
  frontmatter). Reading many small task files is cheap for Claude as long as task bodies stay
  light: each note is mostly frontmatter, and attachments are `![[link]]` references not loaded
  unless opened.
- **ONE database: the Inbox.** Every capture is a note in `Inbox/` with a `type` property.
  "Tasks" is NOT a separate folder; it is a Base view filtered to `type: action`. A captured
  action appears in the task list instantly because the task list is just a filter of the inbox.
  Splitting actions from everything else is filtering, not moving files. A separate `Tasks/`
  folder would add a move step with no benefit.
- **Before inventing any frontmatter property, read [[frontmatter-properties]].** Reserved names
  are read by software, and repurposing one breaks it silently. Four rules carry most of the
  weight:
  - **`status:` is tasks only** (`inbox` / `open` / `in-progress` / `done` / `cancelled`).
    Documents, projects and notes use **`stage:`** (`built` / `partial` / `design-only` /
    `draft` / `active`). Generated pages carry neither. Without this split, any query filtering
    on `status` without also filtering `type` silently mixes tasks and documents.
  - **`verified:` and `revisit:` are the maintenance vocabulary.** Adding `revisit: <date>` to
    any note enrols it in the weekly tripwires sweep with no code change, and it will email you
    when the date arrives. `verified:` means a *person* checked the claims, so it never belongs
    on a generated file.
  - **Generated pages are `last_run:` + `healthy:`**, no `status`, no `stage`, no `verified`,
    no `captured`. Those four all imply a human acted.
  - **`snake_case` for anything new.** The `camelCase` properties are TaskNotes' own and cannot
    be changed; do not add more.

### Capture note schema

- **Capture note schema** (reference: `Inbox/_Inbox Template.md`):
  ```
  ---
  type: ""            # "" (untriaged) | action | todo | learning | idea | reference | dump
  captured: 2026-01-15T14:22   # ISO local time to the minute
  status: inbox
  priority: 1-none
  ---
  <content in the body>
  ```
  Every capture path writes `priority` explicitly: `1-none` normally, and on urgent captures
  all three of `urgent: true`, `priority: 4-high` and **`scheduled: <today>`** (see below).
- **Task status values:** `inbox` (untriaged), `open`, `in-progress`, `done` (the work was
  finished), `cancelled` (dropped, merged into another task, or superseded; the `## Log` line
  says which). Both `done` and `cancelled` are closed: every cockpit view, script and sweep
  treats them alike, and both carry `completedDate` (TaskNotes writes it for any completed
  status). Kept apart so dropped work never counts as done work
  ([[frontmatter-properties]] § `status`).
- **Every task carries a next action, as a checkbox, at the top of the body.** The layout:
  ```
  ---
  <frontmatter>
  ---

  ## Next action
  - [ ] Next: <one physical step>
  - [ ] Then: <optional, ordered, max three open lines>

  <quoted fragment, ## Facts, ## Status quo, Source: line>
  ```
  - **Definition of a well-defined task:** it has a clear next physical step as an open
    checkbox (`- [ ] Next: ...`), **or** it is waiting on someone or something
    (`waiting: true` plus `- [ ] Waiting: <who>, <on what>`). Anything else is **not well
    defined**, whatever its priority or date, and gets flagged at triage until it has one.
  - **Directly under the frontmatter**, before everything else, so it shows first when the note
    opens and in the cockpit's checklist column. A qualifier is allowed
    (`## Next action (when the reply comes in)`).
  - **The open `- [ ] Next:` line is the block's first line**, above ticked steps and above a
    `Waiting:` line.
  - **A step's own estimate goes inline at the end of its line:** `- [ ] Next: email the
    landlord (2 min)`, or `(1.5 h)`, separate from the task's `timeEstimate`. Inline so it moves
    with the step when a Then is promoted and cannot go stale. `plan-today` reads it for the
    two-minute page and writes it back on Submit; the checker enforces the form.
  - **Always a checkbox** (`- [ ]`), never prose.
  - **Enforced at write time:** every Claude Edit/Write to an `Inbox/` task runs
    `vt tasks --hook` (`tools/check_tasks.py`). Structure errors (block first, an open step,
    both halves of waiting, status values, registered keys, log shape, a log line for any state
    change, `completedDate` on done and cancelled, untouched `## Current context`) block until
    fixed, reported for the whole file, old problems included. Judgment calls (outward step
    ticked with no Waiting, all steps ticked, waiting with a past date, calendar blocks after a
    close or move) come back as questions. `vt tasks` sweeps all. Not covered: script writers
    and Bash edits, which is why tasks are edited with Edit/Write only.
  - **Every writer follows it:** `commit-to-action`, Canvas pulls and the daily Canvas sync
    (`tools/canvas/tasks.py`), triage passes, hand edits. Updating a task means ticking and
    adding steps in that top block, never a new checklist further down.
  - **If no next action can be named, that is the finding, not a blank:** propose one and ask
    (see `commit-to-action` § next physical action). Raw captures (Raycast, Shortcut, messaging
    bridges, `vt todos --add`) arrive without a sharpened one; they get it at triage, and
    `prioritise` Pass 1 flags every task still missing one.
  - Why: a task you open and do not know how to start gets read and put down again. Naming the
    physical step converts an unbounded worry into something dismissible.
- **A task may carry a `## Current context` block right under `## Next action`.** Machine-owned:
  the `plan-today` pre-run replaces it every morning with status, sources and verbatim lines, up
  to a hidden `%% end current context %%` line. Never edit inside it; durable facts go elsewhere
  in the note. The same run may tick `Next:` / `Then:` steps the data proves done and set a very
  certain next step, but never touches frontmatter ([[plan-today]]).
- **A task may carry a `## Log` at the very bottom of its body.** One line per check-in, newest
  last: `- Oct 5 · not done, kept → Oct 7 · reply received Oct 4 (email)`. Date as "Oct 5" · the
  user's answer · the key finding with its source. Written by
  [[_system/skills/plan-today/SKILL|plan-today]] after the user submits its panel, **and by any
  session that changes a task's state** (steps, status, waiting, dates), as
  `- Oct 7 · <what changed> · <source>` (`vt tasks --hook` requires it on such edits). The next
  morning's guess starts from the last line, and a second move triggers "break it down or drop
  it?". One line per check-in so bulk reads stay cheap; findings that change the next step go
  into `## Next action`, not the log. No frontmatter property: the log is body text.
  - **Assignment tasks link to the file the assignment is written in.** Every course assignment
    gets a writing file at
    `<COURSE_ARCHIVE>/<Quarter>/<Course>/_mine/Assignments/<Assignment>/<Assignment>.md` (due
    date, links, prompt, `## Notes`), and its task carries `**Write it here:** <obsidian:// link>`
    directly under the Next action line. Create the file if it does not exist yet. Supporting
    notes for that assignment (study-question notes, drafts) go in the same folder. `_mine/` is
    outside the Canvas prune whitelist, so the sync can never delete them
    ([[canvas-archive]]). **The daily Canvas sync does this itself** for every task it creates
    (`tools/canvas/tasks.py` `ensure_writing_file`): it finds an existing file by its header
    `[Canvas](url)` link, so renaming the folder is safe, and never overwrites one. Only tasks
    written by hand or by a skill need it done manually.
- **Two axes, kept apart: `priority` is importance, `scheduled` is commitment.** The
  `prioritise` skill writes `priority` and never decides `scheduled`; `schedule-work` writes
  `scheduled` and never `priority`. See [[daily-loop]]. Priority is deliberately **not** a
  trigger for showing up in the `ToDo` view: unlike a date it never expires, so it would either
  clutter the list forever or need manual demotion every evening. Something else has to drive
  dates, and that is `schedule-work`. Neither skill ever writes `tasknotes_manual_order`; drag
  order is the user's alone.
  - **`prioritised: <ISO datetime>`**: when priority was last set. Lets a stateless pass tell a
    stale priority from a fresh one.
  - **`startable: cold | run-up`**: whether a task can be opened and started immediately, or
    needs thinking time first. **The scheduling skill's key input**: it is the difference
    between something that fits a gap and something needing a protected block. A plain
    frontmatter property, not a registered TaskNotes user field: Bases reads it either way.
  - **`decision: pending | made`**: marks a task whose real work is a **choice**, not
    execution. `pending` means no next physical action exists yet because the choice is not
    made; `made` means only follow-through remains. **Absent means the task is not
    decision-shaped**, which is most tasks. Consumer: the `Undecided` view in `ToDo.base`.
    Written by `commit-to-action` on every item it ingests.
    - **Undecided is not the same as unscheduled**: unscheduled means the work is known and the
      date is not; `decision: pending` means the work itself is not yet known. The
      `Unscheduled` view does not cover this.
    - **`due` carries the decide-by date. No separate field:** the deadline that matters on a
      pending decision is when the choice has to exist, usually well before the event. Do not
      add `decideBy`.
  - **Someone waiting on the user is the tag `blocking-someone`; the user waiting on someone
    else is `waiting: true`.** Two different states; do not conflate them.
  - **`quadrant`** uses plain speakable labels, not Q1-Q4: `urgent-important` /
    `important-not-urgent` / `urgent-not-important` / `neither`. **Importance is the `priority`
    tier; urgency is asked, not inferred.** Deriving urgency from "has a due date soon" fails:
    most tasks come out `neither`, because a task with no date can then never be urgent, and
    "urgent but not yet written down" is exactly the state that matters. Asking costs one word
    per task and makes *urgent-with-no-date* the trigger that generates a date.
  - **High priority is capped: 9 globally, max 3 per [[Areas/North Star]] §2 priority.** The
    limit is the mechanism and the exact digit is arbitrary; change the numbers in
    `prioritise` if yours differ. The cap unit is a North Star priority, **not** an `Areas/`
    folder: otherwise a broad area like Personal would cap its most important item together
    with every errand.
- **Urgent sets a date, not just a flag.** Without it an urgent capture never reaches the
  cockpit, because `ToDo` membership is "has a due date, or `scheduled` today or earlier".
  `scheduled` rather than `due` because `ToDo` matches `scheduled <= today()`, so an unfinished
  urgent item persists tomorrow without ever rendering overdue. **`due` stays reserved for real
  deadlines.**
- **Urgency is a one-way ratchet.** Claude may flag "this looks time-sensitive, confirm?" but
  never downgrades an existing `urgent: true` or `priority: 4-high`. The user's call only.
- **Before enriching or prioritising, Claude reads [[Areas/North Star]]** for what actually
  matters right now, rather than inferring importance from the task text alone. Enrichment
  writes frontmatter only, never the title or body.

### Skills and capture paths

- **Skills live in the vault, not in `~/.claude/`.** Source of truth is
  `_system/skills/<name>/SKILL.md`; each is symlinked into `~/.claude/skills/<name>` so Claude
  Code can find it. Why: the vault syncs across devices and is the same vault the server runs,
  so a skill written once works on every machine and in unattended jobs, while a `~/.claude/`
  copy is machine-local and silently diverges. Side benefit: skills are readable and editable
  as normal notes in Obsidian.
  - **The symlink is the only machine-local part**, so recreate it when a new machine joins:
    `ln -s "$VAULT_PATH/_system/skills/<name>" ~/.claude/skills/<name>`.
  - The `otodos` slash command lives in `_system/claude/commands/` and is linked into
    `~/.claude/commands/` the same way.
- **Capture paths.** `vt todos --add "text"` (or just asking Claude to "add X to my to-dos",
  which runs it). On desktop, one global Raycast hotkey opens a form
  (`_system/raycast-extension/README.md`): Name, Description (optional), and one Type dropdown
  with five options in a fixed order (Action / Learning / Red Notebook / Urgent / Build
  backlog), default Action, so type-and-submit makes a task. Build backlog adds a Normal / High
  priority dropdown. On the phone, an Apple Shortcut offers the same five-way choice and writes
  into the vault via Obsidian's URI scheme ([[apple-shortcuts-capture]]). **Every capture path
  must write byte-identical notes** to the schema above, so the views never have to cope with
  two shapes. On mobile, pass the note content via the clipboard (`clipboard=true`), never
  inside the URL: long URLs truncate silently on iOS.
- **Red Notebook is a tier of learning, not a type.** Important learnings are kept apart from
  ordinary ones. Choosing it writes `type: learning` *and* prepends `#coreLearning` (singular,
  inline in the body, no new frontmatter property), so it needs no schema change. Captures land
  in `Inbox/` like everything else; folding them into the notebook is a periodic judgement pass
  registered in [[maintenance]].
- **The tag also works mid-text.** A line tagged `#coreLearning` inside any note counts as
  consolidated once the notebook cites the note. **A note can be `type: action` *and* a core
  learning**, so nothing gates on `type`. The detector tells a real tag from prose about the
  tag by whether it sits in backticks, the same rule Obsidian's own indexer applies.
- **QuickAdd is deliberately NOT used for capture.** Its "Capture" choice appends into a
  predefined file rather than creating a note per entry. Avoiding it keeps one schema
  implementation per platform (Raycast for desktop, Shortcuts for mobile).
- **Capture must never block.** No capture path asks clarifying questions. Enrichment (project,
  due, quadrant) happens later, at triage.

## Components: status, one line each

**Standing rule: when a component changes, update its doc, not this table.** This table should
only ever need a one-line status edit.

| Component | Status | Doc |
|---|---|---|
| Daily loop (dump → commit → prioritise → schedule) and `plan-today` | Shipped with the template | [[daily-loop]] · [[plan-today]] |
| Task cockpit (TaskNotes + `ToDo.base` + `TaskNotes/Views/`) | Shipped, TaskNotes settings included; TaskNotes itself installed from the store (`SETUP-NOTES.md` § 3) | [[task-cockpit]] |
| Cockpit button (local plugin) | Shipped in `.obsidian/plugins/cockpit/`, on once community plugins are on | [[cockpit-plugin]] |
| Claude Task Launcher (local plugin) | Shipped in `.obsidian/plugins/claude-task-launcher/`; desktop launch needs the Claude Desktop app | [[claude-task-launcher-plugin]] |
| Fast task reader/writer (`vt todos`) | Shipped in the kit's automation repo | `_system/skills/obsidian-todo/SKILL.md` |
| Desktop capture (Raycast) | See its doc | `_system/raycast-extension/README.md` |
| Mobile capture (Shortcuts) | See its doc | [[apple-shortcuts-capture]] |
| Journals (meditation and freeflow) | See its doc | [[daily-meditation]] |
| Build backlog + weekly brief | See its doc | [[build-backlog]] |
| Maintenance brief (alerts logged in the vault, CRITICAL pushed, one weekly note of what needs the user) | See its doc | [[maintenance-brief]] |
| Routine push (morning and evening reminders) | See its doc | [[routine-push]] |
| Push notifications (the channel for anything urgent or timely) | See its doc | [[push-notifications]] |
| Claude context layer (what loads per session, write-back rule, session log) | See its doc | [[claude-context-layer]] |
| Global Claude instructions + Claude memory | See its doc | [[_system/claude/README\|_system/claude]] · [[_system/claude/global-CLAUDE\|global-CLAUDE]] |
| MCP connector instructions | See its doc | [[mcp-instructions]] |
| Vault host (always-on Linux server) | See its doc | [[vps-vault-host]] |
| Scheduled / unattended execution | See its doc | [[scheduled-execution]] |
| Automation runner (`~/automation`, jobs on timers) | See its doc | [[automation]] |
| Claude auth watch (warns before the server's login expires) | See its doc | [[claude-auth-watch]] |
| Maintenance system (`_system/maintenance/`) | See its doc | [[maintenance]] |
| Backups | See its doc | [[backups]] |
| Gmail MCP | See its doc | [[gmail-mcp]] |
| WhatsApp as a source and WhatsApp bridge | See their docs | [[whatsapp-source]] · [[whatsapp-bridge]] · [[_system/whatsapp-bridge/reply-style\|reply-style]] |
| Telegram bridge | See its doc | [[telegram-bridge]] · [[_system/telegram-bridge/reply-style\|reply-style]] |
| Beeper bridge (LinkedIn, Messenger, Instagram) | See its doc | [[beeper-bridge]] |
| Wispr import (recorded meetings filed next to their project) | See its doc | [[wispr-import]] |
| Kindle delivery | See its doc | [[kindle]] |
| Speechify delivery | See its doc | [[speechify]] |
| Travel (door-to-door trip planning, `vt flights`, fare watch) | See its doc | [[travel]] |
| Fitness data sync | See its doc | [[fitness-data-sync]] |
| Canvas course archive | See its doc | [[canvas-archive]] |
| Signal definition (how any inbound pass decides what matters) | See its doc | [[signal-definition]] |
| File explorer / manual ordering (`flexplorer`) | See its doc | [[flexplorer]] |
| Frontmatter property registry | Shipped | [[frontmatter-properties]] |
| Personal context layer (Master Profile + sub-profiles) | Template only; fill in by use | [[_system/profile-convention\|profile-convention]] |
| Working conditions and calendar roster | Template only; fill in on first `schedule-work` run | [[working-conditions]] |
| Scheduling (scheduling-rules, durations; read by `schedule-work` and `plan-today`) | See its doc | [[_system/scheduling/scheduling\|scheduling]] |
| LLM wiki (`Wiki/`, compiled from your notes) | Structure only; first ingest by the user, drift job optional on the server | [[schema]] |

**Standing rule: anything that needs regular checking afterwards goes in [[maintenance]] in the
same session it is built.** Scheduled jobs, credentials, lists and judgements with a shelf life
all rot silently, and a doc describing the thing is not a substitute for a check that forces a
look.

**Standing rule: infrastructure problems reach the user outside the vault.** Expiring or broken
credentials, dead or stalled scheduled jobs, sync failures, and anything else where *the system
itself has stopped working* must not live only in a vault note: a note in `Inbox/` is a record,
not an interrupt, and is read on the user's own triage cadence, which is exactly the cadence
that fails. Only CRITICAL problems interrupt, by push; everything else is logged in the vault
and reaches the user in the weekly [[maintenance-brief]], with mail as the fallback when a push
or the log fails. This applies to system health, **not** to ordinary tasks: the Inbox stays the
single surface for actual work. The mail transport is on the server: Gmail SMTP, port 587 with
STARTTLS, credentials in `~/.claude-auth-watch.env`. Reuse it rather than building a second one;
some hosting providers block ports 25 and 465. Reference implementation: [[claude-auth-watch]].

**Before wiring up any job that writes into existing notes or needs tool use, read
[[scheduled-execution]].** Two-writer conflicts, propose-don't-perform and non-interactive
permissions are the gaps a scheduled job has to handle; a pure reporter that never uses tools and
only creates uniquely named notes sidesteps all three.

## Task cockpit

**The live cockpit is `ToDo.base` at the vault root**, rendered by the TaskNotes plugin, which
identifies tasks by property (`type: action`) and so reads the same notes in `Inbox/` with no
separate folder. `Inbox/Inbox.base` is the triage view over every capture; `TaskNotes/Views/`
holds TaskNotes' calendar, agenda, kanban and relationship views. Two small local plugins ship
with the vault: the **Cockpit** ribbon button (Today, Waiting and As scheduled in one layout)
and the **Claude Task Launcher** (a "Work in Claude" button on each task). `vt todos` reads the
same views from the command line.

Views, settings, gotchas and how the pieces fit: [[task-cockpit]]. The plugins:
[[cockpit-plugin]], [[claude-task-launcher-plugin]]. Folder-by-folder map: [[_system/README|Vault Map]].

## Gotchas: vault-wide

Component-specific gotchas live in the component docs. These apply across the whole vault.

- **Infrastructure facts get documented once, in their `_system/` component doc; every other
  doc links to it, never restates it.** A restated copy goes stale the day the component
  changes, and nobody updates the copy. **After changing a component doc's status line, run
  `~/automation/bin/vt backlinks <component-name>`** and check whether any file it lists needs
  updating too; a written reminder to "grep the vault" is easy to have and not apply. A project
  doc that needs infrastructure links to the component doc and says the short version at most.
- **A `.base` file is a view, not a database.** It stores no data, just filter, sort and
  display config over notes living elsewhere. This is also why capture is unaffected by
  whatever renders the cockpit: capture writes plain files, and the view is a swappable lens.
- **Don't hand-edit `.base` files or a plugin's `data.json`**, even though they are plain
  YAML or JSON. Obsidian silently rewrites and reformats them, so a correct edit can be reverted
  before you test it. Change them through Obsidian's UI (Settings for plugin config, the Base's
  own Sort / Filter / Group toolbar for views). Plain notes are safe to edit directly.
- **TaskNotes' "Create files" and "Update files" buttons (Settings → General → View Commands)
  are destructive.** They regenerate the target `.base` from defaults and overwrite it, with no
  undo. To point a command at `ToDo.base`, type the full path **including `.base`** and press
  neither button. Copy `ToDo.base` somewhere outside the vault before touching that panel.
- **Don't reintroduce a separate Tasks folder.** One inbox database; tasks are a filtered view.
- **The project link field is `projects`, plural.** There is no singular `project`. If a
  singular one appears, a capture path is writing the wrong shape: fix the writer. `todos.py`
  reads plural then singular as a fallback, so a regression here fails silently.
- **Don't put code projects (the Raycast extension, anything with `node_modules`) inside the
  vault.** It wrecks Obsidian indexing and sync.
- **A bulk import (from Notion or elsewhere) pollutes the property namespace.** Obsidian's
  property registry is vault-global, and no plugin setting scopes it away. An imported `Status`
  or `Priority` column can shadow the real lowercase field and make it unselectable in every
  Bases picker, silently. Symptoms and workarounds: [[task-cockpit]] § Gotchas.
  - **Namespace the imported keys (`notion_status`), never lowercase them:** these are two
    unrelated fields sharing a name, so lowercasing merges them and poisons the real field.
  - **Scope the edit by path** (the import folder only, scripted), never Obsidian's own
    All-properties rename, which can rewrite `Inbox/`'s real field too.
  - **Use an underscore, never a hyphen:** Base formulas read `notion-status` as subtraction.
  - **Re-run the transform after any re-import** (`namespace_notion.py` is idempotent), or have
    the importer emit `notion_`-prefixed keys directly.
- **Obsidian Sync does not sync plugin settings unless you turn that on, and the omission looks
  like a plugin bug.** "Active community plugin list" syncs *which* plugins are on
  (`community-plugins.json`); "Installed community plugins" syncs their files *and settings*
  (`data.json`). Without the second, each device runs its own TaskNotes config and they drift
  ("Task not found" on the phone, a view's result count disagreeing with the rows drawn).
  Reloading or updating the plugin cannot fix a config divergence.
  - **Order is the fix:** enable it on the main computer first and let it finish uploading, then
    on the phone, then force-quit and reopen the phone app. Enabling both at once, or the phone
    first, risks the phone's config winning.
  - **Set it up when a device first joins**, before configuring any plugin on it.
  - Sync's separate "Settings" toggle (core app settings, hotkeys, appearance) is a third thing
    covered by neither plugin toggle.
- **Don't assume a scheduled or unattended agent reaches what an interactive session reaches.**
  See [[scheduled-execution]] before scoping any job as "run it on a schedule".
- **Preserve `urgent` as the user's call**: Claude never downgrades a high-priority or urgent
  item, only flags "confirm urgency?".
- **Verify tool and plugin facts by search**, not from memory: plugins change quickly.
- **Populate project tasks just in time.** Only the current stage of a project gets real task
  notes in `Inbox/`, not the whole roadmap upfront. A backlog of tasks for work months away
  buries what matters now. No roadmap-ID field on tasks: a task's title or body naming its
  stage in plain language is enough. When a project's roadmap changes, check the current stage
  for tasks that should exist but don't, and flag (never silently delete) tasks whose work no
  longer matches. Never touch a task's status just because the roadmap changed elsewhere.
