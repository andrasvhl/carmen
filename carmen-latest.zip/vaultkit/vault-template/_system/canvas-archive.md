---
type: reference
component: canvas-archive
stage: design-only
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Canvas archive: your Canvas courses, verbatim, in the vault

**Status:** optional module, **not installed** until the kit's `modules/canvas/README.md` is
followed; its last step sets `stage: built` and `verified:` here. If you never install it,
delete this doc and the `canvas-archive` skill. Referenced from `SYSTEM.md` § Components.

## What it's for

Answering a specific question about a specific class from your own course material. Canvas
access usually ends some time after a course or a degree finishes, and none of it is
recoverable afterwards, so the archive is a complete local copy, not a set of links. It works
with any school's Canvas; the host is whatever you set as `CANVAS_HOST`.

**Only your own courses, within your school's rules.** The token acts as you and sees exactly
what you see. Check your school's acceptable-use policy for Canvas and its API before the first
pull; most allow personal access tokens for your own use, some restrict automated access.
Cases, readings and slides are licensed to you as a student: a private archive is fine,
republishing it is not.

## How it works

`vt canvas` (`~/automation/tools/canvas/`) talks to the Canvas REST API with a personal access
token and writes one note per Canvas item into the archive folder (`VK_CANVAS_ARCHIVE`, default
`Areas/School/Course Archive/`):

```
<archive>/
  <Term>/[Enrolled|Waitlisted|Dropped/]<Course title> - <code>/
    <Course title> - <code>.md        anchor, type: class
    Modules.md                        the spine: every item, in Canvas order
    Syllabus.md
    2 - Pricing Strategy/             module, minus the date and "Session"
      2 - Pricing Strategy.md         folder note = the module's first page
      Pages/ · Readings/ · Materials/ · Assignments/ · Quizzes/
    _Unfiled/                         announcements, discussions, no-module items
    _mine/                            your own coursework (never touched by the tool)
    _sync-log.md
  Other/<Course>/                     sites in Canvas's "Default Term"
  _files/<Course>/<module>/           binaries, mirroring the same structure
  _files/<Course>/_manual/            gated readings you saved from a browser
```

Per course it pulls the syllabus, module structure, every page body, assignments with rubrics
**and your own submission, score and feedback**, announcements, discussion threads with
replies, quizzes (descriptions, not questions), and every file it can see.

**Canvas keeps files in three places and many courses hide one.** The Files tab often 403s and
the Pages tab 404s for students, so the module list is the authority and the tab listings are a
bonus. Files also appear as plain links inside page and assignment HTML, and on a course whose
readings are all links that is the *only* place they appear. Pages link to other pages, so the
walk is transitive, capped at 400 per course. Page HTML is converted to Markdown by a stdlib
converter with no model in the loop, so nothing is summarised away.

**Terms and enrolment.** The term folder is Canvas's own term name. A term in which you are
waitlisted for anything splits into `Enrolled/` and `Waitlisted/`, from the Canvas enrolment
role, never from access (an unpublished course 403s while you are enrolled). A current-term
course Canvas stops listing moves to `Dropped/` and is kept whole. Every move is a `vt move`, so
your own notes inside and every link to the course come with it.

**Outbound readings are a separate pass**, `vt canvas links`, because one course can link out
~50 times to other people's servers. It has its own `--plan`, per-host rate limiting (1 s),
robots.txt handling and its own cache, and harvests links from the notes already on disk, so it
needs no re-pull. Its job is not fetching, it is **not lying about what came back.** Every
response is classified `ok`, `paywalled`, `thin`, `login-required`, `media`,
`robots-disallowed` or `error:<reason>`, and anything short of real text is recorded as such
with the URL intact. `vt canvas links --gated` prints the worklist; save those from a signed-in
browser into `_files/<Course>/_manual/` under any filename, and `vt canvas adopt` works out
which reading each file is from the document's own text (never guessing: anything that does not
clear both thresholds is reported with its scores and left alone).

**A link to an archived reading or course file points at its note**, so clicking stays in
Obsidian; the note carries the original URL.

`vt canvas extract` turns each downloaded binary into text beside it: PDF via `pypdf`, PPTX via
`python-pptx` **including speaker notes**, DOCX, XLSX, WebVTT captions, and source files
verbatim. A PDF with no text layer is recorded as `canvas_extract_status: no-text-layer` rather
than producing an empty note that claims to hold the text; `--ocr` reads those with tesseract.

**Everything is incremental.** A note is rewritten only if its content changed (`last_run`
excluded), each file is keyed on Canvas's `updated_at` plus size, so a second run writes nothing
and downloads nothing. State is checkpointed after every course, so an interrupted run resumes.

**Cache the expensive upstream step, make everything downstream free to redo.** Three caches,
all under `~/.local/state/automation/canvas/`: raw PDF text keyed on sha256 (no age guard
needed: different bytes, different key), every Canvas API response (`pull --from-cache`
replays them with no requests and no live token, refusing past 7 days), and the reading text.

**The daily job (optional).** `automation@canvas_tasks.timer` runs `jobs/canvas_tasks.py` at
05:30 local time. It refreshes the current term's **enrolled** courses, then keeps assignment
tasks in `Inbox/` in step with Canvas (rules in `tools/canvas/tasks.py`):

- **New assignment due within 21 days**, not submitted → a Triage task (`status: inbox`,
  `priority: 1-none`, `due`, `## Next action` checkbox), titled `Complete <assignment>
  (<course code>)`, body carrying points, the Canvas URL and `Course: [[<anchor>]]`.
  `VK_CANVAS_TASK_PROJECT` adds a `projects:` link.
- **Due date changed** → the task's `due` follows. **Submitted** → `status: done` plus
  `completedDate`. **Removed from Canvas** → a failing check, never a deletion.
- **Never a duplicate**, done tasks in `Archive/Inbox/` included: match on the assignment URL
  in the body, else the course code in the title plus a similar title is reported, not created.
- A task edited in the last 15 minutes is left for the next run.
- Fails a check 7 days before `CANVAS_TOKEN_EXPIRES`. Never schedules anything or writes
  calendar events.

## Setup / rebuild

`modules/canvas/README.md` in the kit is the full procedure. In short: make a token in Canvas,
run `bin/set-canvas-token` **in your own terminal** on the server, create the virtualenv with
`requirements.txt`, check Obsidian Sync can carry binaries, then `vt canvas courses` → `plan` →
`pull --course <id> --dry-run` → `pull --course <id> --prune` → `extract` → `links --plan` →
`links --prune` → `links --gated`. After that, `vt canvas refresh` does the whole sequence.

## Config

| Thing | Where |
|---|---|
| Code | `~/automation/tools/canvas/` |
| Entry point | `~/automation/bin/vt canvas` |
| Host, token, expiry | `~/.automation.env`: `CANVAS_HOST`, `CANVAS_TOKEN`, `CANVAS_TOKEN_EXPIRES`, written by `bin/set-canvas-token` |
| Archive folder | `VK_CANVAS_ARCHIVE` in `config.env`, default `Areas/School/Course Archive` |
| Project on new tasks | `VK_CANVAS_TASK_PROJECT` in `config.env`, default none |
| State | `~/.local/state/automation/canvas/state.json`, written atomically |
| Caches | `~/.local/state/automation/canvas/` `api/`, `pdf-text/`, `ocr-text/`, `readings/` |
| Lock | `~/.local/state/automation/locks/canvas.lock` |
| Parsers | `~/automation/requirements.txt` (the venv); OCR needs apt `tesseract-ocr poppler-utils` |
| Module aliases | state → `courses[<id>].module_aliases`, keyed on the raw module name |
| Daily job | `jobs/canvas_tasks.py`, `units/automation@canvas_tasks.timer` |

## Gotchas

- **An expired token looks exactly like "nothing changed".** Tokens often have a capped
  lifetime. `vt canvas` refuses to run past `CANVAS_TOKEN_EXPIRES` and warns for 14 days before
  it, and the daily job fails a check 7 days before, which is why that value is not optional.
- **Canvas file URLs redirect off-host** (to inst-fs or S3). `urllib` re-sends every header
  across a redirect by default, which would hand the token to a CDN. `api.py` strips
  `Authorization` on any host change; do not remove that handler.
- **`--prune` is the dangerous flag.** It is a whitelist: it can only delete a path state
  records the tool as having written, which this run did not write again. That is why your own
  files anywhere in a course folder are safe. It still turns a path bug into data loss, so run
  it on one course first.
- **A pull and an extract are one operation with two names.** A changed binary gets a fresh
  "not extracted yet" note; only `extract` puts the text back. `refresh` runs both.
- **Never rename a module folder by hand.** The next pull recreates the original and `--prune`
  deletes yours. Use `vt canvas alias --load`; the next pull relocates the folders and every
  stored path.
- **A hand-saved reading is the only text here that cannot be re-derived.** `links --force`
  never refetches a reading whose status is `manual`.
- **Binaries reach your other devices only if Sync allows them.** Obsidian Sync needs "All other
  file types" on for `.pptx` and `.xlsx`, and every file under your plan's per-file size cap; a
  file rejected for size is never re-evaluated and nothing reports it. The extracted text is
  markdown and always syncs.
- **Never hand-edit a note in the archive.** The next pull silently reverts it. Write your own
  note beside it and link to the archived one.
- **Never use `urllib.robotparser.read()`.** It fetches robots.txt with Python's default
  User-Agent, which several hosts answer with 403, and silently turns that into "disallow
  everything". `links.py` fetches robots.txt itself, with the same UA the real request uses.
- **`unavailable:403` or `:404` on a section is normal.** Concluded courses have tabs turned off;
  it is recorded in `_sync-log.md`.
- **Changed the code? Grep the server for the new symbol before trusting a run.** A fix that
  exists only on the laptop produces a successful-looking run that applied none of it.

## Known limitations

- **Lecture recordings are not retrievable.** They are iframes (Panopto, Kaltura, Zoom); the
  Canvas API does not expose the media. The URL is written into the note, and that is all.
- **Quiz questions are not fetched.** `/quizzes/:id/questions` is teacher-scoped.
- **`plan` is a floor**: it counts files Canvas lists but will not hand over (locked files),
  which the pull reports as `no download URL (locked?)`.
- **Legacy `.xls` is not extracted** (openpyxl reads `.xlsx` only); the binary is archived.
- **Waitlist detection depends on your school's Canvas setup.** It matches a role name
  containing "waitlist". A school that models waitlists another way never splits a term.
- **Gated readings need you.** They are listed, never faked; `_manual/` is how they get in.
- **Every property the tool writes is `canvas_`- or `mine_`-prefixed**, and none are yours to
  set. The course anchor's `code`, `term` and `instructors` are the deliberate exception. See
  [[_system/frontmatter-properties|frontmatter-properties]].
- **This is not the Wiki.** The archive is raw source material; distilling it into `Wiki/` is
  a separate, reviewable step, and must leave out any module an instructor marked confidential.

## Decisions

**Token, not a browser session.** A browser-driven export needs a person with a browser open,
which can never run unattended on the server. A token makes it an ordinary script.

**Verbatim, one note per item, no model in the loop.** Model-written summaries read well and
are the wrong substrate: you cannot tell what was dropped. Distillation is a later step.

**Binaries live in the vault and Sync carries them.** One transport, not two. Excluding
`_files/` on a phone keeps gigabytes of decks off it while every note and all extracted text
still arrives.

**The pull half is stdlib-only.** Only extraction and the readings pass need third-party
parsers, so a pull never fails because a virtualenv is missing.

**Grouped by term, then module.** One folder per Canvas module with kind subfolders inside,
mirroring the Modules view, so a session's page, deck, readings and assignment sit together.

## See also
- `modules/canvas/README.md` in the kit: install, accounts, self-test
- [[_system/frontmatter-properties|frontmatter-properties]]: the `canvas_` and `mine_` properties
- [[_system/skills/canvas-archive/SKILL|canvas-archive skill]]: how Claude runs it
