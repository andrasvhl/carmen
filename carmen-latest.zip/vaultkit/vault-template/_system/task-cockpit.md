---
type: reference
component: task-cockpit
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Task cockpit: TaskNotes and Bases

**Status:** built. Referenced from `SYSTEM.md` § Task cockpit. It lives in its own doc because
the content outgrew the hub.

---

## What it's for

The daily driver: one flat, drag-reorderable list of `type: action` notes, with enough property
editing to triage without opening each note. The task engine is **TaskNotes**, not a hand-built
path of Bases views plus a board plugin.

## How it works

**Identification.** TaskNotes uses property-based task identification
(`taskPropertyName: type`, `taskPropertyValue: action`), so it reads the same `type: action`
notes already in `Inbox/`. No data migration and no new folder.

**The live cockpit is `ToDo.base` at the vault root.** There is exactly one cockpit base. You
can reach it two ways, and the difference matters:

- **The cockpit ribbon button** ([[cockpit-plugin]]) opens `ToDo.base` by hard-coded path.
  This is the daily-driver route.
- **TaskNotes' native "Open Tasks View" command**, whose target is set in **Settings →
  TaskNotes → General → View Commands**. Each native command has its own target `.base` path
  there, with a reset-to-default and "Create files"/"Update files" generation. That setting,
  not a manual file move, is what makes a relocation work: TaskNotes' reorder-persistence
  bookkeeping follows the View Commands mapping, not just the YAML content. Keep it pointed at
  `ToDo.base` (see Gotchas).

`ToDo.base` filters `note["type"] == "action"`, excludes the folder of imported notes, and
defines these views: `ToDo`, `Triage`, `Unscheduled`, `All Tasks`, a project-scoped view, and
`Done`. A project-scoped view (`projects.contains(link("Your Project"))`) is embedded in that
project's plan note with `![[ToDo.base#Your Project]]`.

**Sort uses the raw `priority` property directly.** The numeric-prefixed values
(`1-none` to `4-high`) sort correctly alphabetically on their own. No view's sort or columns
reference any formula. A leftover pass-through formula is still in the file (see Known
limitations).

**`ToDo`'s membership rule already covers upcoming deadlines**, which is why there is no
separate "Upcoming Deadlines" view:
```
(due.isEmpty() == false || (scheduled.isEmpty() == false && date(scheduled) <= today())) && status != "done"
```
`due` is unbounded, so every future-dated open task shows; only `scheduled` is capped at
today or earlier, so a same-day commitment persists rather than vanishing overnight. Priority
is deliberately not a membership trigger: unlike a date it never expires. Ordering is drag
position only (`tasknotes_manual_order`), with no algorithmic sort on top.

**`TaskNotes/Views/`** holds TaskNotes' default view set (kanban, calendar, mini-calendar,
agenda, pomodoro) plus `relationships.base`. Trimming the defaults does not hold while the View
Commands mapping is stale: TaskNotes regenerates them. Fix the mapping before trimming.

There is no separate dashboard page: the `ToDo` base does that job, so a second surface
embedding the same views would be redundant.

The ribbon button that opens the stacked review layout is a separate local plugin, see
[[cockpit-plugin]].

## Config

| What | Where |
|---|---|
| Task identification | Settings → TaskNotes → `taskPropertyName: type`, `taskPropertyValue: action` |
| Which `.base` each native command opens | Settings → TaskNotes → General → **View Commands** |
| Where new UI-created tasks are written | Settings → TaskNotes → Task Storage → **Default folder** (must read exactly `Inbox`) |
| Priority values | Settings → TaskNotes → Task Properties → Priority values |
| The cockpit, and the only one | `ToDo.base` (vault root): views `ToDo`, `Triage`, `Unscheduled`, `All Tasks`, a project view, `Done` |

**Priority scale: `1-none` / `2-low` / `3-normal` / `4-high`.**

**Field mapping:** TaskNotes uses `projects` (plural, list), not `project` (singular); there is
no `lane` property, since a kanban-board design was rejected in favour of plain drag-reorder
within one list. Reconciled through TaskNotes' own field-mapping settings. Property editing
opens a modal for some fields rather than being fully inline: an accepted tradeoff, since
drag-and-drop mattered more.

## Gotchas

- **Never hand-move or hand-rename a TaskNotes-managed `.base` file.** Point the command at
  the new path in View Commands instead. Moving the file on the filesystem without updating the
  mapping makes drag order revert on leaving and re-entering the view (or under rapid
  successive reorders), and makes TaskNotes regenerate its full default view set at the old
  path.
- **"Update files" and "Create files" in View Commands are DESTRUCTIVE. They regenerate the
  target from TaskNotes' defaults and overwrite whatever is there; they do not merge.** One
  click replaces your real views with the stock set (Manual Order, All Tasks, Not Blocked,
  Today, Overdue, This Week, Unscheduled). **There is no undo, and Obsidian keeps no `.trash`
  copy of a `.base` overwritten this way.** Treat both buttons as last resort, for generating a
  file that does not yet exist. **To change which file a command opens, edit the path field
  only and press neither button.**
- **Type the full path including the `.base` extension.** TaskNotes does not append the
  extension or validate the path: it treats `ToDo` as a distinct, missing file, and generating
  against it produces two stock files, an extensionless `ToDo` alongside a clobbered
  `ToDo.base`. Every other row in that settings panel shows a full path with the extension;
  match them.
- **Back up the target `.base` outside the vault before touching View Commands at all.** One
  `cp`. The two gotchas above are each one keystroke or one click away.
- **The `Priority`/`priority` case-fold collision recurs whenever an import lands.** A
  capitalised property from imported notes with a typed entry in `.obsidian/types.json`
  shadows the real lowercase schema field, making it **unselectable in every Bases picker**
  (Filter, Sort, Properties/columns), silently, with no error. The fix is to namespace the
  imported keys with a prefix (use an underscore: hyphens break Bases formulas) and remove the
  orphaned entry from `types.json`.
  - Workaround for Sort: a pass-through formula (`priorityText: priority`) gets its own
    unambiguous entry in the picker.
  - Workaround for the Properties/column picker, which has **no formula workaround** (the
    coloured-dot rendering is tied to TaskNotes recognising the real field): **duplicate a view
    that still has the correct binding**, then swap the duplicate's filter and sort and delete
    the broken original. Duplicating copies the column config verbatim without going through
    the picker. This is the general technique for this whole class of collision.
  - The same shape applies to `Status`, `Urgent`, `Waiting` and `Type`. After any re-import,
    check that no bare capitalised `Status:`/`Urgent:`/`Waiting:`/`Type:`/`Priority:` keys
    remain in the imported folder and that `.obsidian/types.json` holds no entry for them.
- **TaskNotes' "Default folder" setting drifts.** Typing into that field can append to the
  existing value rather than replace it if not fully cleared first (for example ending up as
  `TaskNotes/Inbox`). Check it if new tasks created in the UI land somewhere odd.
- **Don't hand-edit `.base` files.** Obsidian's engine silently rewrites them. Use the base's
  own Sort/Filter/Group toolbar. (Vault-wide rule, recorded in `SYSTEM.md` § Gotchas.)
- **Dead end, do not re-investigate:** a plugin called "Better Tables" sounds like it might do
  table-row drag-reorder for Bases. It doesn't. It is an unrelated standalone markdown-table
  editor, incompatible with Bases and frontmatter.
- **Two things that do not matter:** the `property:` vs `column:` key inside `sort:` blocks
  (Obsidian's own regenerations use both, drag works either way); and a `groupBy` rendering
  glitch (cards grouped under a literal `"True"` label or a raw `{"icon":...}` JSON blob), a
  cosmetic Bases bug from grouping by a boolean-ish field with unset values.

## Known limitations

- Property editing opens a modal for some fields rather than being fully inline.
- **Four dead formulas remain in `ToDo.base`:** `priorityWeight`, `priorityCategory`,
  `urgencyScore`, `priorityText`. Nothing reads them. They are inert, with one trap:
  `priorityWeight` still tests the old vocabulary (`"none"/"low"/"normal"/"high"`), so it
  returns its `999` fallback for **every** task, and anyone picking it from a sort dropdown
  gets a silently constant sort. Delete these four; the rest are TaskNotes auto-generated
  time-tracking and date-category helpers: unused, harmless, picker clutter. Formulas can only
  be removed through Obsidian's UI.
- If TaskNotes ever stops being enough and a custom Bases view gets reconsidered: it is **2 to
  4 days of real engineering** (the young `registerBasesView` API, rebuilding inline-editable
  cells for several property types, safe frontmatter writes, and, the riskiest unknown,
  whether a custom view renders correctly when embedded via `![[...]]`). Because tasks are
  plain frontmatter throughout, switching engines costs **zero data migration**: a
  deliberately swappable layer.

## Decisions

**TaskNotes over a hand-built Bases path.** The cockpit needs genuine drag-to-reorder in a
plain list (not kanban lanes), plus reasonable property editing. No Bases-native view or
Bases-compatible plugin does flat-list drag-reorder. Rejected: a single-lane board (still
card-based), a custom `registerBasesView` plugin (a 2 to 4 day build), and keeping tasks in an
external app with a slow API (tasks are the most frequently touched part of the system).
TaskNotes' Task List view drag-reorders, writing `tasknotes_manual_order` to frontmatter.

**TaskNotes' native priority vocabulary.** TaskNotes only lets you rename which frontmatter key
holds priority, not redefine its value vocabulary, so a parallel P1 to P3 scheme could not
drive TaskNotes' native sort and colour without a translation layer that does not exist. The
schema adopts TaskNotes' scale rather than fighting the engine.

**Numeric-prefixed priority values, replacing a `priorityWeight` formula.** TaskNotes' settings
let each priority's stored value carry a numeric prefix so Bases' native alphabetical sort
orders correctly: `1-none/2-low/3-normal/4-high`. The formula approach was abandoned because a
`999` fallback for notes missing `priority` broke sort order, and Bases formulas do not always
recompute for files that have not been touched since an edit. When the values change, update
every existing task note and every capture path to match.

**The "Urgent" capture checkbox also sets `priority: 4-high`.** Non-urgent captures write
`priority: 1-none` explicitly rather than leaving the field unset, so it is a real filterable
value everywhere.

**`priority` and `quadrant` stay separate axes.** Priority is the single ordinal that drives the
flat list's sort and colour (a Bases view has only one active sort). Quadrant is the
AI-suggested urgent × important classification, used to surface important-not-urgent work that
priority alone tends to bury.

**The status vocabulary means something.** `inbox` = captured but not yet triaged; `open` =
triaged and real; `in-progress`; `done`. Both capture paths write `inbox`, and `Inbox.base`'s
Inbox view filters on `type == ""`, so a note leaves it the moment it has `type: action`,
triaged or not. Two settings in `ToDo.base` give untriaged tasks a home: a **`Triage` view**
(`status == "inbox"`, newest first by `file.ctime`) as the work queue, and **`status != "inbox"`
in `Unscheduled`'s filter** so the Someday bucket only ever holds triaged work. The second is
the one that matters; the view alone would leave unprocessed captures mixed into Someday.

**`waiting` is a field, not a status.** `blockedBy` (TaskNotes-native, relational) is for
task-to-task dependencies; `waiting` is for waiting on a person or external event, and lives on
an otherwise normal open task, so it never removes the task from `ToDo`. Implemented as a
TaskNotes boolean user field (`key: waiting`, `displayName: Waiting`, default `false`), and
shown as the last entry in `ToDo`'s `order:` list. A view rebuild can drop the column; re-add it
if it goes missing.

## See also
- [[_system/SYSTEM|SYSTEM]]: the hub, and vault-wide gotchas including property pollution from
  imported notes.
- [[cockpit-plugin]]: the ribbon button that opens the review layout.
- [[claude-task-launcher-plugin]]: per-note button that launches Claude Code on a task.
