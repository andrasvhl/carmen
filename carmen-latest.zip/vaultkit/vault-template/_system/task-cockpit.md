---
type: reference
component: task-cockpit
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Task cockpit: TaskNotes, Bases views, the Cockpit button and `vt todos`

**Status:** built, shipped with the starter vault, verified <INSTALL-DATE>. Needs the TaskNotes
plugin installed from the store (`SETUP-NOTES.md` § 3). Referenced from `SYSTEM.md` § Task
cockpit.

## What it's for

The daily driver: one flat, drag-reorderable list of `type: action` notes, with enough property
editing to triage without opening each note. Tasks are plain notes in `Inbox/`, so every layer on
top of them (TaskNotes, the `.base` views, the Cockpit button, `vt todos`) is a swappable lens:
none of them stores task data of its own.

## How it works

Five pieces, all reading the same notes:

| Piece | What it is | Where |
|---|---|---|
| **Task notes** | Every capture is a note in `Inbox/`; tasks are the ones with `type: action` | `Inbox/`, schema in `SYSTEM.md` § Capture note schema |
| **`ToDo.base`** | The cockpit: Bases views over those notes, rendered as TaskNotes task lists | vault root |
| **TaskNotes** | Community plugin. Renders the task-list views with drag-to-reorder, edits properties inline or in a modal, adds calendar, kanban and agenda views | Settings → TaskNotes; settings shipped in `.obsidian/plugins/tasknotes/data.json` |
| **Cockpit button** | Local plugin. One ribbon click lays out three `ToDo.base` views in the main area | [[cockpit-plugin]] |
| **`vt todos`** | Command-line reader and writer over the same notes, used by Claude and the skills | `~/automation/bin/vt todos`, skill `obsidian-todo` |

A sixth, optional piece works on a single task: the **Claude Task Launcher** adds a "Work in
Claude" button to an open task note ([[claude-task-launcher-plugin]]).

**Identification.** TaskNotes identifies tasks by property (`type` = `action`), not by tag or
folder, so it reads the notes already in `Inbox/`. New tasks created in TaskNotes' own dialog
are written to `Inbox/` too (its default folder).

### The views in `ToDo.base`

| View | Shows |
|---|---|
| `ToDo` | Has a `due` date, or `scheduled` today or earlier, and not done. The daily driver |
| `Today` | Due or scheduled today or earlier, not done, not `waiting` |
| `Waiting` | Not done, `waiting: true`; sorted by scheduled, then due |
| `As scheduled` | Everything with a `scheduled` date, not done, in date order |
| `Triage` | `status: inbox`: captured, not yet triaged, newest first |
| `Unscheduled` | Triaged (`status` not `inbox`), no due, no scheduled: the Someday bucket |
| `Undecided` / `Decisions` | `decision: pending`: the work is a choice not yet made |
| `All Tasks` | Everything not done |
| `Done` | Done, most recently changed first |

`ToDo` deliberately covers upcoming deadlines (any future `due` shows), while `scheduled` only
counts once its day arrives, so scheduling something for next Thursday does not clutter today.
Priority is not a membership trigger: unlike a date it never expires. Ordering in `ToDo` is drag
position (`tasknotes_manual_order`), which only you write.

The Cockpit button opens **Today** and **Waiting** side by side on top, **As scheduled** across
the bottom (configurable in Settings → Cockpit).

### `Inbox/Inbox.base`

The triage view over every capture, not just tasks: Inbox (untriaged, `type: ""`), Actions,
To-do, Learnings, Ideas, Reference, All Captures. A note leaves the Inbox view the moment it gets a
`type`; a task that has a type but has not been triaged yet shows in `ToDo.base` → `Triage`.

### `TaskNotes/Views/`

TaskNotes' own extra views, each opened by a TaskNotes command (Settings → TaskNotes → General →
View commands points each command at its file):

| File | Command | Shows |
|---|---|---|
| `agenda-default.base` | Open agenda view | The next seven days as a list |
| `calendar-default.base` | Open advanced calendar view | Week calendar with scheduled and due tasks |
| `mini-calendar-default.base` | Open calendar view | Month grid by due, scheduled, created, modified |
| `kanban-default.base` | Open kanban view | Columns by `status` |
| `relationships.base` | (embedded in task notes) | Subtasks, blocked-by, blocking, project members of the open note |
| `pomodoro-stats.base` | Pomodoro stats | Empty unless pomodoro storage is set to daily notes (see Known limitations) |

All of them filter on `type == "action"` like the cockpit.

### `vt todos`

`~/automation/bin/vt todos` parses every `type: action` note in `Inbox/` and prints the `ToDo`,
`Triage` and `Unscheduled` views with the **same filters as `ToDo.base`** (the script's header
lists them). `--view all` gives everything not done, `--json` a machine-readable dump, and
`vt todos --add "text"` writes a new task note in the capture schema. It is a reader of the
cockpit's definitions, never a second opinion: **if you change a view's filter in `ToDo.base`,
mirror it in `code/automation/tools/todos.py`**, or Claude and the cockpit will disagree about
what is active.

## Setup / rebuild

1. **Settings → Core plugins → Bases: on.**
2. **Settings → Community plugins:** turn off Restricted mode, then install **TaskNotes** from
   the store (Browse). The shipped `data.json` already holds the settings below; TaskNotes picks
   it up on first load.
3. Cockpit and Claude Task Launcher are already in `.obsidian/plugins/` and listed in
   `community-plugins.json`, so they switch on with community plugins. Check both are enabled
   in Settings → Community plugins.
4. Test: click the ribbon's dashboard icon. Three panes open. Run `~/automation/bin/vt todos`;
   the example task shows in the same group as in the cockpit.

Full steps, including Sync settings: `SETUP-NOTES.md` § 3.

## Config

| What | Where | Shipped value |
|---|---|---|
| Task identification | Settings → TaskNotes → Task properties / identification | by property: `type` = `action` |
| Where new tasks are written | Settings → TaskNotes → Task storage → Default folder | `Inbox` |
| Status values | Settings → TaskNotes → Task properties | `inbox`, `open`, `in-progress`, `done` (`done` counts as completed) |
| Priority values | same | `1-none`, `2-low`, `3-normal`, `4-high`; the numeric prefix makes alphabetical sort correct |
| Default status and priority for new tasks | same | `inbox`, `1-none` |
| `waiting` | TaskNotes user field (boolean, default false) | key `waiting` |
| Which file each command opens | Settings → TaskNotes → General → View commands | `ToDo.base` and the six files in `TaskNotes/Views/` |
| Auto-create default view files | Settings → TaskNotes → General | off, so TaskNotes never regenerates its defaults over these files |
| Calendar | Settings → TaskNotes → Calendar | week starts Monday, 24-hour clock. Change to taste |
| Google / Microsoft calendar, ICS, API, webhooks | Settings → TaskNotes → Integrations | all off and empty |
| Cockpit layout | Settings → Cockpit | `ToDo.base`: Today, Waiting, As scheduled |

**To add a view for one project**, open `ToDo.base`, duplicate `All Tasks` with the view menu,
rename it after the project, and add the filter `projects.contains(link("Your Project"))`.
Embed it in the project's anchor note with `![[ToDo.base#Your Project]]`.

## Gotchas

- **"Create files" and "Update files" in Settings → TaskNotes → General → View commands are
  destructive.** They regenerate the target `.base` from TaskNotes' defaults and overwrite it,
  with no undo and no trash copy. To change which file a command opens, edit the path field only
  and press neither button. Copy `ToDo.base` outside the vault before touching that panel.
- **Type the full path including `.base`.** TaskNotes does not add the extension: `ToDo` is
  treated as a different, missing file.
- **Never move or rename a `.base` file a TaskNotes command points at** without updating View
  commands to match. A stale mapping makes drag order revert and makes TaskNotes regenerate its
  default view set at the old path.
- **The Default folder field can append instead of replace.** Clear it fully before typing. If
  new tasks land somewhere odd (for example `TaskNotes/Inbox`), check it.
- **New tasks from TaskNotes' own dialog are scheduled for today by default** (Settings →
  TaskNotes → Task defaults → Default scheduled date). That puts them straight into `ToDo` with
  status `inbox`. Set it to none if you want every new task to wait for `schedule-work`.
  `vt todos --add` never sets a date unless asked.
- **A capitalised property elsewhere in the vault can shadow a task field** (an imported
  `Priority` hides `priority` in every Bases picker). See `SYSTEM.md` § Gotchas.
- **Obsidian Sync does not carry plugin settings unless "Installed community plugins" sync is
  on.** Without it each device runs its own TaskNotes config, and the phone shows "Task not
  found" style errors.

## Known limitations

- Some property edits open a modal rather than editing inline.
- `ToDo.base` carries about forty formulas that TaskNotes generated (date categories, time
  tracking). Most views do not use them. They are harmless; remove them through the base's UI
  if they clutter the pickers.
- `pomodoro-stats.base` only shows data when TaskNotes stores pomodoros in daily notes. The
  shipped setting stores them in the plugin, so that view is empty until you change it.
- `vt todos` mirrors only `ToDo`, `Triage`, `Unscheduled` and `All Tasks`. The other views exist
  only in Obsidian.

## Decisions

**TaskNotes over a hand-built Bases view.** The cockpit needs drag-to-reorder in a plain list
(not kanban lanes) plus property editing. No built-in Bases view does flat-list drag-reorder;
TaskNotes' task list does, writing `tasknotes_manual_order` to frontmatter. Rejected: a custom
Bases view plugin (days of work on a young API). Because tasks are plain frontmatter, switching
engines later costs no data migration.

**TaskNotes' priority vocabulary, with numeric prefixes.** TaskNotes lets you rename the
priority field but drives its colours and sort from its own value list, so the schema adopts
`1-none` to `4-high` rather than a parallel P1 to P3 scheme that would need translation.

**`waiting` is a field, not a status.** `blockedBy` is for task-to-task dependencies; `waiting`
marks an otherwise normal open task that waits on a person or event, so it never drops out of
`ToDo`.

**`inbox` means untriaged.** Capture writes `status: inbox`; triage moves it to `open`. The
`Triage` view shows the queue, and `Unscheduled` excludes `inbox` so the Someday bucket only
holds triaged work.

## See also

- [[_system/SYSTEM|SYSTEM]]: the task schema and vault-wide gotchas
- [[cockpit-plugin]]: the ribbon button and its layout
- [[claude-task-launcher-plugin]]: the per-task "Work in Claude" button
- [[frontmatter-properties]]: which property names the views read
- `_system/skills/obsidian-todo/SKILL.md`: how Claude uses `vt todos`
