---
type: reference
component: scheduling-rules
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Scheduling rules: how work gets placed into a day or a week

**Status:** built. Referenced from `SYSTEM.md` § components.

## What it's for

This is one set of placement rules. Both [[_system/skills/schedule-work/SKILL|schedule-work]] (the
week) and [[_system/skills/plan-today/reference/day-plan|plan-today's day plan]] (one day)
follow it. That way a day plan is never built by fitting blocks into gaps by hand, and it stays
at 20-30 min with little input from you. This page holds decisions only: durations live in
[[_system/scheduling/durations|durations]], the week's shape in your week structure note, and
when you can work in [[_system/working-conditions|working-conditions]]. A plan that breaks a rule
here is wrong.

## How it works

### Always true

1. **Durations come from the docs, not from questions.** Check [[_system/scheduling/durations|durations]]
   first. For anything not there, Claude estimates or looks it up. The daily plan asks one
   question only: is there anything that has to happen that the panel did not show, or anything
   unusual about the day (an event with travel, a guest, a late night planned)? There is no
   question per task type.
2. **x 1.5 on guesses, whoever made them.** An estimate made from the task description alone
   (yours or Claude's) gets x 1.5, rounded up to 15 min. This does not apply to table values or
   to estimates made from evidence (page counts, an earlier log line). Students took about 1.6x
   their own prediction (Buehler, Griffin & Ross 1994).
3. **No splitting during a run.** Multi-part work is split once, inside the durations formulas.
   Each item gets one check: is it away from home? Then add the commute.
4. **15 min between blocks.** After hard work (rule 7) the gap is **30 min and nothing hard
   follows**. Short breaks restore energy but barely restore performance, and draining work needs
   more than 10 min (Albulescu et al. 2022).
5. **Max ~8 timed items a day, at most 3 important.** Count everything with a time: tasks,
   classes, appointments, calls, meals with others. Meals alone, the morning routine and the
   commute do not count. Important means `4-high` or `important-not-urgent`. No study backs a
   number; the point is having a limit at all (Ivy Lee method).
6. **Ranking decides what gets into the day; the week structure decides where it goes.** The
   important items are ranked and placed first, but each one goes into the slot its kind belongs
   in (for example admin and class prep in the dip, big rocks in a peak), not automatically the
   earliest free slot.
7. **Energy: two peaks, one dip** (your week structure note, § Week at a glance).
   Peaks: <PEAK_1> and <PEAK_2>. Dip: <DIP_WINDOW>. **Hard work goes in a peak**: emotionally
   heavy work, introspection, big-rock work, organising flights and travel, decisions (the full
   list is under § Hard work). Classes, class prep, admin, sport, errands and mechanical work go
   in the dip. Claude judges a new case by how similar it is to the list.
   **The one exception:** standing big-rock blocks in your week structure may reach into the dip
   on purpose.
8. **State the arithmetic before placing:** free hours, hours asked for, and what does not fit.
   Overflow is named, never absorbed.
9. **Carry-over is scheduling.** Every task already scheduled for the day is ranked together
   with the new candidates and gets a verdict: placed, or deferred with a date. Nothing is
   pushed by default, because otherwise tasks scheduled for the day silently never reach the plan.
10. **`Next:` lines are physical first steps** ("open the PDF, read the exhibits first"),
    so a calendar block can carry them as written: the block's description holds the `Task:` line
    plus this step. If-then plans raise follow-through (Gollwitzer & Sheeran 2006). **When a block
    ends with the task unfinished, the `Next:` line is updated with where to restart**
    ("from p. 14, exhibit 3"). Unfinished work keeps pulling attention, and a written plan for
    coming back reduces this (Leroy 2009).
11. **Two-minute rule.** Anything 5 min or less is done in the two-minute batch, including a
    quick next step of a larger task (sending a pre-drafted email that moves it forward). Tasks
    of 5 to 10 min are batched into one slot. There is one limit: 5 min. The rule applies only
    while planning or processing, never inside a focus block (Allen's own caveat).
12. **Free time is rough but protected.** Unplanned time and the afternoon or evening off get
    a part of the day, not exact times (Tonietto & Malkoc 2016: fixed times make leisure feel
    like work). They are listed in the week structure and blocked in the calendar as a busy block
    titled `Free`, with nothing inside. Scheduling treats them as commitments. Plans with other
    people keep their real time.

### When it applies

- **Class days:** the commute before the first class is always planned (see durations §
  Quick reference). The way back is planned only when the next item is at home.
- **Class prep:** capped at 60 min for a major class and 30 min for a minor one, and shorter when
  the readings are light. Claude estimates from the actual readings.
- **Assignments:** Claude reads what the assignment asks and estimates from the work.
- **Long, draining sport session:** no big rock afterwards that day.
- **Hosted dinner:** groceries and cooking are placed earlier the same day (durations §
  Formulas).
- **Travel:** a travel day is lost for work; the day after counts as half.
- **After a night past midnight:** a day without classes starts 1 h later; a class day starts
  as usual but gets no hard work in the morning. **After a party with alcohol:** light work
  only the next morning.
- **Weekday mornings:** the first placeable block is <FIRST_BLOCK_TIME>, right after the daily
  plan ends. One block, `🌅 Morning routine + daily plan` <MORNING_START>-<FIRST_BLOCK_TIME>,
  holds the routine, the daily plan and the two-minute batch (your week structure note, § Day
  by day).
- **Week scope:** the 80% ceiling and the `Buffer` blocks live in schedule-work § Pass 2
  (The 80% rule). The one open buffer afternoon a week lives in the week structure.

### Hard work

This is work that drains you and needs a peak (rule 7). Claude judges a new case by how similar
it is to this list.

- **Emotional:** introspection and reflection work; hard conversations (conflict, saying no,
  bad news, sensitive family topics); calls with family or close friends when something heavy is
  on the table.
- **Decisions and stakes:** decisions with consequences (a job offer, a major plan, enrolling
  in or dropping a course); money admin (taxes, bills, insurance, bank); bureaucracy with stakes
  (visas, health insurance, official forms); applications (fellowships, programmes, anything
  evaluated).
- **Logistics:** organising flights and travel, especially with several people; organising
  events for a group (a hosted dinner, a trip, a group outing).
- **Thinking:** big-rock work (strategy, quarter objectives); first drafts of anything long (an
  essay, a plan, a talk); important outreach (cold or networking messages to people who matter);
  learning something technically new.
- **Avoided:** anything already pushed twice, whatever it is.

**Not hard (goes in the dip):** class prep and readings, routine assignments including routine
graded writing, routine admin, replies to friends, sport, errands, the email batch.

## Decisions

- **One shared doc, separate from the week structure.** The week structure describes the ideal
  week, and the placement method gets lost as one bullet there. Rejected: plan-today calling
  schedule-work in a day mode (slower, and that mode does not exist).
- **Rules and durations on separate pages, in one folder.** Rules are decisions, durations are
  data. `_system/scheduling/` holds both.
- **Pre-estimated durations over morning questions.** Unestimated items get badly misjudged,
  but asking every time would make the daily plan long.
- **Learning durations from actuals is a separate build** and is not done here; the panel does
  not log actual durations.
- **Not adopted:** if-then obstacle lines for the frog (WOOP), and "every deferred task gets a
  first step" as a new rule, since the task hook already enforces a `Next:` line.

## See also

- [[_system/scheduling/scheduling|Scheduling]]: the folder note
- [[_system/scheduling/durations|durations]] and [[_system/working-conditions|working-conditions]]
- Your week structure note: what the week must contain
- [[_system/skills/schedule-work/SKILL|schedule-work]] and [[_system/skills/plan-today/SKILL|plan-today]]: the two readers
