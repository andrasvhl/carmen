---
type: reference
component: scheduling
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Scheduling: the docs that decide when work happens

**Status:** built. Everything scheduling-related sits in one place.

## What it's for

One folder for the method of scheduling, read by [[_system/skills/schedule-work/SKILL|schedule-work]]
(the week) and [[_system/skills/plan-today/SKILL|plan-today]] (the day). The shape of your
ideal week stays in your week-structure note under `Areas/`, because it is the shape of your life,
not system.

## How it works

| Doc | Answers |
|---|---|
| [[_system/working-conditions\|working-conditions]] | *When* you can work (sleep, meals, fixed commitments, work windows) |
| [[_system/scheduling/scheduling-rules\|scheduling-rules]] | *How* a block is placed: gaps, caps, energy, carry-over, the two-minute rule |
| [[_system/scheduling/durations\|durations]] | *How long* recurring things take, door to door |
| Your week-structure note (outside the folder) | *What* the week must hold and protect |

`plan-today` preloads all three with `context_read.sh scheduling`, its own part since the
others are near the ~30 KB tool-output limit. `~/automation` reads working-conditions by path (quiet
hours, the plan-today pre-run, tripwires).

## Gotchas

- **Moving a doc here breaks code paths, not only links.** `vt move` rewrites vault links; the
  paths in `~/automation` and `context_read.sh` have to be changed by hand. Grep both
  before any move.

## See also

- [[_system/SYSTEM|SYSTEM]]
