---
type: reference
component: durations
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Durations: how long recurring things really take, door to door

**Status:** built. You agree the values once, and each one is backed by evidence from your vault.
Learning from actuals is a separate build: a task note in `Inbox/` for updating this table from
logged task durations over time. Referenced from `SYSTEM.md` § components.

## What it's for

The data half of scheduling. [[_system/scheduling/scheduling-rules|scheduling-rules]] says how
to place a block; this page says how long the block is, so neither schedule-work nor the daily
plan has to ask. Values are door to door (changing, travel, shower) and are used as they are:
**no x 1.5 on top**. Anything not here is estimated by Claude (x 1.5 when it is a guess, per
scheduling-rules) or looked up.

## How it works

### Formulas (anywhere)

| Type | Formula |
|---|---|
| Sport | length + <PREP_TIME> prep + <EXIT_TIME> exit (shower, change) + commute both ways. From home: no commute |
| Meal out | meal + commute |
| Hosted dinner | groceries + cooking, earlier the same day, + the dinner |
| Commute | look it up (distance and mode) unless it is in Quick reference. The way there is always planned; the way back only when the next item is at home |

### Table

Fill in one row per recurring thing. The Evidence column says where the value comes from: a
fitness app log, a calendar entry with departure and return times, or your own statement.

| Type | Door to door | Evidence |
|---|---|---|
| <YOUR_SPORT> from home, <USUAL_LENGTH> | <DURATION> | <e.g. moving time from your training log> |
| 1 h of sport somewhere else | <DURATION> | the sport formula; your statement |
| <YOUR_SPORT> with a drive | moving time + <DURATION> | <e.g. left and back-and-showered times on a past day> |
| Long session, <LENGTH> | <DURATION> | <e.g. elapsed vs moving time, plus the formula> |
| <ANOTHER_SPORT>, <LENGTH> | <DURATION> | <e.g. departure time for a booked slot> |
| Strength at home, <LENGTH> | <DURATION> | <your training plan> |
| Class | the listed length; commute per the formula | [[_system/working-conditions\|working-conditions]] § Classes |
| Scheduled call | <DURATION> | your statement |
| Lunch | <DURATION> nearby, <DURATION> further away | your statement |
| Dinner | <DURATION> at home (can run longer); out: <DURATION> + commute | your statement |
| Groceries or errands | <DURATION> | <e.g. a past hosted dinner> |
| Big-rock session | <DURATION>, with a 10 min break every 90 min | <e.g. a past session that ran as estimated> |
| Flight | flight + 3 h | rule of thumb |

### Look up, don't table

- **Commutes:** the distance and mode for the actual place.
- **Assignments:** read what the assignment asks for and estimate from the work.
- **Class prep:** estimate from the actual readings (pages, cases), within the caps in
  scheduling-rules.

### Quick reference: <YOUR_CITY>, <CURRENT_TERM>

| Item | Value |
|---|---|
| <YOUR_USUAL_COMMUTE> | <PLANNED_TIME> planned (the trip itself is <ACTUAL_TIME>) |
| <RECURRING_LOCAL_EVENT> | <DURATION> including the commute both ways |

## Decisions

- **Durations are separate from rules:** this page is data, the rules page is decisions. One
  page for both mixes the two (e.g. "long session: 5 h, no big rock after").
- **Place-bound values are tagged with their place:** values in Quick reference hold only in
  that place; elsewhere the formulas and look-ups apply.
- **No per-type question in the daily plan:** asking every time is too much overhead. Patterns
  are found backwards, in the learning build.

## See also

- [[_system/scheduling/scheduling|Scheduling]]: the folder note
- [[_system/scheduling/scheduling-rules|scheduling-rules]]: how blocks are placed
