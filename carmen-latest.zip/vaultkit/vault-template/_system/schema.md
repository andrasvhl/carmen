---
type: reference
component: llm-wiki
stage: partial
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# LLM wiki schema: how the wiki is built and maintained

**Status:** partial as of <INSTALL-DATE>, verified <INSTALL-DATE>. Shipped as structure only: no
articles until the first ingest. Referenced from `SYSTEM.md` § Components and from `CLAUDE.md`
§ Always true. The workflow Claude follows is the `wiki` skill
(`_system/skills/wiki/SKILL.md`); this doc holds the rules and the reasons.

## What it's for

A vault grows faster than anyone can reread it. Search finds what you can name; it does not tell
you what you already concluded. The wiki is the compiled layer that does: a small set of articles
stating what the owner thinks and knows, read **before** anything else, so a session starts from
the owner's accumulated view rather than from the model's general prior.

The idea is Andrej Karpathy's "LLM wiki" pattern: the person writes raw sources, the model
compiles and maintains a wiki from them, and the wiki is what gets read at question time.

It is deliberately small. What makes it work is that `Wiki/index.md` is read whole before any
query, which is only affordable while it stays readable in one sitting.

## How it works

### The invariant

**The wiki is derived, never authored.** The owner writes sources; the owner and Claude only
read the wiki. Nothing appears in an article that does not trace to a source.

The rule is about **provenance, not process**. "Every claim traces to a source" and "only an
ingest run may write a page" are different rules, and only the first is needed. That is why
filing a good query answer back as a page is allowed (§ Filing an answer back).

Consequences:

- Obsidian has no per-folder read-only, so the invariant is held by the lint pass, not by
  permissions. Every article carries `wiki_sources`; a claim that cannot be traced is a defect.
- **Disagreeing with an article means fixing the source, then re-ingesting.** Never editing the
  page. The first time this is inconvenient is the moment the invariant silently breaks.

### Layers, and who owns what

| Layer | Owner | Holds |
|---|---|---|
| Sources: `Inbox/`, `Areas/`, `Projects/`, `Resources/`, any imported notes | the owner | Everything raw. Edited freely |
| `Wiki/` | Claude | Narrative and synthesis. Never hand-edited |
| Profile layer: [[Areas/Master Profile\|Master Profile]] and sub-profiles | Claude, on the owner's say-so | **Atomic dated facts**, with tiers and shelf lives |

**The wiki and the profile layer divide by kind, not by topic.** *"Prefers 25-minute review
sessions"* is atomic and dated: profile. *"Every study method that stuck was one with a fixed
daily slot, and every one that failed relied on remembering to do it"* is synthesis across
sources, and ages differently: wiki. The wiki may link to a profile note and never restates its
content. Duplicating a fact in two places is how two contradictory versions end up in the vault
and the wrong one gets read ([[_system/profile-convention|profile-convention]]).

**Where a topic already has an owned treatment elsewhere** (a carefully maintained note on a
subject), the wiki registers that note as a **source** and cites it, rather than writing a
competing article.

### What is a source

Anything the owner wrote or deliberately kept that **asserts something**: notes, class notes,
book notes, journal entries, `type: learning` captures, project retrospectives, a clipped article
with the owner's own annotations. Language does not matter; quote the owner's words verbatim.

### What is not a source

Three tests. Fail any one and the note is not distilled:

1. **Does it assert anything?** A note that is nothing but wikilinks or a list of child pages is
   navigation, not content. Imports from other tools produce one of these per folder; a naive
   full ingest turns them into a wiki of contents pages.
2. **Is there text, or only a container?** Empty tables, notes that are only an attachment
   embed. These are indexed, not distilled.
3. **Is it knowledge or logistics?** Dated arrangements that expire (a trip itinerary, session
   times, a deadline list) belong to the task and calendar layer.

A fourth category is not a failure: **some real sources are for reading, not compiling.** A
collection of favourite quotes, or a lookup table of numbers, has no concept to extract, and
summarising it destroys the only thing it is. Register it as considered, and leave it alone.

**Bulk reference material** (a course archive, saved papers, downloaded slides) stays
**indexed, not distilled**. It enters the wiki only through engagement: the owner's own notes or
submissions about it, `type: learning` captures, or a logged gap. The wiki's value is the delta
over what the model already knows, and most curriculum is something the model already has.

### The stub bar

**A page needs two sources, or one source plus an existing vault note.** Volume alone never
justifies a page. A candidate that fails the bar is noted on the relevant source page or in the
ingest's `log.md` entry, and promoted when a second source arrives. Not every good idea earns a
page; a wiki of one-source stubs is just a slower copy of the notes.

### Article format

One article per **concept**, named as a short claim or concept in kebab-case
(`fixed-slot-beats-intention.md`), never per source and never per life area. One **source page**
is allowed for a single source rich enough that several articles draw on it (a long notebook, a
course the owner engaged with heavily); it summarises what is in that source and links out.

```markdown
---
type: wiki
wiki_origin: ingest              # ingest | query
wiki_ingested: 2026-01-15        # date of the last ingest that touched this page
wiki_sources:
  - "[[Resources/Learning/Spaced repetition|Spaced repetition]]"
  - "[[Inbox/Flashcards stopped working after week three]]"
---
```

The body opens with the claim in one bold sentence, then the owner's own words quoted and
attributed to their source, then how it connects to other articles, then any tension between
sources. The full worked template is in the `wiki` skill § Article template.

Rules for every article:

- **Cites sources, never other wiki pages, as evidence.** Links between articles are navigation.
  If page B's claim rests on page A, grounding thins with every generation while each step looks
  fine, and a restructure breaks pages that depended on other pages existing.
- **Distinguish what the owner concluded from what a source said.** "Read in a book" and "found
  for themselves" are different weights.
- **Third parties appear only as what the owner concluded**, never as what someone else is like.
  Anything about a named person's health, finances or relationships is raised with the owner
  before it is recorded anywhere (`CLAUDE.md` § Always true).
- **No credential of any kind**, and never distil a note that carries a pointer to one: cite it
  as a link and do not summarise it.

### Ingest

1. **Pick a slice.** A folder, a topic, or what `Wiki/_pending.md` lists. Ten to forty notes is
   a good size; the whole vault at once is not.
2. Read every note in the slice. Apply § What is not a source to each.
3. **Step A: the map only, then stop for review.** The proposed article list, which notes feed
   each, what was merged and why, what was rejected and under which test. The owner approves or
   changes the structure before anything is written. This is the step that stops the wiki being
   organised in a way the owner would not have chosen. Once the owner trusts the structural calls,
   they can hand them back.
4. **Step B: write.** Articles, `index.md` entries, links both ways between related articles,
   a `log.md` entry, and a row in `_sources.md` for every note read (distilled or not), with its
   hash.
5. **Lint** (below).

Expect one source to touch many pages: a rich new note usually amends several existing articles
rather than only adding one. Check every existing article it bears on, not just the new ones.

### Re-ingest: when a source changes

Sources in a vault **grow in place**; they are not append-only. So `_sources.md` keeps a content
hash per source, in two tables: sources that were distilled, and sources that were judged and
deliberately not distilled. The second table stops the drift job reporting the same rejected
notes as new forever, and it means a note that later **grows** into a real source gets noticed
rather than staying rejected on an old judgement.

A changed hash makes the articles that source fed candidates for re-ingest. **Re-ingest is
diff-scoped, not whole-file:** read the changed part plus the articles that source fed, and ask
one question, does this change the claim? Three outcomes: no change (update the hash), amend the
article, or a new article is warranted. Re-read the whole file only when it was restructured
rather than added to.

### Query: "what do I know about X"

1. **Read `Wiki/index.md` whole**, then the articles it points to.
2. Answer from the articles, citing them, and through them their sources. Say plainly which part
   of the answer is the owner's own view and which is Claude adding general knowledge.
3. **If the wiki could not fully answer, log the gap** in `log.md` (`## [date] gap | <question>`),
   then fall back to the rest of the vault and the web as `CLAUDE.md` § Always true describes.
   The wiki grows toward the questions it failed, not toward whatever happened to be fed in.
   This is the mechanism that scales past anyone's ability to decide in advance what to compile,
   and the only route by which bulk reference material becomes an article.

### Filing an answer back

One test: **can every claim in this answer be traced to something already in the vault?**

| | Route |
|---|---|
| Synthesis over existing material: the connection is what is new | **Write the page**, with `wiki_origin: query` |
| The owner said something new in the conversation | **Capture it to `Inbox/` first**, then distil it like any source |
| Claude supplied it: model knowledge, web research, an outside framework | **Foreign body.** It goes in only if the owner deliberately captures it as a source |

Query-derived pages carry `wiki_origin: query` so lint audits that class harder. The stub bar
still applies.

### Lint

Monthly, or after any large ingest. Checks:

- **Traceability.** Every article has `wiki_sources`; spot-check a few claims against them.
- **Registry.** Every cited source has a row in `_sources.md`, and every row's file exists.
- **Broken wikilinks**, in both directions.
- **Contradictions** between articles: flagged in the article with quotes from both sources,
  never silently smoothed.
- **Stale provisional sections:** material derived from a situation that has since moved on.
- **Index size.** `index.md` still readable in one sitting (target under 200 lines).
- **Orphans:** reported, not fixed. An article nothing links to is not automatically a defect,
  and manufacturing links to satisfy a graph metric is the failure mode.

Lint findings are fixed **in the sources** where they are about content, and in the wiki only
where they are about the wiki's own structure (links, index, registry).

## Setup / rebuild

The vault template ships `Wiki/` with the five structural files and no articles, this doc, and
the `wiki` skill. Steps (symlink the skill, install the drift timer, the first ingest) are in the
kit's `modules/wiki/README.md`.

**Rebuild from zero is cheap by design:** delete every article, keep the sources, re-ingest.
That is what the invariant buys.

## Config

- `Wiki/index.md`: **the catalog, read first.** Organised **by kind** (concepts, source pages),
  never by life area: the most useful articles cross areas, and an area-shaped catalog fights
  that. One line per page. Target under 200 lines.
- `Wiki/Wiki.md`: the Obsidian folder note (the `X/X.md` convention in the
  [[_system/README|Vault Map]]). Explains the folder. Deliberately **not** the catalog.
- `Wiki/log.md`: append-only, newest at the bottom, headings `## [YYYY-MM-DD] kind | title` with
  kind one of `ingest`, `reingest`, `query`, `gap`, `lint`, so `grep "^## \[" Wiki/log.md` lists
  everything.
- `Wiki/_sources.md`: the registry. Written only by ingest sessions, never by hand. Two tables
  (`## Ingested`, `## Considered and not ingested`), columns `Source | Hash | date | Articles fed`
  or `Why not`. Hash: `shasum -a 256 "<file>" | cut -c1-12`. Paths are vault-relative in
  backticks; a long shared prefix may be shortened to `…/<rest>` if the rest is unique.
- `Wiki/_pending.md`: generated daily by the kit's `jobs/wiki.py` on the server: drifted sources,
  deleted sources, cited-but-unregistered sources, and new candidates. **Findings never go to
  `Inbox/`**, which is the task list. The job's checks are routine-tier; only "`_sources.md`
  parsed" is important, because the detector being blind is a different event from anything it
  finds.
- **What the job counts as a new candidate:** `Inbox/` notes with `type: learning`, and any note
  in a `Clippings/` folder if one exists. Widen it in `jobs/wiki.py` (`CANDIDATE_TYPES`,
  `CANDIDATE_FOLDERS`) and here together.
- Frontmatter: `type: wiki`, `wiki_sources`, `wiki_origin`, `wiki_ingested`. Registered in
  [[_system/frontmatter-properties|frontmatter-properties]].

## Gotchas

- **Keep it small.** The constraint is the index being read whole. Twenty good articles beat two
  hundred thin ones; when in doubt, the stub bar says no.
- **Navigation notes are not sources.** Folder indexes and lists of links are the most common
  thing a first ingest wrongly distils, especially after an import from another notes tool.
- **Never hand-edit an article, even to fix a typo in a quote.** Fix the source, re-ingest. A
  hand-edited page silently stops being reconstructible.
- **`Wiki/Wiki.md` is not `Wiki/index.md`.** The folder note explains the folder; the index is
  the catalog. Writing the catalog into the folder note means the read-first step reads the
  wrong file.
- **`type: learning` is not a guarantee.** Many captures typed as learnings are really a book
  recommendation or a name to remember. Apply the tests and the stub bar at ingest rather than
  trusting the type.
- **Run the drift job on one machine only.** It keeps its history in machine-local memory; two
  machines writing `_pending.md` for real produce competing pages in one synced file. Anywhere
  but the server, `--dry-run` only.

## Known limitations

- **No unattended ingest.** The job detects; it never writes an article. Rewriting existing pages
  without a review step, while the owner may be editing the same vault, is the unsafe half, so
  ingest and re-ingest are sessions the owner starts.
- **No semantic search.** Retrieval is the catalog plus grep. If the gap log shows a body of
  material is genuinely unreachable that way, build an index as a command in the kit's
  automation repo, not as an Obsidian plugin, so it works on the server too.
- **Traceability is spot-checked, not proven.** Lint samples claims; it does not verify every
  sentence.

## Decisions

**The wiki is derived, never authored.** Rejected the looser version where the owner may edit
articles directly: reconstructibility from sources is what makes restructuring cheap, and a
hand-edited page silently stops being reconstructible. Cost accepted: correcting an article takes
two steps instead of one.

**Bulk reference material is indexed, not distilled.** Rejected one summary article per course or
per book: it manufactures pages for material the owner has nothing to say about, and most fail
the stub bar. Cost accepted: a cross-cutting synthesis exists only once a logged gap pulls it in.

**Two-step ingest: map, review, then write.** Rejected writing straight through: the first
structure a model proposes is often not how the owner would organise it, and restructuring
written articles costs far more than editing a list.

**Detection is automated, writing is not.** A pure reporter can run unattended safely; an ingest
cannot. Splitting them is what makes any of it automatic.

## See also

- `Wiki/index.md`: the catalog. Start there, not here.
- `_system/skills/wiki/SKILL.md`: the ingest, query and lint workflow, step by step
- [[_system/profile-convention|profile-convention]]: the other derived layer, and the boundary
- [[_system/frontmatter-properties|frontmatter-properties]]: where `wiki_*` is registered
