---
type: reference
component: claude-task-launcher
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Claude Task Launcher plugin: a "Work in Claude" button on task notes

**Status:** built, shipped in `.obsidian/plugins/claude-task-launcher/`, verified <INSTALL-DATE>.
Referenced from `SYSTEM.md` § Components.

## What it's for

Starting an **interactive** Claude Code session on one task in one click, pre-loaded with the
task's content, instead of copying the note into a chat by hand. Nothing runs unattended: you
read the prompt and press send yourself.

## How it works

| Situation | Result |
|---|---|
| Open a note whose `type` is `action` or `learning` | A **Work in Claude** button (bot icon) appears in the note's title bar. Change the type and it appears or disappears live |
| Open a dated meditation journal entry (`Areas/Personal/Meditation Journal/YYYY-MM-DD`) | A **Work through with Claude** button (same bot icon). The prompt is one line, `Run the plan-today skill on this meditation journal entry.`, plus the file path and body. The flow itself lives in [[_system/skills/plan-today/SKILL\|plan-today]], so the prompt cannot drift from it. Nothing is written until you confirm, and the entry itself is untouched |
| Any other note | No button |
| Click it on the **desktop** | Opens a `claude://code/new?q=<prompt>` link. The Claude Desktop app opens a new Code session and shows the prompt in the composer, **not sent** |
| Click it on the **phone or tablet** | Copies the prompt to the clipboard. Paste it into a Claude Code session that works in this vault (for example a Remote Control session in the Claude app) |

The task prompt is: one intro line (`Help with this task from the vault.`), the file path, the
title, and the note's body without its frontmatter. Desktop prompts open with two setup lines
first (see Gotchas): switch the session to auto permission mode, and move to the vault folder if
the session started elsewhere. Also available as the command **Claude Task Launcher: Work in
Claude**.

**What it runs:** no shell command, no network request of its own. On the desktop it hands one
`claude://` link to the operating system, which passes it to Claude Desktop. The vault folder is
read from Obsidian (the vault's own path on this computer), never hardcoded.

## Setup / rebuild

Shipped as `main.js` and `manifest.json` in `.obsidian/plugins/claude-task-launcher/`, listed in
`.obsidian/community-plugins.json`. No build step, not from the store.

1. Settings → Community plugins: Restricted mode off.
2. **Claude Task Launcher** appears under Installed plugins. Make sure its toggle is on.
3. For the desktop path, install the **Claude Desktop** app (the app with the Code tab, not just
   the `claude` command-line tool). Installing it registers the `claude://` links. Without it,
   switch Settings → Claude Task Launcher → Desktop action to **Copy to clipboard**.
4. Open the example task in `Inbox/`: the bot icon is in the title bar.

`.obsidian/` only reaches other devices if Obsidian Sync's plugin-sync toggles are on; a server
copy of the vault that does not sync configs never loads the plugin.

## Config

**Settings → Claude Task Launcher:**

| Setting | Default | Meaning |
|---|---|---|
| Launchable note types | `action, learning` | Values of `type` that get the button |
| Desktop action | Open in Claude Desktop | Or Copy to clipboard. Mobile always copies |
| Prompt intro | `Help with this {kind} from the vault.` | `{kind}` becomes `task` or `<type> note` |
| Maximum prompt length | 4800 | Characters; longer prompts are cut with a notice |

**To turn it off:** Settings → Community plugins → Claude Task Launcher toggle off. To remove it,
delete `.obsidian/plugins/claude-task-launcher/` and its line in `community-plugins.json`.

## Gotchas

- **Link-opened sessions start in manual permission mode**, even when `~/.claude/settings.json`
  sets `defaultMode: "auto"`. The link has no mode parameter (only `q`/`prompt`, `folder`,
  `file`), so the plugin cannot set it. Every prompt therefore opens with "First switch this
  session to auto permission mode (set_session_permission_mode, session self).": the session asks
  once through an approval card and runs in auto after that.
- **The link's `folder` parameter is unreliable, so the plugin does not send it.** Claude Desktop
  treats any folder passed in a link as untrusted and asks to confirm it on every launch, and
  after confirming it can still start the session in a scratch workspace. The prompt instead
  opens with "If your working directory is not <vault>, first move this session there with
  change_directory."
- **The prompt goes through a URL.** Very long note bodies are cut at the maximum length. Keep
  task bodies short and link to longer notes instead.
- After editing `main.js`, toggle the plugin off and on: Obsidian does not reload plugin code.

## Known limitations

- Desktop only for the direct launch; there is no link that reaches a specific session on the
  phone, hence the clipboard.
- No button on the TaskNotes cards in the cockpit itself: TaskNotes draws its own cards, and
  patching another plugin's display is fragile. If revisited, first check whether TaskNotes
  offers a supported card-action hook. Until then, open the note first.
- The prompt is deliberately minimal. A session started in the vault already loads `CLAUDE.md`
  and the router, so the prompt does not repeat them.

## Decisions

**The button comes from the `type` property, not from text in the note.** Every capture already
has `type`, so every task gets the button the moment the plugin loads, no capture path changes,
and retyping a note adds or removes the button with no second place to keep in sync.

**Meditation journal entries are matched by folder and `YYYY-MM-DD` filename, not by `type`.**
Entries are `type: note`; making them `type: action` would pull every entry into the ToDo views.
The journal's hub note and template do not match the filename test, so they get no button.

**Interactive, not automatic.** A background job that works a task with no one watching would
need answers to permissions, two writers editing one note, and review before anything is sent
(see [[scheduled-execution]]). The button only prepares a prompt; you send it.

## See also

- [[task-cockpit]]: the task system these notes live in
- [[cockpit-plugin]]: the other shipped local plugin
- [[scheduled-execution]]: why a fully automatic version is not wired up
- [[_system/SYSTEM|SYSTEM]]: the hub
