---
type: reference
component: claude-task-launcher
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Claude Task Launcher plugin: a "Work in Claude" button on task notes

**Status:** built, shipped in `.obsidian/plugins/claude-task-launcher/`, verified <INSTALL-DATE>.
Referenced from `SYSTEM.md` § Components.

## What it's for

Starting an **interactive** Claude Code session on one task in one click, pre-loaded with the
task's content, instead of copying the note into a chat by hand. Nothing runs unattended: you
read the prompt and press send yourself.

## How it works

| Situation | Result |
|---|---|
| Open a note whose `type` is `action` or `learning` | A **Work in Claude** button (bot icon) appears in the note's title bar. Change the type and it appears or disappears live |
| Any other note | No button |
| Click it on the **desktop** | Opens the link `claude://code/new?q=<prompt>&folder=<this vault's folder>`. The Claude Desktop app opens a new Code session, asks you to confirm the folder, and shows the prompt in the composer, **not sent** |
| Click it on the **phone or tablet** | Copies the prompt to the clipboard. Paste it into a Claude Code session that works in this vault (for example a Remote Control session in the Claude app) |

The prompt is: one intro line (`Help with this task from the vault.`), the file path, the title,
and the note's body without its frontmatter. Also available as the command **Claude Task
Launcher: Work in Claude**.

**What it runs:** no shell command, no network request of its own. On the desktop it hands one
`claude://` link to the operating system, which passes it to Claude Desktop. The folder is read
from Obsidian (the vault's own path on this computer), never hardcoded.

## Setup / rebuild

Shipped as `main.js` and `manifest.json` in `.obsidian/plugins/claude-task-launcher/`, listed in
`.obsidian/community-plugins.json`. No build step, not from the store.

1. Settings → Community plugins: Restricted mode off.
2. **Claude Task Launcher** appears under Installed plugins. Make sure its toggle is on.
3. For the desktop path, install the **Claude Desktop** app (the app with the Code tab, not just
   the `claude` command-line tool). Installing it registers the `claude://` links. Without it,
   switch Settings → Claude Task Launcher → Desktop action to **Copy to clipboard**.
4. Open the example task in `Inbox/`: the bot icon is in the title bar.

## Config

**Settings → Claude Task Launcher:**

| Setting | Default | Meaning |
|---|---|---|
| Launchable note types | `action, learning` | Values of `type` that get the button |
| Desktop action | Open in Claude Desktop | Or Copy to clipboard. Mobile always copies |
| Prompt intro | `Help with this {kind} from the vault.` | `{kind}` becomes `task` or `<type> note` |
| Maximum prompt length | 4800 | Characters; longer prompts are cut with a notice |

**To turn it off:** Settings → Community plugins → Claude Task Launcher toggle off. To remove it,
delete `.obsidian/plugins/claude-task-launcher/` and its line in `community-plugins.json`.

## Gotchas

- **Claude Desktop asks to confirm the folder on every launch.** By design: a folder passed in a
  link is always treated as untrusted. One extra click.
- **The prompt goes through a URL.** Very long task bodies are cut at the maximum length. Keep
  task bodies short and link to longer notes instead.
- After editing `main.js`, toggle the plugin off and on: Obsidian does not reload plugin code.

## Known limitations

- Desktop only for the direct launch; there is no link that reaches a specific session on the
  phone, hence the clipboard.
- No button on the TaskNotes cards in the cockpit itself: TaskNotes draws its own cards, and
  patching another plugin's display is fragile. Open the note first.
- The prompt is deliberately minimal. A session started in the vault already loads `CLAUDE.md`
  and the router, so the prompt does not repeat them.

## Decisions

**The button comes from the `type` property, not from text in the note.** Every capture already
has `type`, so every task gets the button the moment the plugin loads, no capture path changes,
and retyping a note adds or removes the button with no second place to keep in sync.

**Interactive, not automatic.** A background job that works a task with no one watching would
need answers to permissions, two writers editing one note, and review before anything is sent.
The button only prepares a prompt; you send it.

## See also

- [[task-cockpit]]: the task system these notes live in
- [[cockpit-plugin]]: the other shipped local plugin
- [[_system/SYSTEM|SYSTEM]]: the hub
