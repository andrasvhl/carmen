---
type: reference
component: travel
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Travel: door-to-door trip planning and flight price watch

**Status:** built (search helper live against both sources, watch job tested offline).
Referenced from `SYSTEM.md` § Components.

## What it's for

Booking tools compare airport to airport, on one site, in cash. Real trips start at a home
address and end at a specific destination, so the cheapest answer often uses an airport hours
away, a train, a hidden-city fare or a day-early arrival. This component makes those options
cheap to compute, and keeps watching a fare after the answer is given, with the laptop shut.

## How it works

Three parts, one per machine boundary:

| Part | Where | What it does |
|---|---|---|
| Skill `travel` | `_system/skills/travel/` (symlinked on both machines) | The method: intake, airport and date grid, search, door-to-door comparison, buy-timing verdict, trip page, watch block. It reads your travel profile note for your preferences |
| `vt flights` | `~/automation/tools/flights.py` | Searches Skiplagged and Kiwi over a whole airport × airport × day grid in one call; prints the cheapest fare per pair and per day, and flags hidden-city, self-transfer and missing bags |
| `vt trains`, `vt ferries` | `~/automation/tools/trains.py`, `tools/ferries.py` | Rail and bus connections door to door from Transitous (no fares); ferry sailings and fares from Ferryhopper |
| `flight_watch` job | `~/automation/jobs/flight_watch.py`, on <SERVER>, 08:10 and 18:10 | Re-prices every watch and pushes deals |

**Data sources.** Skiplagged (`https://mcp.skiplagged.com/mcp`) and Kiwi (`https://mcp.kiwi.com`)
publish free MCP servers that need no key. `vt flights` calls them as plain HTTP JSON-RPC, so the
same code runs in a chat on the laptop and in the unattended job on the server. Kiwi quotes in
USD. Anything else is converted with the ECB daily reference rate. Interactive runs confirm
candidates on Kayak (the main confirmation source), Google Flights and the airline sites through
the browser (skill `reference/sources.md`). All three keyless MCP servers (`skiplagged`, `kiwi`,
`ferryhopper` at `https://mcp.ferryhopper.com/mcp`) are also registered in Claude Code at user
scope on both machines. Trains come from Transitous (`https://api.transitous.org`), an open
community router over public timetables.

**Trip pages** live in `Areas/Personal/Travel/`, one per trip, linked from the trip's task.

### Flight watch

A watch is a fenced `flight-watch` block of JSON inside a trip page:

```
{"id": "<TRIP_ID>", "from": ["<AIRPORT_1>", "<AIRPORT_2>", "<AIRPORT_3>"], "to": ["<DEST_AIRPORT>"],
 "dates": "<YYYY-MM-DD>..<YYYY-MM-DD>", "stops": 2, "bag": true, "adults": 1,
 "target_usd": 700, "until": "<YYYY-MM-DD>"}
```

`id` keys the price history; `dates` takes a day, a comma list or `A..B`; `bag: true` excludes
hidden-city fares; `until` defaults to the last departure day. The job reads blocks from every
page under `Areas/Personal/Travel/` and never writes to those pages.

**A deal**, which is all it pushes:
- at or under `target_usd`;
- or, with at least 4 checks, 12 % and $40 under the median seen so far;
- or a new low by 5 %.

A deal pushes once (priority 0, with the fare link), and again only after a further 5 % drop,
or after 7 days if it is still a deal. Pushes that fall in quiet hours wait for the next run.
Every run rewrites the generated flight-watch status page, one section per watch with the daily
lowest fare. That page is where the skill reads the trend from.

## Setup / rebuild

1. Code: `tools/flights.py`, `jobs/flight_watch.py`, `tests/flight_watch.py`,
   `units/automation@flight_watch.timer` in `~/automation`. Push to <SERVER>.
2. On the server: `sudo cp ~/automation/units/automation@flight_watch.timer /etc/systemd/system/ &&
   sudo systemctl daemon-reload && sudo systemctl enable --now automation@flight_watch.timer`.
3. Skill symlink on each machine: `ln -s $VAULT_PATH/_system/skills/travel ~/.claude/skills/travel`.
4. MCP servers on each machine: `claude mcp add --scope user --transport http skiplagged
   https://mcp.skiplagged.com/mcp` and the same for `kiwi https://mcp.kiwi.com`.
5. Test: `python3 -m tests.flight_watch` (offline), then
   `~/automation/bin/run-job flight_watch --dry-run` on the server.

## Config

| Path / knob | Contents |
|---|---|
| `Areas/Personal/Travel/*.md` | Trip pages and their `flight-watch` blocks |
| `_system/flight-watch-status.md` | Generated status page; never edit |
| `~/.local/state/automation/flight_watch.memory.json` (server) | Full price history (120 checks per watch), last push per watch, held pushes |
| `MAX_COMBOS_PER_RUN = 30` in `jobs/flight_watch.py` | Search budget per run; the oldest-checked watches go first |
| `_GAP`, `RETRY_WAITS`, `COOL_DOWN` in `tools/flights.py` | Skiplagged pacing |

## Gotchas

- **Skiplagged rate-limits by calls per minute.** Two parallel calls, or one every 2 s, drew
  HTTP 429 on a third of an 18-call grid; one call at a time, about every 8 s, never did.
  `vt flights` runs Skiplagged serially at that pace, retries, and does one more pass after a
  60 s cool-down. Running several grids back to back in one session still exhausts it.
- **Kiwi's `curr` parameter is ignored; the field is `currency`.** Without it, prices come back
  in EUR.
- **Hidden-city fares are only marked in Skiplagged's `attributes` (`hidden-city`).** A filter on
  anything else silently mixes them into "regular" fares.

## Known limitations

- **The job sees Skiplagged and Kiwi only.** Google Flights, airline sites and frequent-flyer
  awards are checked only in interactive runs, so an alert is a lead to confirm, not a quote.
- No Southwest anywhere in the automated path.
- `vt trains` has no fares, and its timetables stop at the next published timetable change.
- Kiwi cannot tell a protected interline itinerary from a self-transfer; mixed carriers are
  flagged self-transfer.
- No hotels, by scope.

## Decisions

**Keyless sources over SerpAPI and fli.** SerpAPI returns Google's price insight but needs an
account and caps the free tier at about 250 searches a month. `fli` (a reverse-engineered Google
Flights client) broke and now scrapes the page. Skiplagged and Kiwi need nothing and run on the
server. SerpAPI remains the upgrade if unattended Google price insight becomes worth an account.

**Trains from Transitous, not DB's API.** Deutsche Bahn access through db-vendo-client against
bahn.de answers `OPS_BLOCKED` from Akamai bot protection on every profile (db, dbnav, dbweb),
and the library's own maintainers call DB access "very unreliable" and recommend Transitous.
Working around bot protection is ruled out. Cost: no fares from the script; bahn.de is read in
the browser.

**Seats.aero Pro not used.** With a single airline program, that program's own site covers the
same award space for free. Reconsider above about 60,000 miles or with a transferable points
currency (skill `reference/playbook.md`).

**Deals only, by push.** Alerts go out only when prices indicate a good deal. Rising prices go
to the status page, never to the phone.

**Watches live in the trip page.** Rejected: a central registry file. Keeping the watch beside
the analysis it came from means deleting a trip page ends its watch, and you can edit the target
where you read the reasoning.

**One skill.** One skill with reference files, rather than a split into dozens of skills, as
long as one command starts it.

## See also
- [[_system/skills/travel/SKILL|travel skill]]: the method
- Your travel profile note: your preferences
- The generated flight-watch status page: prices
- [[push-notifications]]: the push channel
- [[_system/maintenance/automation|automation]]: the job runner
