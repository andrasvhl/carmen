---
type: reference
component: fitness-sync
stage: design-only
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Fitness sync: Strava (and optionally WHOOP) activities into a training-log note

**Status:** optional module, **not installed** until the kit's `modules/fitness/README.md` is
followed; its last step sets `stage: built` and `verified:` here. If you never install it,
delete this doc. Referenced from `SYSTEM.md` § Components.

## What it's for

Training sessions recorded on a watch end up in Strava, and heart-rate data in WHOOP, but not in
the vault, where the rest of your planning lives. This job closes that gap without you
remembering to do anything: every two hours it looks for new Strava activities of the types you
chose, adds the matching WHOOP workout and that morning's recovery reading, and appends one
numbers-only entry per session to a note. It writes data, never interpretation.

## How it works

A plain Python job on the server, `jobs/fitness_sync` in `~/automation`, started by
`automation@fitness_sync.timer` every 2 hours at :27. No Claude involved. Each run:

1. Refreshes the Strava token and saves the new refresh token at once (Strava rotates it).
2. If WHOOP is connected, calls it every run, even with nothing to log, so its rotating
   refresh token never goes cold (Gotchas).
3. Lists every Strava activity from the earlier of (cursor minus 3 days) and (now minus 21
   days), keeps the chosen sport types of 5+ minutes not logged yet, matches each to the WHOOP
   workout starting closest to it (within 20 minutes) and the latest recovery reading in the 30
   hours before it.
4. Appends the entries to the log note, advances the cursor past everything seen, keeps a
   bounded list of logged ids so re-scanning is harmless.
5. Rewrites [[fitness-sync-status]] (machine-written: last run, health per service, problems).

Problems are the runner's checks: they land in the alert log like any job's, and `heartbeat`
checks that the job ran recently. The first run after authorising logs nothing older than
itself (unless `FITNESS_BACKFILL_DAYS` was set).

## Setup / rebuild

From the kit: `modules/fitness/README.md`. In short: libraries into `~/automation/.venv`, your
own Strava API app (and optionally a WHOOP developer app), one OAuth round trip each with
`run-job fitness_sync.auth strava|whoop` in your own Terminal, then the timer.

To re-authorise one service after a revoke or a dead token (you run this in your own
Terminal): `ssh -t <server> '~/automation/bin/run-job fitness_sync.auth whoop'` (or `strava`).

## Config

| Path | Contents |
|---|---|
| `~/automation/jobs/fitness_sync/` | The code, on the server (not in the vault) |
| `~/.fitness-sync/config.json` | Client ids and secrets, OAuth tokens. Mode 600, never in the vault, never printed |
| `~/.fitness-sync/state.json` | Sync cursor, first-run floor, logged activity ids |
| `~/.automation.env` | Optional `FITNESS_*` settings (log note, sport types, minimum minutes, quiet-days note, redirect URI) |
| `automation@fitness_sync.timer` | The schedule |
| The log note (default `Areas/Fitness/Training log.md`) | Where entries are appended |
| [[fitness-sync-status]] | Generated health page |

## Gotchas

- **Both services rotate the refresh token on every use.** The job saves the new one before
  using it; a run that refreshed and did not save would break the chain. WHOOP has no grace
  period, and a rotation can commit on WHOOP's side even when the reply was a timeout, so the
  job allows 30 seconds and never runs twice at once.
- **`invalid_request` or `invalid_grant` from WHOOP while Strava works is a dead credential,
  not missing data.** Re-authorise; the data is still in WHOOP.
- **A job that runs is not a job that works.** The type filter once silently matched nothing
  after a library update. The job now flags "activities found, none of your types" and keeps a
  21-day re-scan so a missed session is picked up on the next run.
- **Two writers on one note.** If you edit the log note in Obsidian at the moment the job
  appends, Sync can keep only one side. Low odds; add your own notes under older entries.

## Known limitations

- Numbers only: no comparison against a plan, no commentary.
- Only the chosen Strava sport types. Sessions not recorded in Strava are never seen.
- WHOOP matching is by start time (within 20 minutes), not a shared id, so two workouts
  started close together can be confused.
- Strava's API now needs a Strava subscription on the account that owns the API app.

## Decisions

- **A plain script, not a Claude job.** The data is objective sensor output, so it is appended
  directly, with no review step and no model in the loop.
- **Paste-back OAuth, no callback server.** Authorising happens once per service; a listener
  reachable from your browser would be moving parts for two clicks a year.

## See also

- [[fitness-sync-status]]: the generated health page
- [[_system/SYSTEM|SYSTEM]]: the hub
