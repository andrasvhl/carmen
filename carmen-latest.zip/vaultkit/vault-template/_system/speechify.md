---
type: reference
component: speechify
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Speechify delivery: uploading documents to your Speechify library to listen on the go

**Status:** built. Skill: `send-to-speechify`. Referenced from `SYSTEM.md` § Components.

## What it's for

You can listen to readings on your phone when you are away from your desk, because Speechify reads PDFs aloud. "Send X to Speechify" should work like [[_system/kindle|kindle]]: one lookup, with no need to work out again how to get files in.

## How it works

- **Route:** upload through the web app at `https://app.speechify.com` in **your Chrome** (Claude in Chrome), signed in as `<YOUR_EMAIL>` via "Continue with Google". The library syncs to the phone app by itself, so you do nothing on the phone.
- **No email-in, no watched folder.** Speechify has no import address and does not auto-import from iCloud, Drive or Dropbox. Every other route needs taps on the phone.
- **The upload that works:** open `https://app.speechify.com/library`, click **Add** in the sidebar, `find` the `type=file` input, then `file_upload` with **one path**. Repeat the whole sequence (reload the library, Add, find, upload) for each file. Confirm by reading the library page: every file should be listed under Today.
- **Finding course readings:** same as [[_system/kindle|kindle]] § Course readings: files via `canvas_file_path` under `Course Archive/_files/`.

## Config

| What | Value |
|---|---|
| Account | `<YOUR_EMAIL>`, Google login |
| Plan | `<YOUR_PLAN>` (the free plan caps the library at 5 files; Premium has no file cap) |
| Library | `https://app.speechify.com/library` |
| School license page | `<YOUR_SCHOOL_SPEECHIFY_LICENSE_URL>` |

## Gotchas

- **One file per upload.** If you pass several paths to the file input, it reports success but only the first file lands. The others are lost without any error.
- **The input on the home page does not work after the first upload.** It reports success and nothing arrives. Use the input that appears after clicking **Add** on the library page.
- **Uploads can take a minute to appear in the list.** An upload can report success, be missing on the next reload, and appear later. Retrying too early leaves a duplicate. Wait and reload once more before re-uploading.
- **Upload from the vault path, not `~/.workspace-mcp/attachments/`.** `file_upload` only reads files inside the session's folders, so the Kindle staging dir is rejected. Pass the `canvas_file_path` under the vault directly. Files generated in the session scratchpad also upload fine.
- **Clicking Add can toggle the menu closed** if it is already open. Take a screenshot to confirm the Upload File menu is showing before using the input.
- **Never pay to upgrade.**
- **Some courses have no class prep note with dates** (for example, when the syllabus is empty). In that case the session number is the Nth meeting of that course in your calendar. Module folders are numbered by session.

## Known limitations

- Needs your Chrome open and signed in to Speechify. Does not run unattended or from <SERVER>.
- Readings that are library links (behind your school's library proxy) are fetched as in [[_system/kindle|kindle]] § Course readings before upload.

## Decisions

**Web upload through your Chrome, not an iCloud or Drive folder.** Folder routes need a manual import on the phone for each file, while the web library syncs by itself. Drive linking is also rejected because it gives Speechify access to the whole Drive.

## See also
- [[_system/kindle|kindle]]: the reading counterpart, and the course-readings recipe
- [[_system/canvas-archive|canvas-archive]]: where course files come from
- `_system/skills/send-to-speechify/SKILL.md`: the steps
