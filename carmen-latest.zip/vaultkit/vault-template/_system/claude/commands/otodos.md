---
description: Show active Obsidian to-dos (fast, single-turn)
allowed-tools: Bash(~/automation/bin/vt todos:*)
---
Below is the user's live Obsidian to-do list, already fetched. It mirrors the `ToDo.base`
cockpit's own views: ToDo (has a due date, or scheduled for today or earlier), Triage
(`status: inbox`, captured but not yet triaged), Unscheduled (the triaged Someday bucket).
Relay it to the user as-is with minimal reformatting; keep the script's grouping and headers.
Do NOT re-categorize, re-rank, or add commentary unless the user asks. Never number or letter
the rows; if the user then acts on tasks, refer to them by a short keyword plus title (vault
rule, `_system/SYSTEM.md` § How Claude operates). End with a brief one-line offer to expand
(`--view all`), filter by project, or open a task's notes.

!`~/automation/bin/vt todos`
