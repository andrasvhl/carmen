# Claude's own configuration

What lives here:

- `global-CLAUDE.md`: the master of `~/.claude/CLAUDE.md`, your cross-project instructions to
  Claude. **Fill in its "About me" section first.** Edit this file, never `~/.claude/CLAUDE.md`
  directly. Why a master copy in the vault: the vault syncs and is backed up, so your
  instructions survive a new laptop, and you can edit them in Obsidian like any note.
- `commands/`: slash commands (for example `otodos`, a fast to-do listing). Linked into
  `~/.claude/commands/`.

**How the copy gets there.** Either copy it by hand after each edit:

```bash
cp "$VAULT_PATH/_system/claude/global-CLAUDE.md" ~/.claude/CLAUDE.md
```

or add the SessionStart hook from `SETUP-NOTES.md`, which copies it whenever the two differ. A
copy rather than a symlink because some Claude apps ignore a symlinked `~/.claude/CLAUDE.md`.

**Known limit:** if you use Claude on two machines, each needs the hook (or the copy step) set
up once.
