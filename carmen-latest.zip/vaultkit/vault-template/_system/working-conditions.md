---
type: reference
component: working-conditions
stage: partial
verified: <INSTALL-DATE>
revisit: <REVISIT-DATE>
captured: <INSTALL-DATE>T12:00
---

# Working conditions: when work can realistically be placed

**Status:** partial (template, not yet filled in), verified <INSTALL-DATE>. Read by `schedule-work`
and before proposing any day plan. Fill it in on the first `schedule-work` run; that skill's
Pass 1a asks exactly these questions.

## What it's for

The parameters a plan has to respect to be a real plan rather than a wish: when the day starts
and ends, what a weekend can hold, what sport and commuting cost, and which calendars exist.
Not priorities: those are [[Areas/North Star]] §2 and §5, and they stay there.

**This file exists because a plan built without it is confidently wrong.** A scheduling pass
that does not know the day starts at 09:30 or that evenings are taken will place blocks that do
not exist, and two sentences from the user then invalidate most of the plan. Writing the
constraints down once means no run re-guesses them.

## How it works

Fill in every row. Replace `(elicit)` with the real answer and the date it was stated.

| | |
|---|---|
| Sleep | (elicit: wake time weekdays / weekends, lights out. Write it as `Wake 07:30 weekdays, 09:00 weekends. Lights off 23:00`: the Telegram bridge reads this row for quiet hours) |
| Weekdays | (elicit: start, end, lunch, dinner) |
| Mornings | (elicit: what kind of work goes here: hard, avoided, creative?) |
| Afternoons | (elicit) |
| Evenings | (elicit: free, light work, or real work?) |
| Weekends | (elicit: max hours of work per day, and when) |
| Focus blocks | (elicit: when deep work happens, how long a block is, how many per week) |
| Sport | (elicit: weekly minimum, preferred time of day) |
| Social | (elicit: standing dinners, evenings kept free, how many social nights a week) |
| Commute | (elicit: how long, which days) |
| Fixed weekly commitments | (elicit: classes, standing meetings) |
| Weekly rhythm | (elicit: when you plan the week, when you check mid-week) |
| Travel | (elicit: trips in the next weeks, and the days either side) |

**Placement rules, which have the force of deadlines.** Add your own. A common one worth
testing: *emotionally demanding or avoided work goes in the morning, while fresh. A plan that
puts it in the afternoon is a plan that will not happen.*

- (elicit)

### Calendar roster

**Read every calendar listed here, never only the primary one.** A plan built against one of
three calendars is worse than one built against none, because it looks informed. Re-check the
list at the start of every `schedule-work` run (`list_calendars`), because calendars get added;
a new one is a question for the user: what is it for, and does it block time?

| Calendar | Role | Blocks time? | Claude may write? |
|---|---|---|---|
| (elicit: main) | main, meetings and invites | yes | yes |
| (elicit: optional: a "Focus" calendar for solo work) | solo work blocks | no | yes |
| (elicit: subscribed feeds: holidays, events, RSVPs) | read only | - | no |

**Every condition here carries an expiry, and the file carries a `revisit:` date.** A condition
without one gets silently carried into a week where it is false. If `revisit:` has passed, say
so in one line and ask rather than planning against it.

## Gotchas

- **Your answer in the session beats this file.** If what the user says differs from what is
  recorded, the file is stale: say so, and propose updating it at the end of the run.
- **Propose writes to this file, do not slip them in.** One line at the end of a run, naming
  what would be recorded and until when.

## See also
- `_system/skills/schedule-work/SKILL.md`: the main reader
- [[Areas/North Star]]: priorities and decision rules
