---
type: reference
component: signal-definition
stage: partial
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Signal definition: how a pass over inbound material decides what matters

**Status:** partial. The detection tests below are written and come from a real run. The
channel registry they depend on is **not built** yet; it is specified in your project plan.
Referenced from `SYSTEM.md` § Components.

## What it's for

Any pass over inbound material (mail triage, WhatsApp scans, enrichment, future automated
ingestion) has to answer *"is this important?"* thousands of times. Leave that to judgement on
each run and it gets answered by surface shape. Surface shape is wrong in one consistent
direction: **the things that matter most often look the most routine.**

This file holds the **detection** rules. It does not hold personal priorities. Those live in
[[Areas/North Star|North Star]], and the two must not be merged. Detection answers *"does this
need to reach the user at all?"*; North Star answers *"how much does the user care, relative to
everything else?"* Each has one implementation, following `SYSTEM.md`'s standing rule against
two definitions of the same thing.

## How it works

### Layer 0: deterministic Gmail labels, for the user's eyes only

Server-side Gmail filters in your mailboxes move known bulk mail **out of the Inbox into
labels**. They match on sender address, `List-Id` or attachment, never on judgement. Their only
job is to make your mail client's unified inbox and its push notifications carry mostly people.
Example set:

| Label | Account | What | Kept in Inbox on purpose |
| --- | --- | --- | --- |
| `Shopping` | all | online retailers, shipping carriers, pharmacies | sign-in, code, security, declined, failed subjects |
| `Receipts` | all | payment services, app stores, banks, hosting, subscriptions | same exclusions |
| `Lists/<LIST_NAME>` | `<YOUR_EMAIL>` | group and member mailing lists, institution-wide announcements | lists for groups you lead, restricted lists for your own cohort |
| `Lists/<BLAST_LIST>` | `<YOUR_EMAIL>` | label on every blast mail; only calendar invites (`invite.ics`) leave the Inbox | all other blast mail |
| `<SERVER>` | all | routine `<SERVER>` reports, Healthchecks UP | FAILED, expires, DOWN, BAN, TRIPWIRE, "could not" (these also push, [[push-notifications]]) |

**This is not a signal decision and must never become one.** A label says where a mail is shown,
not whether it matters. The filters sit in front of the user reading their inbox, **not in front
of a triage pass**: every pass still reads all mail, whatever its label. **Never use `in:inbox`,
`-label:` or any label exclusion in a triage query.** That is Gotcha 4 again, done by a filter
instead of a query. Luma, Eventbrite and Google Forms are deliberately left unfiltered, for the
reason Gotcha 4 gives.

### Layer 1: the channel test, applied before reading

Some senders are always opened in full, however routine they look, because they are
**designated deadline channels**. The list lives in `SYSTEM.md` § "How Claude operates" and
stands in for the channel registry until that is built. Typical members:
`<SCHOOL_DIGEST_EMAIL>` · `<INTERNATIONAL_OFFICE_EMAIL>` · `<BILLING_OFFICE_EMAIL>` ·
`<HEALTH_CENTER_EMAIL>` · `<ADVISOR_EMAIL>`.

**Every mailbox, every time.** `<YOUR_EMAIL>` and `<YOUR_PERSONAL_EMAIL>` carry different parts
of your life. Scanning one of them is not scanning your mail.

**And WhatsApp, which is readable.** It goes through WAHA on `<SERVER>`: [[whatsapp-bridge]] §
Reading WhatsApp. Group chats carry deadlines that never show up in any official digest. A pass
that skipped WhatsApp must say so and must never imply it was covered. **Test it before calling
it unavailable:** a doc header can be stale while the session itself is live.

### Layer 2: the six signal tests, applied to content

An item is **signal** if any one of these is true. They are deliberately independent: one hit is
enough, and every test is cheap enough to run on everything.

1. **A date exists in the world.** A deadline, appointment, RSVP, expiry, hearing, or a window
   that closes. Not "this feels urgent": a date someone else set.
2. **Someone is blocked.** A direct question with no reply, a document waiting for a signature,
   an approval only the user can give. Severity is how long they have waited, not the tone of
   the ask.
3. **Money, legal or status consequence.** Payment, contract, insurance, visa, enrolment,
   billing, liability. This applies even when the message is calm and administrative.
4. **The option expires or the action is irreversible.** A refund window, a cancellation fee
   that goes up, a spot that can be transferred free until a date. **This test catches what the
   date test misses**, because the deadline often sits on the *option*, not on the event.
   **It includes registrations with limited capacity, where the option runs out through demand
   rather than a date:** big-name speaker series, lunch lotteries, treks, retreats with limited
   seats, and anything that says "fills quickly", "limited capacity", "first come" or
   "registration opens at". **The trigger is the announced opening time, not the event date.**
   Report it as *"registration opens <day time>"*, because by the time the event is close the
   seats are gone. See Gotcha 5.
5. **It is decision-shaped.** No next physical action exists until the user chooses something.
   These items pass for two-minute admin and sit for weeks. The full mechanism is in
   `commit-to-action` § "Classify every item as decision-shaped or not".
6. **Something failed silently.** A bounce, a declined card, a stalled sync, an unconfirmed
   booking, a frozen data source. Nothing announces these; they only surface if someone looks
   for them.

### Layer 3: what is explicitly NOT signal

These false positives crowd out the real signal:

- **Insistence.** How often a sender chased, how many exclamation marks, whether the subject
  says URGENT. A club broadcast can nag; a visa rule change states itself once, calmly.
- **Recency.** The most valuable item in a session can be days old and unread. Never filter to
  recent or already-read.
- **Volume of the thread.** Thousands of messages in a group chat do not make it important.
  That is just a busy chat.
- **The subject line.** See Gotchas.

### Reporting rules

- **Never state an inference as a fact.** If the evidence only supports "this was probably the
  user", write that, or ask. Account-security alerts must never be reported as the user's own
  doing without evidence. A 2-Step Verification change, for example, looks exactly like what a
  compromise looks like.
- **Name what could not be seen.** Voice notes, images, PDFs, view-once messages, chats outside
  scope. A gap nobody mentions reads as "nothing found".
- **Dismissal is visible, never silent.** Everything dropped is named in one line with a reason.
  Silent dismissal causes the failures below, and it is why the four-list format has a Noise
  section at all.

## Gotchas

**Five failure modes.** Every one comes from trusting surface shape over content.

1. **Institutional senders that look automated.** A school digest gets filed as noise in one
   line while it holds registration and proposal deadlines. It is the designated channel, and it
   looks like a newsletter by design. The deadline can even be visible in the search snippet
   and the mail still goes unopened. **Fix: layer 1 above.**

2. **Trusting the subject line as the summary.** A progress mail titled *"You are on track!"*
   gets reported as a status update, while the body shows most requirements unmet and some not
   started. **The subject is marketing; the body is the fact.** Fix: for anything that passes
   layer 1 or 2, read the body, never the snippet.

3. **Category dismissal.** A whole category (such as a recruiting stream) gets dropped as
   irrelevant and takes real application deadlines with it, deadlines that matter because North
   Star may still leave that path open. **Dismiss items, not categories.** When you do dismiss a
   category, say so out loud so the assumption can be seen.

4. **Filtering by Gmail category in the query itself.** This is the worst of the five because
   it happens *before* anything is read and leaves no trace. A query like
   `-category:promotions -category:social -list:*` cuts newsletter noise, but **personal
   invitations go out through invitation platforms, which add `List-Unsubscribe` headers, so
   they land in Promotions.** A filter like that removes an invitation and all its RSVP
   reminders. The scan then reports the event date as unknown, even though it was in plain text
   all along.

   **Rule: never exclude a Gmail category in a triage query.** Cut noise by judging items after
   reading their headers, not by excluding envelopes before you see them. Expect real, personal,
   dated content from **Paperless Post, Partiful, Luma, Evite, Punchbowl, Google Forms receipts,
   Calendly, Doodle**, and any other RSVP or scheduling platform. `-list:*` has the same defect;
   avoid it for the same reason.

5. **Capacity-limited events read as ordinary events.** A deadline scan files a big-name speaker
   event under **optional / FYI**, dated by the event weeks away rather than by the registration
   opening, and the event sells out within hours. The digest had announced the opening time days
   earlier, as one entry among dozens. The blast mail only arrives at the moment registration
   opens, which is already too late for a daily pass. **Fix: test 4's capacity clause. Pull every
   "registration opens at" line out of the digest as its own item, with the opening time as the
   deadline.**

## Known limitations

- **Ranking still depends on North Star, and North Star is v1.** Detection can say "this is
  signal". It cannot say that a close friend's birthday matters more than a club RSVP.
  [[whatsapp-source]] reached the same conclusion from its side: a sweep put an invitation at the
  top purely because the sender kept insisting, with no idea whether that sender was a close
  friend.
- **Voice notes and images are invisible.** WhatsApp audio and pictures arrive with no
  transcript or OCR, so an answer given in a voice note, or the date printed on an invitation
  image, gets missed. No test above can fire on content that was never read.
- **The channel registry does not exist yet.** Layer 1 is a hand-maintained list kept in two
  files. It will drift until the registry is built.
- **No measured recall, and the one prefilter that was measured failed.** Nobody knows what
  share of real signal these six tests catch. Separately, a *keyword prefilter* (what a pass might
  use to decide what to read at all) was tested on group chats. It reported "essentially nothing
  this week" for a stretch that held several hard deadlines and a government ruling that affected the user.
  **The rule that follows holds for every channel: never keyword-filter before reading.** A
  regex returns a confident, plausible, shorter list whether it works or not. That is the same
  silent failure as the Gmail-category exclusion in Gotcha 4. Mechanism and numbers:
  [[whatsapp-source]] § "Measure the recall gap once instead of arguing about it".

## Decisions

**Detection and priority stay separate.** One file answering "does this matter" end to end was
tempting. It was rejected because the two change at different speeds: North Star is rewritten
every horizon as the user's life changes, while the detection tests barely change. Merging them
would mean rewriting stable rules every quarter.

**One signal definition across all channels.** Mail, WhatsApp, and later Granola and calendar
all use the same six tests. Separate signal rules for each source are exactly the fragmentation
the channel registry is meant to prevent, and the failure modes above happen on every channel.

**Inbox filtering is allowed; triage filtering is not.** Filtering bulk mail out of the Inbox is
allowed because it only changes what the user sees and gets notified about. Every filter is
deterministic and can be inspected in Gmail settings. Used as a triage prefilter, the same
filters would repeat Gotcha 4 and the keyword-prefilter failure measured above. Some
high-volume sources stay in the Inbox on purpose because they carry signal: blast lists (social
and speaker events), Eventbrite and Luma.

**Open: should this become executable?** Today it is a document a model reads. Tests 1, 3 and 6
are mechanical enough to become code. It is undecided whether that is worth doing before the
registry exists.

**Open: who maintains the always-open list, and how often is it reviewed?** A list nobody
maintains rots into the same failure, only more slowly.

## History

Every rule here comes from something that went wrong or right in a real mail and WhatsApp triage
run, not from abstract reasoning.

## See also
- [[Areas/North Star|North Star]]: personal priority. Detection lives here, importance lives there.
- [[whatsapp-source]]: the same problem, seen from the WhatsApp side.
- [[gmail-mcp]]: every mailbox, and why the split matters.
