---
type: reference
component: daily-meditation
stage: built
captured: <INSTALL-DATE>
verified: <INSTALL-DATE>
---

# Daily meditation: how the note gets created

**Status: works on iPhone, end-to-end.** A phone run produces the complete note: frontmatter,
`captured:` timestamp, date heading and every `##` question. **Any number of journals can run on
this pattern.** For example, a meditation journal (choice `Daily Meditation`) and a second
free-writing journal (choice `freeflow`). **The `obsidian://new&content=` path this replaced is
dead and must not be revived.** See § Why the URI path is dead.

The practice itself lives in the meditation journal's anchor note; this doc is only the
machinery. Referenced from `SYSTEM.md` § Components.

---

## Setup / rebuild

### ▶︎ THE SETUP

**The template file is `Areas/Personal/Meditation Journal/_Daily Meditation Template.md`.** It is a normal
vault file, so **it syncs to the phone** like any other note.

**The settings below sync too, so enter them once on the Mac.** Vault configuration sync is on
between Mac and iPhone: community plugins are active on the phone, which only happens with the
community-plugin list toggles on. *Core plugin settings* and *Active core plugin list* are on by
default, and Daily Notes and Templates are core plugins. **The vault host server is the only
client with `Configs: none`.**

> [!warning] `Configs: none` is the vault host's setting, not a vault-wide fact
> [[vps-vault-host]] records `Configs: none` for the **headless Linux server**, so it never
> pulls Mac themes and plugins it cannot use. **It says nothing about Mac ↔ iPhone.** Do not read
> it as vault-wide and use it to reject plugins such as QuickAdd or Advanced URI (see § Design
> decisions).

**The community-plugin lists are on** and coexist with desktop-only plugins (such as `cockpit`
and `claude-task-launcher`) without incident: those simply do not load on mobile. Nothing to
change.

#### QuickAdd: one command, reusable per note type

**QuickAdd, not Daily Notes.** Daily Notes is deliberately left unconfigured and reserved for
general journaling: it is a single global slot, and spending it on one specific practice would
block the broader use. QuickAdd has no such limit: **one Template choice per note type**, each its
own command.

QuickAdd has `isDesktopOnly: false`, so it runs on the phone. Community plugins sync, so enabling
it on the Mac is enough.

**On the Mac:**

1. Settings → Community plugins → enable **QuickAdd**.
2. Settings → QuickAdd → **Add Choice**, name it `Daily Meditation`, type **Template**.
3. Open that choice's settings (the gear) and set:

| Field | Value |
|---|---|
| Template Path | `Areas/Personal/Meditation Journal/_Daily Meditation Template.md` |
| File Name Format | on → `{{DATE:YYYY-MM-DD}}` |
| Create in folder | on → `Areas/Personal/Meditation Journal` |
| Open | on |
| If the target file already exists | **Do nothing** |

**"Do nothing" is the right duplicate behaviour, and the default `prompt` is not.** From
`main.js`: `{id:"doNothing", description:"Leaves the file unchanged and opens the existing
file.", resolutionKind:"reuseExisting"}`, so a second tap later in the day reopens what was
already written. The alternatives are all wrong for a daily note: *append to bottom/top* stacks a
second blank template onto the answers, *overwrite* erases them, and *increment* / *duplicate
suffix* scatter `YYYY-MM-DD 1.md` files through the folder. Left at the default `prompt`, the
phone shows a six-option menu every time the note already exists.

4. Click the **lightning bolt** next to the choice to expose it as a command.
5. On the phone: Settings → Mobile → add **QuickAdd: Daily Meditation** to the keyboard toolbar,
   or run it from the command palette.
6. **On the Mac: a button link** at the top of the journal's anchor note:
   `obsidian://quickadd?vault=<YOUR_VAULT_NAME>&choice=Daily%20Meditation`,
   the same URI as the iPhone Shortcut (`vault=`, not `vaultName=`, which Obsidian ignores).
   **And a sidebar icon** (`flower-2`, "Today's meditation") from the local Cockpit plugin, which
   runs the choice by its id (`<CHOICE_ID>`); see [[cockpit-plugin]]. **Renaming the choice breaks
   the Shortcut and the button (by name); recreating it breaks the icon (by id).**
   QuickAdd 2.25 registers its own `quickadd` URI handler, so this runs the choice directly. It is a
   different path from the dead `obsidian://new&content=` URI above and does not revive it. A
   bookmark cannot do this: bookmarks point at a fixed file, folder or search.

**A QuickAdd upgrade can silently reset "If the target file already exists" to *prompt*.** The
2.12 → 2.25 upgrade migrates the old setting into `fileExistsBehavior` and can land on
`{"kind": "prompt"}`, so a second tap shows the choice menu again and one wrong tap makes
`YYYY-MM-DD (1).md`. Reset it to `{"kind": "apply", "mode": "doNothing"}` in
`.obsidian/plugins/quickadd/data.json`. **After any QuickAdd update, check this setting first.**

**The template's date tokens work as written.** `{{date:...}}` and `{{time:...}}` are matched
case-insensitively by QuickAdd (`RegExp(/{{DATE:([^}\n\r+]*)...}}/i)` in `main.js` v2.12.3), so
the same file also works with core Templates. No QuickAdd-specific rewrite, and no lock-in.

#### Gotcha: "Template not found" in QuickAdd settings

**QuickAdd's *Template Folder Path* must be empty for co-located templates.** Otherwise a choice
reports `Template not found` for a file that plainly exists.

Cause, from `main.js` v2.12.3:

```js
getTemplateFiles(){ return String.isString(this.settings.templateFolderPath)
  ? this.app.vault.getFiles().filter(I => I.path.startsWith(this.settings.templateFolderPath))
  : [] }
```

and the Template Path field validates with `suggestions.includes(value) || "Template not found"`.
So the field only accepts a path under *Template Folder Path*.

**Empty is the correct value**, because `path.startsWith("")` is true for every file. **This is a
structural consequence of keeping templates co-located** (§ The reusable pattern): the setting is
a single prefix filter, so it can only ever scope *one* folder. Co-location and a non-empty
Template Folder Path are mutually exclusive.

**The warning is not cosmetic: the value is discarded.** A Template Path entered while the
warning shows can be saved to `data.json` and then reset to `templatePath: ""` once the settings
pane is reopened. **Fix *Template Folder Path* before touching *Template Path***, or every path
entered is silently dropped and the field keeps reading empty. There is no error beyond the inline
`Template not found` text, and the choice looks merely unconfigured rather than broken.

#### The reusable pattern

This is the shape to copy for the next note type, not just this one. A second journal uses the
same folder-plus-co-located-template shape, its own QuickAdd choice (for example `freeflow`) and
its own one-action Shortcut. Setup takes minutes once the gotchas below are known.

1. **Template lives next to what it creates**, named `_<Thing> Template.md`, matching
   `Inbox/_Inbox Template.md` and `Areas/People/_Person Template.md`, and the co-location
   convention in [[_system/README|Vault Map]] § Folder conventions. **No central templates folder**:
   QuickAdd takes a file path, so a folder would buy nothing and would break a convention already
   in use in several places.
2. **One QuickAdd Template choice per type**, exposed as a command.
3. **Daily Notes stays free.** It is the one global slot; never spend it on a specific practice.

#### The Apple Shortcut trigger

**QuickAdd registers its own URI handler**, verified in `main.js` v2.12.3:
`registerObsidianProtocolHandler("quickadd", ...)` resolving via `getChoice("name", c.choice)`,
so the choice is addressed **by its name**, exactly as typed in QuickAdd's settings.

The whole Shortcut is one action. **Open URLs**, with:

```
obsidian://quickadd?vault=<YOUR_VAULT_NAME>&choice=Daily%20Meditation
```

**About 70 characters, well under the ~185-200 character ceiling that kills the old approach.**
Nothing is built, encoded, or passed as content, so there is no length question and nothing that
can silently truncate. That is the point: the URL carries an *instruction*, not a *payload*.

**The lookup is by name, and it is case-sensitive.** `getChoice("name", c.choice)` compares with
strict `===`; there is no `toLowerCase()` on that path. An iPhone keyboard can lowercase the name
while the URL is typed in, so the Mac works while the phone returns
`URI could not find any choice named 'daily meditation'`. **`Daily Meditation` and
`daily meditation` are different choices as far as the handler is concerned**, and the error is
identical to the one a missing choice produces, so it reads as a sync failure rather than a typo.

**A one-word lowercase choice name removes the whole class of problem**: no capitals for
autocorrect to change, no `%20` to get wrong. If the choice is ever renamed, the `choice=`
parameter in the Shortcut must be updated to match exactly; nothing warns you.

**Trigger:** a Home Screen icon on the first page, so it is what you see on unlocking the phone.
The Action Button is used by `Add to Inbox` ([[apple-shortcuts-capture]]).

**The "allow to open Obsidian" prompt:** tap **Always Allow**, not Allow Once. It reappears after
every edit to a Shortcut. To change it later: Shortcuts → the shortcut → Details (ⓘ) → Privacy.

**`value-<name>=` parameters can prefill template variables** if a future choice ever needs input
passed from the Shortcut: the handler maps any `value-foo=bar` into QuickAdd's variable `foo`.
Not needed here.

---

## Decisions

### Design decisions

**Template file over plugin-generated content.** Plugin settings do reach the phone (the
vault host's `Configs: none` is not vault-wide; see the warning in § THE SETUP), so that is no
reason to reject a plugin. The template file still wins on simpler grounds: core Templates and
Daily Notes are **already enabled**, need no plugin install on either device, and a template is a
vault file edited in Obsidian like any other note.

**The template is the only copy of the questions that the note ever sees.** The canonical list and
the reasoning stay in the journal's anchor note. **Change the anchor note first, then the template
file.**

**No `status:` property.** [[frontmatter-properties]] reserves `status:` for tasks only. A journal
entry is `type: note`: it needs no triage, which is also why these land in
`Areas/Personal/Meditation Journal/` rather than `Inbox/`.

## History

### Why the URI path is dead

Passing the note body through `obsidian://new&content=` from an iOS Shortcut creates the note,
parses the frontmatter, and silently truncates the body mid-word once the full URL passes roughly
185-200 characters. There is no error anywhere. Escaping `#` as `%23` or adding `Set Variable`
after magic-variable chips does not fix it. Moving the content out of the URL does.

**Standing lessons:**

- **macOS is not a valid test bed for this.** Long, fully escaped URLs deliver complete notes on
  the Mac while failing on iOS.
- **Test against pristine output.** Compare with untouched notes produced by a Shortcut known to
  work before forming theories.
- **Look at the final URL first.** A Quick Look on the URL the Shortcut builds tells you
  immediately whether Shortcuts or Obsidian is dropping content, instead of inferring it from the
  output file.

## See also
- The meditation journal's anchor note: the practice, the questions, why each question exists
- [[apple-shortcuts-capture]]: the capture Shortcut. Long captures hit the same ~200-character total URL limit; it is fixed by passing content via `clipboard=true`
