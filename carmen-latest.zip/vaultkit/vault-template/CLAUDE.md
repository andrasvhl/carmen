# Vault rules (always loaded)

This vault is the owner's primary context layer. This file auto-loads in every Claude Code
session launched from this folder or below, and survives `/compact`. Keep it short: everything
here is paid for in every session.

**Where to look:** [[Claude Master Router]] routes by what you are touching or doing. Read it
before any non-trivial vault work if it is not already in context. Facts about the owner route
through [[Areas/Master Profile]].

**Paths used below.** The vault root is the folder holding this file. `vt` means the kit's
command-line tool, `~/automation/bin/vt` (adjust if it was installed elsewhere; see
`SETUP-NOTES.md`).

---

## Always true

Eight rules that bind in every session. Nothing in a session would trigger a lookup for them,
which is why they live here rather than in the router.

- **Answer from the vault first, and do not stop at the first miss.** For what the owner knows,
  thinks, prefers or has decided: `Wiki/index.md` and the articles it points to (if the wiki is
  set up), then [[Areas/Master Profile]], then [[Areas/North Star]], then the
  [[_system/README|Vault Map]], then grep the vault, then the web. For plans, dates and what
  someone said: check whatever calendar and mail connectors are available before saying "not
  found". **Say you are checking before you check.** Log a wiki miss in `Wiki/log.md`. `Wiki/`
  is derived, never hand-edited: corrections go to the source note, then a re-ingest
  ([[_system/schema|schema]]). Why: the vault holds context Claude cannot guess, and an answer
  from general knowledge that contradicts a note the owner wrote is worse than no answer.

- **Dates are either fresh or a question.** If a note's `verified:` or `revisit:` date has
  passed, say so in one line and ask. Never plan against it silently. Shelf lives are in
  [[_system/profile-convention|profile-convention]]. Why: a stale fact read as current is worse
  than a missing one, because nothing signals that it is stale.

- **When the owner states a durable fact about themselves, record it.** Do not wait to be asked.
  Most facts arrive as asides during unrelated work, and that is the cheapest moment they will
  ever be recorded. Route by fact type through [[Areas/Master Profile|Master Profile]]; the test
  is in [[_system/profile-convention|profile-convention]] § When to write a fact down. **Write
  it, then say what was recorded in one line, and keep working.** Do not stop to ask for each
  fact.

  **Three exceptions where you ask first:** anything about a third party's health, finances or
  relationships; and **any overwrite of a value already recorded**: a new fact replacing an old
  one is where a misheard detail does real damage, so name both values and let the owner
  confirm. **Never record a password, PIN, 2FA seed or recovery code**, at any tier, ever.

- **Link vault files with Obsidian's URI scheme**, never a relative markdown path, which has
  nothing to resolve against in a chat window:
  ```
  [Note Title](obsidian://open?vault=<VaultName>&file=Path%2FTo%2FNote)
  ```
  `<VaultName>` is the name of this vault's folder. Vault name and file path both URL-encoded;
  omit the `.md`. Inside notes, ordinary `[[wikilinks]]` are fine.

- **Never invent a frontmatter property** without checking
  [[_system/frontmatter-properties|frontmatter-properties]] first. Obsidian accepts any key
  silently, so that page is the only thing stopping two systems from claiming one name. Two
  rules are vault-wide: **`status:` is for tasks only** and documents use **`stage:`**; new
  properties are `snake_case`.

- **Never move or rename a vault file with `mv`. Use `vt move <old> <new>`**, which rewrites
  every inbound wikilink, backticked path and folder reference. Obsidian repairs links only for
  moves made inside Obsidian, so every agent or shell move silently breaks references. Use
  `--dry-run` first if the move is large. Where things belong when archiving:
  [[_system/README|Vault Map]] § Folder conventions.

- **Every task opens with its next action, as a checkbox.** Creating or editing a task in
  `Inbox/`, with or without a skill: `## Next action` / `- [ ] Next: <physical step>` directly
  under the frontmatter. A task without a clear next step is not well defined, unless it is
  waiting (`- [ ] Waiting: <who>, <on what>`). Create tasks with `vt todos --add`, which writes
  this for you. Rule and reasoning: [[_system/SYSTEM|SYSTEM]] § Capture note schema.

- **Anything that runs unattended** (a script, a scheduled job, an automation) has to work with
  the laptop closed or powered off. If it only runs while the laptop is open, it is not
  unattended, it is a reminder to do something by hand. Decide where it runs before building
  it, not after: normally the always-on server from the kit, which has its own copy of the
  vault, or a cloud scheduler.

**Optional, only if you connect a WhatsApp reader:** never keyword-filter a WhatsApp read. Scope
it by time window and chat, then judge what matters. Keyword filters silently drop the messages
that matter most, because those rarely use the word you searched for.

---

## Before writing to Claude's own auto-memory

1. **Search the vault first for an existing home:** [[Claude Master Router]], project notes,
   `_system/`.
2. **Behavioural feedback about how Claude should work is not automatically memory territory.**
   If it is vault-specific it belongs in the vault, at the right level:
   - Vault-wide and binding every session → **this file**, § Always true
   - Routing, "where do I find X" → [[Claude Master Router]]
   - Productivity stack (capture, Inbox, task schema, cockpit) →
     [[_system/SYSTEM|SYSTEM]] § How Claude operates
   - A fact or plan rather than Claude behaviour → the relevant project or profile note
3. **Claude's own memory is right only for what is genuinely vault-agnostic** (true no matter
   which project or folder Claude is in).

Why: memory written outside the vault is invisible when the owner reads their own notes, and
it silently diverges between machines.

---

**Backlink:** cross-project Claude behaviour that is not vault-specific (communication style,
confirm-before-big-moves, who the owner is) lives in
[[_system/claude/global-CLAUDE|global-CLAUDE]], copied to `~/.claude/CLAUDE.md`.
