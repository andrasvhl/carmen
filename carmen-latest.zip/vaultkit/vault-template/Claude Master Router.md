# Claude Master Router

**Entry point for how Claude should navigate this vault.** Route from here; do not re-derive
detail in this file. Keep it a lookup table: pointers only, current state only. Every word here
is read often, so it should never hold explanations that belong in a component doc.

**To find where anything is, read the [[_system/README|Vault Map]].** It lists every folder and
every `_system/` doc with what it holds, plus the conventions for where new things go. This file
routes by task; the Map shows location.

**Where a rule belongs.** Apply this before adding anything here:

| The rule... | goes in |
|---|---|
| binds even when nobody looks it up | `CLAUDE.md` at the vault root (auto-loads) |
| tells you where to look | this file |
| explains how something works, or why | the component doc that owns it |
| describes what is inside another index | nowhere. Point at it, never summarise it |
| records a decision and its date | the owning doc's `## Decisions` or `## History` |

---

## Route by what you're touching

- **Productivity stack** (capture, Inbox, task schema, cockpit) → [[_system/SYSTEM|SYSTEM]]
- **Creating or editing any task, with or without a skill** → create it with
  `~/automation/bin/vt todos --add` (writes the schema for you), and keep a `## Next action`
  block with a `- [ ]` checkbox directly under the frontmatter. Rule:
  [[_system/SYSTEM|SYSTEM]] § Capture note schema.
- **What actually matters right now** (priorities, the not-doing list, tie-breaks) →
  [[Areas/North Star|North Star]]. **Read before enriching, prioritising or planning a day.**
- **Any durable fact about the owner** (identity, health, money, career, taste, a named person)
  → [[Areas/Master Profile|Master Profile]]. It routes by fact type; this file routes by work
  type.
- **What the owner knows, thinks, has concluded or has a practice for** →
  `Wiki/index.md`, the catalog of the compiled wiki, read whole first. `CLAUDE.md` § Always true
  makes it the first read; this row is only the pointer.
- **When work can be placed** (capacity, working hours, calendars) →
  [[_system/working-conditions|working-conditions]]. Read before proposing any day plan.
- **Any calendar question** ("what's on today", "am I free") → query **every** calendar in
  [[_system/working-conditions|working-conditions]] § Calendar roster, never only the primary.
- **The daily loop** (dump, commit, prioritise, schedule) and why it is four steps →
  [[_system/daily-loop|daily-loop]]
- **Course material from Canvas** (what a class covered, a slide deck, a reading, an assignment)
  → the course archive (optional canvas module); how it is built and refreshed →
  [[_system/canvas-archive|canvas-archive]], skill `canvas-archive`. Never hand-edit a note in it.
- **What's where: any file, folder or `_system/` doc** → [[_system/README|Vault Map]]

## Route by what you're doing

- **Writing frontmatter, or reaching for a new property** →
  [[_system/frontmatter-properties|frontmatter-properties]]. Never invent a key without checking.
- **Changing the owner's global Claude instructions** → [[_system/claude/README|_system/claude]].
  Edit the master copy in the vault, never `~/.claude/CLAUDE.md` directly.
- **Writing or editing a skill** → [[_system/skills/README|skills conventions]]
- **Ingesting notes into the wiki, re-ingesting, or linting it** → skill `wiki`; rules in
  [[_system/schema|schema]]. Never hand-edit a `Wiki/` page.
- **Creating or editing a profile note** → [[_system/profile-convention|profile-convention]] and
  [[_system/_profile-template|_profile-template]]
- **Creating a folder or project anchor** → [[_system/README|Vault Map]] § Folder conventions
- **Writing or editing anything in `_system/`** → [[_system/_component-doc-template|_component-doc-template]]
  first. Edits are where docs drift. `~/automation/bin/vt docs` checks a doc against it.
- **Moving or renaming any file** → `~/automation/bin/vt move <old> <new>`, never `mv`
  (`CLAUDE.md` § Always true).
- **Building anything that runs unattended** → it must work with the laptop off
  (`CLAUDE.md` § Always true).

---

**Backlink:** vault-wide rules that must bind every session live in `CLAUDE.md` at the vault
root. Cross-project Claude behaviour lives in [[_system/claude/global-CLAUDE|global-CLAUDE]],
copied to `~/.claude/CLAUDE.md`.
