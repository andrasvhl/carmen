const {
  Plugin,
  Notice,
  TFile,
  Platform,
  MarkdownView,
  PluginSettingTab,
  Setting,
} = require("obsidian");

// Claude Task Launcher: a "Work in Claude" button in the title bar of every
// note whose frontmatter `type` is in the launchable list.
//
// What it runs: nothing by itself. It never executes a shell command and never
// sends a prompt.
//   - Desktop, mode "desktop": opens the deep link
//       claude://code/new?q=<prompt>&folder=<this vault's folder>
//     which the Claude Desktop app handles: a new Code session with the vault as
//     working folder (Desktop asks you to confirm the folder) and the prompt
//     pre-filled in the composer, NOT sent. The folder is read from Obsidian
//     (the vault's own path), never hardcoded.
//   - Mobile, or mode "clipboard": copies the prompt to the clipboard.
//
// No network access of its own. Settings live in data.json in this folder.

const DEFAULT_SETTINGS = {
  launchableTypes: "action, learning",
  mode: "desktop", // "desktop" | "clipboard"
  promptIntro: "Help with this {kind} from the vault.",
  maxPromptChars: 4800,
};

module.exports = class ClaudeTaskLauncherPlugin extends Plugin {
  async onload() {
    this.actionEls = new WeakMap();
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.addSettingTab(new LauncherSettingTab(this.app, this));

    this.registerEvent(
      this.app.workspace.on("active-leaf-change", (leaf) => this.refreshAction(leaf))
    );
    this.registerEvent(
      this.app.metadataCache.on("changed", (file) => {
        const view = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (view && view.file === file) this.refreshAction(view.leaf);
      })
    );
    this.app.workspace.onLayoutReady(() => {
      const view = this.app.workspace.getActiveViewOfType(MarkdownView);
      if (view) this.refreshAction(view.leaf);
    });

    this.addCommand({
      id: "start-claude-code-on-note",
      name: "Work in Claude",
      callback: () => this.launch(),
    });
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  launchableTypes() {
    return new Set(
      String(this.settings.launchableTypes || "")
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
    );
  }

  noteType(file) {
    const fm = this.app.metadataCache.getFileCache(file)?.frontmatter;
    return fm ? fm.type : undefined;
  }

  refreshAction(leaf) {
    const view = leaf?.view;
    if (!(view instanceof MarkdownView) || !view.file) return;

    const existing = this.actionEls.get(view);
    if (existing) {
      existing.remove();
      this.actionEls.delete(view);
    }

    if (this.launchableTypes().has(this.noteType(view.file))) {
      const el = view.addAction("bot", "Work in Claude", () => this.launch(view.file));
      this.actionEls.set(view, el);
    }
  }

  buildPrompt(file, noteType, body) {
    const kind = noteType === "action" ? "task" : `${noteType} note`;
    const intro = String(this.settings.promptIntro || DEFAULT_SETTINGS.promptIntro)
      .split("{kind}")
      .join(kind);
    return [intro, "", `File: ${file.path}`, `Title: ${file.basename}`, "", body].join("\n");
  }

  async launch(explicitFile) {
    const file = explicitFile ?? this.app.workspace.getActiveFile();
    if (!(file instanceof TFile)) {
      new Notice("Claude Task Launcher: no active note.");
      return;
    }

    const noteType = this.noteType(file);
    if (!this.launchableTypes().has(noteType)) {
      new Notice(
        `Claude Task Launcher: "${file.basename}" has type "${noteType ?? ""}", ` +
          "which is not in the launchable types (Settings → Claude Task Launcher)."
      );
      return;
    }

    const raw = await this.app.vault.read(file);
    const body = raw.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, "").trim();
    let prompt = this.buildPrompt(file, noteType, body);

    const max = Math.max(500, Number(this.settings.maxPromptChars) || DEFAULT_SETTINGS.maxPromptChars);
    let truncated = false;
    if (prompt.length > max) {
      prompt = prompt.slice(0, max);
      truncated = true;
    }
    const cut = truncated ? ` (prompt truncated to ${max} characters)` : "";

    const basePath = this.app.vault.adapter.basePath; // desktop only
    if (Platform.isDesktopApp && this.settings.mode !== "clipboard" && basePath) {
      const uri =
        `claude://code/new?q=${encodeURIComponent(prompt)}` +
        `&folder=${encodeURIComponent(basePath)}`;
      try {
        require("electron").shell.openExternal(uri);
      } catch (e) {
        window.open(uri);
      }
      new Notice(`Opening Claude Desktop…${cut}`);
      return;
    }

    try {
      await navigator.clipboard.writeText(prompt);
      new Notice(
        `Task copied${cut}. Paste it into a Claude Code session working in this vault.`
      );
    } catch (e) {
      console.error("Claude Task Launcher: clipboard write failed", e);
      new Notice("Claude Task Launcher: could not copy to the clipboard. See the console.");
    }
  }
};

class LauncherSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    const s = this.plugin.settings;
    const save = () => this.plugin.saveSettings();

    new Setting(containerEl)
      .setName("Launchable note types")
      .setDesc("Comma-separated values of the frontmatter `type` property that get the button.")
      .addText((t) =>
        t.setPlaceholder(DEFAULT_SETTINGS.launchableTypes).setValue(s.launchableTypes).onChange(async (v) => {
          s.launchableTypes = v;
          await save();
        })
      );

    new Setting(containerEl)
      .setName("Desktop action")
      .setDesc(
        "Claude Desktop: opens a new Code session in this vault with the prompt pre-filled, unsent " +
          "(needs the Claude Desktop app). Clipboard: only copies the prompt. Mobile always copies."
      )
      .addDropdown((d) =>
        d
          .addOption("desktop", "Open in Claude Desktop")
          .addOption("clipboard", "Copy to clipboard")
          .setValue(s.mode)
          .onChange(async (v) => {
            s.mode = v;
            await save();
          })
      );

    new Setting(containerEl)
      .setName("Prompt intro")
      .setDesc("First line of the prompt. {kind} becomes 'task' or '<type> note'. File path, title and body follow.")
      .addText((t) =>
        t.setPlaceholder(DEFAULT_SETTINGS.promptIntro).setValue(s.promptIntro).onChange(async (v) => {
          s.promptIntro = v;
          await save();
        })
      );

    new Setting(containerEl)
      .setName("Maximum prompt length")
      .setDesc("Characters. Longer prompts are cut, with a notice. Keeps the link within URL limits.")
      .addText((t) =>
        t.setPlaceholder(String(DEFAULT_SETTINGS.maxPromptChars)).setValue(String(s.maxPromptChars)).onChange(async (v) => {
          const n = parseInt(v, 10);
          if (!Number.isNaN(n)) {
            s.maxPromptChars = n;
            await save();
          }
        })
      );
  }
}
