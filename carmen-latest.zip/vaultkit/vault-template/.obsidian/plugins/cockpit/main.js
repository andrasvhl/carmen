const { Plugin, Notice, PluginSettingTab, Setting } = require("obsidian");

// Cockpit: a one-click review layout over the main area.
//
//   ribbon click  -> main area becomes the Cockpit split:
//                    [ top-left view | top-right view ]
//                    [        bottom view            ]
//   click a note  -> previous main layout is restored, the note opens full-page
//   ribbon again  -> back out of Cockpit manually
//
// It never touches the sidebars or the ribbon, so nothing customised there can
// be clobbered (Obsidian's Workspaces core plugin restores ribbon state too,
// which is why this is a plugin and not a saved workspace).
//
// No network access, no shell commands, no files written. The only state it
// keeps on disk is its own settings (data.json in this folder).

const DEFAULT_SETTINGS = {
  baseFile: "ToDo.base",
  topLeftView: "Today",
  topRightView: "Waiting", // leave empty for a single pane on top
  bottomView: "As scheduled", // leave empty for no bottom pane
};

module.exports = class CockpitPlugin extends Plugin {
  async onload() {
    this.active = false;
    this.busy = false;
    this.savedMain = null;

    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.addSettingTab(new CockpitSettingTab(this.app, this));

    this.addRibbonIcon("layout-dashboard", "Cockpit", () => this.toggle());

    this.addCommand({
      id: "toggle",
      name: "Toggle Cockpit",
      callback: () => this.toggle(),
    });

    this.addCommand({
      id: "close",
      name: "Close Cockpit",
      callback: () => this.exit(null),
    });

    // Leaving Cockpit is driven by navigation: the moment a file takes over
    // one of the panes, restore the previous layout and reopen it at full size.
    this.registerEvent(
      this.app.workspace.on("file-open", (file) => this.onFileOpen(file))
    );
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  views() {
    const s = this.settings;
    return [s.topLeftView, s.topRightView, s.bottomView]
      .map((v) => (v || "").trim())
      .filter(Boolean);
  }

  findLeaf(viewName) {
    const baseFile = this.settings.baseFile;
    return this.app.workspace.getLeavesOfType("bases").find((leaf) => {
      const state = leaf.getViewState().state || {};
      return state.file === baseFile && state.viewName === viewName;
    });
  }

  allPanesPresent() {
    return this.views().every((v) => Boolean(this.findLeaf(v)));
  }

  async toggle() {
    if (this.busy) return;
    if (this.active) return this.exit(null);
    return this.enter();
  }

  async enter() {
    const baseFile = this.settings.baseFile;
    if (!this.app.vault.getAbstractFileByPath(baseFile)) {
      new Notice(`Cockpit: cannot find ${baseFile}. Check Settings → Cockpit.`);
      return;
    }
    if (!(this.settings.topLeftView || "").trim()) {
      new Notice("Cockpit: no top-left view set. Check Settings → Cockpit.");
      return;
    }

    this.busy = true;
    try {
      // Remember only the main area. Sidebars and ribbon are left alone.
      this.savedMain = this.app.workspace.getLayout().main;

      const layout = this.app.workspace.getLayout();
      layout.main = this.buildMain();
      await this.app.workspace.changeLayout(layout);

      this.active = true;
    } catch (err) {
      console.error("Cockpit: failed to enter", err);
      new Notice("Cockpit could not build the layout. See the developer console.");
      this.savedMain = null;
    } finally {
      this.busy = false;
    }
  }

  // Mirrors the structure Obsidian itself writes for split panes. The "bases"
  // view type and its {file, viewName} state are read off workspace.json, not
  // public API: if a future Obsidian renames them, the panes open empty.
  buildMain() {
    const s = this.settings;
    const baseFile = s.baseFile;
    const id = () => Math.random().toString(16).slice(2, 18);
    const pane = (viewName) => ({
      id: id(),
      type: "tabs",
      children: [
        {
          id: id(),
          type: "leaf",
          state: {
            type: "bases",
            state: { file: baseFile, viewName },
          },
        },
      ],
    });

    const topLeft = s.topLeftView.trim();
    const topRight = (s.topRightView || "").trim();
    const bottom = (s.bottomView || "").trim();

    const top = topRight
      ? {
          id: id(),
          type: "split",
          direction: "vertical",
          children: [pane(topLeft), pane(topRight)],
        }
      : pane(topLeft);

    const rows = bottom ? [top, pane(bottom)] : [top];

    return {
      id: id(),
      type: "split",
      direction: "vertical",
      children: [
        {
          id: id(),
          type: "split",
          direction: "horizontal",
          children: rows,
        },
      ],
    };
  }

  onFileOpen(file) {
    if (!this.active || this.busy) return;
    // All panes intact means the file opened somewhere else. Leave us alone.
    if (this.allPanesPresent()) return;
    this.exit(file);
  }

  async exit(reopenFile) {
    if (this.busy) return;
    this.busy = true;

    try {
      if (this.savedMain) {
        const layout = this.app.workspace.getLayout();
        layout.main = this.savedMain;
        await this.app.workspace.changeLayout(layout);
      } else {
        // No snapshot to go back to: just clear the panes.
        for (const name of this.views()) {
          const leaf = this.findLeaf(name);
          if (leaf) leaf.detach();
        }
      }

      if (reopenFile) {
        await this.app.workspace.getLeaf(true).openFile(reopenFile);
      }
    } catch (err) {
      console.error("Cockpit: failed to exit", err);
    } finally {
      this.savedMain = null;
      this.active = false;
      this.busy = false;
    }
  }
};

class CockpitSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("p", {
      text:
        "View names must match the view names inside the base file exactly. " +
        "Changes apply the next time you open the Cockpit.",
    });

    const text = (name, desc, key) =>
      new Setting(containerEl)
        .setName(name)
        .setDesc(desc)
        .addText((t) =>
          t
            .setPlaceholder(DEFAULT_SETTINGS[key])
            .setValue(this.plugin.settings[key])
            .onChange(async (value) => {
              this.plugin.settings[key] = value.trim();
              await this.plugin.saveSettings();
            })
        );

    text("Base file", "Vault-relative path of the base, including .base.", "baseFile");
    text("Top-left view", "Required.", "topLeftView");
    text("Top-right view", "Optional. Empty means one pane across the top.", "topRightView");
    text("Bottom view", "Optional. Empty means no bottom pane.", "bottomView");
  }
}
