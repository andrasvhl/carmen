"""tasks: see _system/checkin-app.md § Code layout."""
