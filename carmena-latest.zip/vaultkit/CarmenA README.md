# CarmenA

How the author actually uses Carmen day to day, anonymized: the skills and guides on top of
the platform. This is an add-on, not a kit of its own.

## Install

1. **Install Carmen first** (`carmen-latest.zip`) and finish its setup with Claude.
2. Unzip this file in the folder that holds your `vaultkit` folder (usually your home folder),
   so its `vaultkit/` merges into yours. Say yes when asked to merge folders. It adds files and
   never replaces Carmen's.
3. The new files land in `vaultkit/vault-template/`. Your vault already exists, so open
   `vaultkit` in Claude Code and ask it to copy the CarmenA skills and guides you want into your
   vault and set them up. Pick only what you will use.

## What is inside, and what each piece needs

| Piece | What it does | Needs |
|---|---|---|
| Travel (skill, guide, playbook, price sources, airports template) | Door-to-door trip planning at the lowest sensible cost, and a price watch that pushes deals | The server and push alerts from Carmen; fill in the airports template for your own bases |
| Coffee chat | Books 1:1 coffee chats: finds a slot in both calendars and drafts the message | Calendar and email modules; your people notes |
| Freetime | Finds when most of a group is free | Calendar and WhatsApp modules |
| Send to Kindle (skill and guide) | Emails readings and files to your Kindle | Email module; your Kindle address |
| Send to Speechify (skill and guide) | Uploads readings to Speechify to listen on the phone | A Speechify account, Claude in Chrome |
| Video transcribe | Transcribes videos and audio offline into your notes | A Mac (Apple silicon recommended) and the transcription module |
| Routine push | Morning and evening routine reminders, text read from your notes | Push alerts (Pushover) and the server |
| Build backlog | Collects build ideas all week and plans one weekly build block | Capture and the server |
| Signal definition | Rules for deciding what in your inbound mail and chats matters | Nothing extra; read by your own passes |

Every file is optional. Skip what you do not use.

Shared for educational purposes only, provided as is, with no warranty of any kind. The same
terms as Carmen apply.
