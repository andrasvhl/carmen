# Setup notes

One-time steps to make this vault work with Claude Code. Your Claude runs most of them with
you, in two parts of the kit's walkthrough: sections 1 to 3 in the obsidian-sync module (before
Sync is connected), sections 4 to 7 right after the automation-runner module. Delete this file
when you are done (and remove it from the Vault Map's root list).

## 1. The vault on your Mac, and today's date

**No vault yet:** this folder becomes your vault. Copy it to where you keep vaults (for example
`~/Obsidian/<Your Vault Name>`), then in Obsidian choose **Open folder as vault**. The folder
name is your vault name: it appears in `obsidian://` links, and must match `VK_VAULT_NAME` in
the kit's `config.env`.

**You already have a vault:** do not copy this folder over it. Your Claude shows you which of
these files your vault does not have yet, and copies only those, with your yes. Nothing you
already have is overwritten.

Set `VAULT_PATH` for the commands below (in the Terminal, or add it to `~/.zshrc`):

```bash
export VAULT_PATH="$HOME/Obsidian/<Your Vault Name>"
```

**Fill in the install date.** The system notes carry `verified: <INSTALL-DATE>` (and
`captured: <INSTALL-DATE>T...`) because the date someone last checked them is today, not the
day the kit was written. Replace the placeholder with today's date, and set the working
conditions note's first review to four weeks from now:

```bash
D=$(date +%F); R=$(date -v+4w +%F)
grep -rlF --include='*.md' '<INSTALL-DATE>' "$VAULT_PATH" | while IFS= read -r f; do
  sed -i '' "s/<INSTALL-DATE>/$D/g; s/<REVISIT-DATE>/$R/g" "$f"
done
grep -rlF --include='*.md' -e '<INSTALL-DATE>' -e '<REVISIT-DATE>' "$VAULT_PATH" || echo "all dates filled"
```

(`date -v+4w` and `sed -i ''` are the Mac's forms.) The three dates in `Areas/North Star.md`
stay as `<YYYY-MM-DD>` until you write your North Star (section 7): they belong to your plan,
not to the install.

## 2. Core plugin: Bases

**Settings → Core plugins → Bases: on.** `ToDo.base` and `Inbox/Inbox.base` need it.

## 3. Community plugins

**Settings → Community plugins → Turn on community plugins** (this switches Restricted mode off;
Obsidian asks you to confirm). Two kinds of plugin are involved:

**Already in the vault, nothing to install.** Two small local plugins ship in
`.obsidian/plugins/`. They load as soon as community plugins are on:

| Plugin | Why | Doc |
|---|---|---|
| **Cockpit** | A ribbon button (dashboard icon) that lays out Today, Waiting and As scheduled from `ToDo.base` in one click | `_system/cockpit-plugin.md` |
| **Claude Task Launcher** | A "Work in Claude" button on every task note: opens Claude Desktop's Code tab in this vault with the task pre-filled, unsent (on the phone: copies it) | `_system/claude-task-launcher-plugin.md` |

Neither connects to the internet or runs commands. The launcher's desktop button needs the
**Claude Desktop** app installed; without it, set Settings → Claude Task Launcher → Desktop
action to "Copy to clipboard". Either can be switched off in Settings → Community plugins.

**From the store.** Click **Browse**, then install and enable:

| Plugin | Author | Why | Needed? |
|---|---|---|---|
| **TaskNotes** | Callum Alpass | Renders `ToDo.base` as a drag-reorderable task list and edits task properties inline | Yes |
| **Folder notes** | Lost Paul | Clicking a project folder opens its anchor note (`Projects/X/X.md`) | Recommended |
| **Flexplorer** | kh4f | Manual file ordering and pinning in the file explorer, so you never rename files to sort them | Optional |

`.obsidian/community-plugins.json` lists all five, so Obsidian enables each one once it is
present. Installing from the store adds the plugin's code next to the settings file already in
its folder; it does not replace the settings.

**TaskNotes and Folder notes come pre-configured** (`data.json` in their plugin folders). Check
in Settings → TaskNotes after installing that these took:

- **Task identification:** by property, property name `type`, value `action`. This makes
  TaskNotes read the notes already in `Inbox/`.
- **Task storage → Default folder:** exactly `Inbox`. If you ever change it, clear the field
  fully before typing: it can append rather than replace.
- **Priority values:** `1-none`, `2-low`, `3-normal`, `4-high`. **Status values:** `inbox`,
  `open`, `in-progress`, `done`.
- **General → View commands:** "Open tasks view" points at `ToDo.base`, the others at
  `TaskNotes/Views/`. **Never press "Create files" or "Update files"** there: they overwrite the
  target `.base` with defaults and cannot be undone. Copy `ToDo.base` somewhere safe before
  touching that panel, and always type paths with `.base` at the end.
- **Task defaults → Default scheduled date** is "today": a task created in TaskNotes' own dialog
  lands in `ToDo` straight away. Set it to none if you would rather every task wait for
  scheduling.

If TaskNotes shows its default settings instead (an empty status list, tasks identified by tag),
the shipped `data.json` was not picked up: set the values above by hand in its settings screen.
After that, change TaskNotes only through its settings screen, never by editing `data.json`.

**You already had a vault with some of these plugins:** your own settings and your own
`community-plugins.json` were kept (only missing files were copied). Enable Cockpit and Claude
Task Launcher by hand in Settings → Community plugins, and compare your TaskNotes settings with
the list above.

**If you use Obsidian Sync:** Settings → Sync → turn on both "Active community plugin list" and
"Installed community plugins", on your main computer first, then on your phone. Otherwise each
device keeps its own plugin settings and they drift, and the two local plugins never reach the
phone.

How all of this fits together: `_system/task-cockpit.md`.

## 4. The kit's command-line tool (`vt`)

The skills call `~/automation/bin/vt` (`vt todos`, `vt move`, `vt docs`), from the kit's
`code/automation` folder. It lives at `~/automation` on the server and, as a second copy, on
this Mac: the kit's automation-runner module (step 8) clones it there. If you put it somewhere
else, either symlink it to `~/automation` or replace the path in `CLAUDE.md`,
`Claude Master Router.md` and the skill files. `vt` finds the vault through `VAULT_PATH` from the
environment, else from `~/.config/vaultkit/config.env` (on the Mac a two-line file with this
vault's path, written in that same step). Check it works:

```bash
~/automation/bin/vt todos
```

You should see the example task under ToDo or Unscheduled.

## 5. Link the skills into Claude Code

Skills live in the vault (so they sync and are backed up) and are symlinked to where Claude Code
looks for them:

```bash
mkdir -p ~/.claude/skills ~/.claude/commands
for s in dump commit-to-action prioritise schedule-work obsidian-todo wiki; do
  ln -s "$VAULT_PATH/_system/skills/$s" ~/.claude/skills/$s
done
ln -s "$VAULT_PATH/_system/claude/commands/otodos.md" ~/.claude/commands/otodos.md
# Optional, only if you installed the kit's canvas module (modules/canvas/README.md):
# ln -s "$VAULT_PATH/_system/skills/canvas-archive" ~/.claude/skills/canvas-archive
```

The general form, for any skill you add later:

```bash
ln -s "$VAULT_PATH/_system/skills/<name>" ~/.claude/skills/<name>
```

If a skill with the same name already exists in `~/.claude/skills/`, `ln` refuses: look at the
existing one before replacing it. Repeat this step on every machine that runs Claude Code
(including the server, where the vault path is usually `~/vault`).

## 6. Your global instructions

**The rule for this whole section: nothing in `~/.claude/` changes without you seeing the exact
change first.** Your Claude shows the diff, backs the file up (`cp FILE FILE.bak-$(date +%F)`),
and waits for your yes. This applies to `~/.claude/CLAUDE.md` and to `~/.claude/settings.json`.

1. Open `_system/claude/global-CLAUDE.md` and fill in the **About me** section. Replace
   `<VAULT_PATH>` with your real vault path.
2. Put it into place:
   - **No `~/.claude/CLAUDE.md` yet:** your Claude says so, and copies it after your yes:
     ```bash
     test -e ~/.claude/CLAUDE.md || cp "$VAULT_PATH/_system/claude/global-CLAUDE.md" ~/.claude/CLAUDE.md
     ```
   - **`~/.claude/CLAUDE.md` exists:** never overwrite it. Your Claude shows
     `diff ~/.claude/CLAUDE.md "$VAULT_PATH/_system/claude/global-CLAUDE.md"`, proposes a merge
     (usually: add the kit's lines to yours), shows the merged result as a diff, and writes it
     only after your yes. Then put the merged text into `global-CLAUDE.md` too, so the master
     and the copy agree before step 3.
3. Optional: keep the copy in step automatically with a SessionStart hook in
   `~/.claude/settings.json` (copies the master over the local file whenever they differ). It
   **overwrites** `~/.claude/CLAUDE.md` at every session start, so add it only once the two
   files are identical (step 2), and only after your Claude has shown you the change to
   `settings.json` as a diff, merged into the hooks you already have rather than replacing
   them:
   ```json
   "hooks": {
     "SessionStart": [{ "hooks": [{ "type": "command", "timeout": 10,
       "command": "S=\"$VAULT_PATH/_system/claude/global-CLAUDE.md\"; [ -s \"$S\" ] && ! cmp -s \"$S\" \"$HOME/.claude/CLAUDE.md\" && cp \"$S\" \"$HOME/.claude/CLAUDE.md\"; true" }] }]
   }
   ```
   Replace `$VAULT_PATH` with the full path if the variable is not set for Claude Code.
4. Optional: check `_system/` docs after every edit with a PostToolUse hook (same rule: diff
   shown, merged into your existing hooks, your yes first):
   ```json
   "PostToolUse": [{ "matcher": "Edit|Write|MultiEdit", "hooks": [{ "type": "command",
     "command": "~/automation/bin/vt docs --hook", "timeout": 30 }] }]
   ```

## 7. First runs

- Open Claude Code in the vault folder and say **"dump"**. Then **"commit to action"**.
- Fill in `Areas/North Star.md` (a rough v1 is the goal, including its three dates) before your
  first **"prioritise"**.
- Your first **"schedule my week"** fills in `_system/working-conditions.md` as it goes. It works
  best with a calendar connector, but runs without one.
- Delete the example task in `Inbox/` once you have real ones.
