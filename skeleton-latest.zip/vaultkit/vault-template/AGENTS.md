# Your vault

**Codex: read `CLAUDE.md` in this folder. It is the real file, and it applies to you
unchanged.** Then read `Claude Master Router.md`, which routes by what you are touching or
doing, before any non-trivial vault work.

Nothing vault-specific lives in this file. It exists only so that a Codex session launched from
this folder is pointed at the instructions rather than left without any.

---

## Why this is a pointer and not a copy

A copy of `CLAUDE.md` made for Codex drifts, because nothing keeps the two in step: links to
notes that do not exist appear, paths go wrong (the Codex folder is `~/.codex/`, lower case), and
every edit to `CLAUDE.md` silently desynchronises the copy without any check comparing them.

A fork is only worth its maintenance if the two sides genuinely need to differ. Here they do
not: the rules are about the vault, not about which model is reading them, so sharing one
instruction file is the more consistent arrangement.

**If Codex ever does need a rule Claude must not follow, put it here under a clear heading**,
and add a check, because that is the moment this file starts being able to rot again.

---

**Backlink:** cross-project behaviour that is not vault-specific (communication style,
confirm-before-big-moves, who you are professionally) lives in `~/.claude/CLAUDE.md`
(Claude) and `~/.codex/AGENTS.md` (Codex).
