---
type: reference
component: raycast-capture
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Obsidian Inbox: Raycast extension (desktop capture)

**Status:** installed. The form mirrors the phone Shortcut (Name, Description, Type dropdown, Build backlog, Best Year). Referenced from
`SYSTEM.md` § Components.

A single global hotkey opens a clean form (no results list): Name, Description (optional) and
a Type dropdown, the same steps as the phone Shortcut. On submit it
writes straight into the Obsidian vault, even when Obsidian is closed.

## What it's for

The desktop half of capture. Capture has to be flawless (north-star priority 1), and it has to
work without Obsidian running. The mobile counterpart is [[apple-shortcuts-capture]].

## How it works

Every capture writes one typed note into `Inbox/` (the single database). **The form mirrors
the phone Shortcut as closely as a form allows**, so both paths write
byte-identical notes; change one, change the other ([[apple-shortcuts-capture]]):

1. **Name** (single line, focused on open) and **Description (optional)** (multiline).
2. **Type**, one dropdown with the Shortcut's six options in its order. Default Action.

   | Type | `type` | Frontmatter lines | Body prefix |
   |---|---|---|---|
   | Action | `action` | `priority: 1-none` | none |
   | Learning | `learning` | `priority: 1-none` | none |
   | Red Notebook | `learning` | `priority: 1-none` | `#coreLearning` + blank line |
   | Urgent | `action` | `urgent: true`, `priority: 4-high`, `scheduled: <today>` | none |
   | Build backlog | `idea` | `priority: 3-normal` or `4-high`, never a date | `#build` + blank line |
   | Best Year | `learning` | `priority: 1-none` | `#bestYear` + blank line |

3. **Priority** (Normal / High) appears only for Build backlog, and the Description hint switches
   to a nudge to describe the idea ([[build-backlog]]).

**Body:** the full Name, a blank line, then the Description; the Name alone if there is none.
**Filename:** the Name with `\ / : # ^ [ ] |` replaced by `-`, cut to 60 characters, the
Shortcut's rule. A clash gets ` 1`, ` 2`, as Obsidian does for the Shortcut. No trailing newline,
also matching the Shortcut.

**There is no untriaged option**, same as on the phone. An earlier checkbox form allowed
unticking everything for `type: ""`; the Shortcut never did.

## Setup / rebuild

1. Check Node is installed. In Terminal:
   ```
   node -v
   ```
   If it prints v18 or higher, you're set. Otherwise install Node LTS from https://nodejs.org
   (or `brew install node`), then reopen Terminal.

2. Move this folder somewhere stable and **outside the vault**, e.g.
   `~/RaycastExtensions/obsidian-inbox`.

3. Install dependencies:
   ```
   cd ~/RaycastExtensions/obsidian-inbox
   npm install
   ```

4. Load it into Raycast:
   ```
   npm run dev
   ```
   Within a few seconds "Add to Inbox" appears in Raycast. Ctrl+C stops the dev process
   afterward; the command stays installed.

5. Set the vault path (only if different from the default). In Raycast, open the "Add to
   Inbox" command's preferences and confirm the path is your vault's absolute path
   (`$VAULT_PATH`).

6. Assign the global hotkey. Raycast Settings → Extensions → "Add to Inbox" → set a Hotkey
   (e.g. Control+Option+C).

**Use:** press the hotkey anywhere. Type the Name. Tab to Description if needed, Tab to Type to
pick something other than Action. Cmd+Enter (or click Capture) submits. Default is a normal
action, so the fastest path is Name and submit.

## Config

Installed copy lives at `~/RaycastExtensions/obsidian-inbox`, outside the vault, so
`node_modules` doesn't get indexed or synced. To change what the form writes (fields, folders,
priorities), edit `src/inbox.tsx`, then re-run `npm run dev`.

## Gotchas

- **Every dependency is pinned exactly, and the pins are the point.** With a caret range,
  `@raycast/api` can drift many minor versions on an `npm install` and quietly drag in a React
  major. The runtime keeps working, but the types get stranded on the old React and
  `npm run build` breaks with `TS2786` errors, unnoticed, because `npm run dev` bundles with
  esbuild and ignores types. So `@raycast/api`, `@types/react` and `@types/node` are all
  pinned to the exact versions `@raycast/api` peer-requires, with `overrides` forcing one copy of
  each in the tree. **Do not put a caret back on any of them.** If you want a newer Raycast API,
  bump all three together to whatever the new version peer-requires, then run `npm run build` and
  confirm it says `checked TypeScript`.
- **`npm run build` is the only thing that checks types.** `npm run dev` will happily load an
  extension whose types do not compile. If you change dependencies, run the build, not just dev.
- **Keep the folder in place.** If the command ever disappears (e.g. after a Raycast update),
  re-run `npm run dev` from the folder.
- **It stays a local extension**: no App Store publishing or review needed.
- **Never move this folder into the vault.** `node_modules` would wreck Obsidian indexing and
  Sync.
- **Verify by reading `src/inbox.tsx`, not by trusting this doc.** A doc can claim behavior that
  was never actually implemented.

## History

**Two copies of the source exist and only one runs.** The vault copy at
`_system/raycast-extension/src/inbox.tsx` can go stale while the installed copy at
`~/RaycastExtensions/obsidian-inbox` (the one Raycast executes) stays correct. Build changes on
the installed copy, then overwrite the vault copy from it. When they disagree, the installed one
is the truth.

**No launcher button in note content.** The Claude Task Launcher button
([[claude-task-launcher-plugin]]) is derived by the plugin from the existing `type` frontmatter
property at render time, so capture never needs to write it. Do not re-propose appending a
button line on capture.

## See also
- [[_system/SYSTEM|SYSTEM]]: the hub and the wider capture architecture.
- [[apple-shortcuts-capture]]: the mobile capture counterpart.
