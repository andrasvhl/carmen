---
type: reference
component: wispr-import
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Wispr import: Wispr Flow meetings filed into the vault

**Status:** built. The job files every finished meeting, and the hourly timer runs on the
server. Referenced from `SYSTEM.md` § Components.

## What it's for

You record meetings with Wispr Flow's Notetaker. Copying each transcript into the vault by hand
does not happen reliably. This job pulls every finished meeting into the vault, one note per
meeting, filed next to the project it is about. It reads Wispr's cloud, not the Mac, so it works
with the MacBook off ([[vps-vault-host]] § Standing rule).

## How it works

- **Source:** Wispr's official remote MCP server, `https://api.wisprflow.ai/connect/mcp`,
  read-only. `vt wispr` (`~/automation/tools/wispr.py`) is the client: OAuth sign-in, token
  refresh, `search_meetings`, and `get_meeting` with every transcript range fetched and joined.
- **Completeness:** the cloud transcript matches the Mac's local `refined.ndjson` word for word,
  speaker turns included, with you named on your own turns. The Mac copy adds nothing the job
  needs.
- **Job:** `jobs/wispr_import.py` on the server. Lists meetings, keeps the ones that are
  `finalized` with a transcript and not yet handled, and for each asks Claude (read-only,
  `runner.ask`) where it belongs, choosing from every folder note under `Projects/` and
  `Areas/`. Python checks the answer against that list.
- **Filed:** `<project folder>/Meetings/<Who> <Mon D> - <Wispr title>.md`. **Unsure, or a
  destination outside the list:** `Inbox/Wispr/`, with a `[!question]` callout giving the best
  guess. Move it with `vt move`.
- **Note shape:** `type: reference`, `captured`, `wispr_id`, `wispr_url`; an English header
  (project link, time in the configured timezone, the import's guess at who "Speaker 1" is,
  marked as inferred); Wispr's summary; Wispr's notes if they differ; the transcript verbatim.
- **Never twice:** the job's memory lists every id it handled, and any note in the vault
  carrying `wispr_id:` counts as handled. Deleting an imported note does not bring it back.
- **Create only.** Project notes are never edited; the meeting note links to its project.

### Using a recording by hand

For "what was said in X", "send today's seminar to Y", or a meeting the job has not filed yet.
Everything below runs on either machine; the token lives on the server, so run it there.

| Want | Command |
|---|---|
| Is the sign-in alive | `ssh <SERVER> '~/automation/bin/vt wispr status'` |
| Today's meetings | `vt wispr call search_meetings '{"since":"<ISO date>T00:00:00Z"}'` (UTC; convert your local time, since a local afternoon can fall on a different UTC date or hour) |
| One meeting, full transcript | `python3 -c 'from tools import wispr as w; import json; print(json.dumps(w.meeting(w.Session(), "<id>")))'` from `~/automation` |
| Send it to someone | build a `.md` with summary + transcript, copy it into `~/.workspace-mcp/attachments/` on the Mac (the Gmail MCP refuses other paths, [[gmail-mcp]] § Gotchas), draft with `mcp__gws__draft_gmail_message`, send only after the user says yes, then delete the copy |

Send the file, not the `share_link`: who can open a Wispr link depends on that meeting's sharing
setting, which this server cannot read. Recipients come from the CRM (`Areas/People/`,
`crm_email`).

## Setup / rebuild

1. Sign in once, from the Mac (the browser redirect needs it), with the token landing on the
   server: `ssh -L 8771:127.0.0.1:8771 <SERVER> '~/automation/bin/vt wispr auth'`, then open
   the link it prints in a browser on the Mac. `vt wispr status` confirms.
2. `sudo cp ~/automation/units/automation@wispr_import.timer /etc/systemd/system/ && sudo
   systemctl daemon-reload && sudo systemctl enable --now automation@wispr_import.timer`

## Config

| What | Where |
|---|---|
| Token (refresh token rotates on use) | `~/.config/vt/wispr.json` on the server, 0600 (see your credentials note) |
| Schedule | `units/automation@wispr_import.timer`: hourly at :17 |
| Staging folder, destinations, timezone, per-run cap (15) | constants at the top of `jobs/wispr_import.py` |
| Ledger | `~/.local/state/automation/wispr_import.memory.json` |

## Gotchas

- **Wispr's device-code sign-in is broken:** the server advertises it, but the page it opens
  fails with "Missing external_auth_id". Only the browser redirect flow works.
- **Port 8765 on the Mac is the plan-today panel.** The sign-in uses 8771.
- **Transcript ranges carry a trailing newline the server adds.** Joining pages line by line
  cuts a word in half at each 40,000-character boundary; `tools/wispr.py` `_page()` strips the
  exact shape and checks every offset.

## Known limitations

- Times are shown in the configured timezone. A meeting held in another timezone still shows
  the configured one, labelled as such.
- A meeting edited in Wispr after import is not updated.
- Dictation history is out of scope: the MCP server does not expose it.
- If the sign-in expires, nothing imports until you sign in again; the job pushes when that
  happens (check `wispr-token`, critical).

## Decisions

- **Cloud MCP, not the Mac's `flow.sqlite`.** The local database is an undocumented schema and
  Mac-only; the MCP server is supported and reachable with the Mac off. Rejected: the Wispr Flow
  Sync Obsidian plugin and `wispr-cli`, which read the local database and dump everything into
  one folder without routing.
- **Own OAuth client instead of a claude.ai connector**, because an organisation-managed Claude
  account can block adding connectors.
- **One note per meeting; unclear ones go to a quiet staging folder, not an Inbox task.**

## See also

- Your project note on using Wispr Flow as the main meeting notetaker
- Your credentials note, [[maintenance]], [[frontmatter-properties]] (`wispr_` namespace)
