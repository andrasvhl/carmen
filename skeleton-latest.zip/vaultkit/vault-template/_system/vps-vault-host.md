---
type: reference
component: vault-host
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Vault host: always-on Linux box (as built)

**Status:** built and verified. Sync bidirectional; MCP connector live. Referenced from
`SYSTEM.md` § Components. The scheduling decision this box enables is documented separately in
[[scheduled-execution]].

The always-on machine that holds a live copy of this vault and runs Claude Code against it, so
agent work no longer depends on the MacBook being awake.

---

## What it's for

An earlier design assumed Obsidian Sync was unreachable by anything except Obsidian, so a
scheduled agent needed a git mirror of the vault as a second, machine-readable representation.
That premise no longer holds: Obsidian ships an official headless Sync client
(`obsidian-headless`, npm publisher `lishid`, Obsidian's lead developer). Any Linux box can hold
a live, always-current copy of the vault. A git mirror is not needed for reachability.

The actual constraint: the MacBook is off when you travel, which kills Claude Code Remote Control
and Dispatch (both need the Mac awake) and freezes a git mirror (the desktop plugin is what
pushes it). An always-on box is the only thing that closes this.

---

## How it works

### The box

| | |
|---|---|
| Provider / region | `<YOUR_PROVIDER_REGION>` |
| Type | `<YOUR_BOX_TYPE>` (vCPU, RAM, disk) |
| OS | Ubuntu LTS |
| Public IP | `<PUBLIC_IP>`: **firewalled off, do not use** |
| Tailscale | `<SERVER>` @ `<TAILSCALE_IP>`, tailnet account `<YOUR_TAILNET_ACCOUNT>` |
| Vault path | `~/vault` on the box (not `~/Obsidian/...` like on the Mac) |
| SSH | `ssh <SERVER>` (alias in `~/.ssh/config` on the Mac, key `~/.ssh/<YOUR_SSH_KEY>`) |

**Put the box in the same region as your Obsidian Sync remote vault.** Confirm it with
`ob sync-list-remote`; do not assume. Sync region is chosen at remote-vault creation and cannot
be changed later without losing version history.

Installed: Node 22 · npm · `ob` (obsidian-headless) **0.0.14** · claude (kept current by the
weekly `claude_update` job; auto-update is enabled but never fires for short `-p` runs, see
maintenance `claude-code-current`) · Tailscale · bubblewrap

---

### Services

Both are systemd units, both `enabled` (start on boot).

- **`obsidian-sync.service`** → `ob sync --path ~/vault --continuous` (via the guard, see below)
- **`claude-rc.service`** → `claude remote-control --name "Vault"`

```bash
ssh <SERVER>
systemctl is-active obsidian-sync claude-rc
sudo journalctl -u obsidian-sync -n 50 --no-pager
```

### Sync configuration: BIDIRECTIONAL

```
Sync mode:          bidirectional      <-- the box CAN write to the vault
Conflict strategy:  conflict           <-- visible conflict files, never a silent merge
Device name:        <SERVER>           <-- labels this box's writes in Sync version history
File types:         image, audio, video, pdf, unsupported
Configs:            none               <-- never syncs .obsidian
Excluded folders:   (none)
```

**The `Configs: none` line is the box's setting only. It is NOT a vault-wide fact.** Mac and
phone can sync vault configuration normally, including community plugins if the
*Active/Installed community plugin list* toggles are on there (they are off by default). In that
case a core-plugin setting entered on the Mac reaches the phone on its own. Misreading this line
as vault-wide leads to wrong design decisions; see [[daily-meditation]] § Design decisions.
Selective-sync options are themselves per-device and never sync, so each device has its own
answer: check Settings → Sync on the device you actually care about.

**The account is on Sync Plus**: 10 GB, 200 MB per file, 12 months of version history. That is
what makes `unsupported` viable. `.heic` never syncs; it is not in Obsidian's image list.

**Nothing is excluded on this box.** The one exclusion anywhere is
`Areas/<YOUR_SCHOOL>/Course Archive/_files`, on the **phone only**, so a phone does not pull the
binary half of [[_system/canvas-archive|canvas-archive]].

Before switching from pull-only to bidirectional, run pull-only cleanly for a while and take a
full backup of the vault first.

**Changing the mode changes the config file but not the running process: `sudo systemctl restart
obsidian-sync` is required for it to take effect.** `ob sync-status` reports the new mode
immediately either way, so status alone is not proof the daemon picked it up.

### Security posture

- Root login disabled, password auth disabled, MaxAuthTries 3, unattended-upgrades on.
- **Port 22 is closed to the public internet.** ufw allows SSH only from the tailnet
  (`100.64.0.0/10`) plus all traffic on `tailscale0`. Verify: tailnet SSH connects, public-IP
  SSH times out. Zero inbound public attack surface.
- Fallback if Tailscale is ever down at both ends: the provider's web console.
- **Accepted tradeoff:** Obsidian Sync is E2EE in transit, but the headless client decrypts to
  disk. The vault sits in plaintext on rented hardware. This is weighed against buying a Mac mini
  and chosen deliberately.

---

### MCP connector: vault access from Claude chat, Cowork, and mobile

Remote Control only serves the **Code** tab. This layer makes the vault readable from ordinary
Claude chat, Cowork, and the mobile app, in normal conversation with no diffs, no PRs, and no
Claude Code.

| | |
|---|---|
| Server | [`obsidian-sync-mcp`](https://github.com/es617/obsidian-sync-mcp) (npm, maintainer `es617`), local/filesystem mode |
| Service | `obsidian-mcp.service`, systemd, enabled |
| Binds | `127.0.0.1:8787`: never directly public |
| Public URL | `https://<SERVER>.<YOUR_TAILNET>.ts.net/mcp` |
| Exposure | **Tailscale Funnel** (`sudo tailscale funnel --bg 8787`), automatic TLS |
| Auth | password-gated **OAuth 2.1**, token in `~/.obsidian-mcp.env` (chmod 600) |
| Mode | **`READ_ONLY=false`, no `WRITE_FOLDERS`**: `write_note`, `edit_note`, `delete_note`, `move_note` all enabled, whole vault writable |
| Config | `~/.obsidian-mcp.env` · logs `~/obsidian-mcp.log` |

It indexes the vault's notes for search, rebuilt on start (a few seconds), and watches the vault
for changes.

**To read the OAuth password** (deliberately never written into chat):
```bash
ssh <SERVER> "grep MCP_AUTH_TOKEN ~/.obsidian-mcp.env"
```

#### The router problem, and how it's solved here

`~/.claude/CLAUDE.md` auto-loads in **Claude Code only**, and that is the chain that points at
[[Claude Master Router]] → [[SYSTEM]]. Chat, Cowork, and mobile have **no CLAUDE.md
mechanism**: the connector hands Claude a set of tools and nothing else. Without a bootstrap,
Claude starts cold every time and reverse-engineers the vault by listing folders and reading
notes, which makes a simple "what are my to-dos" take over a minute despite fast round trips.
The cost is exploration, not network.

**Fix:** `MCP_INSTRUCTIONS_FILE` points at **[[mcp-instructions]]**, a file *inside the vault*,
which the server returns in its MCP `initialize` response. Every client gets it automatically on
connect. Verify it is present in the `initialize` payload.

This keeps the vault as the single source of truth rather than duplicating context into Claude's
account settings. **Edit `_system/mcp-instructions.md` in Obsidian like any other note; it takes
effect on the next new conversation** (instructions are delivered at session start, so existing
chats keep the old copy). No restart needed: the server reads the file per connection.

Keep it short. It is injected into every conversation, so it costs tokens each time. It should
say where things are and point at the router for anything deeper, not restate the router.

**Note:** the server prepends its own built-in instructions, which describe write/move/delete
tools. Make sure `mcp-instructions.md` states the write mode that is actually configured;
if it says read-only while writes are enabled, every chat/Cowork/mobile session is told
something false.

**To reconnect or add on another account:** Settings → Connectors → Add custom connector →
paste the public URL above → authenticate with that password.

**Verify at build:** the endpoint returns HTTP 401 over valid TLS from outside the tailnet, an
unauthenticated `tools/list` returns `Unauthorized`, and a real connection logs
`password accepted` → `HTTP Stream session established`.

#### Why Tailscale Funnel rather than Cloudflare Tunnel
Funnel needs no domain and no Cloudflare account, and Tailscale is already set up here. It
provisions TLS automatically. Only ports 443, 8443 and 10000 are supported, and it requires a
`funnel` nodeAttr in the tailnet policy plus HTTPS Certificates enabled under DNS: both one-time
admin-console settings.

#### Why OAuth rather than a bearer token
Claude's request-header auth (bearer tokens) is **in beta and gated behind "contact Anthropic for
early access"**, so it may not exist on a given account. `obsidian-sync-mcp` implements OAuth 2.1
natively, which sidesteps that entirely. It was chosen over `obsidian-web-mcp` (Python, requires
a Cloudflare-managed domain, no read-only or folder scoping) primarily for `READ_ONLY` and
`WRITE_FOLDERS`.

#### Security posture of this layer: writes are ON and UNSCOPED
- The endpoint **is public by design**. This is a deliberate, partial reversal of the
  zero-public-surface posture above; it is the price of chat/Cowork access. Everything except
  this one path is still tailnet-only.
- It is **writable across the whole vault**, so the worst case is not disclosure alone: it is
  modification.
- `obsidian-sync-mcp` is a **third-party npm package** with read *and write* access to the whole
  vault and a public endpoint. That is a real trust assumption, recorded here rather than
  glossed.

**`WRITE_FOLDERS` is deliberately not used.** The option is real and enforced server-side
(comma-separated, folder-boundary-aware, case-sensitive, ignored when `READ_ONLY=true`). Scoping
to `Inbox` would block storing research and updating infrastructure docs from the phone, which
is most of the reason for having this at all. Note that **`WRITE_FOLDERS=Inbox` would *not*
block task updates**: all `type: action` notes live in `Inbox/`. The real cost is everything
*else*.

**The unavoidable tradeoff, stated plainly:** there is no configuration that both lets an agent
update `SYSTEM.md` from your phone and stops an injected agent from doing it. Those are the same
capability. `WRITE_FOLDERS` is folder-granular, so `_system` cannot be opened for one file and
closed for another.

**Three exposures accepted, in order of how much they matter:**
1. **Instruction-file persistence: the only one that changes kind rather than degree.**
   `_system/mcp-instructions.md` is injected into every chat/Cowork/mobile session's system
   prompt, and `Claude Master Router.md` + `_system/SYSTEM.md` auto-load into every Claude Code
   session. Writable, they convert a one-shot injection an agent obeys once into an instruction
   every future session receives. The package README warns about this directly.
2. **A writable imported corpus (such as `Notion/`) closes a self-propagation loop.** Those files
   are what an agent reads. Frozen, an injection is one-shot. Writable, injected text can seed
   more injected text into notes the next session reads, and wiki distillation would launder
   poisoned source material into the Wiki.
3. **Version history is the only undo.** Sync history is per-file, not a bulk rollback; the box's
   local git history (below) helps, but only on the box.

**Review this before adding automatic inbound sources; the trigger is not a date.** A static
corpus nobody can change is low risk. Inbound email, WhatsApp and meeting transcripts are text
written by other people, arriving automatically. That is when this stops being theoretical.

**To reverse or scope it later:**
```bash
ssh <SERVER> "echo 'WRITE_FOLDERS=Inbox,Projects,Wiki,Resources,Areas' >> ~/.obsidian-mcp.env && sudo systemctl restart obsidian-mcp"
```
Confirm via `tail ~/obsidian-mcp.log`: a scoped start logs `WRITE_FOLDERS: writes restricted to
...`, and an unscoped start logs neither that nor the `READ_ONLY mode` line.

### Vault git history: recoverability and per-line attribution

Purpose is **recoverability and per-line attribution for agent writes, not backup**: restic→B2
already covers backup (see [[backups]]). Runs entirely on the box, box-only by construction:
Obsidian Sync ignores dotfiles, so `.git/` and `.gitignore` never propagate to the Mac or phone.

| | |
|---|---|
| Repo | `~/vault/.git`, plain `git init`, no remote |
| Branch | `master` |
| Author | every commit: `<SERVER> <<SERVER>@localhost>`; see Gotchas below on what this means for `git blame` |
| `.gitignore` | `Attachments/`, `Areas/<YOUR_SCHOOL>/Course Archive/**/_files/`, `.obsidian/`, `.trash/`, `.DS_Store` |
| Course Archive markdown | tracked: machine-written by `vt canvas` and regenerable, but kept in history for the same recoverability/attribution reasons as everything else |
| Secret scan | run one before the first commit |

#### How it works

**`runner.vault_git.commit_if_dirty(message)`** (`~/automation/runner/vault_git.py`) is the one
function that ever touches this repo: `git status --porcelain`, and if dirty, `add -A` + `commit
-q -m message`. Serialised through an flock at `~/.local/state/automation/git.lock` (30s timeout)
so two jobs finishing at once queue instead of racing `git add`/`git commit` against each other.
Never raises past a caller that doesn't want it to; it is called two ways:

1. **Every job gets this for free.** `runner.job.Job.__enter__`/`__exit__` call `commit_if_dirty`
   before and after the job body runs, tagged `"<job>: pre-run snapshot"` / `"<job>: post-run"`.
   This is in the *shared runner*, not per-job code, so every current and future job has it
   without retrofitting. A git failure here is logged and swallowed; it must never fail the job
   that happened to trigger it. Skipped entirely on a `--dry-run` (matches `remember()`'s
   dry-run guard).
2. **`jobs/snapshot.py`**, on `automation@snapshot.timer` every 15 minutes
   (`OnCalendar=*-*-* *:0/15:00`), catches everything with no job behind it at all: a phone
   edit, a chat/Cowork/mobile write through the MCP connector, a plain Sync pull. Commits under
   `"snapshot: periodic"`. Unlike the generic hook, a git failure here becomes a real
   `IMPORTANT`-tier check failure (`git-commit-failed`, watches `vault-git-history` in
   `maintenance.md`): this job is the one thing actually watching for persistent git trouble.

So most writes land in a commit naming the job that made them (`wiki: post-run`,
`status: post-run`, …); `snapshot` is the 15-minute backstop for the rest.

**Verify end-to-end with real commits, not a read of the code:** create a throwaway file, run
`jobs.snapshot` for real, watch it get committed; delete it, run again, watch the delete commit;
confirm the working tree is clean both times.

#### Gotchas

- **`git blame` will not distinguish agents by author**: every commit has the same author,
  because every job runs as the same OS user on the same box. **Attribution is carried by the
  commit *message*, not the author field**: it names the job (`profiles: post-run`,
  `wiki: post-run`, `snapshot: periodic`). `git log -p --author=` is useless here;
  `git log --oneline` and reading the message is what answers "which job wrote this line."
- **`git revert` / `git checkout` on the box is a live vault edit**, not a sandboxed rollback: it
  writes into `~/vault`, which Sync then pushes to the Mac and phone like any other change.
  Treat recovery as a real edit to confirm, not a read-only diff.
- **`~/automation` is itself a separate git repo**: the Mac's `~/automation` clones it as
  `origin`, over SSH, from the box's working checkout (there is no separate bare repo). A script
  deployed and running on the box but never `git add`ed there is invisible to the Mac's clone no
  matter how often it pulls. Commit scripts on the box when you deploy them.
- **This repo does not touch the two-writers gap** ([[scheduled-execution]] gap 1). Git history
  lets a bad overwrite be recovered *after the fact*; it does not prevent one, and Sync still
  resolves a genuine near-simultaneous edit as ordinary last-write-wins before git ever sees a
  conflict.

#### Known limitations

- **No remote, deliberately.** The vault holds health and financial profiles, private notes, and
  material about third parties. Local repo on the box only; do not add a remote without deciding
  that explicitly.
- **A filesystem-level loss of the box loses git history**, even though restic/B2 still has the
  file *contents* nightly. History and per-line blame are not backed up anywhere else.
- **`.claude/settings.local.json` is tracked**: it is a small, secret-free permission allowlist,
  judged safe and useful to version rather than excluded by analogy to `.obsidian/`.

## Gotchas: all hit for real, all cost time

1. **`ob sync-setup` ignores intent and defaults to `bidirectional` with all media types
   enabled.** Run `ob sync-config` immediately after, before the first `ob sync`.
2. **`--file-types ""` does not clear the list** despite the help text saying "(empty to
   clear)". Both `--file-types ""` and `--file-types=` fail silently. v0.0.14 bug.
3. **The sync systemd unit needs an explicit `--path`.** Without it `ob` runs from `/` and
   crash-loops with "No sync configuration found for /". `WorkingDirectory` is not enough.
4. **Remote Control needs the workspace trust dialog even though `claude -p` doesn't.** Fix
   without a TTY by writing `projects["/home/<user>/vault"].hasTrustDialogAccepted = true` into
   `~/.claude.json`.
5. **Remote Control has a *second* one-time consent prompt** ("Enable Remote Control? y/n")
   that genuinely needs a PTY. Answer it once via `ssh -tt` with piped input; it persists as
   top-level `remoteDialogSeen: true`.
6. **Remote Control requires full-scope claude.ai OAuth.** It explicitly rejects
   `ANTHROPIC_API_KEY` and `claude setup-token` / `CLAUDE_CODE_OAUTH_TOKEN`, which is what every
   headless-server guide tells you to use. Use `claude auth login`.
7. **`claude remote-control` repaints its TUI ~4x/second into the journal** (~350k lines/day).
   Needs `StandardOutput` redirected plus a journald cap.
8. **`set -e` + `systemctl is-active` is a trap**: `is-active` returns non-zero for
   "activating" and silently aborts the rest of a script.
9. **Obsidian ignores dotfiles.** Files saved with a leading `.` never sync, and a propagation
   test using such a filename proves nothing.

**A file Sync once rejected is never re-evaluated.** A file created while the client was still
on a lower plan's size limit stays marked too-large after an upgrade; deleting and re-creating it
under a new name makes it sync. The same applies to anything that failed under an old limit: it
stays on one device until it is renamed or re-saved. **Testing a raised limit with a file that
already exists proves nothing.** Use a file Sync has never seen.

**Client entitlement is cached per client, and the headless one lags furthest.** After a plan
upgrade the desktop app may already accept large files while `ob` on the box still logs
`File too large to sync (... max 5.00 MB)` and has to be restarted to notice. Account page,
desktop app and box are three separate caches; check the one you actually care about.

10. **macOS stores filenames NFD, Linux and Obsidian Sync store them NFC.** Any script diffing the
    two copies must normalize first or files with non-ASCII characters (umlauts, accents) show as
    false mismatches. `comm` also needs `LC_ALL=C` on both sides.

### The deletion bug, and the guard that now prevents it

**`ob` <= 0.0.14 in bidirectional mode deletes what it lacks instead of downloading it.** It
cannot distinguish "I never had this file" from "the user deleted this file". If its local copy is
short when the service starts, it reconciles the gap **downward**, pushing deletions that
propagate to the Mac.

The typical trigger: removing a folder exclusion (or widening file types) and then restarting.
The folder comes into scope while the local copy is still empty, and the next restart resolves
that as mass deletions. `Restart=always` makes it a matter of time. Sync version history (including
its deleted-file bulk restore) plus an earlier backup are what recover from it, which is also the
argument for a real backup.

**Mass deletions after a `canvas-archive` naming change are not necessarily a loss.** When the
archive is re-run with a new naming convention, it produces a complete fresh tree; the old tree
goes stale, and deletions of it (plus `.part` / `.md.tmp` interrupted downloads) are duplicates
or junk. Check by content, not filename, before restoring anything: restoring would recreate a
duplicate parallel tree under the old naming.

#### Backups

**Owned by [[backups]].** Not restated here; the box is one of its two layers.

In short: the vault is backed up nightly from this box to Backblaze B2 with `restic`
(`b2:<YOUR_BUCKET>:vault`), and the Mac is covered separately by Backblaze Computer Backup. The
restic passphrase lives in your password manager and is unrecoverable if lost. Scripts in
`~/automation/bin`, credentials in `~/.config/restic/b2-box.env`.

#### The guard

`~/automation/bin/sync-guard.sh` is the unit's `ExecStart`. Before every start it compares the
local file count against `_system/sync-manifest.json`:

- local >= 97% of expected -> **bidirectional**, writes allowed
- local short, or manifest missing / older than 21 days -> **pull-only**, plus an alert note in
  `Inbox/`. Pull-only can download but can never delete, so it self-heals: once caught up, the
  next start returns to bidirectional on its own.
- It **never exits non-zero.** `Restart=always` would turn a hard failure into a restart loop, so
  the safe outcome is "run read-only", not "refuse to run".
- On a healthy start it **ratchets the manifest up** if the box holds more files than recorded.
  Only ever upward: lowering it is exactly how a real gap would get normalised into the baseline.

Test it without starting sync: `GUARD_DRY_RUN=1 ~/automation/bin/sync-guard.sh`

**The rule this replaces guesswork with: never restart bidirectional with a knowingly incomplete
local copy.** To widen `--excluded-folders` or `--file-types`, first set `--mode pull-only`,
restart, let it converge, then return to bidirectional.

**As long as `ob` is 0.0.14, the defect is unpatched upstream, so the guard is load-bearing.**

**Files over the 199 MB Sync cap can never be protected by any of this:** they live on one
machine only and are in no backup.

---

#### Pull-only strands agent work

Pull-only accepts inbound changes and discards local ones. A Claude session on a pull-only box
can write files that never leave it, invisible from every other device and one remote edit away
from silent deletion. **On a pull-only box, agent work is not just unsynced, it is actively
perishable.** Before switching to bidirectional, hash-compare the box against the Mac to find
such files; restarting sync in bidirectional mode uploads them.

#### Write-path verification (run when switching to bidirectional)

- **Push:** files created on the box reach the Mac, hash-identical.
- **Delete:** deletions made on the box propagate and remove the files on the Mac.
- **Conflict:** genuine divergence (sync stopped, both sides edited from the same base, sync
  restarted) produces `<name> (Conflicted copy <SERVER> <timestamp>).md` alongside the original,
  **both versions preserved, nothing silently overwritten.**
- **Device label:** the conflicted copy is attributed to `<SERVER>`, so agent edits stay
  distinguishable from your own.

**Testing conflicts requires forcing divergence; near-simultaneous edits are not enough.** Editing
both sides within seconds produces no conflict: Sync serializes them, the box downloads and
accepts the Mac's version, then uploads its own on top. That is ordinary last-write-wins on
sequential edits and proves nothing. Stop `obsidian-sync`, edit both sides, restart it: that is
the only reliable way to get a real common-base divergence.

These checks are Mac↔box. Propagation to and from the phone needs its own test.

---

### "Allocating sandbox" on the phone: SLOW, not broken

**Symptom:** starting a session from the phone sits on "Allocating sandbox" for a long time, long
enough to look completely hung.

**It is not hung. It eventually completes and works**, with a live local child process on this
box and full vault access. **Just wait it out.** This is the normal first-session startup cost.

**Two debugging traps worth knowing:**

1. **Session capacity is NOT a reliable signal of whether the phone reached this box.**
   `Capacity: N/32` in the log can stay at `1/32` across several attempts, which reads as "no
   new session attached." Wrong: a new session can *replace* the old one rather than adding to
   it, so the count never moves. Check for a **new session ID** instead:
   ```bash
   grep -ao 'session_[A-Za-z0-9]*' ~/claude-rc.log | sort -u
   pgrep -af 'versions/.* --print'      # one live child process per active session
   ```
   A local child process is the definitive proof a session is running *here* and can see the
   vault, rather than in an Anthropic cloud container that cannot.

2. **There genuinely are two different execution paths in the Code tab**, and this matters
   independently of the slowness above:

   | | Runs on | Sees this vault? |
   |---|---|---|
   | **Remote Control** ("Vault", computer icon + green dot) | this box | **yes** |
   | **Claude Code on the web** (cloud environment) | Anthropic cloud container | **no** |

   Prefer opening the existing **"Vault"** session from the session list.

**Setup kept from this:**
- `bubblewrap` installed: it is absent from the base Ubuntu image and is what a sandbox would
  need. Keep it.
- `claude-rc.service` logs to `~/claude-rc.log` instead of the journal, because
  `claude remote-control` repaints its TUI ~4x/second and floods journald.
- `kernel.apparmor_restrict_unprivileged_userns = 1` on Ubuntu 24.04+ restricts unprivileged
  user namespaces, which would matter if the sandbox is ever re-enabled.

**Current ExecStart:**
```
~/.local/bin/claude remote-control --name "Vault" --verbose
```
**`--no-sandbox` is no longer supported by `claude remote-control`.** With the flag the process
exits at startup ("--no-sandbox is not supported by claude remote-control") and the unit
crash-loops, showing `activating` forever. Never re-add it.
Debug with `grep -aiE "error|denied" ~/claude-rc.log`, not the journal.

---

## Known limitations: what this box does NOT do

Claudian, Raycast, Apple Shortcuts, Granola's Mac app, computer use, and iMessage are macOS-only
and stay on the Mac. If those ever need to run unattended, that is a Mac mini, and that decision
is cleanly separable from everything here.

**`.claude/` never reaches the box.** Obsidian Sync skips dotfolders, so the vault's
`.claude/settings.local.json` permission allowlist exists on the Mac only. Sessions on the box
run without it; the box's own `~/.claude/settings.json` is separate and set up by hand.

**Chat/Cowork can write.** Because Obsidian Sync on the box is bidirectional, writes from chat,
Cowork and mobile reach the Mac and phone.

### Memory: small box, and Remote Control sessions never let go

**On a small box with no swap, an idle-session buildup can OOM-kill real work.** A memory-hungry
command (for example `vt canvas extract`) gets killed with exit 137, and if the command was piped
the shell reports exit 0: it looks like a clean run that did nothing.

**The cause is not the workload.** `claude remote-control` spawns one child process per session
and **never reaps an idle one**. Each holds ~250MB to send a heartbeat every 20 seconds, forever.
A handful of abandoned phone sessions can hold well over a gigabyte.

**Sessions do eventually die, but only two things do it**, and neither is idle management:
- **Auth token expiry.** Sessions end together with `session_token expired, no refresh was
  delivered, exiting`, roughly monthly, when the credential rotates.
- **A `claude-rc` restart.**

So between credential rotations, sessions accumulate for weeks with nothing watching them.

**The dangerous part is which process the OOM killer picks.** If it picks `ob sync --continuous`
(~225MB), the vault silently stops syncing, every job keeps writing to a copy that never comes
back, and nothing reports it. The failure looks exactly like nothing happening.

**A killed session cannot be reopened from the app.** The phone shows "Can't reach your
computer… will reconnect when it's back" and retries a process that no longer exists, forever.
The *transcript* survives in `~/.claude/projects/-home-<user>-vault/<uuid>.jsonl` and stays
readable, and `claude --resume <uuid>` continues it **on the box**. Content is never lost; the
thread is just no longer resumable from the phone. Transcripts are pruned after 30 days by
default (no `cleanupPeriodDays` is set). `session_log` reads them (and the Telegram bridge's,
same folder) twice a day into the session-log note, which outlives the pruning.

#### What is built

**Swap does not bound this, and that is why the reaper exists.** With RAM plus swap at a few GB
and ~250MB a session, new sessions fill the box sooner than the monthly credential rotation would
clear them. Swap converts a hard OOM into a couple of weeks of warning. Only the reaper actually
caps it.

1. **Swap: 4GB**, `vm.swappiness=10`, persisted in `/etc/fstab` and
   `/etc/sysctl.d/99-swappiness.conf`. **Not `/etc/sysctl.conf`**: that file may not exist, so
   writing to it would silently not survive a reboot. Idle sessions are the ideal thing to page
   out: untouched memory, never read back.
2. **Detection: `jobs/heartbeat.py`.** Reports session count and total MB daily, warns above
   `MAX_RC_SESSIONS = 3`, and separately warns about anything within 24h of being reaped.
   Reports only; it never kills.
3. **The reaper: `jobs/rc_reap.py`**, `automation@rc_reap.timer` daily at **08:00, after
   heartbeat at 07:30**, so a session is always reported before it is closed. Closes anything
   idle past `REAP_IDLE_DAYS = 7`.

Shared logic lives in `runner/rc_sessions.py` so the reporter and the reaper can never disagree
about what "idle" means.

**Three decisions inside the reaper worth not undoing:**

- **Idle is measured from the last log line that is not `Heartbeat sent`**, never process age or
  file mtime: the 20-second ping keeps both looking alive indefinitely. Age would kill a session
  used daily for eight days.
- **An idle time that cannot be determined is never reaped.** A missing or unparseable bridge log
  means the session cannot be judged, and unjudged means untouched.
- **SIGTERM only, no SIGKILL fallback.** The process flushes its transcript on shutdown, and that
  transcript is the only thing surviving a reap. A session that ignores SIGTERM is reported and
  retried next run rather than forced.

**`pgrep -f` matches any command line merely containing the pattern.** A shell one-liner
inspecting these very processes can match itself, which would inflate the count and reap nothing
real. Both callers guard on the binary path containing `/claude/versions/`.

## Decisions

### Standing rule: everything runs on the box, not the Mac

The box is always on; the laptop is shut when you travel, which is exactly when unattended work
matters. **Anything built here has to work with the Mac powered off**, and "it works on my
machine" is a defect report, not a status.

Three concrete forms this takes:

- **Code lives in `~/automation` (git), never in the vault.** Obsidian Sync carries markdown but
  not `.py`, so a script in the vault silently exists on one machine only, and copies diverge or
  are missing on the box.
- **Never hardcode a machine's paths.** `/Users/<name>/...` in a script means it cannot run on the
  box; `~/vault` hardcoded means it cannot run on the Mac. Resolve the vault at runtime
  (`runner/config.py` does this) and invoke tools through `~/automation/bin/vt`, which is
  identical on both.
- **A skill is not installed until the box has it too.** `SKILL.md` syncs, but the symlink into
  `~/.claude/skills/` and any script do not, so a skill can be invisible to the box while the
  vault copy is present.

**The check before calling anything done: would this still work if the MacBook never opened
again?** If the answer is no, it is not finished.

**Three known exceptions, all deliberate:**

- **The WhatsApp bridge**: Mac-only; see [[_system/whatsapp-source|whatsapp-source]].
- **Video transcription** (`vt transcribe`, [[_system/skills/video-transcribe/SKILL|video-transcribe]]):
  **Mac-only by decision.** A small box (2 vCPU, ~4 GB RAM) cannot fit whisper.cpp's `large-v3`
  in memory at all, and `large-v3-turbo` runs *below* realtime on two Intel cores: a 2.5 hour
  recording would take 5 to 8 hours and pin the machine. On an Apple Silicon Mac the same job
  takes about twenty minutes. This is a capacity limit, not a portability defect: the code lives
  in `~/automation`, hardcodes no machine paths, and resolves the vault through
  `runner/config.py` like everything else, so it would run on the box the day the box is big
  enough. `vt transcribe doctor` prints a warning when it is run on the box. A larger box
  (4 vCPU, 8 GB) would close this; it is not needed because transcription is a job you start and
  watch rather than one that has to run while you travel.
- **The plan-today check-in panel** ([[_system/plan-today|plan-today]]): its always-on server
  (`<YOUR_LAUNCHD_PREFIX>.plan-today-panel`, a LaunchAgent on 127.0.0.1:8765) and the builder run
  on the Mac only. **Mac-only by design, and it stays that way:** the panel is an interactive
  page shown in the Claude desktop app's browser pane, so it only exists while you are at the
  Mac. Everything unattended behind it runs on the box: the 08:00 pre-run (`plan_today_prerun`)
  and the message and calendar fetch (`plan_today_delta`, called over ssh). Do not port the
  server to the box.

The Router and the vault-root `CLAUDE.md` keep a one-line trigger; this file owns the rule,
because everything it references is here.

---

## History

### Verification to perform at build time

- Pull the whole vault and hash-compare every markdown file against the Mac: expect all
  byte-identical, zero mismatches, zero unexpected files on the box.
- Files absent from the box should all be explainable: dotfiles (Obsidian ignores these by
  design) and any file types not in the file-types list (`unsupported` covers `.xlsx`, `.json`,
  `.tsx`, `.html` and similar).
- Live propagation both ways: create on Mac → box in **~5s**, delete on Mac → gone in ~5s.
- End-to-end agent read: `claude -p` on the box correctly lists every open `type: action` note in
  `Inbox/`.

## See also
- [[scheduled-execution]]: the scheduling decision this box enables, and its open gaps.
- [[_system/SYSTEM|SYSTEM]]: the hub.
- [[mcp-instructions]]: the file this box injects into every chat/Cowork/mobile session.
- [[whatsapp-source]]: a planned local-process source that would run here.
