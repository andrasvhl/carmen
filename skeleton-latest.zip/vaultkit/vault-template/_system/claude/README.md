# Claude's own configuration, shared by every machine

What lives here, plus a router history note (the decision log for [[Claude Master Router]]), so that every machine you run Claude on uses the same files. Obsidian Sync keeps them in step:

- `global-CLAUDE.md`: the master of `~/.claude/CLAUDE.md`, your cross-project instructions to
  Claude. **Fill in its "About me" section first.** A SessionStart hook in
  `~/.claude/settings.json` on each machine copies it over the local file when the two differ.
  **Edit this file, never `~/.claude/CLAUDE.md`.** A copy rather than a symlink because some
  Claude apps ignore a symlinked `~/.claude/CLAUDE.md`.
- `memory/`: Claude Code's auto-memory for every project on every machine, set through
  `autoMemoryDirectory` in each machine's `~/.claude/settings.json`. `MEMORY.md` is the index.
  Only vault-agnostic memory belongs here. Vault facts go in the vault ([[CLAUDE]] § Before
  writing to Claude's own auto-memory).
- `session-log.md` and `session-log-history.md`: what every session worked on, the last 7 days
  and everything older. Written by `session_log`; never edit them. How it works:
  [[claude-context-layer]].
- `commands/`: slash commands (for example `otodos`, a fast to-do listing). Linked into
  `~/.claude/commands/`.

**How the copy gets there.** Add the SessionStart hook from `SETUP-NOTES.md`, or copy it by hand
after each edit:

```bash
cp "$VAULT_PATH/_system/claude/global-CLAUDE.md" ~/.claude/CLAUDE.md
```

**Same path on every machine.** If a second machine (for example <SERVER>) keeps the vault
somewhere else, symlink the path used on your main machine to it, so every settings file and the
global file's import line use one path.

**Hooks are identical on every machine, as far as possible.** `~/.claude/settings.json` does not
sync, so any hook you add on one machine gets added to the others in the same session. Current
set: SessionStart (copy `global-CLAUDE.md`), and PostToolUse on Edit/Write/MultiEdit running
`vt docs --hook` and `vt tasks --hook`.

**Known limit:** two machines writing memory within seconds of each other can produce a Sync
conflict file instead of a merge. This is rare, and you can see it when it happens; it never
fails silently.
