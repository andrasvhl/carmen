# Global instructions

**Master copy: `_system/claude/global-CLAUDE.md` in your Obsidian vault.** It is copied to
`~/.claude/CLAUDE.md`, which Claude Code loads in every session on this machine, whatever folder
you start in. Edit the master, never the copy: if you set up the SessionStart hook in
`SETUP-NOTES.md`, the copy is overwritten at the start of every session. Changes apply from the
next session.

<!-- ============================================================
     ABOUT ME: fill this section in. Replace every <placeholder>.
     Keep it short: this file is read in every session, everywhere.
     Delete the example bullets you do not want.
     ============================================================ -->

## About me

<One or two lines: who you are and what you mostly use Claude for. Example: "Product manager,
uses Claude for research, writing, planning and some coding.">

### How to work with me

- <Communication preference. Example: "Be concise, lead with the answer.">
- <Example: "Challenge flawed reasoning plainly; verify current facts by search rather than
  trusting training data.">
- <Example: "Flag risks and better options rather than just complying.">
- <Example: "Confirm before big or irreversible moves.">
- <Example: "If a request mixes plan language with implement language, take the narrower
  reading: write the plan and stop.">
- <Example: "Don't impose structure (templates, processes) unprompted. Surface the open question
  and let me design it.">
- <Language. Example: "Reply in the language I write in.">
- <Style. Example: "No em dashes, no filler phrases.">

<!-- ======================== end of About me ======================== -->

## The Obsidian vault is the primary context layer

My vault is at `<VAULT_PATH>` (replace with the full path, for example
`~/Obsidian/MyVault`). It holds most of my context, plans, projects and routing, rather than
Claude's own memory system. True regardless of which project or folder the session is in.

**The vault owns its own rules.** Its `CLAUDE.md` and `Claude Master Router.md` are imported
below, so both load in every session wherever it was started. Nothing vault-specific belongs in
this file: put it in the vault's `CLAUDE.md` (always true), its `Claude Master Router.md`
(routing), or the component doc that owns it.

@<VAULT_PATH>/CLAUDE.md
@<VAULT_PATH>/Claude\ Master\ Router.md

**If that import did not load** (some Claude apps drop imports that resolve outside the
session's working folder), read `<VAULT_PATH>/CLAUDE.md` and then `Claude Master Router.md`
directly before doing any vault work.
