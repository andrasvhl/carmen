---
type: reference
component: profile-template
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Profile template

**Copy this file when creating a sub-profile of [[Areas/Master Profile|Master Profile]].** It is
the standard every profile note follows. The rules at the bottom matter more than the headings:
read them before deviating.

Companion to [[_component-doc-template]], which does the same job for `_system/` component docs.
Conventions this template implements (tiers, sourcing, shelf lives, the staleness rule) are
defined once in [[_system/profile-convention|profile-convention]].

---

## The template

````markdown
---
type: sub-profile
parent: "[[Master Profile]]"
domain: <slug>                 # health | identity | finances | career | people
verified: 2026-01-15           # when these claims were last checked, not when the file was touched
captured: 2026-01-15T12:00
---

# <Domain> Profile

Sub-profile of [[Areas/Master Profile|Master Profile]]. **<One bold line: what is true of the
owner in this domain.>**

**Read this when:** <the trigger, in one line. What question sends someone here.>

Conventions: [[_system/profile-convention|profile-convention]]. `(elicit)` marks a field worth
having that is not yet known.

---

## 1. <Domain section>

<One line stating what this section answers. Required, see rule 2.>

| Fact | Value | Tier | Source | As of |
|---|---|---|---|---|
| | | | | |

## 2. <Domain section>
...

## N. Unknowns register

<Always the last numbered section.>

| Unknown | Blocks | How to resolve |
|---|---|---|
| | | |

## Maintenance

- <What rots here, and how fast.>
- Registered in [[maintenance]] § Profile layer.

## Config

<Optional. Where the underlying data actually lives: documents, accounts, other notes.>

## See also
- [[Areas/Master Profile|Master Profile]]: the hub
````

Sections are optional but their **order is fixed**: numbered domain sections, then Unknowns
register, then Maintenance, then Config, then See also. Skip what does not apply; never reorder.

---

## Rules

1. **`parent:` is mandatory and is what makes the layer checkable.**
   `~/automation/bin/vt backlinks "Master Profile"` returns every file declaring it,
   and that set must equal the router table in [[Areas/Master Profile|Master Profile]]. A
   sub-profile missing from the router is unreachable; a router row with no file is a dead link.
   Both fail silently.

2. **Every section opens with one line saying what it answers.** Not decoration. A retrieval pass
   frequently sees a single section without the rest of the file, and a bare table under a bare
   heading cannot be interpreted alone. This is the same reason the fact table keeps its header
   row adjacent to its data rather than growing long enough to be split.

3. **Keep each section short enough to stand alone: roughly 200-500 words. This is a per-section
   rule and there is no file-level cap.** A retrieval pass often sees one section alone, so that is
   the unit that matters; a profile covering more domains is legitimately longer. A section that
   has to be read in sequence with its neighbours is one section doing two jobs: split the
   section, never the file.

3b. **A profile states facts and does not reason about them. Hard limit: 110 words of prose per
   section, and less is better.** A section is a table with a lead-in line, not an essay with a
   table attached.

   If a fact suggests a conclusion, **the conclusion goes in the note that acts on it** and the
   profile carries a one-line pointer. Create a companion note if none exists.

   **This is the rule most likely to be broken, including by whoever is reading it**, because an
   important deadline always feels like it belongs next to the fact that produced it. It does not.
   Splitting the file does not help either; the prose travels with the fragments.

   **So it is enforced mechanically, not by memory:**
   ```
   ~/automation/bin/vt profiles
   ```
   Run it after editing any profile. `--strict` exits non-zero for a hook or a cron job.

4. **The default fact table is five columns, in this order:**
   `| Fact | Value | Tier | Source | As of |`.
   A section whose content has a genuinely different natural shape (a payment schedule, a career
   sequence) **may change the leading columns but must keep `Source` and `As of` as the last
   two.** Those two are the provenance and recency metadata the whole design rests on; losing them
   turns a fact into a rumour.

5. **Unknown is a first-class entry.** A field worth having but not yet known is written
   `(elicit)` in place, so the gap is visible where the answer belongs. Gaps needing more than an
   answer (a measurement, a document lookup, a professional opinion) go in the Unknowns
   register with what they block and how to resolve them. **Never leave a cell blank**; a blank
   invites a plausible invention, which is the failure this whole layer exists to prevent.

6. **Never write a fact you were not given.** If it was inferred from vault evidence rather than
   stated by the owner, its `Source` is `inferred` and it is treated as a question, not an answer.
   See [[_system/profile-convention|profile-convention]] § Source vocabulary.

7. **Depth belongs in the sub-profile, never in the master.** [[Areas/Master Profile|Master Profile]]
   is deliberately thin and routes by fact type. If a fact fits one domain, it goes in that domain.

8. **Identifiers may be recorded. Authenticators may not.** The line is whether the value *is*
   the key to something, not whether it looks sensitive.

   | May be recorded (owner's choice) | Never record |
   |---|---|
   | Passport, national ID, visa and policy numbers | Passwords, PINs, TANs, 2FA and recovery codes |
   | Emails, phone numbers, handles, addresses | Full card numbers, CVV, bank details paired with credentials |
   | Which institution, which product, which document | Anything that alone grants access to an account |

   Remember the vault syncs across devices and is read by scheduled agents, so decide
   deliberately how much of the left column you want in it. The right column is not negotiable:
   a document number identifies you; a password *is* access, and no profile ever needs it, not at
   any tier, not with any justification, not even if asked. **If a password, PIN, 2FA seed or
   recovery code is ever supplied for this vault, do not write it down. Say so and move on.**

## See also
- [[_system/profile-convention|profile-convention]]: the conventions this template implements
- [[Areas/Master Profile|Master Profile]]: the hub
- [[Areas/People/_Person Template|_Person Template]]: the sibling template for person notes
- [[_component-doc-template]]: the equivalent standard for `_system/` component docs
