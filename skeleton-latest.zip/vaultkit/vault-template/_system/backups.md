---
type: reference
component: backups
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Backups: the hedge against losing the vault

**Status:** built and **restore-tested**. Referenced from `SYSTEM.md` § Components.

## What it's for

Without this, Obsidian Sync is the only copy of the vault. Files above the 199 MB Sync cap then exist on exactly one machine.

A sync-client defect can delete files in bulk ([[vps-vault-host]] covers the sync client). Sync version history may hold them, but only for a limited window, and it sits on the same service that is doing the deleting. This setup exists so that the next incident is a restore, not an investigation.

## How it works

Two independent layers, on two machines, using two different vendors' products.

| | **Server** (<SERVER>) | **Mac** |
|---|---|---|
| Covers | the vault | the whole Mac disk |
| Tool | `restic` -> Backblaze **B2** | Backblaze **Computer Backup** |
| Repository | `b2:<YOUR_BUCKET>:vault` | managed by Backblaze |
| Schedule | `backup-vault.timer`, 03:20 UTC nightly | continuous, client-driven |
| Retention | 7 daily, 5 weekly, 12 monthly, 3 yearly | **30 days** |
| Runs with the Mac off | **yes** | no |

**They are different products despite the shared brand.** Computer Backup is the consumer whole-machine product; B2 is object storage with buckets and API keys. Computer Backup **does not support Linux**, which is the entire reason the server needs B2.

**Incremental runs are cheap.** Only the first upload is slow; later runs add only what changed.

**The server job is self-reporting.** It refuses to run on missing or placeholder credentials, and writes an alert note into `Inbox/` if a run fails, so a failed backup is visible rather than silent. What it cannot report is *never running at all* (see Known limitations).

## Setup / rebuild

All scripts live in `~/automation/bin` on the server. Code never lives in the vault ([[vps-vault-host]] § Standing rule).

| Script | Does |
|---|---|
| `setup-b2.sh` | one-time interactive setup: prompts for bucket + keys (hidden), mints the passphrase, writes the env file, verifies, runs the first backup |
| `backup-vault.sh` | the nightly job itself |
| `restore-test.sh` | restores real files and diffs them against the live vault |
| `diag-b2.sh` | reports credential *shape* and does a live auth check **without printing any secret** |
| `fix-b2-keyid.sh` | repairs just the keyID, keeping the existing passphrase |

To rebuild from zero: create a private B2 bucket and an application key scoped to it, then run `ssh -t <SERVER> '~/automation/bin/setup-b2.sh'`.

## Config

- **Credentials:** `~/.config/restic/b2-box.env` on the server, `chmod 600`, never in a script.
- **Store the restic passphrase in your password manager.** That is the only copy outside the env file, and it is the one item in this entire system with no recovery path. Make sure access to the password manager itself has its own recovery path.
- Systemd units: `backup-vault.service` (oneshot) and `backup-vault.timer`.

## Gotchas

- **`401 bad_auth_token` at `b2_authorize_account` is never a bucket problem.** Auth happens before any bucket lookup. It means the keyID/secret pair is wrong. A typical cause: the **bucket name pasted into the keyID field**. A keyID is hex; if it looks like a name, it is in the wrong field. `diag-b2.sh` diagnoses this without exposing anything.
- **The keyID is not secret and stays visible** in the Application Keys table. Only the `applicationKey` is shown once. So a wrong keyID never requires making a new key.
- **Run the first backup through systemd, not interactively.** A large first upload over SSH dies with the session, which leaves a run that seemed to work but zero snapshots. `sudo systemctl start --no-block backup-vault.service` survives disconnect and lands in the journal.
- **B2 bucket names are globally unique across all Backblaze customers**, not per-account.

## Known limitations

- **Computer Backup keeps 30 days of version history.** This is the weakest link in the whole setup: a deletion that goes unnoticed for longer than that ages out. Extended Version History is a paid upgrade and is the single highest-value thing left to buy.
- **A timer that silently stops firing emits no alert.** The script shouts when it runs and fails; it cannot shout when it never runs. Hence the monthly check in [[maintenance]].
- **The restic passphrase is unrecoverable.** Lose it and the repository is permanently unreadable. No reset, no support path, no exceptions.
- **Nothing versions the server outside the vault directory.** `~/automation` is git; the rest of the server is disposable by design.

## Decisions

**Two vendors' products rather than one tool everywhere.** Computer Backup already covers the Mac far more broadly than a Mac-side restic job would, so a second overlapping Mac backup is redundant complexity. `restic` stays installed on the Mac only so it can restore *from* the server repository. A single restic setup on both machines would mean hand-rolling whole-disk coverage the Mac already has.

**The server is the backup source for the vault, not the Mac.** The server holds the most complete copy (including files over the Sync cap that are absent from the Mac) and runs 24/7, which satisfies the standing rule that unattended work must survive the MacBook being closed.

## See also
- [[vps-vault-host]]: the server and the sync client this guards against
- [[maintenance]]: the quarterly restore test and the monthly timer check
