---
type: reference
component: beeper-bridge
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Beeper bridge: LinkedIn, Messenger and Instagram messages, readable by Claude

**Status:** built. Built pieces: `beeper-server.service` (a verified device of your Beeper
account) and `msg_watch`, an hourly silent health check. The plan-today pre-run and delta read
through it, and the two-minute page's Chat send was tested up to prepare. Referenced from
`SYSTEM.md` § Components.

## What it's for

You send LinkedIn messages and don't want to keep checking whether replies came in. You also
want Claude to read those messages directly. Neither network has an API for a personal inbox.
Logging in to either one from the server would get the account flagged (see
[[_system/vps-vault-host|vps-vault-host]]). Facebook's message notification mails are not a
reliable substitute: they can stop arriving for weeks. This component reads the messages
through Beeper and works with the MacBook off.

## How it works

```
LinkedIn / Messenger / Instagram
      │  Beeper Cloud bridges (Beeper's servers log in, not this box)
      ▼
Beeper account ──► Beeper Server on <SERVER> (headless, Desktop API on localhost)
                        │  beeper CLI, read-only
                        ▼
       plan-today pre-run and delta, any session, the two-minute page
```

- **Accounts are connected as Beeper Cloud, never On-Device.** With Cloud, the networks see
  Beeper's servers. On-Device on this box would connect from the server's datacenter IP.
- **Nothing is sent to you from here. No pushes, no mail.** The component exists so Claude can
  read the messages. Do not add a message notifier.
- **Health:** `msg_watch` runs hourly and only checks two things, "Beeper reachable" and
  "Beeper accounts connected". Both are IMPORTANT, so a dropped login is logged and shown in
  the Monday brief, never pushed. `beeper-server` is deliberately not in the heartbeat's
  service list, because that list pushes.

### In the daily plan, and replying

Claude handles these conversations the way it handles mail: in the plan-today check-in and in
deals like a Marketplace purchase. One module, `runner/beeper.py`, gives every caller the same
read:

- **Pre-run** (`plan_today_prerun`): a `DATA: LinkedIn, Messenger and Instagram` section, read
  whole like WhatsApp. Each header carries the `chat_id` a draft needs. ROUTINE check
  *Beeper readable for the pre-run*.
- **Delta** (`plan_today_delta`): a `chats` key, rendered by `fetch_delta.sh` as `## LinkedIn: …`
  sections, which the delta agent judges.
- **Replies are `k: "send"`** with `msg: {via: linkedin|messenger|instagram, to: <chat_id>, body}`.
  They appear in the two-minute page's **Chat** group with **Send via Claude**, which works like
  mail (`chatsender.py`): an 8 s Undo, and the send is held if someone wrote since the draft.
  Your click is the approval. Over ssh to `python3 -m tools.chat send <chat_id>`, with the text
  on stdin.
- **From Telegram:** `tools.chat send` and `beeper send` are on the bridge's ask list, so you
  tap Allow with the exact text in view.

### Reading messages (any Claude session)

On the box, read-only, no Beeper sign-in needed per session:

```bash
ssh <SERVER> 'TMPDIR=~/.cache/tmp ~/.local/bin/beeper messages search --after <YYYY-MM-DD>T00:00:00Z --sender others --full --read-only'
ssh <SERVER> 'TMPDIR=~/.cache/tmp ~/.local/bin/beeper messages list --chat "<CHAT_NAME>" --full --read-only'
ssh <SERVER> 'TMPDIR=~/.cache/tmp ~/.local/bin/beeper chats list --unread --read-only'
```

Always pass `--read-only`. A send goes only through the two gated paths above.

## Setup / rebuild

1. **You:** sign in to Beeper (Mac desktop app or iPhone), then connect LinkedIn and Messenger
   (Instagram optional), **choosing Beeper Cloud** for each. The desktop app suggests On-Device,
   which only works while that machine is on. Do not add WhatsApp. Keep that device signed in:
   it approves the box in step 2.
2. **You, on the box:** `ssh -t <SERVER>`, then
   `TMPDIR=~/.cache/tmp ~/.local/bin/beeper setup --server --install --email <YOUR_BEEPER_EMAIL>`.
   Enter the emailed code and approve the new device from the phone.
3. Verify the box: `beeper verify list -t server --json` shows the request; accept it on the
   Mac, compare the emojis, then `beeper verify sas-confirm -t server --id <id>`. Then
   `sudo cp ~/automation/units/beeper-server.service /etc/systemd/system/ && sudo systemctl
   enable --now beeper-server` (boot start; the CLI's `targets enable` only starts it at login).
4. `~/automation/bin/run-job msg_watch --dry-run` checks the read path. Then
   `sudo cp ~/automation/units/automation@msg_watch.timer /etc/systemd/system/ && sudo
   systemctl daemon-reload && sudo systemctl enable --now automation@msg_watch.timer`.

CLI install: `npm install -g --prefix ~/.local beeper-cli@0.6.2`. The npm publisher `bi` is a
maintainer of Beeper's official `@beeper/desktop-api` package. The wrapper downloads the
binary from `github.com/beeper/cli` releases and checks its sha256.

## Config

| Path | Contents |
|---|---|
| `~/.local/bin/beeper` | CLI wrapper; binary cached in `~/.cache/beeper-cli/<version>/` |
| `~/automation/jobs/msg_watch.py` | hourly health check, no pushes |
| `~/automation/runner/beeper.py` | the read path; `SKIP_NETWORKS` |
| `~/automation/units/automation@msg_watch.timer` | hourly |
| `~/automation/units/beeper-server.service` | the server, at boot |

## Gotchas

- **Never read through `beeper messages search`.** Its index is built in the background and
  is incomplete: it can return one message of a thread where `messages list --chat` returns
  all of them. `runner/beeper.py` lists chats by `lastActivity`, then reads each active chat.
- **Search and list return a bare list with no chat titles.** The network comes from the chat's
  `network` ("Facebook/Messenger") or the `accountID` prefix (`linkedin.`, `facebookgo.`).
  LinkedIn text is HTML.
- **Marketplace threads are `type: group` with 2 participants**, titled "<YOUR_NAME> · <listing>".
  `is_group` treats them as direct.
- **LinkedIn ads look exactly like people** (no flag). `beeper.ever_wrote(chat_id)` tells a
  chat you answered from a cold one.
- **`beeper verify` alone only prints the state.** The box's request is confirmed with
  `beeper verify sas-confirm -t server --id <request id>`. Without `--id` it answers 409.

- **The CLI fails with `EXDEV: cross-device link not permitted` unless `TMPDIR` is on the home
  filesystem.** The wrapper unpacks in `/tmp` and renames into `~/.cache`. Use
  `TMPDIR=~/.cache/tmp`; `msg_watch` sets it.
- **Unpacking prints thousands of `LIBARCHIVE.xattr.com.apple.provenance` tar warnings** on
  first run of each version. They are harmless.
- **The npm package is `beeper-cli`, not `@beeper/cli`**, even though the repo's package.json
  says `@beeper/cli`. The scoped name does not exist on npm.

## Known limitations

- **iMessage is not covered**, by decision: it only exists on Apple hardware, and the iPhone
  already notifies natively.
- **Beeper's servers decrypt LinkedIn and Messenger traffic.** This is an accepted trade-off.
- **Unofficial access.** LinkedIn's terms name cookie-based bridging. The risk sits with your
  account, lowered but not removed by using Cloud.

## Decisions

- **Beeper Cloud on the server, over email notifications or self-hosted mautrix.** Email
  covered LinkedIn only, often as a snippet, and Messenger not at all. Self-hosted mautrix
  bridges would log in from the server's datacenter IP. Unipile (€49/mo) lacks Messenger.
- **Read on demand, no notifier.** The goal is for Claude to read the chats, not for you to be
  notified. The daily plan and sessions read them when they run.

## See also

- [[whatsapp-bridge]]: WhatsApp, read through WAHA, not Beeper
