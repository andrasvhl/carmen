---
type: reference
component: skills-conventions
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Skills: conventions

**How skills are written and maintained in this vault.** Read this before creating or editing
any skill. It lives inside `_system/skills/`, not in a general conventions file, so you find it
where the rule applies.

## Where skills live

**Source of truth is `_system/skills/<name>/SKILL.md`, symlinked into `~/.claude/skills/<name>`.**
Never author a skill directly under `~/.claude/` and plan to move it later.

```bash
ln -s "$VAULT_PATH/_system/skills/<name>" ~/.claude/skills/<name>
```

**The full rule and its rationale live in [[_system/SYSTEM|SYSTEM]] § Architecture decisions.**
That file owns this decision, so it is not repeated here.

**If you find a skill still living in `~/.claude/`, do not silently migrate it: create a task
note.** A move is usually also a correctness review of code written against an older schema.

## Improving a skill after it runs

**Every skill carries a self-improvement clause.** This convention applies to every skill in
this vault. When the user pushes back on how a run went, or changes something proposed to them,
**treat it as design input rather than a correction to apply silently**: convert it into
concrete, specific options and let them choose. Quiet compliance wastes the most valuable moment
a skill gets: right after it has been used for real. Ground proposals in what actually happened
in that run rather than in general reasoning; offer the review after a real run rather than
waiting to be asked; and record each adopted change in the skill file with its date and reason,
so a later reader does not quietly revert it. **Never edit a skill while a run of it is in
progress**: collect the improvements, say so, and apply them once the run ends. Changing the
process mid-run makes the user follow a moving target while doing the work. **Copy this clause
into every new skill as an `## Improving this skill` section**: a short duplicated block is more
reliable than a pointer that may not get followed.

## The skills shipped here

`dump` · `commit-to-action` · `prioritise` · `schedule-work` · `obsidian-todo` · `canvas-archive` · `freetime` · `coffee-chat` ·
`video-transcribe` · `send-to-kindle` · `plan-today` · `travel`.
Design reasoning for the first four is in [[_system/daily-loop|daily-loop]], not in the skill files.

## See also
- [[_system/SYSTEM|SYSTEM]]: owns the skills-live-in-the-vault decision
- [[_system/daily-loop|daily-loop]]: why the four loop skills are shaped as they are
- [[Claude Master Router]]: routes here
