---
type: reference
component: flexplorer
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# flexplorer: file explorer and manual ordering

**Status:** enabled. Referenced from `SYSTEM.md` § Components.

## What it's for

Replaces Obsidian's file explorer and lets you order folders **manually**. That order is
meaningful: it usually encodes a sequence (the order of a to-do list, the reading order of a set
of docs), not alphabet.

## How it works

**File order is controlled by this plugin, never by renaming files.** Folders are ordered manually, and that order is meaningful: it usually encodes a sequence (the order of a to-do list, the reading order of a set of docs), not alphabet.
- **Never add numeric prefixes** (`1 - Foo.md`, `01_Bar.md`) to force an order. That pollutes filenames, breaks existing links on every reorder, and duplicates what the plugin already does. If a folder needs a specific order, set it in the plugin instead.
- The order lives in `.obsidian/plugins/flexplorer/data.json` under `items["<folder path>"].customOrder`, with `sortOrder: "custom"`. Folder keys are vault-relative paths (`"/"` for the root). Writing that file directly is fine, but **Obsidian must be reloaded afterwards** (`Cmd+R`) or the running plugin will overwrite the change from memory. Back the file up before editing it; it is large and holds the order of the whole vault.
- **After creating new notes, place them deliberately.** New items are appended at the bottom (`newItemPlacement: "bottom"`, because top-placement kept pushing fresh files above the notes that orient the folder). Bottom is only the default landing spot, not the answer: put the file where it logically belongs in the sequence, and say so rather than leaving it wherever it landed.
- **Anchor and overview notes belong at the top of their folder.** Pin them (`isPinned: true` on the item, plus the path in the top-level `pinnedFiles` list) rather than relying on order alone. Pinning sorts within the file's own parent folder, so it is safe and local. **Every folder note (`X/X.md`) and every `_index.md` in the vault is pinned this way**, together with `_system/SYSTEM.md`. When you create a new folder note or index note, pin it too; otherwise it lands at the bottom with everything else and the folder loses its entry point.

## Gotchas

- **Obsidian must be reloaded (Cmd+R) after any direct edit to `data.json`**, or the running
  plugin overwrites the change from memory. Back the file up first: it holds the order of the
  whole vault.
- **`SYSTEM.md`'s standing gotcha says plugin config goes through the UI, not by hand.** Direct
  edits are a deliberate exception for bulk changes only, and always with a backup plus a reload.

## See also
- [[_system/SYSTEM|SYSTEM]]: the plugin table listing this as enabled
- [[_system/README|Vault Map]]: folder structure conventions
