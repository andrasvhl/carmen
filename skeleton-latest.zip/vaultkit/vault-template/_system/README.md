# Vault Map

Start at [[Claude Master Router]] (vault root). It routes to `SYSTEM.md` for how capture, the
Inbox and the task system work. This file is the folder map: where things are, and where new
things go.

The task engine (TaskNotes over Bases) is documented in `SYSTEM.md`'s "Task cockpit" section.

**This file is maintained for you.** `vaultmap` rewrites it weekly from what is actually on disk
(`vault-map-accuracy` in [[_system/maintenance/maintenance|maintenance]]), so it does not depend
on anyone remembering. Still list a new file or folder here in the same session you add it.
Forgetting can be fixed later, but a map that is missing one entry teaches every reader to stop
trusting it.

## What this file covers

Top-level folders, always.

Below that, go deeper wherever a folder's **name does not tell you what is inside**. That test
is the rule. The folders named below are the ones it currently selects. They are listed
explicitly because a general principle alone does not hold across runs.

**Enumerated one level down, always:** `_system/`, `Projects/` (every project, with what it is)
and `Resources/` (main groupings). Which components and which projects exist is the reason
someone opens this file at all. Inside a folder that earns depth, list what carries decisions or
facts, not every file.

**Deliberately not enumerated**, so a check stops proposing them: the Canvas course archive
(machine-written by `vt canvas`, changes on every run), `Attachments/` and `Archive/`. Their
top-level entry says what they hold.

**No dates.** Not verification dates, not "moved here" annotations. This is a map: it says where
things are now, in the present tense. When something moved, and why, belongs in git if the vault
is versioned. A doc that needs narrative keeps it in a `## History` section below the fold.

## Folders

- `CLAUDE.md` (vault root): the rules that bind every Claude session. Auto-loads.
- `Claude Master Router.md` (vault root): the entry point for how Claude navigates the vault.
  Routes to this file, `SYSTEM.md`, and the profile layer. Backlinks to the global
  `~/.claude/CLAUDE.md`.
- `SETUP-NOTES.md` (vault root): one-time install steps (plugins, skill links). Safe to delete
  once set up.
- `ToDo.base` (vault root) and `TaskNotes/Views/`: the task cockpit surface over `Inbox/`.
  `ToDo.base` is the live one, and the one `obsidian-todo` reads; `TaskNotes/Views/*.base` are
  the plugin's own default views (agenda, calendar, mini-calendar, kanban, relationships,
  pomodoro stats). See `task-cockpit.md`.
- `Inbox/`: **the one database.** Every capture is a typed note here (see `SYSTEM.md`),
  triaged via `Inbox/Inbox.base`. Tasks are not a separate folder; they are the notes with
  `type: action`. `_Inbox Template.md` documents the schema.
- `Areas/`: ongoing parts of life with no end date (for example Work, Health, Personal,
  Finances, Career, People). Tasks and projects link here. Also holds **two files that are not
  areas**, both life content rather than machinery, which is why neither sits in `_system/`:
  - **`North Star.md`**: current priorities, the explicit not-doing list, and decision
    tie-breaks, read by every enrichment and prioritisation pass. Expires by design.
  - **`Master Profile.md`**: the entry point for any durable fact about you, and the
    **fact-type router** to every sub-profile. Deliberately thin. North Star is what matters
    *now*; the Master Profile is what stays *true*. Sub-profiles live inside their areas (for
    example `Health/Health Profile.md`, `Personal/Travel Profile.md`, `People/People.md`), each
    carrying `parent: "[[Master Profile]]"`. Convention: `profile-convention.md`.

  `People/` is the **CRM**: one note per person, all fields `crm_`-prefixed, one base
  (`People.base`), queried with `vt people`. `_Person Template.md` is the template. Contacts not
  worth a note live in a lookup index outside the vault,
  `~/.local/share/crm/contacts-index.json`. Method: [[Areas/People/People|People]].

  The Canvas course archive, if you use it, is machine-written by `vt canvas` and never
  hand-edited; a `_files/` folder inside it mirrors the course folders and holds the binaries.
  See [[canvas-archive]].
- `Projects/`: active, deadline-bound work, one folder per project with its anchor note inside
  (see Folder conventions). List each project here with one line on what it is, once there are
  projects. Empty to start.
- `Resources/`: curated reference and reading. List its main groupings here as they appear.
- `Wiki/`: the compiled wiki of what you know and have concluded, distilled from your sources,
  **written by Claude, never by hand.** `index.md` is the catalog and is read first; `Wiki.md`
  is the folder note; `log.md` records ingests and gaps; `_sources.md` is the source registry;
  `_pending.md` is generated daily. What is in it: [[Wiki/index|Wiki index]]. How it works:
  [[_system/schema|schema]]. This file does not track its contents.
- `Attachments/`: files (PDFs, images) embedded in notes.
- `Archive/`: finished projects and areas, moved here whole.
- `_system/`: config and living docs about the machinery. `SYSTEM.md` is the hub (locked
  architecture decisions, the task schema, vault-wide gotchas, one status line per component);
  each component has its own doc, all following `_component-doc-template.md` (the documentation
  standard):
  - `raycast-extension/README.md`: desktop capture
  - `apple-shortcuts-capture.md`: mobile capture
  - `daily-meditation.md`: how the phone creates a Daily Meditation (or Freeflow) journal note
    via QuickAdd
  - `daily-loop.md`: decision record for the four daily-loop skills (dump, commit-to-action,
    prioritise, schedule-work); the skills hold instructions, this holds the reasoning
  - `plan-today.md`: the short morning check-in after the meditation: the server pre-run, the
    delta fetch, the Mac-only panel server and page, and how the skill ties them together.
    Skill: `skills/plan-today/`
  - `build-backlog.md`: build ideas captured all week from both capture paths, turned into one
    plan for a weekly build block
  - `task-cockpit.md`: how the task cockpit fits together: `ToDo.base` and its views, TaskNotes
    and its settings, `TaskNotes/Views/`, the Cockpit button and `vt todos`
  - `cockpit-plugin.md`: the local plugin behind the task-review ribbon button
  - `claude-task-launcher-plugin.md`: the local plugin that adds a per-note Claude Code launcher
  - `vps-vault-host.md`: the always-on Linux server
  - `backups.md`: the vault to Backblaze B2 from the server, the whole Mac to Backblaze Computer
    Backup
  - `sync-manifest.json`: **machine-written.** Expected file count for the server, regenerated
    by the server; the bidirectional-sync guard reads it before every start
  - `canvas-archive.md`: the optional Canvas course archive (`vt canvas`): modules, pages,
    assignments, rubrics, your own submissions and grades, files with extracted text, the
    readings pass and the daily assignment-task sync. Delete it if you do not use Canvas.
    Skill: `skills/canvas-archive/`
  - `kindle.md`: sending documents to your Kindle by email: the fixed address, the sending
    account and the traps. Skill: `skills/send-to-kindle/`
  - `speechify.md`: uploading readings to your Speechify library to listen on your phone: the
    web upload in your Chrome, one file at a time, and the traps. Skill:
    `skills/send-to-speechify/`
  - `travel.md`: door-to-door trip planning at the lowest sensible cost, and the flight price
    watch that keeps checking a fare from the server. Skill: `skills/travel/`
  - `flight-watch-status.md`: **machine-written.** Rewritten by `flight_watch` on every run;
    never edit by hand
  - `whatsapp-source.md`: WhatsApp as a read source: the ban research and the retrieval rules
  - `whatsapp-bridge.md` / `whatsapp-bridge/`: the conversational WhatsApp channel, phone to
    vault. The folder holds `reply-style.md`, the prompt that shapes how the bridge writes
  - `telegram-bridge.md` / `telegram-bridge/`: the Telegram channel, phone to vault, with voice,
    media, shell and proactive messages. The folder holds `reply-style.md`
  - `beeper-bridge.md`: LinkedIn, Messenger and Instagram messages read through Beeper on the
    server, read-only, so Claude can see replies with the MacBook off
  - `wispr-import.md`: Wispr Flow meeting recordings pulled from Wispr's cloud and filed as one
    note each next to the project they are about, hourly from the server
  - `maintenance-brief.md`: the weekly maintenance brief
  - `gmail-mcp.md`: local Gmail MCP server holding your mailboxes at once
  - `claude/`: Claude's own config shared by the MacBook and the server: `global-CLAUDE.md`
    (the master of `~/.claude/CLAUDE.md`), `memory/` (auto-memory for every project) and
    `commands/` (slash commands). See its README
    - `session-log.md` (machine-written): what every Claude session worked on, rolling 7 days,
      rewritten by `session_log`. Read on demand, never preloaded
    - `plan-today-prerun.md` (machine-written): the morning panel rows `plan-today` opens with,
      overwritten by `plan_today_prerun` on the server. Never edit
  - `claude-context-layer.md`: what loads into a Claude session where, the write-back rule, and
    how the session log is built (transcript digests, Mac push, the `session_log` job)
  - `push-notifications.md`: Pushover from the server to your phone; the channel for anything
    urgent or timely, because push is read promptly and email is not
  - `routine-push.md`: step-by-step Pushover reminders for the morning and evening routines,
    timed to the minute; the wording is owned by the routine notes themselves, not by code, so
    editing a routine in Obsidian changes the next push
  - `fitness-data-sync.md`: cron job on the server that pulls Strava and WHOOP and auto-logs new
    runs into a training log
  - `fitness-sync-status.md`: **machine-written.** Rewritten by `sync.py` on every cron run;
    never edit by hand
  - `maintenance/`: the registry of everything that rots silently, and the machinery that
    watches it:
    - `maintenance.md`: **the registry itself**: data-freshness tripwires, credentials,
      scheduled jobs, judgement with a shelf life, and the docs that assert an inventory.
      Standing rule: anything needing regular checking gets added here in the same session
      it is built
    - `maintenance-status.md`: **machine-written**, regenerated daily: what's failing now,
      what's passing, what's declared but watched by nothing
    - `alert-log/`: **machine-written**, append-only, one file per month: every failing check,
      repair and crash, the record the maintenance brief reads
    - `briefs/`: **machine-written**, one note per maintenance brief run: what needs you,
      what was fixed, what is still broken
    - `automation.md`: the systemd-timer runner in `~/automation` that does the checking
    - `claude-auth-watch.md`: the watchdog that warns before the server's Claude Code login
      expires. Its script is `_system/claude-auth-watch/check.py`, checked in here but run
      from the server
    - `scheduled-execution.md`: how unattended agent work runs on timers, and how
      `runner/ask.py` fills the gaps
  - `working-conditions.md`: when work can realistically be placed, and the calendar roster.
    Read by `schedule-work` and before proposing any day plan; carries its own `revisit:` date
  - `scheduling/`: the docs that decide when work happens, read by `schedule-work` (the week)
    and `plan-today` (the day):
    - `scheduling.md`: the folder's own doc: which scheduling doc answers what
    - `scheduling-rules.md`: how a block is placed: gaps, caps, energy, carry-over, the
      two-minute rule
    - `durations.md`: how long recurring things take, door to door
  - `signal-definition.md`: how any inbound pass decides what matters. Partial; the channel
    registry it depends on is not built
  - `frontmatter-properties.md`: which frontmatter property names are already taken and by
    what; check before inventing a new one
  - `_profile-template.md`: **the template every sub-profile copies.** Fixed section order,
    the five-column fact table, and the eight rules that make the layer checkable. Sibling of
    `_component-doc-template.md`, which does the same job for component docs
  - `flexplorer.md`: the file-explorer plugin: manual ordering, pinning, and the `data.json`
    mechanics
  - `profile-convention.md`: how facts about you are recorded: the Fixed/Slow/Current tiers,
    sourcing vocabulary, shelf lives, and the staleness rule
  - `schema.md`: how the AI distills sources into `Wiki/`: what counts as a source, the article
    format, ingest, re-ingest, query and lint, the derived-never-authored invariant, and how it
    divides from the profile layer. The wiki's own log is `Wiki/log.md`, not a `_system/` file
  - `mcp-instructions.md`: **exempt from the template**: it is an agent prompt injected into
    every chat session

  `skills/`: Claude skills, source of truth, symlinked into `~/.claude/skills/` for discovery
  (see `SYSTEM.md` for why they live here). **`skills/README.md` holds the conventions for
  writing and improving them.**
  - `dump/`: the verbal brain dump, the offloading half of the daily check-in
  - `commit-to-action/`: turns a dump into task notes
  - `prioritise/`: decides what matters (`priority`, `quadrant`)
  - `schedule-work/`: decides when it happens (`scheduled`, calendar blocks)
  - `obsidian-todo/`: the fast reader and writer over `Inbox/` via `vt todos`, which the other
    skills read the backlog through rather than re-implementing
  - `wiki/`: ingest notes into `Wiki/`, answer "what do I know about X" from it, lint it
  - `canvas-archive/`: archives your Canvas courses into the vault via `vt canvas` (optional)
  - `video-transcribe/`: transcribes audio and video into vault notes via `vt transcribe`, Mac
    only
  - `freetime/`: finds when most of a WhatsApp group is free via `vt freetime`
  - `send-to-kindle/`: downloads an article or document and emails it to your Kindle
  - `plan-today/`: the morning check-in after the meditation: the prefilled panel, then today's
    plan in the calendar; holds the panel server, its scripts and the agent prompts
  - `send-to-speechify/`: uploads readings to your Speechify library through the web app
  - `travel/`: plans a trip door to door at the lowest sensible cost, writes a trip page and can
    set a price watch that pushes deals from the server
  - `coffee-chat/`: books 1:1 coffee chats via `vt coffee`, creating the invites only after the
    slot is picked

  Reasoning for the first four lives in `daily-loop.md`, not in the skill files.

  Project-specific planning docs (master plan, PRD, etc.) live with their project in
  `Projects/`, not here.

## Folder conventions

- **A project's anchor note lives *inside* its folder, as a folder note, never as a sibling
  next to it.** For a project `X`, write `Projects/X/X.md` (the anchor) and put every detail doc
  alongside it in `Projects/X/`. The `folder-notes` plugin then makes clicking the folder open
  the anchor, so the file explorer shows one entry with the detail docs nested under it. Why
  not `Projects/X.md` beside `Projects/X/`: Obsidian sorts folders before files, so the anchor
  renders *below* its own folder and the name appears twice. Applies to any folder-plus-overview
  pairing, not just `Projects/`.

- **Anything live archives into itself; it moves to `Archive/` only when it is finished.**
  Two different things get called "archiving", and collapsing them splits one project across
  two folders:

  | Situation | Where it goes |
  |---|---|
  | A doc inside a live project or area is superseded | `<that folder>/Archive/` |
  | The project or area itself is finished | `Archive/<Name>/`, the whole folder |

  The local `Archive/` is that thing's own small dump: material worth referring back to without
  leaving it. So `Projects/X/Archive/` and `Areas/Y/Archive/` are both correct, and neither is a
  staging area for the vault-level `Archive/`. Only completion moves something out, and then it
  moves entirely, anchor and all.

  **There is no shared holding pen**: no `Projects/Archive/`, no `Areas/Archive/`. A holding pen
  gives "where is X?" two answers. Live means the archive is inside it; finished means it is not
  under `Projects/` or `Areas/` at all.

  **Moving any of it: `~/automation/bin/vt move <old> <new>`, never `mv`.** Obsidian only
  rewrites links for moves made inside Obsidian, so a shell or agent move silently breaks every
  path-qualified link, backticked path and folder reference pointing at what moved. `vt move`
  does what Obsidian would, and refuses to move a source registered in `Wiki/_sources.md`.

- **File order inside a folder is set with the `flexplorer` plugin, never by renaming** (no
  `01 ` prefixes). Renaming to sort breaks links and makes names lie about content. Anchor and
  `_index.md` notes are pinned to the top of their folder. Full mechanics, including the
  `data.json` paths and the reload requirement: [[_system/flexplorer|flexplorer]].

## Loose files in the vault root

Only `CLAUDE.md`, `AGENTS.md`, `Claude Master Router.md`, `SETUP-NOTES.md` and `ToDo.base`.
Anything else in the root is unfiled: give it a home.

## Knowledge layer (LLM Wiki)

Sources stay raw and frozen; the AI reads them but never edits them. It distills them into
`Wiki/` with an index and backlinks, logging to `Wiki/log.md`. Contents and conventions live
with the layer itself: [[Wiki/index|Wiki index]] and [[_system/schema|schema]].
