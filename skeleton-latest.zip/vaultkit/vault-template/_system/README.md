# Vault Map

Start at [[Claude Master Router]] (vault root). This file is the folder map: where things are,
and where new things go.

**This is the Skeleton.** It holds the wiring only: the server, the connections, the automation
runner and the vault architecture. It has no skills and no life content yet; you build your own
agent on top of it. Carmen is the complete agent built on this same skeleton, and adds the
skills, the task cockpit, the daily check-in, `Areas/` with North Star and the profile layer,
and the `SYSTEM.md` hub.

**Keep this file current.** List a new file or folder here in the same session you add it. If
you install the `vaultmap` job, it rewrites this file weekly from what is actually on disk.
Forgetting can be fixed later, but a map that is missing one entry teaches every reader to stop
trusting it.

## What this file covers

Top-level folders, always.

Below that, go deeper wherever a folder's **name does not tell you what is inside**. That test
is the rule. **Enumerated one level down, always:** `_system/`, `Projects/` (every project, with
what it is) and `Resources/` (main groupings). Inside a folder that earns depth, list what
carries decisions or facts, not every file.

**Deliberately not enumerated:** `Attachments/` and `Archive/`. Their top-level entry says what
they hold.

**No dates.** This is a map: it says where things are now, in the present tense. History
belongs in git if the vault is versioned, or in a doc's own `## History` section.

## Folders

- `CLAUDE.md` (vault root): the rules that bind every Claude session. Auto-loads.
- `AGENTS.md` (vault root): a pointer for other agents to `CLAUDE.md`.
- `Claude Master Router.md` (vault root): the entry point for how Claude navigates the vault.
  Routes to this file and to the component docs. Backlinks to the global `~/.claude/CLAUDE.md`.
- `SETUP-NOTES.md` (vault root): one-time install steps (plugins, links). Safe to delete once
  set up.
- `Inbox/`: **the one database.** Every capture is a typed note here; tasks are not a separate
  folder, they are the notes with `type: action`. `_Inbox Template.md` documents the schema,
  and `vt tasks` checks every task against it.
- `Projects/`: active, deadline-bound work, one folder per project with its anchor note inside
  (see Folder conventions). List each project here with one line on what it is. Empty to start.
- `Resources/`: curated reference and reading. List its main groupings here as they appear.
- `Wiki/`: an empty scaffold for a compiled wiki of what you know, distilled from your sources
  and **written by Claude, never by hand.** `index.md` is the catalog, `Wiki.md` the folder
  note, `log.md` records ingests and gaps, `_sources.md` is the source registry and
  `_pending.md` the queue. How it works: [[_system/schema|schema]].
- `Attachments/`: files (PDFs, images) embedded in notes.
- `Archive/`: finished projects and areas, moved here whole.
- `_system/`: config and living docs about the machinery. Each component has its own doc,
  all following `_component-doc-template.md` (the documentation standard):
  - **Server and runner**
    - `vps-vault-host.md`: the always-on Linux server, and the standing rule that anything
      unattended must run with the laptop off
    - `backups.md`: the vault to Backblaze B2 from the server
    - `push-notifications.md`: Pushover from the server to your phone, the channel for
      anything urgent, because push is read promptly and email is not
    - `maintenance-brief.md`: the weekly note of what needs you, instead of maintenance mail
    - `maintenance/`: the registry of everything that rots silently, and the machinery that
      watches it:
      - `maintenance.md`: **the registry itself**: tripwires, credentials, scheduled jobs and
        judgement with a shelf life. Standing rule: anything needing regular checking gets
        added here in the same session it is built
      - `automation.md`: the systemd-timer runner in `~/automation` that does the checking
      - `claude-auth-watch.md`: the watchdog that warns before the server's Claude Code login
        expires
      - `scheduled-execution.md`: how unattended agent work runs on timers, and how
        `runner/ask.py` fills the gaps
  - **Connections**
    - `telegram-bridge.md` / `telegram-bridge/`: the Telegram channel, phone to vault, with
      voice, media and proactive messages. The folder holds `reply-style.md`
    - `whatsapp-source.md`: WhatsApp as a read source: the ban research and the retrieval rules
    - `whatsapp-bridge.md` / `whatsapp-bridge/`: the conversational WhatsApp channel, phone to
      vault. The folder holds `reply-style.md`
    - `beeper-bridge.md`: LinkedIn, Messenger and Instagram messages read through Beeper on the
      server, read-only
    - `wispr-import.md`: Wispr Flow meeting recordings pulled from Wispr's cloud and filed next
      to the project they are about
    - `gmail-mcp.md`: a local Gmail MCP server holding your mailboxes at once
    - `fitness-data-sync.md`: the server job that pulls Strava and WHOOP
  - **Capture**
    - `apple-shortcuts-capture.md`: mobile capture with the iPhone Action Button
    - `raycast-extension/README.md`: desktop capture with a Mac hotkey
  - **Claude**
    - `claude/`: Claude's own config shared by the laptop and the server: `global-CLAUDE.md`
      (the master of `~/.claude/CLAUDE.md`). See its README
    - `claude-context-layer.md`: what loads into a Claude session where, and the write-back
      rule
    - `mcp-instructions.md`: **exempt from the template**: an agent prompt injected into every
      chat session
  - **Conventions**
    - `frontmatter-properties.md`: which frontmatter property names are already taken and by
      what; check before inventing a new one
    - `profile-convention.md` and `_profile-template.md`: how facts about you get recorded once
      you add a profile layer: the Fixed/Slow/Current tiers, sourcing, shelf lives and the
      staleness rule
    - `schema.md`: how the AI distills sources into `Wiki/`
    - `flexplorer.md`: the file-explorer plugin: manual ordering, pinning and the `data.json`
      mechanics

  `skills/`: where your Claude skills will live, as the source of truth, symlinked into
  `~/.claude/skills/` for discovery. Empty in the Skeleton apart from **`skills/README.md`,
  which holds the conventions for writing and improving them.**

## Folder conventions

- **A project's anchor note lives *inside* its folder, as a folder note, never as a sibling
  next to it.** For a project `X`, write `Projects/X/X.md` (the anchor) and put every detail doc
  alongside it in `Projects/X/`. The `folder-notes` plugin then makes clicking the folder open
  the anchor. Why not `Projects/X.md` beside `Projects/X/`: Obsidian sorts folders before files,
  so the anchor renders *below* its own folder and the name appears twice.

- **Anything live archives into itself; it moves to `Archive/` only when it is finished.**

  | Situation | Where it goes |
  |---|---|
  | A doc inside a live project is superseded | `<that folder>/Archive/` |
  | The project itself is finished | `Archive/<Name>/`, the whole folder |

  **There is no shared holding pen**: no `Projects/Archive/`. Live means the archive is inside
  it; finished means it is not under `Projects/` at all.

  **Moving any of it: `~/automation/bin/vt move <old> <new>`, never `mv`.** Obsidian only
  rewrites links for moves made inside Obsidian, so a shell or agent move silently breaks every
  path-qualified link and backticked path pointing at what moved. `vt move` does what Obsidian
  would.

- **File order inside a folder is set with the `flexplorer` plugin, never by renaming** (no
  `01 ` prefixes). Renaming to sort breaks links and makes names lie about content. Mechanics:
  [[_system/flexplorer|flexplorer]].

## Loose files in the vault root

Only `CLAUDE.md`, `AGENTS.md`, `Claude Master Router.md` and `SETUP-NOTES.md`. Anything else in
the root is unfiled: give it a home.
