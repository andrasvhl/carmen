---
type: reference
component: maintenance-brief
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Maintenance brief: one Monday note of what needs you, instead of maintenance mail

**Status:** built and deployed. Verify it with a real dry run on <SERVER> (the model answers and the
answer passes the guard) and a heartbeat dry run. It replaces the weekly `digest`, which is retired.
The proposal plan note for this component records its decisions and defaults.
Referenced from `SYSTEM.md` § Components.

## What it's for

Weekly maintenance mails tend to go unread. A channel you ignore is not a channel, so findings have
to arrive as decisions. Truly urgent things push. Everything else is logged in the vault and arrives
once a week as at most five decisions, each with a next action and the question "Create a task?".

## How it works

### Routing (in `runner/job.py` `_report` and `runner/alert.py`)

| What | Goes to |
|---|---|
| A CRITICAL check fails | Pushover, every run. Mail only if the push fails (`[PUSH FAILED]`) |
| An IMPORTANT or ROUTINE check fails | a block in the alert log, when new or escalated. No mail |
| A failing check passes again | a `resolved` block in the alert log |
| A job crashes | a block in the alert log; a push if it is the same job's second crash in a row |
| The alert log cannot be written | mail for those findings (`[LOG FAILED]`) |

Every failure is logged, critical included, so the log is the whole record. **No job writes an Inbox
task note any more.** "Truly urgent" is the CRITICAL tier, unchanged ([[push-notifications]] § Who
pushes). "In a row" for crashes means no successful run in between, read from the job's own state
file.

### The alert log

`_system/maintenance/alert-log/<YYYY-MM>.md`, one file per month (in your local time zone).
**Append-only by construction**: the file is opened for append and each block is one write, so a
lost Obsidian Sync race costs one block, never the document ([[scheduled-execution]] gap 1). One
block per finding:

```
### <YYYY-MM-DD HH:MM TZ> · heartbeat · failing · important
- time: <ISO-8601 UTC timestamp>
- job: heartbeat
- check: WhatsApp readable, newest message within 48h
- key: WhatsApp readable, newest message within 48h
- tier: important
- owner: you
- event: failing
- detail: newest message across 50 chats is 52h old
```

`event` is `failing`, `resolved`, `crashed` or `repair`. Values are folded onto one line.

### The Monday run (`jobs/maintenance_brief.py`, Mon 14:05 <YOUR_TIMEZONE>)

1. **Safe repairs, in Python, before any model runs** (`runner/repairs.py`). The model fixes
   nothing. The whole menu:
   - restart `obsidian-sync`, `wa-consumer`, `waha` or `obsidian-mcp` if it is down, then re-check
     after 30 s
   - re-run a job whose last run crashed, through systemd so `OnFailure=` still applies
   - re-run a job whose check failed only on a transient error (timeout, refused connection,
     DNS, HTTP 502-504), unless it also has a failing critical check
   - delete a git `index.lock` or `HEAD.lock` (vault repo, `~/automation`) older than 10 minutes
     with no git process running

   One attempt per item per ISO week, at most three job re-runs per pass, every action logged as a
   `repair` block. Anything else is reported, never attempted. Excluded from re-runs:
   `build_brief` (it runs the same afternoon) and the brief itself.
2. **Credentials drift**, server only (`runner/credentials_drift.py`): the credentials doc's
   <SERVER> table against the server. Files present, modes `0600`/`0700`, key names, and
   secret-shaped files the doc never mentions. Key names come from `grep -o '^[A-Za-z0-9_]*='`,
   never anything that can print a value (credentials doc § Gotchas). Each difference is an
   IMPORTANT check (`credentials-drift`), so it is logged and appears in the brief. The laptop rows
   are not checked.
3. **One read-only Claude turn** (`runner.ask`: Read, Glob, Grep), after waiting for `build_brief`'s
   run to finish (asked of systemd; its lock is never touched). Inputs: the week's alert log, every
   job's state file, the mechanical Still broken list, the repairs, the drift result, expiry
   candidates, and [[maintenance/maintenance|maintenance]] § 1. The model writes only the two
   sections that need judgement.
4. **Telegram** ([[telegram-bridge]]): a header, "Maintenance: 2 need you, 1 Claude can fix,
   3 fixed", naming the note, then one silent message per item, each with
   [Let Claude fix it] [Create task] / [Skip]. `Who` only labels the message. Let Claude fix it
   starts a session that does the item as far as it can, and closes its task if it needed
   nothing from you. If Telegram fails, one Pushover summary linking to the note; mail only if that
   fails too.
5. **Last week's fixes are re-checked.** The model sees which tasks Claude closed since the last
   brief; one whose finding is still failing comes back as an item with `Reopens:`, and Python
   reopens that task (never on a dry run).

### The note: `_system/maintenance/briefs/<YYYY-MM-DD>.md`

| Section | Written by |
|---|---|
| 1. **Needs you**: at most 5, ranked by consequence; what is wrong, why it matters, next action, effort, "Create a task?" | the model, re-rendered by Python from parsed fields |
| 2. **Fixed automatically this week**: repairs that worked, findings that passed again; then what was tried and did not work | Python |
| 3. **Still broken**: every open finding, most severe first, with how many weeks (from the log; before the log existed, the check's run streak) | Python, from the log and every job's state. Never the model |
| 4. **Expiring within 30 days**: logins, tokens, `revisit:` dates | the model, from mechanical candidates; those candidates verbatim if the model fails |
| 5. **Everything else ran**: one line counting scheduled jobs that reported, crashed or stopped | Python |
| Items, machine-readable: a `maintenance-brief-items` JSON block, one entry per Needs you item with an id (`mb-<date>-<n>`) | Python |

**Creating a task is a reply in a Claude session**: "create tasks 1 and 3". The session reads the
brief and creates each with `vt todos --add`, using the item's next action. With the Telegram
bridge, the items block feeds the buttons instead: [Let Claude fix it] [Create task] / [Skip] on
every item ([[telegram-bridge]]).

**If the model pass fails**, the brief is still written: section 1 says so, section 4 lists the
mechanical candidates, sections 2, 3 and 5 are complete. The message says nothing is ranked, and the
job fails an IMPORTANT check.

**Watched by** `heartbeat`, CRITICAL, daily: "maintenance brief ran this week". Passes if the note
for the last due Monday exists, or the job's state shows a real run since; before the first run, if
the timer was activated after the due time. So a dead brief pushes instead of going quiet.

## Setup / rebuild

```bash
ssh <SERVER> '~/automation/bin/run-job maintenance_brief --dry-run'   # logs the note, writes and pushes nothing
ssh <SERVER> 'sudo cp ~/automation/units/automation@maintenance_brief.timer /etc/systemd/system/ \
  && sudo mkdir -p /etc/systemd/system/automation@maintenance_brief.service.d \
  && sudo cp ~/automation/units/automation@maintenance_brief.service.d/timeout.conf /etc/systemd/system/automation@maintenance_brief.service.d/ \
  && sudo systemctl daemon-reload && sudo systemctl enable --now automation@maintenance_brief.timer'
```

Tests: `tests.alert_log_routing`, `tests.maintenance_repairs`, `tests.credentials_drift`,
`tests.maintenance_brief`, `tests.brief_state_parsing`, `tests.urgent_push`.

## Config

| Knob | Value | Where |
|---|---|---|
| Schedule | Mon 14:05 <YOUR_TIMEZONE>, 60 s jitter | `units/automation@maintenance_brief.timer` |
| Unit timeout | 3000 s | `units/automation@maintenance_brief.service.d/timeout.conf` |
| Model timeout | 900 s; wait for `build_brief` up to 900 s | `ASK_TIMEOUT`, `WAIT_FOR_BUILD_BRIEF_S` |
| Needs you cap | 5 | `MAX_NEEDS_YOU` |
| Restartable services | obsidian-sync, wa-consumer, waha, obsidian-mcp. `tg-bridge` is deployed but not on the list yet: open decision | `repairs.SERVICES` |
| Labelled "needs you" | an action on credentials or systemd: `sudo`, a state-changing `systemctl` (start, stop, restart, enable, disable, daemon-reload…), copying or writing into `/etc/systemd`, editing an env file, rotating, revoking or changing a key, token or password; or no `Who`. Mentions, reads, diffs and committing a copy stay Claude's. An overrule is logged | `ALWAYS_YOU`, `kind_of()` |
| Fix log | every Let Claude fix it session, its outcome and task; read back by the next brief | `~/.local/state/automation/brief-fixes.json` |
| Re-runs | max 3 per pass, 180 s wait each | `repairs.MAX_RERUNS`, `RERUN_WAIT_S` |
| Stale git lock | older than 600 s, no git process | `repairs.LOCK_MIN_AGE_S` |
| Heartbeat grace after 14:05 | 6 h | `heartbeat.BRIEF_GRACE_H` |

## Gotchas

- **A rerun on the same Monday does nothing** if that day's brief exists. Delete it to regenerate.
- **The runner's own `locks/*.lock` files are never "stale"** in a way that blocks anything: they
  are `flock` locks, released by the kernel when the holder dies. Only git's lock files are on the
  repair menu.
- **The template's `TimeoutStartSec=600` kills long oneshots.** This job ships a drop-in. The same
  limit applies to `build_brief`, whose model timeout is 1500 s.
- **`vt docs` and `inventory` skip `briefs/` and `alert-log/`** (`check_docs.GENERATED_DIRS`).
  Without that, every weekly note would need a `SYSTEM.md` row.

## Known limitations

- **Repairs are deliberately few.** Anything beyond the menu is reported, never attempted, and the
  menu grows only by a code change.
- **Mail fallbacks are per finding, not batched**, and only happen when push or the vault log fails.
- **Unchanged by this:** `wa_consumer` and `claude-auth-watch` still push and mail through
  `notify.send_urgent`; `routine_push` pushes directly. They are urgent by design.
- **Weeks broken** is exact only for findings first logged after deployment; older ones show their
  run streak.

## Decisions

- **Truly urgent goes to Pushover; everything else is logged, not mailed.**
- **Runs Monday at the build brief's time**, at 14:05 so the two model turns do not overlap.
- **No automatic tasks.** The brief asks whether to create one.
- **Who does it: you, or Claude.** Each item says which, by what it asks for; changing credentials
  or systemd, or a missing `Who`, is labelled yours. The label is all it decides: every item can be
  handed to Claude, which goes as far as it can. Full rule: [[telegram-bridge]] § Decisions.
- **The brief goes to Telegram** with Create task and Let Claude fix it buttons, and Pushover plus
  the vault note is the fallback.
- **"Truly urgent" is the CRITICAL tier, unchanged.** Claude login expiring or expired, any CRITICAL
  check failing, the WhatsApp ban tripwire.
- **Automatic Inbox notes from jobs stop.**
- **Every failure is logged, critical included**, so the log is the complete record and section 3
  can be built from it. Rejected: logging only non-critical findings, which would leave pushed-only
  findings with no history.

## See also

- the proposal plan note for this component: decisions and defaults
- [[push-notifications]] § Who pushes
- [[maintenance/maintenance|maintenance]]: concerns `maintenance-brief`, `credentials-drift`
- [[automation]]: the runner
- the credentials doc: the table the drift check reads
- [[build-backlog]]: the pattern this copies
