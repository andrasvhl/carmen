---
type: reference
component: scheduled-execution
stage: design-only
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Scheduled / unattended execution: how agent work runs without a laptop open

**Status:** scheduled jobs run on timers on the server, and the three original gaps are closed
by `runner/ask.py` (read-only tools, `--permission-mode dontAsk`, Python holds the pen,
`propose()` for review-before-write). Each gap below has a status line. Two jobs write into
existing notes: `vaultmap` rewrites the Vault Map, and `red_notebook` appends to a notebook note.
Referenced from `SYSTEM.md` § "Scheduled / unattended execution".

---

## What it's for

Running enrichment, dedup, sweeps and check-in prep on a schedule, while your laptop and phone
are asleep. The hard part is not scheduling. It is **reachability**: which machine-readable copy
of the vault can a scheduler actually see?

## How it works

**Scheduled and unattended work runs directly on <SERVER>: systemd timers call `claude -p`
against the real vault. No git mirror, no cloud Routines.**

This works because Obsidian ships an official headless Sync client (`obsidian-headless`, on
npm). An always-on Linux server (<SERVER>, full build detail in [[vps-vault-host]]) holds a live,
always-current copy of the vault through that client, and `claude -p` on the server reads it
directly. Check this once after setup, for example by asking it to list every open
`type: action` note in `Inbox/`.

**What this gains over a git mirror plus cloud Routines:** full-fidelity reads of the real vault
(no folder exclusions to reason about); any cadence, not a one-hour floor (a real systemd timer,
not a cloud Routine's minimum interval); and jobs can keep state on disk directly instead of
being forced stateless by a container model. An `enriched:` timestamp is still worth keeping,
for ordinary idempotency.

**Write capability.** Sync on <SERVER> is **bidirectional**; test push, delete, conflict
behavior and device attribution between your computer and the server before relying on it. The
MCP connector runs `READ_ONLY=false` with **no `WRITE_FOLDERS` scoping**, so chat, Cowork and
mobile can write anywhere in the vault. This is deliberate: scoping to `Inbox/` would block
storing research and updating infrastructure docs from the phone. Treat it as an accepted risk
and review it before adding jobs that read untrusted input. Reversal is one line in
`~/.obsidian-mcp.env` plus a service restart.

## Gotchas

- **Don't assume a scheduled agent reaches what an interactive session reaches.** A `claude -p`
  job on <SERVER> sees the real, full vault plus whatever local MCP servers are actually running
  on that server, but **not** Gmail, Calendar, Notion or Drive. Check current reach before
  scoping any job as "run it on a schedule".
- **Prompt-injection scope.** Once writes are enabled, a scheduled agent reading imported notes
  (and later email and meeting transcripts) is processing text it doesn't control. Confining
  what a job can write to a specific folder (the same principle as the MCP connector's
  `WRITE_FOLDERS` scoping) should apply to server jobs too.

## Known limitations

Write capability tends to land before its own safeguards, which is what turns gaps 1 and 2 from
future work into live exposure. Each gap is closed by `runner/ask.py` structurally rather than by
policy. **Two of the three are closed with a qualification, and the qualifications are the part
worth reading**: gap 2 is closed by reinterpreting it, and gap 1 is closed for the model but not
for Python's own write.

1. **Two writers on one file.** A git branch + PR per write would isolate every agent write from
   the live file; that mechanism does not exist here. Sync *can* produce a proper conflicted copy
   preserving both versions, but only under genuine divergence (for example, the server's sync
   service stopped). **Near-simultaneous edits are not enough: Sync serializes them into ordinary
   last-write-wins.** That is the real failure shape for an agent writing while you edit the same
   note on your phone.

   > **Status: closed for the model, NOT eliminated for Python.** `runner/ask.py` hands the model
   > `Read`/`Glob`/`Grep` and nothing else, hardcoded so no job can widen them, and deliberately
   > no `Bash` (a shell is a write tool in disguise). **The model cannot collide with a phone edit
   > because it has no tool that touches a file.** But the *job* still writes: `jobs/vaultmap.py`
   > calls `write_text()` on `_system/README.md`, racing Obsidian Sync exactly as
   > [[fitness-data-sync]] does on its target file. What mitigates that is the vault git snapshot
   > the runner commits around the write: **revertable, not prevented**, and last-write-wins is
   > still the shape. An append-only write is materially safer than a whole-file rewrite: a lost
   > race costs an appended block, not the document.
2. **"Propose, don't perform."** The confirm-before-big-moves principle stands, but with no PR
   review step something else has to actually implement it (a staging file, a report the user
   approves before a second pass applies it, or similar), not just inherit the sentence.

   > **Status: closed. The mechanism exists; each job chooses whether to use it.**
   > `runner.ask.propose()` implements this gap literally: model output lands as a dated note in
   > `_system/proposals/`, beside the original and never over it, carrying `proposed_for:` and an
   > explicit "nothing has been changed".
   >
   > **`jobs/vaultmap.py` opts out of it** and writes `_system/README.md` directly, with
   > structural validation in `_guard()` standing in for the review: the answer must start with
   > the original's first line (this catches chat preamble landing in the live map), keep ≥80% of
   > the length, and not drop protected sections. That is **verify-then-perform**, a weaker
   > guarantee than propose-then-approve, and it holds only where a wrong answer is detectable.
   > That is true of the Vault Map, which can be regenerated from the directory tree.
   >
   > **So the live question is not "is there a mechanism" but "which one should this job use".**
   > For a distillation there is no ground truth to diff against, so a guard can prove nothing was
   > destroyed and never that the result is right. `jobs/red_notebook.py` writes directly, as an
   > explicit decision, mitigated by an append-only construction (the model never sees the file)
   > rather than by detectability. `propose()` remains available if that trade stops feeling
   > right.
3. **Non-interactive permission mode.** `claude -p` from a timer has no TTY; with an empty
   `allowedTools` in `~/vault`, an unattended run hangs or fails on its first tool-use prompt. It
   needs an explicit `--permission-mode` (or a settings.json entry) before anything unattended
   can run at all.

   > **Status: fully closed.** `runner/ask.py` passes `--permission-mode dontAsk` with an
   > explicit read-only allowlist, verified headless with no TTY. Every AI job runs on it.
4. **What is scheduled.** Plain scripts such as [[fitness-data-sync]] (no agent) don't hit gaps 2
   or 3 at all, but they do instantiate gap 1's risk for their target file; see that doc's
   Gotchas. `jobs/vaultmap.py` and `jobs/red_notebook.py` are the `claude -p` jobs. **For the
   current full list of what's scheduled (cron and systemd both), see [[automation]]**: this doc
   stays about architecture and gaps, that one is the live inventory.
5. **Connector reach is an open question.** Cloud Routines reach Gmail, Calendar, Notion and
   Drive through Anthropic's cloud connectors. A `claude -p` process on <SERVER> has no
   equivalent built-in reach: it needs its own integration (local OAuth credentials, or an MCP
   server on the server, the same pattern used for the WhatsApp MCP). **A scheduled Gmail sweep
   needs its own reachability answer first.** Not decided here.

## History

A git mirror of the vault plus Claude Code Routines was the earlier design, chosen when Obsidian
Sync was believed unreachable by anything except the Obsidian app. Routines are stateless, have a
one-hour minimum interval, and can only push to `claude/`-prefixed branches, and they cannot run
local stdio processes such as the WhatsApp MCP. The headless Sync client removed the reason for
the mirror. Whether git is still worth keeping purely for version history and backup is a
separate question.

## See also
- [[vps-vault-host]]: the server this runs on, as built.
- [[_system/SYSTEM|SYSTEM]]: the hub.
- [[automation]]: the live inventory of scheduled jobs.
