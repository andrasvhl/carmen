---
type: reference
component: maintenance-registry
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Maintenance registry: everything that needs regular checking, in one place

**Status:** built and automated. Checks run daily and weekly on the server
([[_system/maintenance/automation|automation]]); coverage is stamped below. Referenced from
`SYSTEM.md` § Components.

<!-- maintenance-status:start -->
> [!info] **Live status**: generated, do not edit.
> Full detail, grouped by what you have to do, is on the generated maintenance-status page.
<!-- maintenance-status:end -->

**Jump:** [1 · Only you can do these](#1-only-you-can-do-these) ·
[2 · Nothing can check these](#2-nothing-can-check-these) ·
[3 · The machine handles these](#3-the-machine-handles-these)

## What it's for

> [!important] **Standing rule: anything that needs regular maintenance gets added here, in the
> same session you build it.** A component doc describing the thing is not a substitute: nobody
> re-reads a dozen component docs looking for what expired.

The recurring failure in this vault is not breakage, it is **silent staleness**: something quietly
stops agreeing with reality and nothing is watching. Each instance tends to be discovered by
accident.

Component docs describe how each piece works. This file answers a different question: *what do I
have to look at, and how often, or it will lie to me?*

## How it works

Grouped by **the kind of attention it needs from you**, not by what kind of thing it is. A
credential you must re-authenticate and a credential the machine refreshes are different
problems, even though both are credentials.

**Cadence is coarse on purpose.** Automated rows say `daily` or `weekly`; the exact schedule
lives in the generated maintenance-status page, because a time written here would drift the
moment a timer moved. A row reading **not yet** is declared but uncovered: that is the honest
state, not an omission.

**Within each table, rows run most consequential first**, ranked by what breaks if it is
missed, not by which date is nearest. Deadlines are swept weekly by `tripwires`, so imminence
is already handled; this ordering answers "what would hurt most".

Commands are not listed. Where a check is automated the code is the definition; where it is
manual the command lives in the linked doc. A table that pastes shell commands rots the moment
a path changes.

---

### 1. Only you can do these

*System state only a person can restore: an interactive login, a credential to re-mint, a
judgement to re-form. Detection may be automated; acting on it cannot be.*

**Not tasks.** An obligation you owe someone is a task in `Inbox/` with a `due` date. What
belongs here is the way a **document or credential stops being true**. Paying an instalment is
a task; `Finances Profile` §2 still listing a schedule that ended is a concern. Same date,
different failure.

| What | When | Why it matters |
|---|---|---|
| Claude Code login on the server <!--[claude-login]--> | ~30 days | Interactive OAuth, so it cannot be automated. `ssh -t <SERVER> renew-claude`. Watched by [[_system/maintenance/claude-auth-watch\|claude-auth-watch]] |
| Google OAuth, each mailbox <!--[google-oauth-tokens]--> | if compromised | `.google_workspace_mcp/client_secret.json` plus a token file per account. Plaintext, on more than one machine, one of them a public VPS. [Revoke here](https://myaccount.google.com/permissions). Dies every 7 days if the app reverts to Testing |
| Wispr Flow sign-in <!--[wispr-token]--> | when it lapses (no stated expiry) | Interactive OAuth from the Mac's browser, so it cannot be automated. Refresh rotates on use. Lapsed, nothing imports; `wispr_import` pushes (critical). See [[_system/wispr-import\|wispr-import]] § Setup |
| Canvas access token <!--[canvas-token]--> | on its expiry date | The school may not issue a longer one. An expired token makes an incremental archive run report "nothing changed" and exit 0: the exact silent-success shape this registry exists for. `vt canvas` refuses past `CANVAS_TOKEN_EXPIRES` and warns for 14 days, and `canvas_tasks` fails a check (mail) from 7 days out, every renewal. See [[_system/canvas-archive\|canvas-archive]] |
| Gmail app password <!--[gmail-app-password]--> | if revoked | Carries every infrastructure alert. If it dies, only the Inbox note survives |
| [[Areas/North Star\|North Star]] <!--[north-star-revisit]--> | on its `revisit:` date | A first version is meant to be wrong in places, and every prioritisation pass reads it |
| [[_system/working-conditions\|working-conditions]] <!--[working-conditions-revisit]--> | on its `revisit:` date | The day-shape a plan must respect. Every condition carries its own expiry |
| Always-open sender list <!--[sender-list-sync]--> | no date set | Two copies, in `SYSTEM.md` and [[_system/signal-definition\|signal-definition]], that can drift apart. The channel registry will supersede both when it is built |
| [[Areas/People/People\|People]] contact data <!--[contacts-refresh]--> | re-export every ~3 months | The CRM is built from **static snapshots**: a Mac Contacts vCard export, a class list CSV, and the WhatsApp chat list. Numbers change, new people arrive, and `crm_last_contact` only moves when someone updates it. Nothing re-reads the sources, so the data ages silently from the export date. Re-export Contacts (All Contacts > ⌘A > File > Export vCard) and re-run `crm_import.py`; method in People § History. **Not yet** watched |
| WhatsApp session <!--[whatsapp-session]--> | if it dies | Linked device on the primary number, held by WAHA on the server (whatsapp-bridge doc). **Re-pairing needs the phone in hand and is not remotely recoverable**, so a death while travelling ends the channel until you are back at a screen |
| Beeper sessions: LinkedIn, Messenger <!--[beeper-accounts]--> | when a network logs out | Beeper Cloud logins behind `msg_watch` (beeper-bridge doc). LinkedIn is known to drop bridged sessions. Re-login from the Beeper phone app. Watched by `msg_watch`'s IMPORTANT check *Beeper accounts connected* once the timer is on |
| Telegram bot token <!--[telegram-bot-token]--> | if leaked | `TELEGRAM_BOT_TOKEN` in `~/.automation.env` on the server. Whoever holds it can receive your messages to the bot and send as it; the owner-ID check stops them driving the vault, not that. Revoke with BotFather `/revoke`. **Partly watched:** `tg-bridge` pushes an alert when a 409 lasts past 2 minutes, meaning someone else is polling with the token or has set a webhook. A leak used only to send as the bot is not detected (telegram-bridge doc) |
| Pushover keys <!--[pushover-credentials]--> | if leaked or revoked | User Key and the server's API token in `~/.automation.env` (push-notifications doc). Every CRITICAL alert and the Claude login expiry warning ride on them. A refused send fails loudly and falls back to mail, so a revoked token is noticed; a leaked one lets anyone push to the phone and is not detected. Re-mint on pushover.net, by hand, never through an agent session. **Not yet** watched |
| Groq + OpenAI API keys <!--[transcription-api-keys]--> | if leaked; when OpenAI credit runs out | `GROQ_API_KEY`, `OPENAI_API_KEY` in `~/.automation.env`, for the Telegram bridge's voice transcription. OpenAI is prepaid with a monthly budget cap, so an empty balance silently kills the fallback while Groq still works. **Not yet** watched |
| restic passphrase + B2 keys <!--[restic-b2-credentials]--> | if lost | `~/.config/restic/b2-box.env` on the server. **A lost `RESTIC_PASSWORD` makes the repository permanently unreadable**: there is no recovery path. It belongs in the password manager, not only in that file. See [[_system/backups\|backups]] |
| Backblaze Computer Backup retention <!--[computer-backup-retention]--> | decide once | Covers the whole Mac ([[_system/backups\|backups]]) but keeps only **30 days** of version history. A deletion that goes unnoticed longer than that ages out. Extended Version History is a paid upgrade |

### 2. Nothing can check these

*No automated check is possible: they need a device, a running app, or a human eye. They stay
here so their absence stays visible rather than being mistaken for coverage.*

**Before adding a row here, check the claim.** A concern filed here because its check was
imagined as *making a test capture* turned out to be fully automatable: recent captures either
carry `priority` or they do not, and that is readable from the output. "Needs a device" is often
a description of the check someone imagined, not a real limit.

**The same mistake recurs with judgement work.** Merging learnings needs judgement, which is
true of the *writing* and irrelevant to whether a **check** is possible. If the justification
describes the work rather than the check, detection is probably mechanical and the row belongs
in §3.

| What | When | Why it matters |
|---|---|---|
| Cockpit `.base` formulas <!--[cockpit-formulas]--> | monthly | Needs Obsidian running to evaluate. `priorityWeight` rotted once already |
| Localhost Obsidian link redirect <!--[obsidian-link-redirect]--> | when a Code-tab link fails | Mac-only by nature (Obsidian runs there), so nothing on the server can see it. `~/automation/tools/obsidian_link_server.py`, launchd `<YOUR_LAUNCHD_LABEL>`, port 8799; exists because the desktop app only linkifies `http(s)`. If it is down, every vault link in a Code-tab reply is dead. `launchctl print gui/$(id -u)/<YOUR_LAUNCHD_LABEL>`; rule in `CLAUDE.md` § How to link |
| Apple Shortcut revision <!--[apple-shortcut-revision]--> | quarterly | No machine-readable version to compare. It can run several revisions behind unnoticed |
| Restore test from the vault B2 repo <!--[restic-restore-test]--> | quarterly | **A backup you have never restored from is not yet a backup.** Run `~/automation/bin/restore-test.sh` on the server; it diffs restored files against the live vault. See [[_system/backups\|backups]] |
| `backup-vault.timer` actually fires <!--[backup-timer-fires]--> | monthly | The script alerts loudly *when it runs and fails*. A timer that silently stops firing produces no alert at all: the exact silent-success shape this registry exists for. `systemctl list-timers backup-vault` |
| `CLAUDE.md` ↔ [[Areas/Master Profile\|Master Profile]] <!--[claudemd-profile-pair]--> | quarterly | CLAUDE.md carries a pointer, never a copy. If a copy appears, delete it rather than syncing |
| `workspace-mcp` version pin <!--[workspace-mcp-pin]--> | on any update | Pinned to `1.23.1` deliberately. Do not let it drift; the pin is the point |
| Wiki lint pass <!--[wiki-lint]--> | monthly | Contradictions between articles, claims that no longer trace to a source, stale provisional sections. Needs judgement: an orphan is not automatically a defect, and manufacturing inbound links to satisfy a graph metric is the failure mode. See [[_system/schema\|schema]] |

### 3. The machine handles these

*You only need to know when one stops being true. Coverage is stamped at the top; anything here
not yet automated shows as unwatched, which is the point.*

**Services and hardware**

| What | When | Why it matters |
|---|---|---|
| `obsidian-sync` <!--[sync-alive]--> | daily | Everything downstream reads a frozen copy if it stops |
| `claude-rc` <!--[remote-control-alive]--> | daily | Remote Control stops. **Does not crash when broken**: it can print `Connected` for a day on dead tokens |
| Routine reminders <!--[routine-push]--> | 4× daily | Morning and evening routine pushes, text read from the routine notes at send time. Mails if a `[!push]` block is missing or empty, a header time disagrees with the timer, or Pushover refuses. See [[_system/routine-push\|routine-push]] |
| WhatsApp bridge liveness <!--[whatsapp-bridge-liveness]--> | daily | The consumer mails on any `session.status` transition, with a 90s debounce and a live re-read so a planned restart passing through `STOPPED`/`STARTING` stays silent. Self-reported, though: it only holds while `wa-consumer` is alive, which is the row below. See [[_system/whatsapp-bridge\|whatsapp-bridge]] |
| `wa-consumer` and `waha` running <!--[whatsapp-bridge-daemons]--> | daily | Both units are in `heartbeat.SERVICES` as `critical`. This is the `watchdog-alive` shape one level in: session-death mail and the ban tripwire both only fire if `wa-consumer` is alive, so without this check the bridge's alerting would be circular. See [[_system/whatsapp-bridge\|whatsapp-bridge]] |
| WAHA hidden-message workaround <!--[waha-hidden-messages]--> | after any WAHA upgrade | WAHA's list endpoint hides about a third of group messages and serves pre-edit text; `runner/waha_store.py` reads them from GOWS's private SQLite schema instead. An upgrade can break that read (the delta fetch then reports a store-read error) or fix the bug (waha#2289, then delete the workaround). After an upgrade, run `plan_today_delta --since <3 days ago>` and check `hidden_recovered`, `edits` and `errors` in `counts.whatsapp`. **Not** automatically watched. See [[_system/whatsapp-bridge\|whatsapp-bridge]] § Reading WhatsApp rules 5 and 6 |
| `tg-bridge` running <!--[telegram-bridge-alive]--> | daily | `heartbeat.SERVICES`, `critical`. The bridge's own alerts (approvals, proactive messages) only fire while it is up, so without this the channel could die silently. Its crash mail quotes `tg-bridge.service`'s journal (`runner.alert.unit_for`). See [[_system/telegram-bridge\|telegram-bridge]] |
| Beeper server reachable <!--[beeper-reachable]--> | every 2 min | `beeper-server.service` on the server, read through the `beeper` CLI ([[_system/beeper-bridge\|beeper-bridge]]). If it stops answering, LinkedIn, Messenger and Instagram go unread, and the plan-today pre-run and delta lose that source without erroring. `msg_watch` fails an IMPORTANT check *Beeper reachable*; account logouts are the separate `beeper-accounts` row |
| WhatsApp ban tripwire <!--[whatsapp-ban-tripwire]--> | on a trip | Latches, stops the WhatsApp session and mails when WhatsApp appears to warn the account about unauthorized tools. Clears only by hand (`rm ~/.local/state/automation/wa-tripwire.json` plus a consumer restart), deliberately, because the point is to stay off the primary number until you have decided. See [[_system/whatsapp-source\|whatsapp-source]] § Ban risk |
| `obsidian-mcp` <!--[mcp-alive]--> | daily | Chat, Cowork and mobile lose their path to the vault |
| Wispr meeting import <!--[wispr-import]--> | hourly | A meeting that fails to fetch or route is logged, not dropped. A Wispr page-shape change fails loudly instead of cutting transcripts. See [[_system/wispr-import\|wispr-import]] |
| `claude-auth-watch.timer` <!--[watchdog-alive]--> | daily | The warning system itself. Disabled, silence looks exactly like health |
| Checks answering from a job that stopped <!--[stale-green-checks]--> | daily | Same shape as the row above, one level in. A check that passed and then lost its job keeps rendering **healthy** forever (`selftest` has no timer, so rows can read green for weeks off one run). Stale-green is worse than failing: the page answers "is this still true?" with a yes it cannot support |
| Timers running but not committed <!--[unit-repo-drift]--> | daily | Scripts and units deployed to the server and never `git add`ed recur. A timer running from `/etc/systemd/system` but absent from `units/` means a rebuild from the repo comes back with that job silently missing. See [[_system/vps-vault-host\|vps-vault-host]] |
| Open tasks no view can see <!--[unreachable-tasks]--> | daily | `ToDo.base` excludes `Archive/` and `Notion/` by folder, and `obsidian-todo` reads only `Inbox/`. A task note in either is overdue and invisible at once: the task system under-reporting what is open while looking healthy. Without this check such tasks are found only by audit |
| Finished work piling up in the Inbox <!--[inbox-sweep]--> | weekly | `Inbox/` is the capture queue, the alert channel and the archive at once, and only the first two were designed. Unswept, completed work becomes a large share of what every triage pass has to read past. `sweep` moves done tasks older than 30 days to `Archive/Inbox/<YYYY-MM>/` |
| Canvas assignments in step with tasks <!--[canvas-task-sync]--> | daily | `canvas_tasks` refreshes the archive for the courses you are **enrolled** in (never waitlisted ones) and keeps assignment tasks in step: due dates follow Canvas, a submission marks the task done, new assignments due within 21 days arrive in Triage with `## Next action` / `- [ ] Next: complete and submit on Canvas` at the top of the body (per [[_system/SYSTEM\|SYSTEM]] § Capture note schema) and their readings listed with direct links, and an assignment removed from Canvas is flagged, never deleted. Never duplicates, done tasks included (matched on the Canvas URL in the task body). It **writes into live task notes**, one frontmatter line at a time (its one-off `--backfill-readings` mode only inserts a block), skipping any task edited in the last 15 minutes; the runner's vault snapshot makes every write revertable. Holds the Canvas lock, so it skips rather than collides with a manual `vt canvas` run. Stops after the end of the program and says to disable its timer. See [[_system/canvas-archive\|canvas-archive]] |
| Vault readable from the server <!--[vault-reachable]--> | daily | Every job writes into `Inbox/`; a wrong mount fails silently |
| Disk headroom <!--[disk-space]--> | daily | journald, the vault and logs share one disk |
| Remote Control session sprawl <!--[rc-session-sprawl]--> | daily | Each abandoned phone session holds ~250MB forever and nothing reaps them; enough of them can OOM-kill an unrelated job. Reports only: a killed session cannot be reopened from the phone, so which ones go is your call |
| Strava token rotation <!--[strava-whoop-tokens]--> | daily | `.fitness-sync/config.json`. Strava rotates on every call and it must be re-persisted, or auth breaks days later |
| Fitness sync freshness <!--[fitness-sync-freshness]--> | daily | Judged on its own `state.json`, never `training-log.md`: that only moves when you actually train |
| Fitness sync correctness <!--[fitness-sync-correct]--> | daily | Freshness only proves the sync ran; this reads the `problems` list `sync.py` writes to `state.json` (WHOOP credential failing, run-type filter drifted). Entries can go unlogged for weeks while every freshness check passes. See [[_system/fitness-data-sync\|fitness-data-sync]] |
| Flight price watch <!--[flight-watch]--> | 2× daily | `flight_watch` re-prices every `flight-watch` block in the trip pages and pushes deals only ([[_system/travel\|travel]]). Fails a check when a block will not parse (they are edited by hand) or when a watch gets no fares at all; Skiplagged rate-limits, so a source going quiet looks like no deals rather than an error without this check |
| Vault git history <!--[vault-git-history]--> | daily | Every scheduled job commits any vault change under its own name, before and after its own run; `snapshot` catches everything else (Sync, chat/Cowork/mobile writes) every 15 minutes. Recoverability and per-line `git blame` attribution, not backup: [[_system/backups\|backups]] already covers that |

**The profile layer**

| What | When | Why it matters |
|---|---|---|
| `elicit` count, every profile <!--[profile-elicit-count]--> | weekly | **The one that matters most.** Every other check asks if a fact went stale; this asks whether the layer was ever filled in |
| `inferred` rows <!--[profile-inferred-count]--> | weekly | Claude's own conclusions about you, unconfirmed. They read as authoritative and are not |
| Reasoning creeping in <!--[profile-prose-creep]--> | weekly | The main bloat vector. A profile states facts; reasoning belongs in the note that acts on them |
| `verified:` freshness <!--[profile-verified-freshness]--> | weekly | `Current` rows go stale at 6 months, `Slow` at 12 |
| Router ↔ `parent:` integrity <!--[profile-router-integrity]--> | weekly | A sub-profile missing from the router is unreachable; a router row with no file is a dead link |
| Template conformance <!--[profile-template-conformance]--> | weekly | A convention, not a schema. Drift is invisible until a retrieval returns a section that cannot stand alone |
| [[Areas/People/People\|People]] circles <!--[people-crm-circles]--> | **switched off** | Circle sizes are chosen deliberately and need no size check for now. The `profiles` job still records both counts, but nothing alerts. Revisit if the circles stop meaning anything |
| `elicit`, per person note <!--[person-elicit-count]--> | weekly | Judged per note, never as a total: the database is built to grow, so a rising aggregate means it is working |

**Documents agreeing with reality**

| What | When | Why it matters |
|---|---|---|
| Daily-loop skills resolve <!--[daily-loop-skills]--> | weekly | `dump`, `commit-to-action`, `prioritise`, `schedule-work`. A moved script path or renamed schema field breaks one silently, and you find out mid-run |
| Captures still write `priority` <!--[mobile-capture-priority]--> | daily | Both capture paths. Judged on real recent captures, not a test one. This can stop silently and otherwise is found only by accident |
| Frontmatter property drift <!--[property-registry-drift]--> | weekly | A typo like `revist:` drops a note out of the sweep and looks identical to one never enrolled |
| Unsyncable filenames <!--[syncable-filenames]--> | weekly | A note with an unsyncable name never reaches the server. The sync client logs it once, then stays silent forever |
| `SYSTEM.md` § Components <!--[system-components-drift]--> | weekly | The other half of the same pair |
| [[_system/README\|Vault Map]] <!--[vault-map-drift]--> | weekly | `SYSTEM.md` delegates the folder map here, one-way, so this can fall behind while `SYSTEM.md` stays current. **Tests presence only**: whether each folder is *named* in the file, not whether the sentence around the name is true. Its accuracy is the row below |
| Vault Map descriptions still true <!--[vault-map-accuracy]--> | weekly | The presence check can pass clean while a description is plainly false. String presence is checkable; accuracy is not, and no deterministic check closes that. Rewritten weekly by `vaultmap`, which **updates the file itself** rather than asking you to. The model holds no write tool: Python writes the answer after checking it, and the runner commits before and after, so a bad week is one `git revert` naming the job. **A fixed drift is not reported**: it would mail and open a note every week the job worked. Only being unable to check, or refusing an answer, alerts, and that says "unverified", never "clean" |
| Session log <!--[session-log]--> | 2× daily | The session-log page: what every Claude session worked on, Mac and Telegram, 7 days rolling, older days in history. `session_log` on the server fails IMPORTANT if a day's summary is refused by the guard (that day is left untouched and retried), and ROUTINE if no Mac digest is newer than 3 days, which is either the Mac being shut or the Mac's session-digest launchd agent not pushing. See [[_system/claude-context-layer\|claude-context-layer]] |
| plan-today pre-run <!--[plan-today-prerun]--> | daily | `plan_today_prerun` on the server writes the plan-today-prerun page, the pre-guessed check-in panel for [[_system/skills/plan-today/SKILL\|plan-today]]. Fails IMPORTANT if the model pass fails or its JSON is refused (yesterday's page stays; the morning session sees the stale date and runs the live pull). ROUTINE per source: WhatsApp, each Gmail mailbox (gws refresh tokens, read in memory, never written back), and **calendar, which fails every run until a calendar-scoped token exists on the server**. Guesses only: the job never edits a task |
| Red Notebook consolidation <!--[red-notebook-consolidation]--> | daily | `#coreLearning` arrives two ways: **captures** in `Inbox/` from the Raycast/Shortcut Red Notebook option, and **passages** tagged mid-text in a note about something else. Neither reaches the Red Notebook note on its own. **Both halves are automated**: `core_learnings` reports the backlog (ROUTINE, never mails, fails past 10 pending or 35 days), `red_notebook` distils and appends (runs before `wiki` so a new entry registers as source drift the same morning). The notebook is a wiki source many articles cite, so the write is **append-only by construction, not by inspection**: the model returns entries and never sees the file, so nothing already written can change. Refuses >6 items in one pass, and refuses an answer that switched language, padded or lost an item. **A drained backlog is not reported**, same as `vault-map-accuracy`; only being unable to distil alerts, and that says "untouched", never "clear". **What no guard checks is whether a distillation is faithful**: that is what the revertable commit is for. A passage closes when the notebook cites its note; a capture when it moves to `Red Notebook/Core Learnings/`. Feeds: [[_system/raycast-extension/README\|Raycast]] and [[_system/apple-shortcuts-capture\|apple-shortcuts-capture]] |
| Build backlog reaches the weekly block <!--[build-backlog-brief]--> | weekly, Mon | Build ideas are captured all week with no date (Raycast and Shortcut "Build backlog", or the `build` tag on any Inbox note), so nothing surfaces them except this. `build_brief` drafts one brief task in `Inbox/` and pushes ahead of the weekly build block. **Fails loudly** if the model pass fails or its answer drops an item (push + mail), and if the push itself fails. An empty backlog is a quiet push, never silence. Items are never closed or discarded by the job; the brief proposes, you decide. Detail: [[_system/build-backlog\|build-backlog]] |
| Maintenance brief runs every week <!--[maintenance-brief]--> | weekly, Mon | Every non-critical finding goes to the vault alert log instead of mail, and this brief is the only place they reach you, so a dead brief would make a broken week look quiet. `heartbeat` checks daily, CRITICAL, that this week's brief ran; the brief fails a check (logged) if its model pass fails, and still writes every open finding mechanically. Detail: [[_system/maintenance-brief\|maintenance-brief]] |
| Server secrets match the credentials map <!--[credentials-drift]--> | weekly, with the brief | The map is hand-kept and secrets get added by hand over `ssh`, so it drifts silently. The brief compares the server table with the server: files present, modes, key names (via `grep -o '^[A-Za-z0-9_]*='`, never values), and secret-shaped files the doc never mentions. **The MacBook rows stay manual**: nothing on the server can see the Mac |
| Component docs follow the standard <!--[doc-standard]--> | on every edit, plus weekly | Only the template's sections, in its fixed order; `component`/`stage`/`verified`, never `status:`; one status line; no build log above the fold. **Checked at write time** by a Claude Code PostToolUse hook (`vt docs --hook`, see [[_system/vps-vault-host\|vps-vault-host]]) that hands violations to the editing session; `inventory` is the backstop for edits the hook cannot see (Bash rewrites, Obsidian on the phone). One definition: `tools/check_docs.py` |
| History in the reading path <!--[doc-history-placement]--> | weekly | Broken repeatedly: history disguises itself as justification at the moment you are editing |
| Server Claude Code is current <!--[claude-code-current]--> | weekly, Sun | Every AI job calls `claude -p --model opus` through `runner/ask.py`, and the alias resolves to the newest Opus *that the installed Claude Code knows*. Auto-update can be enabled (`claude doctor`; the `autoUpdates: false` in `~/.claude.json` is a legacy key native installs ignore) and still never fire, because short `-p` runs exit before the updater gets a turn, so `opus` silently keeps meaning an old model. `claude_update` runs `claude update`, then a headless probe through `runner.ask.probe` (the path every AI job uses) and records what `opus` resolved to. **If the probe fails after an update it relinks `~/.local/bin/claude` to the previous version** (native installs keep old versions) and alerts, so an update cannot silently break the Monday brief. Fails loudly if `claude update` errors, if the probe fails, or if `opus` stops resolving to an Opus model |
| AI jobs run at the right model tier <!--[ai-job-model-tier]--> | **not yet** | The standard is **the `opus` alias, for every job, for now**, never a pinned model id, so it follows new releases. Not every run needs that tier: `red_notebook` (daily distillation) and `vaultmap` are candidates for `sonnet`, `build_brief` (weekly planning, the most judgement) stays on `opus`. `session_log` runs on `sonnet`. `plan_today_prerun` runs `opus[1m]`, still the `opus` alias but with the 1M context, because its full message window does not fit beside the rest of its prompt in 200k. `ask(model=...)` already takes the override; what is missing is the per-job decision. Revisit once usage limits or cost make it matter |
| `CLAUDE.md` + Router stay small <!--[context-file-bloat]--> | **not yet** | `CLAUDE.md` auto-loads every session and the Router is read before any non-trivial work, so every word added is paid forever. Rules tend to crowd out routing until little of the Router is routing, forcing a restructure. **No budget or ratio floor is set**, so each recurrence looks exactly like the last |
| Always-true rules actually followed <!--[always-true-compliance]--> | **not yet** | A skipped rule produces a fluent answer with nothing visibly missing: the silent-success shape this registry exists for. The **"say you are checking before you check"** clause in `CLAUDE.md` is the current detector, and it works only if you notice an absence |
| `Inbox/_Inbox Template.md` <!--[inbox-template-drift]--> | **not yet** | Schema source of truth, wired to nothing that enforces it |
| [[Areas/People/_Person Template\|_Person Template]] <!--[person-template-drift]--> | **not yet** | Same failure class as the Inbox template |
| Dead wikilinks <!--[dead-wikilinks]--> | weekly | Fail silently. Some are deliberate forward links, so this reports rather than alerts |
| Wiki source drift <!--[wiki-source-drift]--> | daily | `Wiki/_sources.md` holds a content hash per ingested source. A changed hash means the articles it fed are stale, and the derived-never-authored invariant means a wiki page can never notice this itself. Watched by `jobs/wiki.py`, which writes `Wiki/_pending.md` and never re-ingests: rewriting articles unattended is what [[_system/maintenance/scheduled-execution\|scheduled-execution]]'s three gaps make unsafe |
| Wiki candidates never judged <!--[wiki-unregistered-sources]--> | daily | A new `type: learning` note or clipping that was never ingested *and* never recorded as deliberately skipped. Without this, growth-by-usage silently becomes growth-by-nothing. Same job, same page |

## Gotchas

- **Do not confuse this with a task list.** Profile rows get reframed as the obligations
  themselves rather than as the documents going stale. The test: *if you did the thing, would
  this row disappear?* If yes it is a task. A concern survives the doing, because the document
  still has to be corrected afterwards.
- **Do not confuse this with a task list.** Recurring *obligations* (instalments, payments,
  tuition) are tasks in `Inbox/` with real `due` dates. This file is for **system state that
  degrades**, not for things you owe people.
- **Two copies of the sender list already exist** (SYSTEM.md and
  [[_system/signal-definition|signal-definition]]), by deliberate choice for discoverability.
  That is a divergence risk the moment one is edited alone.
- **Ground truth beats documentation, always.** For anything scheduled, run the command.

### Deliberately not maintained

*Recorded so the meta-check stops reporting them and nobody re-litigates.*

| What | Why nothing is needed |
|---|---|
| `cockpit-plugin` | A ribbon button. If it breaks you find out by clicking it: no silent-failure mode |
| `flexplorer` | File order is cosmetic; a wrong order is visible the moment you look at the explorer |
| `kindle` | Fixed address and sending account, no token. A failed delivery comes back as an Amazon email, so the one failure mode reports itself |
| `daily-meditation` | An iPhone Shortcut plus a template. If it breaks, the morning note is simply not created, which is visible the moment it is used |
| `reply-style` | A prompt file the Telegram bridge reads every turn. A bad edit shows up in the next reply; liveness of the bridge itself is `telegram-bridge-alive` |
| `speechify` | An attended web upload in your Chrome, one file at a time, with no token or job behind it. A failed upload is visible on the spot; the doc's `verified:` age is already caught by the generic component-doc freshness check |
| `durations` | Reference values read by schedule-work and plan-today, no code. Values go stale rather than break, and the doc's `verified:` age is caught by the generic component-doc freshness check |

## Known limitations

- **This file itself is a document**, so it depends on someone opening it, which is the same
  failure mode it exists to prevent, one level up. The automated checks and the stamped coverage
  close most of that; cadence beyond them is your call.
- **No drift checker.** [[_system/maintenance/automation|automation]] notes one was considered and
  judged not worth it at a small number of jobs and services. That judgement should be revisited
  as the count grows.
- **The list is only as good as what got added.** The standing rule above is the whole mechanism.

## Decisions

**One registry, not per-component maintenance sections.** Each component doc could carry its own
"what to check" block, and several already imply one. Rejected because the question being asked
is cross-cutting (*what do I check today?*) and answering it would mean opening a dozen docs. The
component docs keep the detail; this file keeps the index.

**Open: cadence.** Weekly, monthly, or on a trigger? The tripwires and the judgement rows have very
different natural rhythms: a dead sync matters within days, North Star within weeks. Likely two
cadences rather than one. **Not decided, deliberately: process design is yours to own.**

**Open: how to bound the two context files, and how to tell whether their rules are obeyed.**
Three candidate mechanisms for size, none chosen: a hard word budget, a routing-ratio floor, or a
scheduled re-read that prunes. Compliance is the harder half, because the failure is silent by
construction: the rule is not obeyed, the answer still reads fine, and nothing in the output marks
the omission. The say-it-out-loud clause makes a miss visible in the moment but automates nothing.
**Not decided, deliberately: process design is yours to own.**

**Open: does the mail/WhatsApp triage itself become a recurring maintenance item?** A weekly
pass is the proposal once the backlog is cleared. Not set up.

## History

Checks run on the server and stamp their coverage at the top; critical things are checked daily,
entropy weekly. What runs and when is a machine fact, so it is generated into the
maintenance-status page rather than written here. Docs that describe a script or condition that no
longer (or not yet) exists are found by trying to use them, never by reading, which is why
drift checks run on a schedule.

## See also
- [[_system/SYSTEM|SYSTEM]]: the hub, and the always-open sender list.
- [[_system/maintenance/automation|automation]] · [[_system/vps-vault-host|vps-vault-host]] · [[_system/fitness-data-sync|fitness-data-sync]] · [[_system/gmail-mcp|gmail-mcp]] · [[_system/whatsapp-source|whatsapp-source]]
- [[_system/signal-definition|signal-definition]]: the other half of what rots, what counts as important.
- [[Areas/North Star|North Star]]: the judgement layer with an explicit revisit date.
