---
type: reference
component: automation
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Automation: the machinery that does the checking

**Status:** built and verified. The job count is not maintained here: the generated maintenance status page builds the live schedule from the timers themselves.
Referenced from `SYSTEM.md` § Components.

## What it's for

Running checks on the server without anyone's laptop open, and making sure a broken thing can
never look identical to a working one. That single sentence produces most of the design.

The failure this guards against is almost never a crash. A bridge can answer queries for weeks
from a frozen snapshot, mobile capture can silently stop writing `priority`, cockpit formulas can
rot, a script can be documented before it exists, and `claude-rc` can print `Connected` while
holding blanked tokens. In each case the process is healthy and the *output* is not.

## How it works

Code lives in `~/automation`, a git repo, on both machines. **Never in the vault**: Obsidian
Sync does not carry `.py`, so a script in the vault silently exists on one machine only.

**Commit and merge to `master` without asking.** This is a single-user repo where the server's
working tree *is* the deployment, so a feature branch left unmerged means `master` silently lags
what is actually running. The general "branch first, let the human merge" default is wrong here
and should not be re-applied. Land the work on `master`, on both machines, and say so. The Mac's
`origin` is the server (`ssh://<SERVER>/~/automation`), and the server sets
`receive.denyCurrentBranch = updateInstead`, so **pushing from the Mac works and updates the
server's working tree in place**: that push *is* the deploy. Committing on the server and
resetting the Mac to it works equally well. Either way, verify both ends are clean and on the
same commit before calling it done. Once a piece of work is complete and verified, commit and
push in the same turn; do not ask, because asking leaves the server running the old code in the
meantime. Commit only the files the session changed, never someone else's untracked work.

Each job is a file in `jobs/`. Everything else is inherited from the shared runner: locking,
atomic state, mail, Inbox notes, the off-box heartbeat ping, and the exit-code contract.

```python
with Job("heartbeat", description="vault-host heartbeat") as job:
    job.check("obsidian-sync running", ok=_is_active("obsidian-sync.service"),
              tier=CRITICAL, owner=AUTOMATIC, covers="sync-alive",
              detail="the vault stops syncing to and from this box")
```

**The exit-code contract is the whole design:**

| Exit | Meaning | What happens |
|---|---|---|
| `0` | The job ran. It may have found problems | The job reports them itself, by mail and note |
| `1` | The job *itself* broke | `OnFailure=` fires; the alert unit mails about the job |

Collapsing those two would make "your sync is down" indistinguishable from "the thing that
checks your sync is down".

**Three signals**, because two is not enough:

| Signal | Fires when | Reaches you as |
|---|---|---|
| Problem found | a check fails | mail + Inbox task note |
| Job broke | crash, hang, OOM, cannot start | mail + note, via `OnFailure=` |
| Absence | pings stop arriving | Healthchecks.io, off-box |

Only the third survives the whole machine going away.

**Rerouted by [[maintenance-brief]].** The table above shows the old routing for the first two
signals. A found problem pushes if CRITICAL and otherwise becomes a block in
`_system/maintenance/alert-log/<YYYY-MM>.md` (`runner/alert_log.py`); a crash is logged and pushes
on the second in a row; no job writes Inbox notes; mail is only the fallback when push or the log
fails. Jobs it added or removed:

| Job | Schedule | Change |
|---|---|---|
| `maintenance_brief` | Mon 14:05 | **new**: safe repairs (`runner/repairs.py`), credentials drift (`runner/credentials_drift.py`), one read-only model turn, the brief note, one push |
| `digest` | Mon 08:00 | **retired**: its weekly all-green mail is the brief's section 5; code, timer and state removed (state kept in `~/.local/state/automation/retired/`) |
| `heartbeat` | daily | gains a CRITICAL check that this week's brief ran |

**Checks and records.** A `check` is an assertion that can fail. A `record` is a measurement
that cannot; it lands in the weekly digest as "what happened". Records are summarised by the
runner, so a job touching 200 notes reports `200`, never 200 names.

**Tiers decide loudness.** `critical` re-alerts every run (a dead service on day three is not
less urgent than day one). `important` mails once, then reports while outstanding.
`routine` never mails.

**`covers=` is the join.** Each check names a concern slug from [[maintenance]]. The daily
`status` job reports concerns with no check, and checks naming no concern. See the generated
maintenance status page.

## Setup / rebuild

```bash
ssh <SERVER>
git clone <origin> ~/automation
sudo cp ~/automation/units/automation@.service \
        ~/automation/units/automation-alert@.service /etc/systemd/system/
sudo cp ~/automation/units/automation@<job>.timer /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now automation@<job>.timer
```

Credentials live in `~/.automation.env` (mode 0600): `GMAIL_USER`,
`GMAIL_APP_PASSWORD`, `MAIL_TO`, `HEALTHCHECKS_URL`, `PUSHOVER_USER`, `PUSHOVER_TOKEN`.
The last two feed `notify.send_push()` (Pushover). `notify.send_urgent()` pushes CRITICAL
failures, crashed jobs and WhatsApp bridge alerts, then mails them as the record; the full list
is [[push-notifications]] § Who pushes.

## Config

| Path | Contents |
|---|---|
| `~/automation/runner/` | `job.py` (the runner), `notify.py`, `config.py` |
| `~/automation/jobs/` | one file per job |
| `~/automation/tools/` | interactive tools, run via `bin/vt` |
| `~/automation/bin/run-job`, `bin/vt` | the only two entry points |
| `/etc/systemd/system/automation@*.{service,timer}` | one shared service template, one timer per job |
| `~/.local/state/automation/<job>.json` | state the digest and status page read |
| `~/.local/state/automation/<job>.memory.json` | machine state, new-vs-ongoing suppression |

## Gotchas

- **Cron cannot report on itself.** There is no equivalent of `LastTriggerUSec`, so the one
  remaining cron entry shows `unknown` in the schedule. A concrete argument for the pending
  migration to a timer.
- **`systemctl list-unit-files --state=enabled` is mostly Ubuntu housekeeping**: chrony, apt,
  logrotate, fstrim, sysstat. Real, but not things you own, and deliberately filtered out.
- **Never redirect a unit to its own file.** `claude-rc.service` used `StandardOutput=append:`
  and produced a 555 MB log of one repainted terminal frame. Everything writes to journald.
- **Not every job can use the system interpreter.** fitness sync needs its own virtualenv, so
  `bin/run-job` picks the interpreter. A second template for "jobs with dependencies" would be
  a second architecture.
- **Never hardcode `/usr/bin/python3`.** On macOS that is 3.9.6 and cannot parse modern type
  hints, so jobs run on the server and crash on the Mac. Use `python3` from `PATH`.
- **A completed `Type=oneshot` instance is unloaded**, so `systemctl show` reports it as never
  having run. Last-run comes from the job's own state file.
- **Many VPS providers block outbound 25 and 465.** Use port 587 with STARTTLS. A blocked port
  *hangs* rather than erroring, which reads exactly like a bad password.

### A job that asks a model

*These come from building `vaultmap`. They are about `runner.ask`, not about deterministic jobs.*

- **Silence must never read as success.** An answer in an unexpected shape can filter down to
  zero findings, and the job then reports "ok, 2/2 checks passed" on a file with confirmed
  errors. "Could not read the answer" and "nothing is wrong" need different code paths, and only
  one of them may pass.
- **A model finding nothing is evidence of nothing.** Two runs minutes apart on unchanged input
  can return seven findings and then zero. So a quiet run may claim only "no drift found this
  run", never "still correct". Only a positive finding is a result.
- **Ask it to describe, never to patch.** Handed a list of wrong lines with no view of the
  whole, it edits a diff: full paths written into a scoped list, a retired entry kept with a new
  path bolted on, commentary narrated into the document. Given the artefact plus the ground truth
  and asked what the file should say, it produces a structurally correct rewrite. The diff
  against the current file is then your finding list, which also deletes the bespoke output
  format that caused the failure above.
- **It adds and corrects well. It will not remove.** Defects that survive repeated runs are the
  ones needing deletion or shortening. Do the removals by hand; they are rare and take seconds.
- **Explicit instructions hold, general principles do not.** "This folder is enumerated" is
  obeyed every run. "Go deeper where the name does not tell you what is inside" is obeyed only
  sometimes. If it matters, name it.
- **Only automate where a ground truth exists.** This works because the directory tree is the
  answer key. Pointed at something with no external referent, the same job produces opinion,
  and opinion flaps.
- **A fixed problem is not a failing check.** Reporting corrected drift would mail and open a
  note every week the job worked. Suppressing the mail is a hack; not failing is the fix. Being
  unable to check still alerts.
- **Two model calls will blow `TimeoutStartSec`.** `ask()` defaults to 600s and the service
  template allows 600s total, so the pair is killed mid-run and reads as a crash.

- **Full list:** `~/automation/GOTCHAS.md`, one row per real failure and what now prevents it.

## Known limitations

- **One job needs judgement, and it is the exception that proves the shape.** `vaultmap` calls
  `runner.ask`, which runs `claude -p` with `--permission-mode dontAsk` and an allowlist of
  `Read`/`Glob`/`Grep`, and no Bash, because a shell is a write tool wearing a disguise. The model
  therefore holds no way to touch a file; Python writes its answer after checking it. Everything
  else here is deterministic Python. See the Gotchas above before writing a second one.
- **The alerting path is deliberately AI-free.** A hallucinated `critical` in a morning mail
  would destroy trust in every other email. When AI jobs arrive they must `record`, never `check`.
- **`maintenance.md` slugs are unenforced.** A typo in a `covers=` string shows up as an
  undeclared concern rather than an error, which is the intended failure mode but still needs
  a human to read it.
- **One cron job remains** (`fitness-data-sync`), unmigrated by choice.
- **One job is not a job at all.** `jobs/wa_consumer.py` is a long-lived HTTP daemon
  ([[_system/whatsapp-bridge|whatsapp-bridge]]), not a `Type=oneshot` run-exit-report unit, so it
  cannot use `automation@.service` or the `Job()` context manager and has its own unit. It still
  borrows the runner's config resolution, logging, state directory and `notify.send_mail`, so the
  alerting path stays single. **Do not generalise from it**: a second daemon would be an argument
  for a daemon template, which is the second-architecture split this runner exists to avoid.

## Decisions

**systemd timers, not cron.** Timers give journald integration, `Persistent=true` for missed
runs, `RandomizedDelaySec`, and critically `OnFailure=`, which the whole alerting layer hangs
off. Cron has no equivalent and cannot report whether it ran.

**A registry doc, not per-component maintenance sections.** The question being asked is
cross-cutting (*what do I check today?*), and answering it should not mean opening twelve docs.

**The schedule is generated, never hand-maintained.** A hand-copied machine fact always drifts;
only generation fixes that category.

**Code leaves the vault.** Obsidian Sync carries markdown, not `.py`, so scripts kept in the
vault diverge between machines. Docs sync through Obsidian, code moves through git, never the
reverse.

## History

The hand-maintained `cron-jobs.md` inventory is retired: its schedule is a generated section of
the maintenance status page, and its gotchas and decisions are above. Discipline does not fix a
document that copies a machine fact.

## See also

- [[maintenance]]: what needs looking after, and why
- The generated maintenance status page: what is watched right now, generated daily
- [[claude-auth-watch]]: the login watchdog, predates the runner
- [[vps-vault-host]]: the server everything runs on
- [[scheduled-execution]]: the three gaps that constrained unattended work
