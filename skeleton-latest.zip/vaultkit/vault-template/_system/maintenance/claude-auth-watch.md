---
type: reference
component: claude-auth-watch
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Claude auth watch: warns before the vault host's Claude Code login expires

**Status:** built. Both channels can be tested end to end (note written, mail delivered).
Referenced from `SYSTEM.md` § Components, registered in [[automation]].

## What it's for

The vault host's Claude Code login is a claude.ai subscription OAuth credential (every
scheduled AI job draws on the plan's 5-hour and weekly limits). Its refresh token has a hard
life of about 30 days. When it dies, [[vps-vault-host|claude-rc.service]] can no longer
authenticate and Remote Control goes down on your phone. Nothing recovers it until someone
signs in on the box.

**Claude Code does warn about this, three days out, at startup.** That does not help here:
`claude-rc.service` runs for weeks at a stretch, so the warning never fires. The daemon
structurally cannot tell you its own credential is dying. This watches from outside it.

The expiry itself cannot be removed. `claude setup-token` mints a one-year token, but
[the docs](https://code.claude.com/docs/en/authentication) state it can only make model
requests and **cannot establish Remote Control sessions or fetch claude.ai connectors**,
which is exactly what this box does. See `## Decisions`.

## How it works

A systemd timer runs `check.py` daily at 07:30 UTC. It reads `refreshTokenExpiresAt` from
`~/.claude/.credentials.json` and cross-checks `claude auth status --json`, so it catches
revocation as well as expiry.

- **More than 3 days left:** writes a line to `~/.claude-auth-watch.state` and exits quietly.
- **3 days or less, or already dead:** creates a task note in `Inbox/`, emails
  `<YOUR_EMAIL>` **and pushes to your phone** via `runner.notify` in `~/automation` (high
  priority). Repeats daily until renewed.

Renewal is one command from your Mac, which is what both the note and the mail tell you:

```bash
ssh -t <SERVER> renew-claude
```

`renew-claude` runs `claude auth login`, restarts `claude-rc`, and prints the new expiry.
The three steps are welded together on purpose (see `## Gotchas`).

**It only ever reports.** It never renews, never restarts, and never edits an existing note.

## Setup / rebuild

```bash
ssh <SERVER>
mkdir -p $VAULT_PATH/_system/claude-auth-watch ~/.local/bin
# place check.py and renew-claude, then:
chmod +x $VAULT_PATH/_system/claude-auth-watch/check.py ~/.local/bin/renew-claude
sudo systemctl daemon-reload
sudo systemctl enable --now claude-auth-watch.timer
sudo systemctl start claude-auth-watch.service   # run once to verify
```

Mail needs a Gmail app password on `<YOUR_GMAIL>`, written to `~/.claude-auth-watch.env` at
mode 0600. The script skips mail cleanly when that file is absent, so the note channel works
without it.

## Config

| Path | Contents |
|---|---|
| `$VAULT_PATH/_system/claude-auth-watch/check.py` | The check. **Lives on the box only. See Gotchas.** |
| `~/.local/bin/renew-claude` | One-command renewal helper |
| `/etc/systemd/system/claude-auth-watch.{service,timer}` | Daily 07:30 UTC, `Persistent=true` |
| `~/.claude-auth-watch.env` | `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `MAIL_TO`. Mode 0600 |
| `~/.claude-auth-watch.state` | Last run's result, one line |

Knobs: `WARN_DAYS` (3) and `OnCalendar` in the timer.

## Gotchas

- **`.py` files do not sync between the Mac and the vault host.** Obsidian Sync carries
  markdown plus `image, audio, pdf, video` only. Code in the vault is per-machine. Editing
  `check.py` on the Mac changes nothing on the box. This doc syncs; the script does not.
- **`systemctl` does not exist on macOS.** Running the restart without an `ssh` prefix
  authenticates sudo on the Mac and then silently does nothing. Check that your shell prompt
  shows the server, not the Mac, before running it.
- **Sign in with your personal account, never a work or school organization.** The browser
  OAuth uses whichever claude.ai account the browser is signed into. An enterprise org that
  does not allow Remote Control makes `claude-rc` log "Bridge environments are not available
  for this organization". Check the account on the consent page before approving; afterwards,
  `~/.local/bin/claude auth status --json` must not show that organization's `orgName`.
- **Signing in is not enough: the daemon caches credentials in memory.** `claude auth login`
  without `sudo systemctl restart claude-rc` leaves the old process running on dead tokens.
  This is why `renew-claude` exists rather than a list of steps.
- **Many VPS providers block outbound ports 25 and 465 by default.** Port 587 with STARTTLS
  works. A blocked port *hangs until timeout* rather than erroring, which reads like a bad
  password.
- **Google shows app passwords as four groups of four.** Pasted with spaces they are 19
  characters and Gmail rejects them; the script strips whitespace. A well-formed 16-character
  password that still returns `535 5.7.8` usually means it was minted under the wrong Google
  account. Check the account chip on the app-passwords page before generating.

## Known limitations

- **Does not renew anything.** Renewal needs an interactive browser OAuth, so it cannot be
  automated and cannot be one click. One command is the floor.
- **Single point of failure on the timer.** If `claude-auth-watch.timer` is disabled or the
  box is down across the whole warning window, nothing warns. `Persistent=true` covers a
  missed run on a box that comes back, not a box that stays down.
- **Mail delivery is unmonitored.** A send failure is recorded in the state file, but nothing
  reads that file. If Gmail revokes the app password, the note channel still works and the
  mail silently stops.
- **The 3-day window is tight if you are travelling.** `WARN_DAYS` is the knob.

## Decisions

**Locked: the expiry stays.** `claude setup-token`'s one-year token cannot establish Remote
Control sessions or fetch claude.ai connectors, and this box needs both (Remote Control is
its purpose; the `mcpOAuth` entries are connectors). Detection before expiry is therefore the
whole fix, which is also what the Claude Code docs recommend for unattended sessions. Revisit
if Anthropic ships a long-lived credential that carries Remote Control.

**Locked: notes are created, never edited.** The filename carries the expiry date, so each
cycle produces its own note. This sidesteps the two-writer conflict gap in
[[scheduled-execution]] entirely rather than working around it: the script never writes to a
file you might have open on your phone. Closing a note is always safe.

**Locked: the alert claims a high-priority slot.** The note is written `urgent: true` /
`priority: 4-high` / `scheduled: <today>`, per the Urgent convention in `SYSTEM.md`. This
consumes one of the 9 global high-priority slots for the ~3 days it is open. Accepted because
it is a hard deadline that takes down the whole remote setup; drop `priority` to `3-normal`
if the slot pressure ever matters more.

**Open: nothing watches the watcher.** If the timer is disabled, silence looks identical to
health. This is the same silent-staleness failure class as any other unattended job. Not
solved here.

## History

The failure this guards against: when the refresh token expires, Claude Code's refresh is
rejected and it blanks `accessToken` and `refreshToken` to empty strings with `expiresAt: 0`,
while `claude-rc.service` keeps printing `Connected` because the process never crashes, so
`Restart=always` gives no protection and the failure only surfaces later as an error on the
phone.

## See also

- [[vps-vault-host]]: the box, its services, sync configuration
- [[automation]]: registry of everything scheduled on the vault host
- [[scheduled-execution]]: the three gaps that constrained unattended work; this job is
  designed to avoid all three
