---
type: reference
component: llm-wiki
stage: partial
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T00:00
---

# LLM wiki schema: how the wiki is built and maintained

**Status:** partial as of <INSTALL-DATE>, verified <INSTALL-DATE>. Shipped as structure only: no
articles until the first ingest. Referenced from `SYSTEM.md` § Components and from `CLAUDE.md`
§ Always true. The workflow Claude follows is the `wiki` skill
(`_system/skills/wiki/SKILL.md`); this doc holds the rules and the reasons.

**These rules were recorded from real ingest passes, not specified in advance.** Karpathy's gist
says conventions should evolve through collaboration rather than be mandated, and this file is
where that collaboration's output is recorded. Update it from what ingests actually show.

## What it's for

A vault grows faster than anyone can reread it. Grep finds what you can name; it does not tell
you what you already concluded. The wiki is the compiled layer that does: a small set of articles
stating what the user thinks and knows, read before anything else, so a session starts from the
user's accumulated view rather than from the model's prior.

It is deliberately small. The constraint that makes it work is that `Wiki/index.md` is read whole
before any query, which is only affordable while it stays readable in one sitting.

## How it works

### The invariant

**The wiki is derived, never authored.** The user writes sources; the user and Claude only read
the wiki. Nothing appears in an article that does not trace to a source.

The rule is about **provenance, not process**. "Every claim traces to a source" and "only an
ingest run may write a page" are different rules, and only the first is needed. That is why
filing a query answer back as a page is allowed.

Consequences:

- Obsidian has no per-folder read-only, so the invariant is held by the lint pass, not by
  permissions. Every article carries `wiki_sources`; a claim that cannot be traced is a defect.
- **Disagreeing with an article means fixing the source, then re-ingesting.** Not editing the
  page. The first time this is inconvenient is when the invariant silently breaks.

### Layers, and who owns what

| Layer | Owner | Holds |
|---|---|---|
| Sources: `Areas/`, `Projects/`, `Inbox/`, `Resources/`, any imported notes | the user | Everything raw. Edited freely |
| `Wiki/` | Claude | Narrative and synthesis. Never hand-edited |
| Profile layer: [[Areas/Master Profile\|Master Profile]] and sub-profiles | Claude, on the user's say-so | **Atomic dated facts**, with tiers and shelf lives |

**The wiki and the profile layer divide by kind, not by topic.** *"Prefers 25-minute review
sessions"* is atomic and dated: profile. *"Every study method that stuck was one with a fixed
daily slot, and every one that failed relied on remembering to do it"* is synthesis that ages
differently: wiki. The wiki may link to a profile note and never restates its content.
Duplicating facts is the "two contradictory facts, retrieve the wrong one" failure
[[_system/profile-convention|profile-convention]] is written against.

Where a topic already has an owned treatment elsewhere (a carefully maintained note on a
subject), the wiki registers that note as a **source** and cites it rather than writing a
competing article.

### What is not a source

Three tests. Fail any one and it is not distilled:

1. **Does it assert anything?** A body of nothing but wikilinks is navigation furniture. Imports
   from other notes tools produce one folder-index page per folder or database; a naive full
   ingest produces a wiki of contents pages.
2. **Is there text, or only a container?** Empty tables, notes that are only attachment embeds.
   These get indexed, not distilled.
3. **Is it knowledge or logistics?** Dated arrangements that expire (a project plan, a season's
   schedule) belong to the task and calendar layer.

A fourth category exists and is not a failure: **some real sources are for reading, not
compiling.** A collection of favourite quotes has no concept in it, and summarising destroys the
only thing it is. Index it, leave it alone.

### Course material

Bulk course material (the course archive, see `_system/canvas-archive.md`) stays **indexed, not
distilled**. It enters the wiki only through engagement: the user's own submissions, `Inbox/`
`type: learning` notes, or gap-capture. Reasoning: the wiki's value is the delta over what the
model already knows, and most of a course archive by words is curriculum the model has. Its
`canvas_kind` frontmatter makes most of the rejection mechanical: `sync-log` and `modules` are
navigation, `announcement` is expiring logistics.

### The stub bar

**Two sources touch it, or one source plus an existing vault note.** Volume alone never justifies
a page. Candidates that fail the bar are not written as stubs; they sit on the relevant source
page and get promoted when a second source arrives.

### Ingest

1. Read every source in the slice.
2. **Step A: the map only.** Proposed article list, which passages feed each, why anything
   merged, what was rejected and under which test. **Then stop for review.** This stops the wiki
   being organised in a way the user would not have chosen. Once the user trusts the structural
   calls, they can hand them back.
3. Write the articles, `index.md` entries, backlinks in both directions, `log.md`, `_sources.md`.
4. Lint.

Karpathy's guidance is that one source touches ~10-15 pages, not just forward links from new
pages. Check every existing article a source bears on, not only the new ones.

### Filing an answer back

One test: **can every claim in this answer be traced to something already in the vault?**

| | Route |
|---|---|
| Synthesis over existing material: the connection is what is new | **Write the page** |
| The user said something new in conversation | **Capture to `Inbox/` first**, then distil. New input arriving through the chat channel |
| Claude supplied it: model knowledge, web research, an imported framework | **Foreign body.** Capture deliberately as a source, or it does not go in |

Two safeguards: query-derived pages carry `wiki_origin: query` so the lint pass audits that class
harder; and **pages cite sources, never other wiki pages as evidence.** Otherwise grounding thins
across generations while each step looks locally fine, and a restructure starts breaking pages
that depended on other pages existing.

The stub bar still applies. Not every good answer earns a page.

### Gap-capture

**Before answering, check the wiki. If it could not fully answer, log the gap in `log.md`.** The
wiki grows toward the questions it failed rather than toward whatever happened to be fed in. This
is the mechanism that scales past anyone's ability to pre-decide across thousands of files, and
it is the only route by which course material becomes an article.

### Updates to existing sources

**Karpathy's pattern assumes sources arrive append-only. Vault sources grow in place.** This is
the one genuinely new piece of design here.

`Wiki/_sources.md` is a generated file with **two** tables: sources that were distilled, and
sources that were judged and deliberately not distilled. Both carry a hash. The second table is
what stops the detector reporting the same rejected notes as pending forever, and it means a note
that *grows* into a real source gets noticed rather than staying rejected on the strength of an
old judgement.

A changed hash means the articles that source fed are candidates for re-ingest. **Re-ingest is
diff-scoped, not whole-file:** feed the changed lines plus the articles that source fed, and ask
one question: does this change the claim? Three outcomes: no change, amend the article, or a new
article is warranted. Whole-file re-read only when a file was restructured rather than appended
to.

Sources that are registered but never distilled (an owned topic note, the profile notes) are
listed so that editing them flags the articles that cite them.

### Lint

Monthly, declared in [[_system/maintenance/maintenance|maintenance]] as `wiki-lint`. Checks:

- **Traceability.** Every article has `wiki_sources`; spot-check claims against them.
- **Broken wikilinks**, in both directions.
- **Contradictions** between articles: flagged in-article with quotes, never silently smoothed.
- **Stale provisional sections:** material derived from a live document whose situation has
  moved. When that situation resolves, those articles need rewriting, not amending.
- **Orphans.** Reported, not fixed. **An orphan is not a synonym for defect**: manufacturing
  inbound links to satisfy a graph metric is the failure mode. Some pages are deliberately
  unlinked.

## Config

- `Wiki/index.md`: the catalog, organised **by kind** (concepts, sources), never by life area.
  The best results cross areas; a life-area catalog fights the pattern's purpose. Target under
  200 lines.
- `Wiki/log.md`: append-only, `## [YYYY-MM-DD] kind | title`, so `grep "^## \[" log.md` lists
  everything.
- `Wiki/_sources.md`: generated, `last_run`, never hand-edited.
- `Wiki/_pending.md`: generated daily by `jobs/wiki.py`. What is outstanding now, plus a dated log
  of what moved. **Findings never go to `Inbox/`**: Inbox is the task list, and a daily job
  posting there would bury real work under status updates within a week. The checks are `ROUTINE`
  for the same reason: real, never worth an interruption. The one exception is
  `_sources.md parsed`, which is `IMPORTANT`: the detector being blind is a different event from
  what it finds.
- **The server owns the changelog.** History lives in the job's machine-local memory, so two
  machines running it for real would render competing pages into one synced file. Any other
  machine only ever `--dry-run`s, which writes neither memory nor page.
- `Wiki/Wiki.md`: the Obsidian folder note (the `X/X.md` convention in the
  [[_system/README|Vault Map]]). Deliberately **not** the catalog.
- Frontmatter: `type: wiki`, `wiki_sources`, `wiki_origin` (`ingest`|`query`), `wiki_ingested`.
  Registered in [[_system/frontmatter-properties|frontmatter-properties]].

## Gotchas

- **`Wiki/Wiki.md` is not `Wiki/index.md`.** The first is the folder note; the second is
  Karpathy's catalog. Writing the catalog into the folder note means the read-first step reads
  the wrong file.
- **Never distil a note carrying a credential pointer.** A note that says where a password lives
  is cited as a link and never summarised. No credential of any kind is recorded in the wiki, at
  any tier, ever.
- **Third parties.** Articles are drawn at what the user concluded, never at what someone else is
  like. Anything about a named third party's health, finances or relationships is raised before
  it is recorded anywhere.
- **`type: learning` is doing double duty.** Many `Inbox/` notes typed as learnings are really
  captures (book recommendations, contact names), not learnings. Apply the stub bar at ingest
  rather than trusting the type.

## Known limitations

- **No unattended distillation.**
  [[_system/maintenance/scheduled-execution|scheduled-execution]] records three open gaps:
  two-writer conflicts, no propose-don't-perform mechanism, no non-interactive permission mode. A
  distillation job uses tools and rewrites existing pages, so it trips all three. Ingest is
  session-triggered until they close.
- **Detection is automated; re-ingest is not.** `jobs/wiki.py` on the server runs daily, before
  the `status` join, and reports drifted sources, deleted sources, articles citing an
  unregistered source, and unjudged ingest candidates. It never writes an article. Re-ingest is a
  session the user starts, because rewriting existing articles unattended is the half the three
  gaps make unsafe. **Splitting the job this way is what makes any of it automatable today:** a
  pure reporter is the same shape as `claude-auth-watch`, which trips none of the three.
- **No semantic index.** Retrieval is catalog plus grep. If the gap log shows the course archive
  is genuinely unreachable that way, build it in the kit's automation repo as a `vt` command,
  never as an Obsidian plugin, since embeddings in a dotfolder would live on one machine only and
  fail the [[_system/vps-vault-host|vps-vault-host]] standing rule.

## Decisions

**The wiki is derived, never authored.** Rejected the looser version where the user may edit
articles directly: reconstructibility from sources is what makes restructuring cheap, and a
hand-edited page silently stops being reconstructible. Cost accepted: correcting an article is
two steps rather than one.

**Course material is indexed, not distilled.** Rejected distilling every course (hundreds of
articles, `index.md` unreadable, a huge input cost) and rejected one summary article per course
(manufactures pages for courses the user has nothing to say about, and several fail the stub
bar). Accepted cost: cross-course synthesis exists only once gap-capture pulls it in, so a
synthesis the user never thinks to ask for never gets written.

**This schema is written from real ingests, not before them.** Rejected specifying first: trial
passes changed the design in ways nobody predicted, and a prediction is not better than a first
article.

## See also

- `Wiki/index.md`: the catalog. Start there, not here.
- `_system/skills/wiki/SKILL.md`: the ingest, query and lint workflow, step by step
- [[_system/profile-convention|profile-convention]]: the other derived layer, and the boundary
- [[_system/frontmatter-properties|frontmatter-properties]]: where `wiki_*` is registered
- [[_system/maintenance/maintenance|maintenance]]: `wiki-lint` and `wiki-source-drift`
