---
type: reference
component: fitness-data-sync
stage: design-only
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Fitness data sync: Strava + WHOOP connected on the server

**Status:** optional component, **not installed** until you follow Setup / rebuild below. Once
both services are authorised and the cron entry is in, set `stage: built` and `verified:` here.
If you never install it, delete this doc. Once installed, Strava and WHOOP are live OAuth
connections with stored refresh tokens that any script can reuse, not just the job built on them.
It runs as a plain Python cron job, not a `claude -p` job. Referenced from `SYSTEM.md` §
Components. Related: your training-log note, your training-plan note.

## What it's for

**The general capability: Strava and WHOOP are both connected.** The server holds working OAuth
credentials and refresh tokens for both APIs (`~/.fitness-sync/config.json`). Any later script on
the server can reuse this connection to read Strava or WHOOP data, with no need to re-authorise
or build a second connection for a different use. See "Using this connection for something else"
below.

**The one thing built on it: auto-logging into a training log.** Writing training-log entries by
hand from pasted Strava and WHOOP screenshots works, but only when you remember to paste them.
`sync.py` closes that gap: it checks Strava for new runs on a schedule, matches each one to the
corresponding WHOOP workout, and appends a numbers-only entry to the training log automatically.
Reviewing sessions in chat still happens on top of this when you share screenshots; this job only
replaces the "get the raw numbers into the log" step.

## How it works

Runs `sync.py` every 2 hours via crontab on **<SERVER>** (`27 */2 * * *`, deliberately *not* on
the hour, see the WHOOP desync gotcha below). See [[_system/vps-vault-host|vps-vault-host]]. Each
run:

0. Takes an exclusive `flock` on `~/.fitness-sync/sync.lock` and exits immediately if another run
   holds it, then **forces a WHOOP token refresh via `get_profile()` whether or not there is a new
   run to log**, so the credential never goes cold (see below).
1. Refreshes the Strava and WHOOP access tokens from the stored refresh tokens.
2. Lists **every** Strava activity (no limit) from the earlier of cursor minus 3 days or now minus
   21 days, filters to `Run`/`TrailRun` of 5+ minutes, and skips any Strava ID already logged. The
   fixed 21-day re-scan is deliberate: any run a cursor bug skips is picked up on the next cycle.
3. For each new run, looks up WHOOP workouts starting within a ±20 minute window of the Strava
   activity's start time and takes the one starting closest to the run, plus the most recent WHOOP
   recovery reading (recovery %, resting HR, HRV) at or before the run. Recovery is a once-a-day
   waking score, so this looks back up to 30h rather than using the tight workout-matching window.
4. Formats distance, elevation, pace, splits, any Strava-flagged PRs, WHOOP's per-zone time
   breakdown, and that morning's recovery reading into a markdown block, and appends it to
   `Projects/<YOUR_TRAINING_PROJECT>/training-log.md` under a `### <date> (auto-logged)` heading.
5. Persists the sync cursor (advanced past every activity seen, runs or not), the logged-ID dedup
   list, and a `problems` list to `~/.fitness-sync/state.json`. All writes are atomic (temp file +
   fsync + rename); the Strava refresh token is persisted the moment it rotates.
   `automation/jobs/heartbeat.py` reads `problems` daily and mails + writes an Inbox note if it is
   non-empty (concern `fitness-sync-correct` in [[_system/maintenance/maintenance|maintenance]]).
6. Rewrites the status note `_system/fitness-sync-status.md` in the vault with last-run time,
   per-service health, the sync cursor and any error. This makes a broken credential visible from
   Obsidian on any device within one cron cycle, rather than only to someone who SSHes in and
   greps `sync.log`.

If Strava isn't authorised yet, or nothing new happened since the last run, it does nothing and
exits 0, so it is safe to leave running unconditionally. **The very first run after authorisation
is a bootstrap**: it just records "now" as the sync cursor and logs nothing, so it never tries to
backfill history you already logged by hand.

Uses two existing, actively maintained libraries rather than hand-rolled OAuth/REST code:
`stravalib` (Strava v3 API) and `whoop` (`hedgertronic/whoop`, WHOOP API v2). Both handle token
refresh and pagination internally.

### Using this connection for something else

Both `config.json` and both libraries are already set up, so a new script doesn't need to touch
OAuth at all, just reuse the stored token the same way `sync.py` does:

```python
import sys
sys.path.insert(0, "<VAULT_PATH>/_system/fitness-data-sync")
from common import load_config, save_config

# Strava
from stravalib.client import Client
config = load_config()
strava = config["strava"]
client = Client()
token = client.refresh_access_token(
    client_id=int(strava["client_id"]),
    client_secret=strava["client_secret"],
    refresh_token=strava["refresh_token"],
)
strava["refresh_token"] = token["refresh_token"]  # Strava may rotate it -- always re-persist
save_config(config)
client.access_token = token["access_token"]
# client.get_athlete(), client.get_activities(), etc.

# WHOOP
from whoop import WhoopClient
config = load_config()
whoop = config["whoop"]
whoop_client = WhoopClient(
    whoop["client_id"], whoop["client_secret"], token=whoop["token"],
    on_token_refresh=lambda t: (whoop.__setitem__("token", t), save_config(config)),
)
# whoop_client.get_sleep_collection(), get_recovery_collection(), get_cycle_collection(), etc.
```

Use the venv at `~/.fitness-sync/venv/bin/python`; it already has both libraries installed. If a
second real consumer shows up, see the "Decisions" entry on doc scope below before adding more to
this file.

## Setup / rebuild

**From zero** (new box, or re-authorising after a revoke):

1. Make sure `python3-venv` is installed via apt, create the venv at `~/.fitness-sync/venv`, and
   `pip install -r requirements.txt` inside it. Versions are **pinned**, not latest: installing
   latest on a rebuild can silently reintroduce a library break (see the `.root` gotcha below).
   Bump versions here deliberately, then verify with `grep WARNING sync.log` after a manual run,
   rather than trusting a fresh `pip install` blind.
2. Register a Strava API app at <https://www.strava.com/settings/api>. "Authorization Callback
   Domain" should be the server's domain (`<SERVER_DOMAIN>`). Note the Client ID and Client
   Secret.
3. Register a WHOOP API app at <https://developer.whoop.com>: free and self-serve, no approval
   needed for personal use (dev mode covers up to 10 WHOOP members). Redirect URI:
   `https://<SERVER_DOMAIN>/callback`. Note the Client ID and Client Secret.
4. Give both Client ID/Secret pairs to Claude (in chat is fine: they get written straight to
   `~/.fitness-sync/config.json`, chmod 600, never into the vault).
5. Claude runs `oauth_strava.py` and `oauth_whoop.py` on the server and relays the printed
   authorisation URL; you open it, log in, authorise, and paste back the resulting
   (broken-looking) redirect URL. One round trip per service.
6. Install the crontab entry (see Config) and verify each service with a live `get_athlete()` /
   `get_profile()` call.

After that, everything (the cron job and any script per "Using this connection for something
else") is fully unattended: refresh tokens keep it running without further consent prompts
(Strava refresh tokens don't expire from inactivity; WHOOP's are rotated and re-persisted
automatically on every refresh via `on_token_refresh`).

## Config

| Path | Contents |
|---|---|
| `_system/fitness-data-sync/*.py` | The scripts. **These do NOT sync via Obsidian** (its file-types list excludes `.py`), so on your other devices this folder is empty. Version them in the server's vault git repo and edit them on the server only. |
| `_system/fitness-sync-status.md` | Vault-visible health note, rewritten every run |
| `~/.fitness-sync/sync.lock` | `flock` target so two runs can't race the WHOOP token rotation |
| `_system/fitness-data-sync/requirements.txt` | Pinned dependency versions |
| `~/.fitness-sync/config.json` | Client IDs/secrets and OAuth tokens, chmod 600 |
| `~/.fitness-sync/state.json` | Sync cursor (`last_synced_iso`) and a bounded window of already-logged Strava activity IDs (dedup) |
| `~/.fitness-sync/venv/` | Isolated Python env (`stravalib`, `whoop`) |
| `~/.fitness-sync/sync.log` | App-level log, rotated at 1 MB x 3 |
| `~/.fitness-sync/cron.log` | Raw stdout/stderr from cron itself |
| `crontab -l` on the server | `27 */2 * * *` → `venv/bin/python sync.py` |

Redirect URI for both OAuth apps: `https://<SERVER_DOMAIN>/callback`. The domain must exist
(Tailscale Funnel, see [[_system/vps-vault-host|vps-vault-host]]) but nothing needs to listen on
it, since both `oauth_*.py` scripts use the manual "paste the redirect URL back" flow rather than
a live callback listener.

## Gotchas

- **`stravalib`'s internal request logging writes `client_secret` and `refresh_token` in plaintext
  at INFO level**, and a default-created `sync.log` is 644 (world-readable). `sync.py` therefore
  pins `logging.getLogger("stravalib")` (and `requests_oauthlib`) to `WARNING`, and explicitly
  chmods `sync.log` to 600 on creation rather than trusting umask. If you touch this logging setup
  again, verify with `grep -i secret sync.log` after a real token refresh, not just a syntax check.
- **Two-writers-on-one-file risk is real here, not hypothetical.**
  [[_system/maintenance/scheduled-execution|scheduled-execution]] flags this as an open gap for
  any job that writes into the vault while Obsidian Sync is also live. This job appends to
  `training-log.md` every 2 hours; if you are editing that exact file in Obsidian at the same
  moment, Sync's last-write-wins behaviour could drop one side's edit. Low probability but not
  zero.
- **This job does not use `claude -p`.** It's a plain deterministic script, which sidesteps two of
  `scheduled-execution.md`'s three blocking gaps entirely: there's no non-interactive permission
  problem (no agent, so no tool-use prompts) and no "propose, don't perform" gap (the content is
  objective sensor output, not an agent's interpretation). Only the two-writers gap above carries
  over.
- **WHOOP can silently desync its refresh token, and the cause is WHOOP's design.** WHOOP rotates
  the refresh token on every use and invalidates the previous one immediately, with **no grace
  period**, and *rotation commits server-side even when the client-facing response is a 502 or
  times out*. One slow or failed refresh therefore desyncs the credential permanently,
  recoverable only by re-running `oauth_whoop.py`. Two things make a job likely to hit it, and
  this one avoids both:
  1. **Cron firing exactly on the hour.** WHOOP's token endpoint bottlenecks at :00/:15/:30/:45
     when every scheduled job on their platform fires at once. Hence `27 */2`.
  2. **Calling WHOOP only when a new Strava run appears**, so the token sits idle and every
     refresh is a "cold" request, the case where WHOOP's endpoint takes 7-18s and blows past a
     default client timeout. `sync.py` calls `get_profile()` on **every** run to keep the
     credential warm, capping the idle window at ~2h.

  Also in place: a 30s HTTP timeout, persist-before-use in `on_token_refresh` with the prior token
  kept as `token_previous` so a desync can be told apart from an expiry, and an exclusive `flock`
  so two overlapping runs can't race the rotation.
  **Symptom to recognise:** `authlib ... OAuthError: invalid_request` on every WHOOP call while
  Strava keeps working, and training-log entries reading "no matching workout found" / "no reading
  found". That is a dead credential, not missing data: the workouts are still in WHOOP and can be
  backfilled through the API. **Sport type is a red herring here**: `find_matching_workout`
  applies no sport filter at all, and Strava's `RUN_TYPES` already includes `TrailRun`.
- **WHOOP matching is time-window-based, not activity-linked.** If two workouts start within 20
  minutes of each other (e.g. a warmup walk logged separately), the match could grab the wrong
  one. Worth a glance if a logged entry's WHOOP numbers look off.
- **`get_activities(after=...)` and WHOOP's collection window both key off UTC.** Local-vs-UTC
  date boundaries aren't an issue in practice since matching is by exact timestamp, not calendar
  day, but remember it when eyeballing `state.json`.
- **`stravalib`'s `activity.type`/`sport_type` are not plain strings.** Newer versions return a
  `Relaxed*Type` wrapper whose `str()` is `"root='Run'"`, not `"Run"`, so a plain string
  comparison silently matches nothing while the job runs without error and logs "no new run
  found". `sync.py`'s `_type_str` unwraps `.root` before comparing. Two safeguards make a
  recurrence visible: (1) `sync.py` logs at **WARNING** whenever Strava returns activities in the
  window but none match `RUN_TYPES`, listing the raw type strings seen, so `grep WARNING sync.log`
  surfaces it; (2) a staleness tripwire logs WARNING if 5+ days pass with nothing logged. The
  pinned `requirements.txt` exists so a rebuild can't silently reintroduce this class of drift.
- **A capped activity list plus a cursor that only advances on a logged run can skip runs
  indefinitely while every health signal says green.** With `limit=15`, non-run activities can
  fill every slot, so each run re-reads the same non-runs and never reaches later runs. Hence: no
  limit, the cursor advances past everything, a fixed 21-day re-scan with ID dedup (self-heals any
  skip), and the heartbeat correctness check. Backfilled runs are appended at the end of the log,
  so they may sit out of date order.
  **Lesson:** a freshness check proves a job ran, not that it did its job. Check the output
  against the source.

## Known limitations

- **Numbers only, no narrative.** Auto-logged entries carry distance, pace, splits, elevation,
  PR flags, and WHOOP zone percentages. They do **not** carry the contextual analysis a chat
  review produces (soreness notes, terrain constraints, "was that walking or running", etc.); that
  judgment requires the conversation, not a script. Auto-logged entries are a numbers backbone;
  chat review adds the rest on top.
- **Doesn't cross-reference `training-plan.md`.** An auto-logged entry doesn't know what that
  day's session was supposed to be, so it can't flag deviations from the plan the way a
  hand-written entry can. Would need date-based lookup against the plan; not built.
- **Run-type filter is Strava's `Run`/`TrailRun` only.** A hike, gym session, or anything else
  logged to Strava is ignored, even if it's a real training session, and sessions not recorded in
  Strava are never seen.

## Decisions

- **Cron + plain script, not a scheduled `claude -p` agent.**
  [[_system/maintenance/scheduled-execution|scheduled-execution]] documents blocking gaps for
  unattended agent runs on the server. Rather than wait on them or build around them, this job is
  deliberately *not* an agent: it's the same shape as `obsidian-sync.service`, a deterministic
  process with a narrow job.
- **Append directly, no staging/review file.** A separate pending file to fold in by hand would
  match the "propose, don't perform" principle, but the data is objective sensor output, not
  interpretation, so the risk that principle guards against doesn't apply the same way.
- **Existing libraries (`stravalib`, `whoop`) over hand-rolled OAuth/REST calls.** Both are
  actively maintained and already handle the fiddly parts (token refresh, pagination, WHOOP's
  refresh-token rotation) correctly.
- **Manual OAuth flow (paste-the-redirect-URL) over a live callback listener.** A live listener
  would need something on the server reachable from whatever device you authorise from, which
  adds moving parts for a step that runs once per API.
- **One doc covers both "the connection" and "the training-log job", not split into two.** A
  standalone connection doc (the way `gmail-mcp.md` documents the mailbox independently of any one
  flow) is justified when there are many consumers; this integration has one. **Split it if a
  second real consumer shows up**: move Setup / rebuild, Config and the reuse snippet into a
  `strava-whoop-connection.md` for the credential layer and let this doc narrow to the
  training-log job. The "Using this connection for something else" section is the seam to split
  along.

## See also
- Your training-log note: what this job writes into.
- `_system/fitness-sync-status.md`: the generated health page.
- [[_system/vps-vault-host|vps-vault-host]]: the box this runs on.
- [[_system/maintenance/scheduled-execution|scheduled-execution]]: the gaps this job does and
  doesn't inherit.
- [[_system/SYSTEM|SYSTEM]]: the hub.
