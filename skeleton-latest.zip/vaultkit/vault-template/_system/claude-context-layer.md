---
type: reference
component: claude-context-layer
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Claude context layer: what a session knows when it starts, and how it learns what earlier sessions did

**Status:** built. Referenced from `SYSTEM.md` § Components.

## What it's for

Every Claude session starts with only what is loaded into it. This doc owns how that is wired:
which files load where, why, and the two mechanisms that carry knowledge between sessions:
the **write-back rule** (findings go back to the file that owns them) and the **session log**
(what each session worked on).

## How it works

### What loads at session start

- **Claude Code, Mac and <SERVER>:** `~/.claude/CLAUDE.md` loads in every project. It is a copy
  of [[_system/claude/global-CLAUDE|global-CLAUDE]], refreshed by a SessionStart hook
  ([[_system/claude/README|_system/claude]]). It `@import`s the vault's `CLAUDE.md` and
  [[Claude Master Router]], so both load wherever the session was started. Auto-memory comes from
  `_system/claude/memory/` on both machines.
- **The `@import` is a workaround.** The desktop app has no default working directory setting, so
  a session started outside the vault would otherwise never see the vault's `CLAUDE.md`.
- **Cowork** drops user-scope imports that resolve outside the session's working directory, and
  ignores a symlinked `~/.claude/CLAUDE.md` (which is why the global file is copied, not linked).
  The global file tells a session to read both files directly when the import did not load.
- **Claude chat (claude.ai) over MCP** gets none of these files. It gets the vault's MCP server
  instructions ([[mcp-instructions]]) and whatever it reads.

### The write-back rule

`CLAUDE.md` § Always true: when a session learns something a file should have told it, it writes
it back to the owning file in the same session, **updating in place, never appending**. The test is
"does this contradict, or is it absent from, the file that claims to own the subject". It does not
depend on detecting a session's end, which Claude cannot do reliably.

### The session log

What every session worked on, both machines, rolling 7 days: the session log page in
`_system/claude/`, with older days in the session log history page beside it. **On demand only**:
one Router line, never preloaded, so its length costs nothing until a session needs it (enriching
tasks, planning a day, "what did we do on X").

1. **Digest** (`~/automation/tools/session_digest.py`, no model): each transcript becomes a few KB
   with the prompts, files edited, commit messages, side-effecting actions (a Gmail draft, a
   calendar event) and the session's final message. Headless `claude -p` job runs
   (`entrypoint: sdk-cli`) and subagent records are skipped.
2. **Mac push:** launchd agent `<YOUR_LAUNCHD_PREFIX>.session-digest` runs `--push` every 30
   minutes while the Mac is awake and copies the Mac's digests to
   `<SERVER>:~/.local/state/automation/session-digests/mac/`.
3. **Job** `jobs/session_log.py` on <SERVER>, 04:30 and 13:00 in `<YOUR_TIMEZONE>`: digests the
   box's own transcripts (Telegram bridge and Remote Control), adds the Mac's, the day's vault git
   changes and `~/automation` commits, and asks once per day for three sections: **Worked on**,
   **Tasks and build items** (linked, with "possibly stale"), **Open threads**. Python places the
   result; the model never sees the page.

## Setup / rebuild

- Box: `sudo cp units/automation@session_log.timer /etc/systemd/system/`, the same for
  `units/automation@session_log.service.d/`, then `sudo systemctl enable --now
  automation@session_log.timer`.
- Mac: `cp ~/automation/units/mac/<YOUR_LAUNCHD_PREFIX>.session-digest.plist ~/Library/LaunchAgents/`
  and `launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/<YOUR_LAUNCHD_PREFIX>.session-digest.plist`.
  Log: `/tmp/session-digest.log`.
- Preview without writing anything: `python -m jobs.session_log --preview --days 7 --out <file>`.
- Tests: `python -m tests.session_digest`, `python -m tests.session_log`.

## Config

- `WINDOW_DAYS = 7` and the schedule live in `jobs/session_log.py` and its timer.
- A day is rewritten on each run until a run after its end has written it (`<!-- final -->`).

## Gotchas

- **The Mac's system `python3` is 3.9** and fails on the module's type hints. The plist uses
  `~/automation/.venv/bin/python`.
- **The box runs on UTC.** Days are cut in `<YOUR_TIMEZONE>` in code, and the timer states the
  zone explicitly.

## Known limitations

- **Transcripts are pruned after 30 days** on both machines (no `cleanupPeriodDays` set). The log
  is the only thing that outlives them.
- **A Mac session is seen only after its next push.** If the Mac is shut straight after a session,
  that session reaches the log on the next wake.
- **The job never edits a task.** It names stale ones; the planner, enrichment or you act.
- Whether a summary is faithful is not checked. Structure is guarded, and the runner's vault
  commit is the revert path.

## Decisions

- **Transcripts as the main source, git as support.** Git shows which files changed, not what was
  worked on. Mac transcripts never sync, so the Mac pushes digests; this keeps the standing rule
  because Mac sessions only exist while the Mac is on.
- **Daily, twice, with a rolling window and a permanent history**, not a weekly page, because the
  purpose is keeping tasks current.
- **Full detail, loaded on demand.** Not capped, because nothing preloads it.
- **Sonnet, not Opus.** Summarising is not planning. `MODEL` in `jobs/session_log.py`.
- **`_system/claude/` for the pages:** it already owns Claude's context layer.

## See also

[[_system/claude/README|_system/claude]] · [[vps-vault-host]] (§ Standing rule, Remote Control
transcripts) · [[telegram-bridge]] · [[maintenance]] (`session-log`) · `~/automation/runner/ask.py`
