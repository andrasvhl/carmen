---
type: reference
component: push-notifications
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Push notifications: Pushover alerts from <SERVER> to your phone

**Status:** built. Critical alerts push (§ Who pushes). Referenced from `SYSTEM.md` § Components.
**Split by urgency:** Pushover keeps what is urgent; non-urgent proactive messages go to the
Telegram bridge ([[telegram-bridge]]). The weekly maintenance brief was the first to move.
Everything else here stays on Pushover until more callers move.

## What it's for

**Push notifications get read promptly; email often does not.** Record your own reachability in
[[Areas/Master Profile|Master Profile]] § Reachability. Anything urgent or time-sensitive must
reach you by push, not mail. The typical case: a capacity-limited event opens registration and
sells out within hours, while the only alerts were a digest item and a blast email
([[signal-definition]] Gotcha 5).

## How it works

`runner/notify.py` in `~/automation` has `send_push(title, message, *, url=None, url_title=None,
priority=0, device=None, retry=None, expire=None)`, beside `send_mail()` and `write_note()`. It POSTs to Pushover's messages API from
<SERVER>, so it works with your laptop shut. The Pushover app on your phone receives it.

| Channel | Use it for | Read |
|---|---|---|
| **Push** (`send_push`) | Urgent or time-sensitive: a registration opening, a lottery closing, a same-day deadline, a failure you must act on now | Promptly |
| **Email** (`send_mail`) | Reports, digests, anything that can wait a day | Not promptly |
| **Note** (`write_note`) | The work itself, as a task in `Inbox/` | On your triage cadence |

**Priority:** `-1` quiet, `0` normal, `1` high (bypasses quiet hours), `2` emergency (plays
through mute and Focus, repeats every `retry` seconds until acknowledged or `expire` runs out).
`2` is refused unless the caller passes `retry` >= 30 and `expire` <= 3600. A `url` makes the
notification one tap from the registration page or thread.

**`send_urgent(subject, body, *, push_message, priority)`** is what callers use for failures:
push first, then mail the full detail as the record. A failed push prefixes the mail subject
`[PUSH FAILED]`.

### Who pushes

| Alert | Where | Priority |
|---|---|---|
| Claude Code login expires within 3 days, or expired | box-only `claude-auth-watch/check.py`, imports `runner.notify` | 1 |
| A CRITICAL check fails in any job report | `runner/job.py` `_report` | 1, **push only** (`notify.push_or_mail`); mail only if the push fails, `[PUSH FAILED]` |
| A job itself crashed (`FAILED to run`) | `runner/alert.py` | 0, **logged** in the vault alert log; push only on the same job's **second crash in a row** |
| WhatsApp ban tripwire | `jobs/wa_consumer.py` | 1 |
| WhatsApp bridge DOWN, delivery failure, account standing changed | `jobs/wa_consumer.py` | 0 |
| Weekly maintenance brief ready, "Maintenance: 2 need you, 3 fixed" | `jobs/maintenance_brief.py`, weekly on Monday | 0, links to the note |
| The maintenance brief did not run this week | `jobs/heartbeat.py`, CRITICAL check | 1 |
| **Routine reminders** (content, not alerts): the morning and evening reminders defined in your routine notes | `jobs/routine_push.py`, text from the routine notes ([[routine-push]]) | 1 for morning, 2 for evening reminders that must be acknowledged; a `2` repeats at its `retry` interval until acknowledged or `expire` runs out |

**Not pushed, on purpose:** important and routine check failures, "recovered" notices, weekly
reports, WhatsApp system-message notices. A push channel that carries drift gets muted.
Test: `python -m tests.urgent_push`.

Important and routine failures do not mail either: they go to
`_system/maintenance/alert-log/<YYYY-MM>.md` and reach you in the Monday brief. Mail remains only
as a fallback, when a push fails or the log cannot be written (`[LOG FAILED]`).

**Failure is loud.** A missing key, an HTTP error or Pushover answering anything but `status: 1`
raises `PushUnavailable`. Callers catch it and fall back to mail, the same contract as
`MailUnavailable`. A push is never silently dropped. **When mail stands in for a failed push, its
subject must say so**, or the urgency is lost without trace.

## Setup / rebuild

1. Pushover app on your phone, account created, notifications (including Critical Alerts) allowed.
2. pushover.net: copy the **User Key**; **Create an Application/API Token** named after your
   server (e.g. `<SERVER>`), type Script, copy the **API Token**.
3. Add both to `~/.automation.env` on <SERVER> by hand (`ssh -t <SERVER> 'nano
   ~/.automation.env'`); never through an agent session, since the values would pass through it.
4. Test from the box:
   `cd ~/automation && python3 -c 'from runner import notify; notify.send_push("test", "hello")'`

## Config

| Path / key | Contents |
|---|---|
| `~/.automation.env` → `PUSHOVER_USER` | your Pushover user key, 30 chars. Mode 0600 file |
| `~/.automation.env` → `PUSHOVER_TOKEN` | the `<SERVER>` application token, 30 chars |
| `~/automation/runner/notify.py` | `send_push`, `PushUnavailable`, `PUSHOVER_URL` |

## Gotchas

- **The token is per application, the user key is per person.** The phone app shows only the
  user key; the token exists only after creating an application on pushover.net.
- **Editing `~/.automation.env` over `ssh` needs `-t`** or nano refuses ("Standard input is not a
  terminal") and leaves a lock file.

## Known limitations

- **Only failures push so far**, plus the routine reminders (§ Who pushes). Which other *content*
  may interrupt you is still undecided; [[signal-definition]]'s tests are the intended policy, and
  [[whatsapp-bridge]] OPEN 2 asks the same question for the WhatsApp channel. Next intended
  caller: the event catcher (registration openings from your school or community digests and
  blasts).
- **Emergency priority (`2`) is used only by the evening routine pushes** ([[routine-push]]).
  Which alerts may page you that way is still undecided, and the 3600 s `expire` cap in
  `send_push` stops anything from paging you for longer than an hour.
- **One-way.** Pushover cannot carry a reply; conversation with the vault is [[whatsapp-bridge]]
  and the Telegram bridge.
- **Limits:** 10,000 messages a month per application, 1,024-character message, 250-character
  title. Far above personal use.

## Decisions

**Split by urgency: Pushover for urgent, Telegram for what can wait.** Pushover stays the channel
for anything that must reach you now, because its priority levels pass Focus mode and Telegram's
do not. Due tasks, `revisit:` dates, stale dumps and other things that keep for hours move to the
Telegram bridge; the maintenance brief moved first.

**Pushover over ntfy.** Reliable iOS delivery, priority levels that can pass Focus mode, $4.99
one-time, one HTTP call. Rejected: ntfy's free tier makes topics guessable and still relays iOS
pushes through its servers.

**Push is a channel beside mail, not a replacement.** Mail stays the record and the fallback;
push carries only what loses value within hours.

## See also

- [[automation]]: the runner and `notify.py`
- [[signal-definition]]: what counts as signal, and Gotcha 5 on capacity-limited events
- [[whatsapp-bridge]]: the two-way channel on WhatsApp
- [[telegram-bridge]]: the Telegram channel, home of non-urgent proactive messages
- [[Areas/Master Profile|Master Profile]]: § Reachability, why push matters
