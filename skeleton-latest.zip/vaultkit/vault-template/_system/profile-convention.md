---
type: reference
component: profile-convention
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Profile convention: how facts about the owner are recorded

**Status:** shipped with the starter vault, verified <INSTALL-DATE>. Referenced from `SYSTEM.md`
§ Components and from every profile note. The hub it serves is [[Areas/Master Profile|Master Profile]].

## What it's for

One place defining how a fact about the owner is written down, so every profile note does not
carry its own copy of the rules.

The constraint it answers: **soft facts decay silently.** A two-year-old weight, salary or
address read as current is worse than no value, because nothing signals the staleness. Every
fact therefore carries when it was true and how confident that is.

## How it works

### The three tiers

Every fact row carries exactly one tier.

| Tier | Meaning | Shelf life |
|---|---|---|
| **Fixed** | Does not change. Date of birth, nationality, a past surgery, a completed degree | Never expires |
| **Slow** | Moves over years. Job, city, partner, credentials | Re-check at **12 months** |
| **Current** | Moves month to month. Weight, income, what is live with someone | Stale at **6 months** |

**Tiering is what keeps profiles small.** Fixed facts are write-once and need no maintenance,
so only the Current tier carries a cadence, and the Current tier should be deliberately short.
A profile that is mostly Current has been written at the wrong altitude.

### Source vocabulary: this is the confidence axis

**Ordered, strongest first.** There is no separate confidence column on purpose: `Source`
already carries it, and an extra column on every table costs more in retrieval noise than it returns.

| Source | Means | Trust |
|---|---|---|
| `measured` | An instrument or a document produced this value | Highest |
| `observed` / `self-tested` | Someone looked, or the owner ran a test on themselves | High, but a judgement not a reading |
| `self-reported` | The owner said it | High for preferences and history, weaker for estimated numbers |
| `[[a note]]` | Stated in another vault note. **Link it rather than writing the word `vault`**: a link is provenance you can follow, a word is not | As good as that note's own sourcing |
| `reference` | External published data, not about the owner specifically | Depends on the source; name it |
| `derived` | Computed from other rows in the same file | As good as its inputs |
| `estimated` | A figure standing in for a measurement not taken | Directional only |
| **`inferred`** | **Claude concluded it from vault evidence. The owner has not confirmed it** | **Treat as a question, not a fact** |

**A wikilink is the preferred form of `vault`.** `| Age | 41 | Current | [[a note]] | 2026 |`
beats `| Age | 41 | Current | vault | 2026 |`, because the first can be checked and the second
cannot. The bare word survives only where no single note owns the fact.

**`(elicit)` rows carry `-` in both `Source` and `As of`.** That is correct and not a missing
source: there is no fact yet to source.

**`inferred` is the one that matters.** The others all trace to something someone stated or
measured. `inferred` marks a fact the system produced about its own user, which is exactly the
category that reads as authoritative while being unverified. An `inferred` row carries a
matching line in the Unknowns register until it is confirmed.

**`inferred` means synthesised from facts the owner confirmed, never Claude's own suggestions.**
A taste pattern drawn from books they said they love is a valid `inferred` row. Recommendations
Claude produced in chat that the owner has not signed off on do not belong in a profile at all,
under any tier or source label. The test is whether the content traces back to something the
owner confirmed.

**Never write a fact with no source.** If it cannot be sourced it is an `(elicit)` row, not a value.

### The fact table

Every domain section is a table in this column order:

```
| Fact | Value | Tier | Source | As of |
```

`As of` is a date, never "recently" or "currently".

**Permitted deviation.** A section whose content has a genuinely different natural shape (a
payment schedule, a career sequence) may change the leading columns, **but `Source` and `As of`
must remain the last two.** Those carry the provenance and recency metadata the design rests on.

**Keep tables short.** A table long enough to be split in retrieval loses its header row, and a
row like `| Weight | ~80 kg | Current | estimated | 2026-01 |` is uninterpretable without the
section that names the domain. This is a documented failure mode of table chunking, not a
stylistic preference. It is also why every section needs a lead-in line.

### Section shape, and the size rule

Every section opens with **one line stating what it answers**, then its table.

**The cap is per section, not per file: roughly 200-500 words each.** A retrieval pass often
sees one section without the rest of the file, so the question that matters is whether a section
can be read alone, not how long the file is. **A profile covering more domains is legitimately
longer**, and there is no file-level limit. Splitting a multi-domain profile into fragments makes
retrieval worse, not better: each fragment carries the same prose overhead and the router gains
a row per fragment.

**If a section is too long, the cause is almost always reasoning that belongs downstream**, not
too many facts. See Gotchas.

### Unknowns are first-class

Every profile note ends with an **Unknowns register**: a numbered final section listing what is
*not* known, what each gap blocks, and how to resolve it. **An invisible gap gets guessed at
instead of filled.** A blank cell invites a plausible invention; a listed unknown does not.

When an unknown is resolved, move it into its domain section with a source and date, and delete
the row from the register.

### File-level freshness

Every profile note carries `verified:` in frontmatter: the date its claims were last checked,
not the date the file was last touched.

**The rule, vault-wide:** if `verified:` is past its tier's shelf life, or a `revisit:` /
`horizon_end` has passed, **say so in one line and ask. Never plan against it silently.**
The same rule governs [[_system/working-conditions|working-conditions]]: conditions without an
expiry get carried into weeks where they are false.

**`verified:` and `revisit:` are different things and stay separate.** `verified:` is when facts
were last checked. `revisit:` / `horizon_end` is when a *judgement* expires.
[[Areas/North Star]] needs both.

### When to write a fact down

**When the owner states a durable fact about themselves, write it into the profile. Do not wait
to be asked.** Most facts arrive as asides in the middle of other work (a nationality mentioned
while booking a flight, an insurer named while triaging mail), and the default failure is to use
the fact for the current answer and let it evaporate. **The moment a fact is stated is the
cheapest moment it will ever be to record.**

**The test, and all three must hold:**
1. **Will it still be true next month?** A deadline, a mood, or "I'm travelling this week" is
   session context, not a fact. Those belong in a task or a dump, never in a profile.
2. **Would a future session answer differently for knowing it?** If nothing changes, it is
   trivia. Volume is not the goal; a profile that records everything retrieves nothing.
3. **Is it about the owner, rather than about the task?** Facts about the work go in the project.

**Then route it by fact type** through [[Areas/Master Profile|Master Profile]], and follow the
conventions above: a `Tier`, a `Source` and an `As of` date, every time.

**Update in place. Never append a second version.** The characteristic failure of a system that
never forgets is not missing data, it is **holding two contradictory facts and retrieving the
wrong one**: an old preference outranking the correct newer one. When a fact changes, overwrite
the row, and move the old value to `## History` if it is worth keeping at all.

**Ask before you overwrite, though.** A first write costs nothing if it is wrong: the field was
empty, and a bad row is visible and easy to correct. An overwrite destroys a value that was
already confirmed, and a misheard detail then looks exactly like a verified one. **Name both
values (the recorded one and the new one) and let the owner confirm before replacing.** This is
the only place in the capture flow that stops for permission; new facts do not.

**A profile stores facts, never reasoning.** If the fact suggests a conclusion, the conclusion
goes in the note that acts on it, and the profile links there. See Gotchas: this is the single
most reliable way a profile degrades, and it has to be resisted at write time rather than
cleaned up later. `check_profiles.py` enforces it.

**Say what was recorded in one line, and keep working.** Do not stop to ask permission for each
fact: the capture rate depends on not interrupting, and facts arrive as asides. **Three
exceptions, and only three:** anything about a third party's health, finances or relationships;
**any overwrite of a value already recorded** (see above); and **never record a password, PIN,
2FA seed or recovery code**, at any tier, with no exception
([[_system/_profile-template|_profile-template]] rule 8). The risk being managed is a wrong value
replacing a right one, which is what the overwrite exception covers.

The router keeps the trigger for this rule; this file owns the rule, because everything it
references (tiers, sourcing, routing, the facts-not-reasoning line) is defined here.

## Config

- **Template: [[_system/_profile-template|_profile-template]].** Copy it when creating a
  sub-profile; it is the enforcement point for everything above.
- Hub: `Areas/Master Profile.md` (`type: master-profile`)
- Spokes: `Areas/<Area>/<Domain> Profile.md` (`type: sub-profile`, `parent: "[[Master Profile]]"`)
- People: `Areas/People/<Name>.md` (`type: person`). Members of the People area, not
  sub-profiles, because they describe other people rather than the owner

## Gotchas

- **Identifiers versus authenticators is the privacy line, not "does it look sensitive".**
  Decide your own line once and write it into [[_system/_profile-template|_profile-template]]
  rule 8. The default shipped here: passwords, PINs, 2FA codes and full card numbers are never
  recorded; document and policy numbers are the owner's call.
- **Do not restate this convention inside a profile note.** Link here. A second copy drifts,
  which is exactly what `SYSTEM.md`'s documented-once rule exists to prevent.
- **A profile states facts. It does not reason about them.** The single most reliable way a
  profile note bloats is by accumulating conclusions next to the facts that produced them, until
  the prose outweighs the table and duplicates notes that already cover the reasoning in more
  depth, with sources. **When a fact suggests a conclusion, put the conclusion where it is acted
  on and link to it.**
- **`master-profile` / `sub-profile` / `person` extend the `type` vocabulary deliberately.**
  `SYSTEM.md`'s list (`action` / `todo` / `learning` / `idea` / `reference`) is scoped to
  `Inbox/`. Not schema drift; do not "fix" it.

## Known limitations

- Nothing enforces the shelf lives automatically. There is no scheduled job checking `verified:`
  dates; the rule relies on being read. Registered in
  [[_system/maintenance/maintenance|maintenance]] for that reason.
- Tier assignment is a judgement call at the boundary. "Job" is Slow until someone is between
  jobs, when it is Current. Prefer the shorter shelf life when unsure.

## Decisions

**Shelf lives are 12 and 6 months.** Six months for Current matches how fast body and money
facts actually move; 12 months for Slow aligns with an annual review rather than being derived
from evidence. Change them here if your life moves faster.

## See also
- [[_system/_profile-template|_profile-template]]: the template implementing this convention
- [[Areas/Master Profile]]: the hub every profile note hangs off
- [[_system/maintenance/maintenance|maintenance]]: where the refresh cadence is registered
- [[_system/SYSTEM|SYSTEM]]: the productivity-stack hub
