---
type: reference
component: template
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>T12:00
---

# Component doc template

Copy this file when documenting a new component of the system (a capture path, a plugin setup,
a script, a convention). It is the standard every component doc in `_system/` follows. The
rules matter more than the headings: read "Rules" at the bottom before deviating.

**Some files in `_system/` are deliberately exempt and must not be reshaped into this
template:** `mcp-instructions.md` (an agent prompt injected into every chat session, not
documentation) and any doc written for an external audience that has to stay shareable as-is.

---

## The template

```markdown
---
type: reference
component: <stable-slug>       # matches the status line in SYSTEM.md
stage: built                   # built | partial | design-only | superseded | dead
                               # NEVER `status:`, which is reserved for tasks. See rule 7.
verified: 2026-01-15           # last date the claims here were checked against reality
captured: 2026-01-15T12:50
---

# <Name>: <one line of what it is>

**Status:** <built | partial | design only | dead> as of <date>, verified <date>.
Tracked by <task note>. Referenced from `SYSTEM.md` § <section>.

## What it's for          # 3-5 lines. Purpose and the constraint it answers. Not history.
## How it works           # Present tense, current reality only.
## Setup / rebuild        # How to recreate from zero, or the build prompt.
## Config                 # Files, paths, settings, knobs.
## Gotchas                # Traps that cost real time. One name for this, everywhere.
## Known limitations      # Capability boundaries, and what this does NOT do.
## Decisions              # Locked and open. One paragraph each, ADR-shaped.
## History                # Superseded decisions and diagnostic trails. Below the fold.
## See also
```

Sections are optional but their **order is fixed**. Skip what does not apply; never reorder.

---

## Rules

1. **`verified:` is a date, not a boolean, and it is mandatory.** It records when someone last
   checked the doc's claims against the actual system. Docs drift silently: a setup can run
   several revisions behind its doc with nothing in the doc to reveal it. A doc that says
   `verified:` months ago is telling you to distrust it.

2. **One name per concept.** Use **Gotchas** for traps that cost time, and **Known
   limitations** for capability boundaries. Do not add "Notes", "Risks", "Build gotchas",
   "Backlog" or "What this does NOT do" as separate top-level headings; they all collapse into
   those two.

3. **Present tense above the fold, history below it.** Current reality goes in "How it works".
   A decision that has been superseded moves to `## History`, marked as superseded, with the
   current answer linked. Never stack `RESOLVED` on top of `Diagnostic history` on top of a
   third layer in the reading path: a reader then has to dig through every layer to learn what
   is true today.

4. **Status lives in exactly two places:** the frontmatter (for machines) and the bold line
   under the H1 (for humans). Nowhere else. Do not bury a status sentence at line 46.

5. **Decisions keep ADR shape without becoming separate ADR files.** Each entry states the
   decision, its date, why, and what was rejected. Deliberately inline rather than one file per
   decision: a separate layer of decision docs drifts from the docs it describes.

6. **`SYSTEM.md` gets one line per component and nothing more.** Full detail lives in the
   component doc. This applies to every component without exception.

7. **Frontmatter uses `stage:`, never `status:`.** `status:` is reserved for tasks and the
   cockpit (`ToDo.base`, `todos.py` read it); a component doc carrying one is a regression, as
   [[frontmatter-properties]] states. A template that ships with `status:` copies the error into
   every doc made from it.

8. **Only the template's sections exist at the top level.** Anything else becomes a `###`
   subsection of the template section it belongs to, keeping its heading text so links still
   resolve. A custom `##` heading is how a doc's structure drifts one edit at a time.

## Enforcement

**These rules are checked, not remembered.** `~/automation/tools/check_docs.py` is their only
executable form, shared by three callers:

- **A Claude Code PostToolUse hook** runs `vt docs --hook` after every Edit or Write to a
  `_system/` doc (see `SETUP-NOTES.md`) and hands any violation back to the session that made
  the edit, which must fix it before finishing, even when the problem predates the edit.
- **`vt docs`** checks every component doc on demand, or the files named.
- **The `inventory` job** repeats the check daily as the backstop for edits the hook cannot
  see: Bash rewrites (`sed`, a Python script) and edits made in Obsidian itself.

Why a hook rather than a stronger instruction: a written rule depends on the editing session
noticing that it applies, and sessions routinely restructure a doc without opening this
template even though the router and `SYSTEM.md` both point here. Findings that land in an Inbox
note reach you days later, after the session that caused them is gone. **Changing a rule here
means changing `check_docs.py` in the same session.**

## See also
- [[_system/SYSTEM|SYSTEM]]: the hub these docs hang off.
- [[_system/README|Vault Map]]: folder-level map.
