---
type: reference
component: telegram-bridge
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Telegram bridge: the vault as a Telegram bot

**Status:** built. Text, voice, media, topics, approvals and the proactive path (the weekly
maintenance brief) are live. Referenced from `SYSTEM.md` § Components.

## What it's for

You talk to the vault from your phone, with your laptop shut, as if it were a terminal Claude
Code session: the vault `CLAUDE.md`, the Router, every skill and a shell. Voice notes and photos
work. The vault can also message you first with things that can wait hours, while Pushover keeps
what is urgent ([[push-notifications]] decision "Split by urgency").

It runs alongside [[whatsapp-bridge]], which stays live until this one has proven itself.

## How it works

```
phone ──Telegram──> getUpdates long poll ──> SQLite inbox (commit, then advance the offset)
                                                  │  owner filter: from.id, private chat, not a bot
                                one Lane worker per (chat, topic), 300 ms debounce
                                                  │
                         AgentPool: one warm ClaudeSDKClient per session (max 2)
                                                  │
                       the box's claude CLI, cwd = the vault, bypassPermissions + ask list
                                                  │
                      ask-list hits ──> [Allow once] [Deny] ──> a tap or a 2-minute deny
                                                  │
                       markdown -> Telegram HTML, 4,000-unit chunks, plain fallback ──> phone

~/automation jobs ──notify.send_telegram(buttons=...)──> phone ──tap──> the bridge (proactive.py)
```

- **`tg-bridge.service` on <SERVER>** runs `jobs/tg_bridge` from `~/automation` (master) under
  the repo `.venv`, which holds `claude-agent-sdk` and `httpx`. One process polls the bot token;
  a `flock` makes a second refuse to start.
- **The agent is real Claude Code**: the Agent SDK drives the box's own `claude` binary
  (`cli_path`), `setting_sources` left at the default so the vault `CLAUDE.md` and user-scope
  skills load. Same MCP servers as any session on the box (gws for Gmail and Calendar).
- **Permissions: `bypassPermissions` plus an ask list** (§ Decisions). `rm -r`/`rm -rf`, `sudo`,
  `git push`, `systemctl stop|disable` and the gws Gmail send ask with buttons; everything else
  runs. Read-only connector tools never ask. Claude Code's own scheduling tools are denied.
- **Sessions:** each Telegram topic is its own Claude session (`/sessions` lists and switches
  within one). A minted uuid per session; before every resume the transcript is checked, and an
  unhealthy one (killed mid-tool, cut-off line) means a fresh session and a one-line note.
  `/new` starts fresh, `/stop` or "stop" interrupts, `/status` reports.
- **While it works:** a typing indicator and a status line ("Reading index.md..."), deleted
  before the answer. Messages sent mid-turn are folded into the next turn.
- **Voice:** Groq Whisper, OpenAI as fallback; the transcript is echoed as `📝 "..."` and lives in
  the conversation only. **Photos and files** are saved to `Attachments/Telegram/<YYYY-MM>/`.
- **How it writes:** [[_system/telegram-bridge/reply-style|reply-style]], read every turn and
  appended to the system prompt. A changed note restarts the warm process, resumed.
- **Proactive messages:** a job calls `notify.send_telegram(text, buttons=...)`. Inside quiet
  hours the message arrives silently. Quiet hours are read at every send from the Sleep row of
  [[working-conditions]]: lights off to the latest wake (weekdays and weekends can differ).
  The bridge receives button taps, because it is the only poller. **Replying to any proactive
  message** continues it: the quoted text goes into the turn as untrusted context.
- **The one proactive caller today is the weekly maintenance brief** ([[maintenance-brief]]): a
  header, then one silent message per item, each with **[Let Claude fix it] [Create task] /
  [Skip]**, labelled "Claude can likely finish this" or "needs your decision, Claude can prepare
  it". Create writes a task named by the item's title, its next action as the checkbox and its
  reasoning under `## Facts` (`todos.add_task`, the same code as `vt todos --add`), read back
  from the brief note's machine-readable block. If Telegram is down, the brief falls back to
  Pushover, then mail.
- **Let Claude fix it** creates the same task, opens a topic named after the item ("🔧 …") and
  starts a session there on the item. It does as much as it can and hands over before deciding
  about your life, stating facts only you know, sending anything to others or deleting,
  leaving drafts for you to decide on. Credentials and systemd are allowed; the ask list puts
  `sudo`, `systemctl stop`/`disable`, `git push` and `rm -r` on your phone. The session ends with
  an `OUTCOME:` line. Done with no message or approval from you closes the task
  (`status: done`, checkbox ticked, a "Done by Claude" section). With your input, or
  `needs you`, the task stays open with what is needed as its next action. Every fix is logged
  in `~/.local/state/automation/brief-fixes.json`; the next brief re-checks last week's closed
  fixes and reopens one whose finding still fails.
- **Failures are never silent:** a failed turn sends a notice into the chat and an urgent push
  plus mail, throttled to one per headline per 10 minutes. `heartbeat` watches the unit
  (`critical`), and a 409 lasting past 2 minutes (someone else polling the token) pushes an alert.

## Setup / rebuild

Code: `~/automation/jobs/tg_bridge/` (package; one file per concern, see its `__init__.py`), the
build record `~/automation/docs-tg/NOTES.md`, and the SDK spike results
`~/automation/docs-tg/phase0-spike-results.md`.

1. **Bot:** @BotFather, token into `~/.automation.env` as `TELEGRAM_BOT_TOKEN`; your numeric
   Telegram user id as `TELEGRAM_OWNER_ID`. Transcription keys `GROQ_API_KEY`, `OPENAI_API_KEY`.
2. **Dependencies:** `~/automation/.venv/bin/pip install -r ~/automation/requirements.txt`.
3. **Tests:** `.venv/bin/python -m tests.tg_bridge` (all must pass; with the SDK installed
   `sdk_shapes` runs too), plus `tests.maintenance_brief` for the brief's delivery.
4. **Unit:** `sudo cp ~/automation/units/tg-bridge.service /etc/systemd/system/`,
   `sudo systemd-analyze verify` it, `daemon-reload`, `enable --now`.
5. **Check from the phone:** "hi" gets an answer; `mkdir -p /tmp/asktest && rm -rf /tmp/asktest`
   shows Allow/Deny; a voice note is transcribed.

**Deploying a permission change needs a default-mode session.** Claude Code's auto-mode classifier
blocks pushing or installing the bypass configuration ("Create Unsafe Agents"), and the rule is to
stop at that block, not route around it. You run those commands yourself or approve each one.

## Config

| Path / key | Contents |
|---|---|
| `/etc/systemd/system/tg-bridge.service` | from `units/tg-bridge.service`: `bin/run-job tg_bridge`, `Restart=on-failure`, 5 starts / 600 s **in `[Unit]`**, `RestartPreventExitStatus=78` (bad config), `KillMode=mixed`, `TimeoutStopSec=150`, `OOMPolicy=continue` |
| `~/.automation.env` | `TELEGRAM_BOT_TOKEN`, `TELEGRAM_OWNER_ID`, `GROQ_API_KEY`, `OPENAI_API_KEY` (see the credentials note) |
| `TG_PERMISSION_MODE` | `bypassPermissions` (default) or `default` to bring back taps on everything outside the allow list |
| `TG_MODEL` | model alias, default the CLI's |
| `TG_STATUS_LINE` | `0` turns the status line off |
| `TG_VT_RULES`, `TG_DISALLOWED_EXTRA` | `;`-separated allow rules replacing the two `vt` forms; extra deny rules |
| `TG_OPENAI_STT_MODEL` | OpenAI fallback model, default `whisper-1` |
| `~/.local/state/automation/tg-bridge.sqlite` | inbound queue, offsets, sessions, message-to-session map |
| `~/.local/state/automation/locks/tg_bridge.lock` | single instance |
| `~/.local/state/automation/brief-fixes.json` | every Let Claude fix it session: topic, task, outcome, whether you were involved (`proactive.FixLog`) |
| `_system/telegram-bridge/reply-style.md` | how the bridge writes. In the vault, not bridge config |
| [[working-conditions]] § Sleep row | quiet hours (`runner/quiet_hours.py`) |
| Limits (`agent.py`) | 2 warm clients, 10 min idle close; watchdog 300 s fresh / 150 s resume before the first event, 300 s between events, 900 s in a tool, 45 min per turn, paused while an approval waits |

## Gotchas

- **Explicit ask rules still reach `can_use_tool` under `bypassPermissions`**, although the SDK
  warns `CanUseToolShadowedWarning` at every start. The warning is wrong for ask rules; do not
  "fix" it by dropping them.
- **`can_use_tool` is not a full gate.** Claude Code's built-in read-only approvals (`date`,
  `uname`) and allow rules in any settings file run first, so some tool calls never reach it.
- **Allow rules match the literal command text.** `Bash(~/automation/bin/vt *)` and the same
  rule written with the absolute home path are different rules; both are listed.
- **A blocked command gets no button, it just fails.** Secret-file deny rules made the WhatsApp
  read fail silently (it sources `~/.waha.env`), which is why they are not used.
- **Never run a second copy against the token.** Two pollers get HTTP 409 forever. A short 409 at
  restart is the previous process's last poll and is normal.
- **Topic-created service messages arrive before the first message of every topic**, and the
  iPhone opens a new topic per message sent outside one. They are skipped as content-free.
- **`setting_sources=["project"]` drops every skill.** Leave it unset.
- **Headless `permission_mode="auto"` does not run the desktop classifier**; it falls through to
  asking. That is why bypass plus an ask list is the chosen equivalent.
- **The poller can stall silently.** No successful poll for 180 s rebuilds the HTTP client; 600 s
  exits for systemd to restart.

## Known limitations

- **Topics for fixes may be refused.** Whether the Bot API lets the bot create a topic in the
  private chat shows only on the first real tap. If Telegram refuses, the fix runs as a named
  session in the main chat, which then becomes the current session there.
- **A bridge restart in the middle of a fix drops the session.** The task stays open with its
  original next action, an ordinary task, and the fix log keeps it as `running`.
- **Anyone in control of your Telegram account controls the box.** The owner filter is the
  lock. Recommended hardening: a two-step verification password, a review of Settings > Devices,
  an app passcode.
- **The agent can read every credential file on the box.** Only the bridge's own keys are
  scrubbed from its environment (an open question in the credentials note).
- **Bash ask rules are prefix matches**: `rm -fr`, `find -delete` or a script run with no tap.
  A backstop against the obvious form, not a sandbox.
- **Proactive messages have one caller.** Due tasks, `revisit:` dates and stale dumps have not
  moved from mail and Pushover; which content belongs here is open (§ Decisions OPEN 1).
- **Quiet hours deliver silently, they do not hold messages** until morning.
- **No audit log of every tool call**: that would need a `PreToolUse` hook.
- No webhooks, groups, text-to-speech or a "flush facts to the vault" step before `/new`.
- **The Gmail send is the only mail tool that asks.** There is no claude.ai Gmail connector on the
  box; Drive's `share_file` and `trash_file`, Gmail drafts and label changes run without a tap.

## Decisions

### LOCKED

**Sessions run with `bypassPermissions` plus an ask list.** Taps on every command outside `vt`
are too disruptive, and Telegram is treated as the same trust surface as Claude Desktop. Scope is
Telegram only: Remote Control, the WhatsApp bridge, scheduled jobs, Desktop and every settings
file keep their own behaviour. No secret-file or env-dump deny rules.

**The Agent SDK, not `claude -p`.** Approval buttons need the agent to stop and wait for an
answer (`can_use_tool`), and `/stop` needs `interrupt()`. The CLI route the WhatsApp bridge uses
has neither.

**Telegram alongside WhatsApp, not instead.** Retiring WhatsApp is decided once this has proven
itself ([[whatsapp-bridge]] § Decisions).

**Alerts split by urgency.** Pushover for what must break through Focus; Telegram for what can
wait hours.

**Quiet hours come from the vault.** Read from the working-conditions Sleep row at every send,
not set in code, so the window follows the week structure. Inside quiet hours messages are silent
rather than held, so nothing is lost overnight.

**The maintenance brief is the first proactive caller.** It was already decided there (Telegram
once the bridge is live, with Create task buttons). Other callers wait for OPEN 1.

**Claude does every brief item as far as it can, on one tap.** Every item gets [Let Claude fix
it]; the brief's sorting (judgement about your life, facts only you know, anything leaving the
vault and box, anything hard to undo, or changing credentials or systemd: needs you; the rest:
Claude) only labels the message and tells the session what to expect. The session hands over at
the point a decision is yours, with the groundwork done. Safety is in the session, not on the
button: the ask list gates the dangerous commands on your phone, and any tap counts as your
input, so that task waits for you to close it. A tap rather than an automatic start: nothing
runs on the box without your say-so. A fix closes its task only if it needed no input from you.
Rejected: a folder rule ("outside `_system/` needs you"), because broken links and property
clean-up in notes are mechanical while North Star in `Areas/` is not. Offering the button only
on items marked as Claude's, with a hard credentials-and-systemd lock, was also rejected: a lock
by mention blocks harmless work such as a read-only diff of a unit file.

**Media and voice.** Files go to `Attachments/Telegram/<YYYY-MM>/`. Transcription is cloud
(Groq, then OpenAI); the audio is deleted once transcribed and no transcript note is written.

**Contexts are Telegram topics, one session per topic**, with `/sessions` as the fallback inside
one topic. Every `vt` subcommand is pre-approved. Status line on.

### OPEN

1. **Which content moves from Pushover and mail to Telegram.** Due tasks, `revisit:` dates and
   stale dumps are the candidates. The policy question is shared with [[whatsapp-bridge]] OPEN 2
   and [[push-notifications]]; [[signal-definition]]'s tests are the natural answer.
2. **Whether to retire the WhatsApp bridge**, once this one has proven itself.

## See also

- [[whatsapp-bridge]]: the WhatsApp channel running alongside this one
- [[push-notifications]]: the urgent channel, and the split by urgency
- [[maintenance-brief]]: the first proactive caller
- [[working-conditions]]: where quiet hours come from
- the credentials note: the keys, and the open question of systemd credentials
- [[maintenance]]: `telegram-bridge-alive`, `telegram-bot-token`, `transcription-api-keys`
