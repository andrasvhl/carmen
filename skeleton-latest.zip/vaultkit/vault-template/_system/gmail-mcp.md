---
type: reference
component: gmail-mcp
stage: built
verified: <INSTALL-DATE>
captured: <INSTALL-DATE>
---

# Gmail MCP: both mailboxes readable and writable from one local server

**Status:** built and verified. Both `<YOUR_PERSONAL_EMAIL>` and `<YOUR_WORK_EMAIL>` are authenticated and return results. Referenced from `SYSTEM.md` § Components.

## What it's for

Anthropic's built-in Google connector binds to exactly one Google account, server-side. Connecting a second one replaces the first. That is a problem when your mail is split across two mailboxes: `<YOUR_WORK_EMAIL>` for work or school and most professional correspondence, and `<YOUR_PERSONAL_EMAIL>` for nearly all personal admin (invoices, flights, RSVPs). Without this, any task that points at the second mailbox points at mail Claude cannot see.

This runs a local stdio MCP server that holds both accounts at once. Every tool takes a `user_google_email` argument, so Claude picks the mailbox per call instead of switching.

## How it works

`taylorwilsdon/google_workspace_mcp` (PyPI `workspace-mcp`) runs on demand via `uvx` and is registered as the MCP server `gws`. Its tools are namespaced `mcp__gws__*` and cover search, message and thread content, batch fetch, attachments, drafts, send, labels and filters.

Auth is a personal Google Cloud OAuth client that you own. Each account is consented once through a browser flow. Refresh tokens are stored per account on disk, and from then on the server refreshes silently.

The built-in claude.ai Gmail connector is **deliberately left connected** to the work account as a fallback. Both surfaces are live at the same time.

**Runs on the server as well.** The client secret and both account token files are copied to `~/.google_workspace_mcp/` on `<SERVER>` (files mode 0600, directory 0700), and `gws` is registered there via `uvx workspace-mcp@1.23.1`. `uv` is installed through Ubuntu's `pipx` rather than the upstream install script. Verify from the server that both mailboxes refresh and answer. This exists because anything that needs mail could otherwise only run while your laptop is open: see the standing rule in [[Claude Master Router]] and [[_system/vps-vault-host|vps-vault-host]]. The cost is a second copy of both refresh tokens on a public-facing VPS, tracked in [[_system/maintenance/maintenance|maintenance]].

## Setup / rebuild

Google side, done signed in as `<YOUR_PERSONAL_EMAIL>` (if your work or school Workspace restricts GCP project creation, the project cannot live under that identity):

1. GCP project `<GCP_PROJECT_ID>`, Gmail API enabled. No billing needed. **Enable the Google Calendar API too**, for the read-only calendar token of `plan_today_prerun` ([[_system/plan-today|plan-today]]). The console must be opened as the account that owns the project.
2. Google Auth Platform, audience **External**, app name `personal-mcp`.
3. Nine scopes: `gmail.readonly`, `gmail.compose`, `gmail.modify`, `gmail.send`, `gmail.labels`, `gmail.settings.basic`, plus `openid`, `userinfo.email`, `userinfo.profile`.
4. **Published to In Production**, unverified. Not submitted for verification.
5. OAuth client, type **Desktop app**, named `workspace-mcp`. Download the JSON.

Local side:

```bash
mkdir -p ~/.google_workspace_mcp && chmod 700 ~/.google_workspace_mcp
mv ~/Downloads/client_secret_*.apps.googleusercontent.com.json ~/.google_workspace_mcp/client_secret.json
chmod 600 ~/.google_workspace_mcp/client_secret.json

claude mcp add -s user gws \
  -e GOOGLE_CLIENT_SECRET_PATH=~/.google_workspace_mcp/client_secret.json \
  -e WORKSPACE_MCP_PORT=8000 \
  -e OAUTHLIB_INSECURE_TRANSPORT=1 \
  -- ~/.local/bin/uvx workspace-mcp@1.23.1 --tools gmail --single-user
```

Write both paths as absolute paths in the real command (see Gotchas). Then **restart the Claude Code session** so the tools load, and run `start_google_auth` once per account. Each one opens a browser: click through "Google hasn't verified this app" via Advanced → Go to personal-mcp, then Allow.

## Config

| Path | Contents |
|---|---|
| `~/.claude.json` → `mcpServers.gws` | Server registration, user scope. No secrets. |
| `~/.google_workspace_mcp/client_secret.json` | OAuth client ID and secret, chmod 600 |
| `~/.google_workspace_mcp/credentials/<YOUR_PERSONAL_EMAIL>.json` | Refresh + access token, plaintext |
| `~/.google_workspace_mcp/credentials/<YOUR_WORK_EMAIL>.json` | Same, work account |
| `~/.workspace-mcp/attachments/` | Downloaded attachments land here with UUID filenames, not original names |

The version is **pinned to `workspace-mcp@1.23.1`** on purpose. This package reads both mailboxes, so silent upgrades are not wanted.

`--tools gmail` limits registration to ~15 Gmail tools instead of the full 120+ across all Google services.

## Gotchas

- **New MCP servers do not appear until the session restarts.** `claude mcp list` will report `✔ Connected` while the tools are still unavailable in the running conversation. This is expected, not a fault.
- **The auth URL sometimes fails to open and drops you on the Google Account home page instead of a consent screen.** That looks like a block but is not one. Check `~/.google_workspace_mcp/credentials/`: if no token file appeared, paste the authorization URL into the browser manually.
- **`openid` is the bare word, not a URL.** In the scope picker, `https://www.googleapis.com/auth/openid` silently matches nothing.
- **Use the absolute path to `uvx` in the config.** The desktop app does not reliably inherit the zsh `PATH`, so a bare `uvx` can fail to launch while working fine from a terminal.
- **Attachment filenames are lost on download.** `get_gmail_attachment_content` saves to a UUID with `Filename: unknown`. Rename the file on the way into `Attachments/`.
- **Sending an attachment by `path` only works from `~/.workspace-mcp/attachments/`.** Vault paths are refused ("local file access is limited to the server's permitted directories"). Copy the file there, send, then delete the copy. This applies to sending files to Kindle; which address and account to use is in [[_system/kindle|kindle]].
- **A "needs re-auth" prompt on the second account is a bug, not an expired login. `--single-user` fixes it.** Without that flag, workspace-mcp binds each MCP session to the first account that refreshes. The second account's successful refresh is then discarded ("Attempt to rebind session" in `~/.google_workspace_mcp/logs/mcp_server_debug.log`) and it opens a browser consent page. Upstream issue taylorwilsdon/google_workspace_mcp#926, unfixed in 1.23.1. It shows up as soon as one session queries both mailboxes. Use the flag on the server registration too.
- **A Google password reset revokes the refresh tokens on both machines at once** (`invalid_grant: Token has been expired or revoked` in the debug log). Fix: run `start_google_auth` for that account on the laptop, then `scp ~/.google_workspace_mcp/credentials/<account>.json <SERVER>:.google_workspace_mcp/credentials/` and `chmod 600` it there. If you skip the copy, server jobs (the plan-today pre-run, the heartbeat) are blind on that mailbox.
- **Two overlapping Gmail tool surfaces exist.** The built-in connector's tools (`search_threads`, `get_message`, `create_draft`) only reach the work account; `mcp__gws__*` covers both accounts. Claude may reach for the wrong one. Say which mailbox you mean.

## Known limitations

- **Gmail only.** Calendar, Drive, Docs, Sheets and Tasks are supported by the same server but not enabled. Google Calendar and Drive stay on built-in connectors, still bound to one account each, so the same limitation persists there.
- **Tokens are plaintext JSON on disk**, not in the macOS Keychain. Anything running as this user can read them, as can any backup of the home directory. Exclude `~/.google_workspace_mcp/` from cloud sync. `WORKSPACE_MCP_CREDENTIALS_DIR` can relocate them to an encrypted volume.
- **Unverified app, 100-user lifetime cap.** Irrelevant at two users, but the OAuth client cannot be shared broadly without a paid CASA assessment.
- **Send is technically permitted.** See the scope decision below.

## Decisions

**Local MCP server rather than switching or forwarding.** Disconnect-and-reconnect is rejected because it only ever yields one mailbox and hits a known account-switching bug (anthropics/claude-code#59512). Forwarding personal mail into the work account is rejected on privacy grounds: medical and personal admin would land in an institution-administered mailbox that its IT can access and that disappears when you leave.

**`taylorwilsdon/google_workspace_mcp` over the alternatives.** It is the only healthy, actively maintained project with genuine multi-account support. `GongRzhe/Gmail-MCP-Server`, the most-linked option, is archived. The "multi-account" listings on MCP directories resolve to tiny single-author repos, unfit to hold two mailboxes. `aaronsb/google-workspace-mcp` is the runner-up but is effectively single-author.

**Full Gmail scopes including send.** Read + search + drafts without send is **not achievable at the OAuth layer**: `users.drafts.create` accepts only `mail.google.com`, `gmail.modify` or `gmail.compose`, and all three also authorize `messages.send`. The alternatives are a policy-level guardrail (a permission deny rule on `mcp__gws__send_gmail_message`) or `--read-only`, which requests `gmail.readonly` alone and drops drafting entirely. The setup uses full scopes with no deny rule. Claude still confirms before any actual send, as standing practice rather than enforced config.

**Published to In Production rather than left in Testing.** External + Testing revokes refresh tokens every 7 days, which would mean re-consenting both accounts weekly. Publishing costs one unverified-app warning per account at consent time and nothing after that. Verification is deliberately not sought: restricted Gmail scopes trigger a CASA Tier 2 assessment costing roughly $540 to $1,000, and Google's personal-use exemption applies.

**Built-in Gmail connector kept on the work account.** Redundant but cheap. It is Google-verified, so it survives anything that breaks the personal OAuth client. Open question below.

**Open: retire the built-in connector?** Two overlapping Gmail tool surfaces mean Claude sometimes has to guess which mailbox is meant. Disconnecting the built-in one is cleaner, at the cost of the verified-app fallback. Not decided.

**Open: widen beyond Gmail?** The same server covers Calendar and Drive, both currently on single-account built-in connectors with the same limitation. Whether `gws` becomes the single Google surface is undecided.

## History

An institution's Workspace admins may restrict third-party OAuth clients for restricted Gmail scopes, which fails with `admin_policy_enforced` and cannot be fixed locally. If that happens, leave that account on the built-in connector and run only the personal account through `gws`. To confirm both accounts work, search for a sender that only writes to one mailbox and check that hits come back on that account and none on the other.

## See also
- [[_system/SYSTEM|SYSTEM]]: component status table
- The research note for this setup, if you keep one: tool comparison, institutional OAuth risk, security detail, revocation steps
