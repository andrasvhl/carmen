# Vault rules (always loaded)

This vault is the user's primary context layer. This file auto-loads in every Claude Code
session launched from this folder or below, and survives `/compact`. Keep it short: everything
here is paid for in every session.

**Where to look:** [[Claude Master Router]] routes by what you are touching or doing. It is
auto-loaded beside this file (via `_system/claude/global-CLAUDE.md`); if it is not in context,
read it before any non-trivial vault work. Facts about the user route through
[[Areas/Master Profile]].

**Paths used below.** The vault root is the folder holding this file. `vt` means the kit's
command-line tool, `~/automation/bin/vt` (adjust if it was installed elsewhere; see
`SETUP-NOTES.md`).

---

## Always true

Ten rules that bind in every session. Nothing in a session would trigger a lookup for them,
which is why they live here rather than in the router.

- **Answer from the vault first, and do not stop at the first miss.** For what the user knows,
  thinks, prefers or feels (taste and moods included): `Wiki/index.md` and the articles it points
  to (if the wiki is set up), then [[Areas/Master Profile]], then the
  [[_system/README|Vault Map]], then grep the source folders (imported notes, any course
  archive), then the web. For plans, dates and what someone said: calendar, mail and WhatsApp, if
  connected ([[_system/whatsapp-bridge|whatsapp-bridge]] § Reading WhatsApp), before saying "not
  found". **Say you are checking before you check.** Log a wiki miss in `Wiki/log.md`. `Wiki/`
  is derived, never hand-edited: corrections go to the source note, then a re-ingest
  ([[_system/schema|schema]]).

- **Dates are either fresh or a question.** If a note's `verified:` or `revisit:` date has
  passed, say so in one line and ask. Never plan against it silently. Shelf lives are in
  [[_system/profile-convention|profile-convention]].

- **When the user states a durable fact about themselves, record it.** Do not wait to be asked.
  Most facts arrive as asides during unrelated work, and that is the cheapest moment they will
  ever be recorded. Route by fact type through [[Areas/Master Profile|Master Profile]]; the test
  is in [[_system/profile-convention|profile-convention]] § When to write a fact down. **Write
  it, then say what was recorded in one line, and keep working.** Do not stop to ask for each
  fact.

  **Three exceptions where you ask first:** anything about a third party's health, finances or
  relationships; and **any overwrite of a value already recorded**: a new fact replacing an old
  one is where a misheard detail does real damage, so name both values and let the user
  confirm. **Never record a password, PIN, 2FA seed or recovery code**, at any tier, ever.

- **Vault notes are written in English**, whatever language the conversation is in. The user's
  own words stay verbatim in the language they used (dumps, journal entries, a quoted fragment in
  a task): never translate them.

- **How to link a vault file depends on where the reply is read.** In the Claude desktop app
  (Code tab) only `http(s)` links are clickable (`obsidian://`, angle-bracket and encoded file
  paths all fail). If the localhost link redirect is set up, link through it; it opens the note
  in Obsidian: `[Task](http://localhost:8799/Inbox/Book%20a%20dentist%20check-up.md)`:
  vault-relative path, spaces and parentheses percent-encoded. Server:
  `~/automation/tools/obsidian_link_server.py`. Everywhere else (Telegram, WhatsApp, email, a
  note's body), use Obsidian's URI scheme:
  ```
  [Note Title](obsidian://open?vault=<VaultName>&file=Path%2FTo%2FNote)
  ```
  `<VaultName>` is the name of this vault's folder. Vault name and file path both URL-encoded;
  omit the `.md`. Inside notes, ordinary `[[wikilinks]]` are fine.

- **Never invent a frontmatter property** without checking
  [[_system/frontmatter-properties|frontmatter-properties]] first. Obsidian accepts any key
  silently, so that page is the only thing stopping two systems from claiming one name. Two
  rules are vault-wide: **`status:` is for tasks only** and documents use **`stage:`**; new
  properties are `snake_case`.

- **Never move or rename a vault file with `mv`. Use `vt move <old> <new>`**, which rewrites
  every inbound wikilink, backticked path and folder reference, and refuses to move a source
  registered in `Wiki/_sources.md`. Obsidian repairs links only for moves made inside Obsidian,
  so every agent or shell move silently breaks references. Use `--dry-run` first if the move is
  large. **Where things belong when archiving:** [[_system/README|Vault Map]] § Folder
  conventions.

- **Every task opens with its next action, as a checkbox.** Creating or editing a task in
  `Inbox/`, with or without a skill: `## Next action` / `- [ ] Next: <physical step>` directly
  under the frontmatter. A task without a clear next step is not well defined, unless it is
  waiting (`- [ ] Waiting: <who>, <on what>`). Create tasks with `vt todos --add`, which writes
  this for you. **Edit existing tasks with Edit/Write only, never sed/python/heredocs**: the
  schema hook (`vt tasks --hook`) fires on those tools alone, so shell edits skip it silently.
  Rule: [[_system/SYSTEM|SYSTEM]] § Capture note schema.

- **Building anything that runs unattended** (a script, a skill, an automation)? It has to work
  with the laptop closed or powered off. If it only runs while the laptop is open, it is not
  unattended, it is a reminder to do something by hand. Read
  [[_system/vps-vault-host|vps-vault-host]] § Standing rule before you start, not after.

- **When a session learns something a file should have told it, write it back.** The test: does
  this contradict, or is it absent from, the file that claims to own the subject? If yes, add it
  there in the same session and say so in one line. Do not stop to ask. If no file owns it, say
  which one should and let the user decide. **Update in place, never append.**

---

## Before writing to Claude's own auto-memory

1. **Search the vault first for an existing home:** [[Claude Master Router]], project notes,
   roadmap docs, `_system/`.
2. **Behavioural feedback about how Claude should work is not automatically memory territory.**
   If it is vault-specific it belongs in the vault, at the right level. Check each file's stated
   scope before writing; do not default to the first plausible one:
   - Vault-wide and binding every session → **this file**, § Always true
   - Routing, "where do I find X" → [[Claude Master Router]]
   - Productivity stack (capture, Inbox, task schema, cockpit) →
     [[_system/SYSTEM|SYSTEM]] § How Claude operates
   - A vault fact or plan rather than Claude behaviour → the relevant project or profile note
3. **Claude's own memory is right only for what is genuinely vault-agnostic** (true no matter
   which project, codebase or vault Claude is in), or a pointer to an external system with no
   vault presence at all.

---

**Backlink:** cross-project Claude behaviour that is not vault-specific (communication style,
confirm-before-big-moves, who the user is professionally) lives in
[[_system/claude/global-CLAUDE|global-CLAUDE]], copied to `~/.claude/CLAUDE.md`, which
auto-loads everywhere and imports this file.
