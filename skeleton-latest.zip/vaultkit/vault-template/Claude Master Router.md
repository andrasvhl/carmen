# Claude Master Router

**Entry point for how Claude should navigate this vault.** Route from here; do not re-derive
detail in this file. **Auto-loaded in every session**, imported by the global instructions master
([[_system/claude/README|_system/claude]]), so every word is paid for every time: keep it a lookup
table, pointers only, current state only. Decisions and their reasons go to the router history
note, never here.

**To find where anything is, read the [[_system/README|Vault Map]].** It is the complete map of
the vault: every folder and every `_system/` doc, each with a description of what it holds and
the conventions for where new things go. Rewritten weekly from disk by `vaultmap`, so it is the
current answer to "where does X live" before any grep. This file routes by task; the Map shows
location.

**Where a rule belongs.** Apply this before adding anything here:

| The rule... | goes in |
|---|---|
| binds even when nobody looks it up | `CLAUDE.md` at the vault root (auto-loads) |
| tells you where to look | this file |
| explains how something works, or why | the component doc that owns it |
| describes what is inside another index | nowhere. Point at it, never summarise it |
| is needed on both machines | a non-dotted file inside the vault. Dotfiles and `.claude/` never sync |
| records a decision, its date or its history | the owning doc's `## History`; for this file and the always-loaded files, the router history note. Always-loaded files hold current state only |

---

## Route by what you're touching

- **Productivity stack** (capture, Inbox, task schema, cockpit, calendar) → [[_system/SYSTEM|SYSTEM]]
- **Creating or editing any task, with or without a skill** → create it with `~/automation/bin/vt
  todos --add` (writes the schema for you), and keep a `## Next action` block with a `- [ ]`
  checkbox directly under the frontmatter. Rule: [[_system/SYSTEM|SYSTEM]] § Capture note schema.
- **What actually matters right now** (priorities, the not-doing list, tie-breaks) →
  [[Areas/North Star|North Star]]. **Read before enriching, prioritising or planning a day.**
- **Any durable fact about the user** (identity, health, money, career, taste and interests, a named person) →
  [[Areas/Master Profile|Master Profile]]. It routes by fact type; this file routes by work type.
- **What the user knows, thinks, has concluded or has a practice for** → [[Wiki/index|Wiki index]],
  the catalog of every topic with material behind it. `CLAUDE.md` § Always true carries the rule
  that makes it the *first* read, not just one option; this row is only the pointer.
- **When work can be placed** (capacity, commitments, energy) →
  [[_system/working-conditions|working-conditions]]. Read before proposing any day plan.
- **Course material from Canvas** (a class's slides, cases, pages, the user's own submissions) →
  [[_system/canvas-archive|canvas-archive]]. The archive itself is the course archive folder;
  never hand-edit a note in it.
- **WhatsApp messages** (what was said in a chat, what the user committed to, what a group announced) →
  [[_system/whatsapp-bridge|whatsapp-bridge]] § Reading WhatsApp. The session is live and readable
  from <SERVER>; **never keyword-filter the read**: scope by time and chat, then judge.
  **Whether it works right now is answered by the maintenance status page**
  (heartbeat check *WhatsApp readable*, a real API read daily), never by a doc's status line.
- **LinkedIn, Messenger or Instagram messages** (what someone wrote, did they reply) →
  [[_system/beeper-bridge|beeper-bridge]] § Reading messages. Read-only `beeper` CLI on <SERVER>.
- **Recorded meetings, seminars, talks** (what was said, a transcript, sending a recording to
  someone) → [[_system/wispr-import|wispr-import]]. Wispr Flow's cloud via `vt wispr`, readable
  with the laptop off; filed copies live in `<project>/Meetings/` and `Inbox/Wispr/`.
- **Any calendar question** ("what's on today", "am I free", "when is X") → query **every**
  calendar in [[_system/skills/schedule-work/SKILL|schedule-work]] § its calendar table, never only
  the primary. Event RSVP services (such as Partiful or Luma) live in imported calendars of their own.
- **What's where: any file, folder or `_system/` doc, with what it holds** → [[_system/README|Vault Map]]
  (see the top of this file)

## Route by what you're doing

- **Building anything that runs unattended** (script, skill, automation) →
  [[_system/vps-vault-host|vps-vault-host]] § Standing rule. It must work with the laptop off.
- **Writing frontmatter, or reaching for a new property** →
  [[_system/frontmatter-properties|frontmatter-properties]]. Never invent a key without checking.
- **Changing the user's global Claude instructions, or Claude's own memory** →
  [[_system/claude/README|_system/claude]]. One master copy and one memory folder for both machines;
  never edit `~/.claude/CLAUDE.md` directly, it is overwritten at session start.
- **Writing or editing a skill** → [[_system/skills/README|skills conventions]]
- **Creating or editing a profile note** → [[_system/profile-convention|profile-convention]] and
  [[_system/_profile-template|_profile-template]]. Then run
  `~/automation/bin/vt profiles`
- **Sending anything to Kindle** (readings, PDFs, epubs) → [[_system/kindle|kindle]], skill
  `send-to-kindle`. Fixed address and account; never look it up in Gmail.
- **Sending anything to Speechify** (readings to listen to) → [[_system/speechify|speechify]], skill
  `send-to-speechify`. Web upload in the user's Chrome, one file at a time.
- **Planning any trip, comparing flights or trains, or watching a fare** → skill `travel`, which
  reads the user's travel profile note; machinery in [[_system/travel|travel]].
- **Reordering files, or pinning a note** → [[_system/flexplorer|flexplorer]]
- **Creating a folder or project anchor** → [[_system/README|Vault Map]] § Folder conventions
- **Writing or editing anything in `_system/`** (component docs, status lines, a single
  paragraph) → [[_system/_component-doc-template|_component-doc-template]] first. Edits are where
  docs drift; a hook re-checks the file after each edit and reports violations to fix.
- **Alerting the user, or anything urgent or time-sensitive** → [[_system/push-notifications|push-notifications]].
  Push is read promptly, email is not: timely things go by `notify.send_push()`, email only for what can wait.
- **What earlier sessions worked on** (last 7 days, laptop and Telegram; enriching tasks, planning,
  "what did we do on X") → the Claude session log note. On demand, never preloaded.
- **Anything that needs regular checking afterwards** → add it to
  [[_system/maintenance/maintenance|maintenance]] in the same session

---

**Backlink:** vault-wide rules that must bind every session live in `CLAUDE.md` at the vault root.
Cross-project Claude behaviour that is not vault-specific lives in
[[_system/claude/global-CLAUDE|global-CLAUDE]], copied to `~/.claude/CLAUDE.md` on each machine.
