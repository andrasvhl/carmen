---
type: wiki
---

# Wiki log

Append-only record of every ingest, re-ingest, query gap and lint pass. Newest at the bottom.

Format: `## [YYYY-MM-DD] kind | title`, with kind one of `ingest`, `reingest`, `query`, `gap`,
`lint`, so `grep "^## \[" log.md` lists everything. A `gap` entry is a question the wiki could
not fully answer: the list of what to compile next.

---
