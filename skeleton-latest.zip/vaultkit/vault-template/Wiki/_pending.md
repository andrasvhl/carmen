---
type: reference
component: llm-wiki
last_run: ""
healthy: true
---

# Wiki: what is pending

**Generated daily by `jobs/wiki.py` on the server. Do not edit; every run overwrites this
file.** It lists sources that changed since they were distilled, sources that were deleted, and
new notes nobody has ingested or judged yet. Nothing here is acted on automatically: re-ingest is
a session you start. Rules: [[_system/schema|schema]].

## Nothing outstanding

*The drift job has not run yet.*
