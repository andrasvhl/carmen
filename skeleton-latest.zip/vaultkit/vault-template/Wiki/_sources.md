---
type: reference
component: llm-wiki
last_run: ""
---

# Wiki sources: the registry

**Written by ingest sessions only. Never hand-edit.** One row per note an ingest has read, with
a content hash taken at that moment (`shasum -a 256 "<file>" | cut -c1-12`). A changed hash means
the source moved, and the articles listed are candidates for a diff-scoped re-ingest. The daily
drift job (`jobs/wiki.py`) reads this file; keep both table headers exactly as they are, even
while the tables are empty.

Paths are vault-relative, in backticks. Example row:
``| `Resources/Learning/Spaced repetition.md` | `3f9a1c2b7d40` | 2026-01-15 | fixed-slot-beats-intention |``

## Ingested

| Source | Hash (sha256, 12) | Ingested | Articles fed |
|---|---|---|---|

## Considered and not ingested

Judged rather than missed, so the drift job does not report these as new, and so one that later
grows into a real source is noticed. Reason, then the hash at the time of judging.

| Source | Hash (sha256, 12) | Judged | Why not |
|---|---|---|---|
