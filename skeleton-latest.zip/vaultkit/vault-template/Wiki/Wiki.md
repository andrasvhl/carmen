# Wiki (written by Claude, never by hand)

A small, interlinked set of articles stating what the owner knows and has concluded, compiled
by Claude from the owner's own notes. One article per concept, every claim cited to a source.

**Start at [[index]]**: that is the catalog, and the thing to read before any article. This
note only explains the folder.

**Derived, never authored.** The owner writes sources; the owner and Claude only read the wiki.
To correct an article, fix the source note, then ask Claude to re-ingest it.

The other files here:

- [[index]]: the catalog, read first.
- [[log]]: append-only record of every ingest, re-ingest, query gap and lint pass.
- [[_sources]]: which source fed which article, with a content hash. Written by ingest sessions.
- [[_pending]]: generated daily on the server: sources that changed, and new notes not yet
  ingested or judged.

Rules: [[_system/schema|schema]]. Workflow: the `wiki` skill.
