---
type: wiki
wiki_origin: ingest
---

# Wiki index

**The catalog. Read this first, whole, before any article and before searching the vault.** One
line per page: `[[page]]: the claim in one sentence`. Empty until the first ingest.

The wiki is derived, never authored: nothing here is written by hand, and every claim traces to
a source. Corrections go to the source, then a re-ingest. Rules: [[_system/schema|schema]].

Organised by kind, never by life area. Keep it under 200 lines.

---

## Concepts

*None yet.*

## Source pages

*None yet. One per source rich enough that several articles draw on it.*

## Not yet ingested

*Material known to exist and not yet read, one line each, so a query knows where the wiki's
coverage ends. Example: `Resources/Cooking/`: 12 notes, none read yet.*
