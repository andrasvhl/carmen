# Module: email (Gmail for Claude, through your own Google Cloud project)

## What it does and why

Lets Claude search, read, label and draft in your Gmail, on the Mac and on the server, through
the open-source MCP server `workspace-mcp` (GitHub `taylorwilsdon/google_workspace_mcp`). It
authenticates with an OAuth client **you own** in **your own Google Cloud project**, so no third
party sits between Claude and Google. Several Gmail accounts can be connected at once.

Data note: emails Claude reads are sent to Anthropic for processing (WALKTHROUGH § 0).

## Already have one?

- claude.ai's built-in Gmail connector: fine to keep; it works in chat but not for jobs on the
  server, and only for one account. Two Gmail tool sets can confuse Claude; tell it which to use.
- An existing Google Cloud project or OAuth client: reuse the project, create a new Desktop
  client for this.
- `ls ~/.google_workspace_mcp 2>/dev/null; claude mcp list` to see if it is already set up.
- **Work or university accounts** may block third-party OAuth apps
  (`admin_policy_enforced`). Try it; if blocked, use only personal accounts here.

## Accounts you need

**Google Cloud project** (free, no billing needed). Signed in as the Gmail account to connect:

1. console.cloud.google.com > project picker > **New project**, name `vault-mcp`. Create, then
   select it.
2. APIs & Services > Library > search **Gmail API** > Enable. (For the calendar module, also
   **Google Calendar API**.)
3. **Google Auth Platform** (or "OAuth consent screen") > Get started. App name `vault-mcp`,
   your email as support and developer contact, Audience **External**.
4. Data access > Add scopes. Keep the list as short as the tools need; each one, in plain words:

   | Scope | Lets Claude... | Add? |
   |---|---|---|
   | `openid`, `userinfo.email`, `userinfo.profile` | know which account it is signed in to | Yes (type `openid` as the bare word) |
   | `gmail.readonly` | search and read mail | Yes |
   | `gmail.compose` | create drafts (Google bundles sending into this scope) | Yes, if you want drafts |
   | `gmail.modify` | label, archive, mark read (not permanent delete) | Yes, if you want Claude to tidy mail |
   | `gmail.labels` | create and rename labels | Only if you want that |
   | `gmail.send` | send mail directly | Only if the package asks for it; sending stays blocked by the deny rule in step 6 |
   | `gmail.settings.basic` | manage filters | Only if you want Claude to manage filters |

   `workspace-mcp` asks Google for the scopes of the tools you turn on, and Google's consent
   page then lists them. If it asks for one you left out here, the consent page shows it: decide
   then. For read-only email, check whether the installed version has a read-only option
   (`uvx workspace-mcp@<version> --help`); check the current docs at
   https://github.com/taylorwilsdon/google_workspace_mcp for the exact flag name.
5. Audience > **Publish app** so it says **In production**. Do not submit for verification.
6. Clients > **Create client** > type **Desktop app**, name `workspace-mcp` > Create >
   **Download JSON**.
7. Say "done".

## Steps

1. **Tools on the Mac.** If discovery found no Homebrew (`which brew` printed nothing), install
   it first. **You run this in your own Terminal** (it asks for your Mac login password, and
   may install Apple's command line tools, which takes a few minutes):
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```
   At the end it prints "Next steps" with two or three commands to paste (on Apple Silicon
   Macs they add `eval "$(/opt/homebrew/bin/brew shellenv)"` to `~/.zprofile`). Paste those
   too, then open a new Terminal window and check `brew --version`. (The command is the one
   on brew.sh; if it has changed, use the one shown there.)

   Then Claude runs `brew install uv` (gives `uvx`) and notes its absolute path: `which uvx`.
2. **Put the client file in place** (it is a secret; move it, do not print it):
   ```bash
   mkdir -p ~/.google_workspace_mcp && chmod 700 ~/.google_workspace_mcp
   mv ~/Downloads/client_secret_*.json ~/.google_workspace_mcp/client_secret.json
   chmod 600 ~/.google_workspace_mcp/client_secret.json
   ```
3. **Register the server with Claude Code** (show the user first; this edits `~/.claude.json`).
   Pin the current version (look it up on PyPI, `workspace-mcp`) and use the absolute `uvx`
   path. The package finds the client file through an environment variable; the name below is
   the one it used when this kit was written. **Check the current docs at
   https://github.com/taylorwilsdon/google_workspace_mcp (section on configuration and OAuth
   credentials) for the exact variable name**, and for whether `--tools` and `--single-user`
   are still spelled that way, before running it:
   ```bash
   claude mcp add -s user gws \
     -e WORKSPACE_MCP_PORT=8000 -e OAUTHLIB_INSECURE_TRANSPORT=1 \
     -e GOOGLE_CLIENT_SECRET_PATH="$HOME/.google_workspace_mcp/client_secret.json" \
     -- "$(which uvx)" workspace-mcp@<version> --tools gmail --single-user
   ```
4. **Restart the Claude Code session**, then ask Claude to run the `start_google_auth` tool once
   per account. A browser opens; the user clicks **Advanced > Go to vault-mcp (unsafe)**
   (it is your own app), then **Allow**. A token file appears under
   `~/.google_workspace_mcp/credentials/`.
5. **Same on the server:** install `uv` (`sudo apt -y install pipx && pipx install uv`), copy the
   folder over without printing it, and register the same way:
   ```bash
   scp -r ~/.google_workspace_mcp vault-host:~/
   ssh vault-host 'chmod 700 ~/.google_workspace_mcp && find ~/.google_workspace_mcp -type f -exec chmod 600 {} +'
   ```
   Then run the same `claude mcp add` on the server (with the server's `uvx` path, from
   `ssh vault-host 'command -v uvx || ls ~/.local/bin/uvx'`).
6. **Block sending on the server, by default.** The server's Claude runs unattended and from
   the phone, and it reads mail written by strangers; a malicious email could try to get it to
   send something. A Claude Code **permission deny rule** stops the send tool no matter what
   the session is told. The tool for a registration named `gws` is
   `mcp__gws__send_gmail_message` (confirm the exact name in a session on the server with
   `/mcp`, which lists each server's tools). Show the user the change to the server's
   `~/.claude/settings.json` as a diff first (CLAUDE.md § Respect what they already have):
   ```bash
   ssh vault-host 'f=~/.claude/settings.json; [ -f "$f" ] && cp "$f" "$f.bak-$(date +%F)"; python3 - "$f" <<"PY"
   import json, os, sys
   p = sys.argv[1]
   d = json.load(open(p)) if os.path.exists(p) else {}
   deny = d.setdefault("permissions", {}).setdefault("deny", [])
   rule = "mcp__gws__send_gmail_message"
   if rule not in deny:
       deny.append(rule)
   json.dump(d, open(p, "w"), indent=2)
   print("deny rules:", deny)
   PY'
   ```
   It prints the deny rules only, never other settings. Offer the same rule on the Mac.
   **To allow sending later, consciously:** remove that line from `permissions.deny` (Claude
   shows the diff), and accept that any session on the server could then send mail as you.
   A middle way is to keep it denied and let Claude write drafts you send yourself.
7. **Restart Remote Control** so the phone session sees the new tools and the deny rule:
   `ssh vault-host 'sudo systemctl restart claude-rc'`.

## Gotchas

- **The app must be "In production"** (unverified is fine). In Testing mode Google expires the
  refresh tokens every 7 days, and you would re-consent weekly.
- **"Google hasn't verified this app"** is expected for your own app. Verification for Gmail
  scopes costs hundreds of dollars and is not needed for personal use (100-user cap).
- **New MCP servers appear only after the session restarts**, even when `claude mcp list` says
  Connected.
- **Use the absolute path to `uvx`.** The desktop app does not always inherit the shell PATH.
- **Several accounts: use `--single-user`**, or the server binds the session to the first
  account and asks the second to re-authenticate every time.
- **Send is technically allowed** by these scopes (drafting cannot be granted without it). That
  is why step 6 denies the send tool on the server by default. Claude must still always confirm
  before sending anywhere it is allowed.
- **Tokens are plaintext files**, readable by anything running as the user. Keep the folder out
  of cloud sync. It is a second copy of the tokens on the server; accepted, but know it.
- **The auth link sometimes lands on the Google Account home page.** If no token file appeared,
  paste the authorization URL into the browser by hand.

## Self-test

In a fresh Claude Code session on the Mac, then in the server's Remote Control session: "Search my
Gmail for the newest message from <a sender they know> and tell me its subject." Then, on the
server only: "Send a test email to myself." Pass: correct subject on both machines, the send is
refused by the permission rule on the server, and `ls ~/.google_workspace_mcp/credentials/`
shows one token per connected account.
