# Module: fitness (Strava and WHOOP sessions into a vault note) - OPTIONAL

## What it does and why

Every two hours a small job on the server asks Strava for new activities of the types you
choose (runs by default), adds the matching **WHOOP** workout (heart-rate zones, strain) and
that morning's recovery reading if you use WHOOP, and appends one short, numbers-only entry per
session to a note in your vault, by default `Areas/Fitness/Training log.md`. You then have your
training next to your plans, readable by Claude, without copying anything by hand.

It is a plain script, not Claude: it never interprets, judges or comments. It writes what the
sensors recorded. A status page, `_system/fitness-sync-status.md`, shows on any device whether
the last run worked.

How it works: `jobs/fitness_sync` in `~/automation`, started by
`automation@fitness_sync.timer` through the same `automation@.service` and `bin/run-job` as
every other job. It uses two maintained libraries, `stravalib` (Strava API v3) and `whoop`
(WHOOP API v2), which handle the OAuth and paging. Secrets live in `~/.fitness-sync/` on the
server, never in the vault. The vault doc is `_system/fitness-sync.md` (shipped with the
starter vault).

**Data note, plainly: this is health data.** Heart rate, HRV, resting heart rate and recovery
scores end up in a vault note, which Obsidian Sync carries to your devices and which Claude
reads when it works in the vault (so it goes to Anthropic when Claude reads it, WALKTHROUGH
§ 0). Strava and WHOOP already hold it; this module only copies it into your vault. If you do
not want recovery and heart-rate figures in the vault, skip WHOOP and only Strava's distance,
pace and splits are written.

**Cost (checked 2026-10-04, verify):** WHOOP's developer API is free for your own account.
**Strava's API needs a paid Strava subscription** on the account that creates the API app
(introduced June 2026; about $12 a month in the US, or included if you already subscribe).
Confirm with the user before they subscribe for this.

## Already have one?

- **Already sync Strava somewhere** (another app, a spreadsheet): fine, Strava allows many
  connected apps. This one only reads.
- **An existing Strava API app of your own**: reuse it (its Client ID and Secret), and add
  this server's address to its callback domain only if nothing else uses that field. Otherwise
  make a second app.
- **An older version of this sync running from crontab** (it keeps its secrets in
  `~/.fitness-sync/config.json`): the file layout is the same, so the new job reuses the
  tokens and the old `state.json` as they are. Install the timer, check one run, then remove
  the crontab line in the same session (two schedulers would refresh the same tokens and break
  WHOOP's chain). Never run both.

## Accounts you need

**1. Strava** with a subscription (see Cost). Then the API app. **The user does this, step by
step, and says "done":**

1. Open **strava.com/settings/api** (logged in to Strava, on a computer).
2. Fill in the form. Exact field names may differ; as of 2026 they are roughly:
   - **Application Name:** anything without the word "Strava", e.g. `My Vault Sync`.
   - **Category:** any that fits, e.g. *Data Importer* or *Training*.
   - **Club:** leave empty.
   - **Website:** any address you own; `https://<VK_TAILNET_HOST>` is fine.
   - **Application Description:** e.g. `Copies my own activities into my notes`.
   - **Authorization Callback Domain:** your server's Tailscale name, the value of
     `VK_TAILNET_HOST` in `config.env` (Claude shows it in step 2 of Steps). Only the name: no
     `https://`, no `/callback`. (See "Why this address" below.)
3. Accept Strava's API agreement (the user reads and accepts it themselves) and create the
   app. Strava may ask for an icon: any small square picture works.
4. The page now shows **Client ID** (a number) and **Client Secret** (behind "show"). Keep the
   page open. **Do not paste either into this chat**; they are typed into a hidden prompt in
   step 3. (The page also shows an access and refresh token: ignore them, they cannot read
   private activities.)

**2. WHOOP (optional)**, only if you wear one. **The user does this and says "done":**

1. Open **developer-dashboard.whoop.com** and log in with the normal WHOOP account.
2. If asked, **create a Team**: any name, e.g. `Personal`.
3. **Create App** (developer-dashboard.whoop.com/apps/create):
   - **Name:** e.g. `My Vault Sync`. Fill in any other required details with your own info.
   - **Scopes:** tick at least `read:workout`, `read:recovery` and `read:profile` (ticking the
     other `read:` ones does no harm).
   - **Redirect URI:** exactly the address Claude shows in step 2 of Steps, e.g.
     `https://vault-host.example-tailnet.ts.net/callback`. It must match character for
     character.
4. Create it. The page shows **Client ID** and **Client Secret**. Keep it open; do not paste
   them here.

WHOOP apps in development mode need no approval for your own account (WHOOP limits how many
members an unapproved app can have; one is fine).

**Why this address.** After you click Authorize, Strava and WHOOP send the browser to the
"redirect" address registered with your app, with a one-time code attached. This module does
not run a web server for that: **nothing listens at the address, the page fails to load, and
that is expected.** You copy the whole address from the address bar (the code is in it) and
paste it into a hidden prompt. So the address only has to be one you control and that WHOOP
accepts, which means `https://`. Your server's Tailscale name (from the tailscale module) is
exactly that, and it never needs Tailscale Funnel or an open port. No Tailscale name? Set
`FITNESS_REDIRECT_URI` in `~/.automation.env` to another `https://` address you control, and
use its domain as Strava's callback domain. (Strava alone would also accept `localhost`; WHOOP
requires `https://`, so the kit uses one address for both.)

## Steps

Prerequisites: automation-runner and tailscale modules done. The server needs **Python 3.12 or
newer** (the `whoop` library needs it; Ubuntu 24.04 and later have it).

1. **The two libraries, into the shared virtualenv.** `bin/run-job` uses `~/automation/.venv`
   when it exists (the telegram module may have made it already):
   ```bash
   ssh vault-host 'cd ~/automation && python3 -c "import sys; assert sys.version_info >= (3, 12), sys.version" && \
     { [ -x .venv/bin/python ] || { sudo apt -y install python3-venv && python3 -m venv .venv; }; } && \
     .venv/bin/pip install -q -r jobs/fitness_sync/requirements.txt && \
     .venv/bin/python -c "import stravalib, whoop; print(\"ok\")" && \
     .venv/bin/python -m jobs.fitness_sync.tests | tail -1'
   ```
   Pass: `ok`, then `all passed` (offline tests, made-up data, a throwaway folder). If the
   telegram module is installed, re-run its tests too, since both share the venv:
   `ssh vault-host 'cd ~/automation && .venv/bin/python -m tests.tg_bridge | tail -1'`.
2. **Show the redirect address** for the accounts above:
   ```bash
   ssh vault-host 'cd ~/automation && python3 -c "from jobs.fitness_sync.common import redirect_uri; print(redirect_uri() or \"NOT SET: see Why this address\")"'
   ```
   Give the user the address (for WHOOP) and the part between `https://` and `/callback` (for
   Strava's callback domain). Now do "Accounts you need".
3. **Connect Strava. You run this in your own Terminal** (it asks for the Client ID, which
   shows as you type, and the Client Secret, which does not; then it prints an address):
   ```bash
   ssh -t vault-host '~/automation/bin/run-job fitness_sync.auth strava'
   ```
   Open the printed address in a browser, log in, **leave every box ticked** (the job needs
   "View data about your private activities"), click **Authorize**. The browser shows an error
   page: copy the whole address from the address bar, paste it into the Terminal prompt (nothing
   shows, that is normal), press Return. Pass: `Done. Strava is connected`. Say "done".
4. **Connect WHOOP (optional). You run this in your own Terminal**, same pattern:
   ```bash
   ssh -t vault-host '~/automation/bin/run-job fitness_sync.auth whoop'
   ```
5. **Claude checks the shape** of the secrets file, key names and mode only:
   ```bash
   ssh vault-host 'python3 -c "import json, os; p = os.path.expanduser(\"~/.fitness-sync/config.json\"); d = json.load(open(p)); print({k: sorted(v) for k, v in d.items()}, oct(os.stat(p).st_mode & 0o777), oct(os.stat(os.path.dirname(p)).st_mode & 0o777))"'
   ```
   Pass: `strava` lists `client_id, client_secret, refresh_token`; `whoop` (if connected)
   lists `client_id, client_secret, token`; then `0o600 0o700`.
6. **Settings (optional)**, in `~/.automation.env`, all with defaults. Ask the user about the
   first two; skip the rest on a first install:

   | Setting | Default | Meaning |
   |---|---|---|
   | `FITNESS_ACTIVITY_TYPES` | `Run,TrailRun` | Strava sport types to log, comma-separated, e.g. `Ride,VirtualRide`, `Swim`, `Hike`, `WeightTraining` (Strava's `sport_type` names) |
   | `FITNESS_LOG_NOTE` | `Areas/Fitness/Training log.md` | The note, relative to the vault. Created on the first entry if missing. Paths outside the vault are refused |
   | `FITNESS_BACKFILL_DAYS` | `0` | Read **only before the very first run**: also log this many days back. 0 means "from now on" |
   | `FITNESS_MIN_MINUTES` | `5` | Shorter activities are treated as accidental starts |
   | `FITNESS_STALE_DAYS` | `7` | After this many days with nothing logged, the status page says so (no alert) |
   | `FITNESS_REDIRECT_URI` | `https://<VK_TAILNET_HOST>/callback` | Only if you have no Tailscale name |

   ```bash
   ssh vault-host "sed -i '/^FITNESS_ACTIVITY_TYPES=/d' ~/.automation.env && echo 'FITNESS_ACTIVITY_TYPES=Run,TrailRun' >> ~/.automation.env"
   ```
7. **A dry run, then the first real run.**
   ```bash
   ssh vault-host '~/automation/bin/run-job fitness_sync --dry-run; ~/automation/bin/run-job fitness_sync'
   ```
   Pass: no traceback; the real run says `first run, floor set`. Nothing is written to the note
   yet (unless you set a backfill). The dry run still refreshes and saves the tokens, because
   both services replace the refresh token on every use.
8. **Timer**, from the shipped template, rendered with the CLAUDE.md command (unit list:
   `automation@fitness_sync.timer`; `automation@.service` is installed already), then:
   ```bash
   ssh vault-host 'sudo systemd-analyze verify /etc/systemd/system/automation@fitness_sync.timer && \
     sudo systemctl enable --now automation@fitness_sync.timer && systemctl list-timers automation@fitness_sync.timer --no-pager'
   ```
   Pass: the next run shows at `:27` past an even hour.
9. **Vault docs** (Claude, on the Mac, showing the change first):
   - `_system/fitness-sync.md`: `stage: built`, `verified:` today, and replace the Status line
     with `**Status:** built <date>, verified <date>. Referenced from SYSTEM.md § Components.`
   - `_system/SYSTEM.md` § Components, one row:
     `| Fitness sync (Strava, optional WHOOP, into a training-log note) | Built <date>; timer every 2h on the server | [[fitness-sync]] |`
   - `Claude Master Router.md` § Route by what you're touching, one line:
     `- **Training sessions, workouts, recovery data** → the log note (\`FITNESS_LOG_NOTE\`, default \`Areas/Fitness/Training log.md\`); how it gets there and why it may be stale → [[_system/fitness-sync|fitness-sync]], health → [[_system/fitness-sync-status|fitness-sync-status]]`
   - `_system/README.md` (Vault Map), under `_system/`:
     `- \`fitness-sync.md\`: the Strava/WHOOP sync job that appends sessions to the training-log note`
     and `- \`fitness-sync-status.md\`: **machine-written** health page, rewritten every run`
   - If the log note's folder is new, list it in the Vault Map's Folders section too.

## Gotchas

- **Never schedule it twice** (a timer plus an old crontab line, or two servers). Both
  services keep exactly one valid refresh token; two refreshers race and WHOOP's loser is dead
  for good. The job and the auth script share a lock on one server; nothing can protect two.
- **A dead WHOOP credential looks like missing data.** `invalid_request` / `invalid_grant` in
  the status page while Strava works, and entries saying "no workout found": re-run step 4.
  Nothing is lost; the job only reads.
- **A Strava refresh that starts failing after mid-2026** may be the subscription, not the
  token: check the account still has one, then re-run step 3.
- **Library upgrades are deliberate.** The versions are pinned in
  `jobs/fitness_sync/requirements.txt`, because a stravalib change once made the type filter
  silently match nothing. After any `pip` change in `.venv` (including for Telegram), run the
  dry run of step 7. The job also flags "activities found, none of your types" by itself.
- **Secrets never reach the logs.** The job keeps the libraries' request logging off (one of
  them logs the client secret at INFO) and scrubs secrets from every error text. The self-test
  checks this.
- **Edit the log note freely, but not at the minute it appends.** The job only appends; your
  own notes under older entries are safe. A simultaneous edit can lose one side in Sync.
- **Times:** the timer uses the server's clock; entries use each activity's local time from
  Strava.

## Self-test

```bash
ssh vault-host 'systemctl is-active automation@fitness_sync.timer; \
  sudo journalctl -u automation@fitness_sync -n 15 --no-pager | grep fitness_sync; \
  sudo journalctl -u automation@fitness_sync --no-pager | grep -ciE "client_secret=|refresh_token=[^*]"; \
  cd ~/automation && python3 -c "from runner import config; print(open(config.VAULT / \"_system/fitness-sync-status.md\").read()[:400])"'
```

Pass: `active`; a recent `fitness_sync: ok, N/N checks passed`; the secret count prints `0`;
the status page says `healthy: true`. Then the real proof: **record a short session of a chosen
type** (a 6-minute walk counts if `Walk` is in your types, or wait for your next real session),
and within about two hours an entry appears at the bottom of the log note. Record the result in
`PROGRESS.md`, plus which services are connected and the settings chosen (names and values,
never secrets).

`heartbeat` checks daily that the job ran within the last 5 hours, but only while
`automation@fitness_sync.timer` is installed (no timer, no check). The job's own findings (a
dead credential, a drifted type filter, a token not saved) land in the alert log like every
other job's; none of them pushes, because a stalled fitness log is never an emergency.
