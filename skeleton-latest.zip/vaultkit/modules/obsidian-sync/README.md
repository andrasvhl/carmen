# Module: obsidian-sync (your vault on the server, safely)

## What it does and why

Puts a live copy of your vault on the server using Obsidian's official headless Sync client
(`ob`, npm package `obsidian-headless`). Edits on your Mac or phone reach the server within
seconds, and Claude's edits on the server reach your devices. A **sync-guard** runs before
every start of the client and refuses to let the server delete anything unless its copy is
complete. This module also adds the starter system files from `vault-template/` to your vault.

## Already have one?

- **Existing vault:** reuse it. Do not restructure it. Ask before adding anything.
- **Obsidian Sync already on:** in Obsidian, Settings > Sync shows the remote vault and plan.
  Reuse that remote vault. Note the plan's file size limit (Standard 5 MB, Plus 200 MB).
- **Vault in iCloud, git or Syncthing:** Obsidian Sync must become the one sync for this folder.
  Two syncs on one folder fight. Plan the move with the user (with a backup first) or stop the
  other sync for that folder.
- **No vault yet:** the kit's `vault-template/` becomes the new vault (step 2 below), and Sync
  is connected to it afterwards.

## Accounts you need

**Obsidian app, account and Sync subscription** (ask before buying):

1. **Obsidian on the Mac**, if discovery found no `/Applications/Obsidian.app`: download it
   from obsidian.md/download, open the downloaded file and drag Obsidian into Applications (or,
   with Homebrew, `brew install --cask obsidian`). Open it once.
2. obsidian.md > Log in / Sign up (top right). Create an account with your email.
3. Account page > Sync > choose a plan (Standard is fine unless you store big PDFs, audio or
   video). Pay.
4. **Before connecting Sync, Claude does Steps 1 and 2 below** (a backup, and the starter vault),
   so the vault Sync uploads already has the starter files in it.
5. In Obsidian on the Mac, with the vault open: Settings > Sync > log in > **Create new vault**
   or connect the existing remote vault. For a new remote vault, pick the region that matches
   the server's location (EU server, EU region; US server, US region); it cannot be changed
   later. Set an **encryption password** if offered and store it in the password manager: the
   server asks for it in step 5.
6. Let the Mac finish uploading. Then on the phone: install Obsidian, open the same remote vault.
7. Say "done".

## Steps

1. **Back up the vault on the Mac first** (a plain copy; skip if there is no vault yet):
   `cp -R "<mac vault path>" ~/vault-backup-$(date +%F)`
2. **Starter vault**, following sections 1 to 3 of `~/vaultkit/vault-template/SETUP-NOTES.md`
   (sections 4 to 7 come after the automation-runner module, WALKTHROUGH § 3):
   - **No vault yet:** copy the template as the new vault, then open it in Obsidian (**Open
     folder as vault**). The folder name is the vault name, so it must match `VK_VAULT_NAME`:
     ```bash
     mkdir -p ~/Obsidian && cp -R ~/vaultkit/vault-template "$HOME/Obsidian/<VK_VAULT_NAME>"
     ```
   - **Existing vault:** list what `vault-template/` would add and show which files already
     exist. With the user's yes, copy **only missing files**, never overwrite. Show the list
     first, then copy:
     ```bash
     rsync -a --ignore-existing --dry-run -v ~/vaultkit/vault-template/ "<mac vault path>/"
     rsync -a --ignore-existing ~/vaultkit/vault-template/ "<mac vault path>/"
     ```
     The user may leave out anything they do not want (for example the example task). If the
     user has their own `CLAUDE.md` in the vault, show a diff and ask.
   - Then SETUP-NOTES § 1 (install date), § 2 (Bases) and § 3 (community plugins). Only after
     that, connect Sync (Accounts, item 5). Obsidian Sync carries the files to the server.
3. **The kit's code** is already on the server at `~/automation` (claude-code module, step 5;
   `ssh vault-host 'ls ~/automation/bin/sync-guard.sh'`). If not:
   `rsync -a --exclude __pycache__ ~/vaultkit/code/automation/ vault-host:~/automation/`
4. **Install and sign in.**
   ```bash
   ssh vault-host 'sudo npm install -g obsidian-headless && which ob && ob --version'
   ```
   **You run this in your own Terminal** (it asks for the Obsidian account email and password):
   ```bash
   ssh -t vault-host 'ob login'
   ```
   Then Claude checks: `ssh vault-host 'ob sync-list-remote'`
   (If `ob login` is not the command in the installed version, `ob --help` lists it.)
   `sync-guard.sh` finds `ob` with `command -v ob`, else `/usr/bin/ob`. Under systemd the PATH
   is short (`/usr/local/bin:/usr/bin:/bin` and the sbin dirs). If `which ob` shows a path
   outside it, uncomment `Environment=OB_BIN=...` in `units/obsidian-sync.service` and set it
   to that path before rendering.
5. **Link the folder, then fix the config immediately** (setup ignores what you ask for).
   **You run this in your own Terminal.** It asks for the vault's **Sync encryption password**
   (the one from Accounts, item 5, in the password manager), if the remote vault has one:
   ```bash
   ssh -t vault-host 'ob sync-setup --vault "<remote vault name>" --path ~/vault'
   ```
   Then Claude fixes the config:
   ```bash
   ssh vault-host 'ob sync-config --path ~/vault --mode pull-only --conflict-strategy conflict \
     --device-name vault-host --configs none && ob sync-status --path ~/vault'
   ```
   Flags can change between versions: check `ob sync-config --help` and confirm with
   `ob sync-status` that mode is **pull-only**, conflict strategy **conflict**, configs **none**.
   Pick file types to match the plan (images and PDFs are usually wanted).
6. **The service, started through the guard**, from the shipped template
   `units/obsidian-sync.service`. It runs `~/automation/bin/sync-guard.sh` as `VK_USER` with
   `VAULT_PATH` and `VK_HOSTNAME` set; the guard picks the mode, then execs
   `ob sync --path "$VAULT_PATH" --continuous`. Dry-run the guard, then render (as in
   CLAUDE.md), verify and start:
   ```bash
   ssh vault-host 'chmod +x ~/automation/bin/*.sh && VAULT_PATH=~/vault GUARD_DRY_RUN=1 ~/automation/bin/sync-guard.sh'
   ssh vault-host 'set -a; . ~/.config/vaultkit/config.env; set +a; cd ~/automation/units && \
     for u in obsidian-sync.service; do \
       envsubst "\${VK_USER} \${VK_HOSTNAME} \${VAULT_PATH} \${VK_VAULT_NAME} \${VK_TIMEZONE} \${VK_ALERT_EMAIL} \${VK_SENDER_EMAIL} \${VK_TAILNET} \${VK_TAILNET_HOST}" \
         < "$u" > "/tmp/$u" && sudo install -m 644 "/tmp/$u" /etc/systemd/system/ && rm "/tmp/$u"; \
     done; sudo systemctl daemon-reload; \
     sudo systemd-analyze verify /etc/systemd/system/obsidian-sync.service && sudo systemctl enable --now obsidian-sync'
   ```
   On a fresh install there is no `_system/sync-manifest.json`, so the guard starts
   **pull-only** (it can download, never delete) and writes a "Sync guard blocked" note into
   `Inbox/`. That is expected now and the note can be deleted. It stays pull-only until step 8
   seeds the manifest: the guard only ever raises an existing manifest, it never creates one.
7. **Wait for the first download**, then compare Mac and server. Filenames must be normalised
   (see Gotchas) or umlauts and accents show as false differences:
   ```bash
   cat > /tmp/nfc-list.py <<'PY'
   import os, sys, unicodedata
   for root, dirs, files in os.walk(sys.argv[1]):
       dirs[:] = [d for d in dirs if not d.startswith(".")]
       for f in files:
           if not f.startswith("."):
               rel = os.path.relpath(os.path.join(root, f), sys.argv[1])
               print(unicodedata.normalize("NFC", rel))
   PY
   scp /tmp/nfc-list.py vault-host:/tmp/
   python3 /tmp/nfc-list.py "<mac vault path>" | LC_ALL=C sort > /tmp/mac.txt
   ssh vault-host 'python3 /tmp/nfc-list.py ~/vault | LC_ALL=C sort' > /tmp/box.txt
   LC_ALL=C comm -3 /tmp/mac.txt /tmp/box.txt | head -50
   ```
   Explain every difference before going on. Expected ones: files above the plan's size limit,
   file types not selected.
8. **Seed the manifest** (the guard's baseline), **on the server, only after step 7 came out
   clean**: the count must come from a complete copy. This counts exactly what the guard counts
   (every file not under a dot-path) and writes the format it reads:
   ```bash
   ssh vault-host 'V=~/vault; n=$(find "$V" -type f -not -path "*/.*" | wc -l); \
     printf "{\"generated\": \"%s\", \"syncable_count\": %d}\n" "$(date -Iseconds)" "$n" \
       > "$V/_system/sync-manifest.json"; cat "$V/_system/sync-manifest.json"'
   ```
   Expect something like `{"generated": "2026-10-04T14:05:00+02:00", "syncable_count": 1234}`,
   with the number close to the Mac's file count from step 7. Do not seed it from the Mac: the
   Mac also has files the server never receives (over the size limit, unselected file types),
   and a count that is too high keeps the guard pull-only.
9. **Go bidirectional, with consent.** The guard decides at every start of the service. It
   allows writes when the manifest exists, is at most **21 days** old, and the local file count
   is at least **97%** of `syncable_count`. So after seeding, restart once:
   ```bash
   ssh vault-host 'GUARD_DRY_RUN=1 ~/automation/bin/sync-guard.sh; \
     sudo systemctl restart obsidian-sync && sudo journalctl -u obsidian-sync -n 20 --no-pager | grep sync-guard'
   ```
   It should log `OK: ... Writes allowed.` and `starting: ob sync --continuous
   (mode=bidirectional)`. From then on, every start while bidirectional ratchets the count up
   (and refreshes `generated`) when the vault has grown; it never lowers it. If the vault has
   not grown for 21 days and the service restarts, the guard drops back to pull-only and leaves
   a note: check the copy is complete, then re-run the seeding command above and restart.

## Gotchas

- **The headless client pushes deletions when its local copy is incomplete.** In bidirectional
  mode `ob` (0.0.14 at the time of writing) cannot tell "I never had this file" from "the user
  deleted it". If the server's copy is short when the service starts, it deletes the missing
  files everywhere. **This has destroyed thousands of files in practice** (recoverable only
  from Sync history and a backup). Hence `sync-guard.sh` and the file-count manifest.
  **Never restart bidirectional with a knowingly incomplete copy.** To widen excluded folders or
  file types: switch to pull-only, restart, let it catch up, then return to bidirectional.
- **`ob sync-setup` ignores the mode you ask for** and defaults to bidirectional with all media
  types. Run `ob sync-config` straight after, before the first sync.
- **`--file-types ""` does not clear the list**, despite the help text.
- **The unit needs an explicit `--path`.** Without it `ob` runs from `/` and crash-loops with
  "No sync configuration found for /". `WorkingDirectory` is not enough (the guard passes it).
- **Changing the config does not change the running process.** Restart the service; `ob
  sync-status` shows the new mode even when the daemon has not picked it up.
- **macOS stores filenames as NFD, Linux and Obsidian Sync as NFC.** Any comparison between the
  two copies must normalise first, and `comm`/`sort` need `LC_ALL=C`, or every umlaut or accent
  shows as a mismatch.
- **Obsidian ignores dotfiles.** Never test with a file whose name starts with `.`.
- **A file Sync once rejected (too big) is never retried**, even after a plan upgrade. Rename or
  re-save it. The headless client also caches the plan; restart it after an upgrade.
- **Testing conflicts needs real divergence:** stop sync, edit both sides, start again.
  Near-simultaneous edits are just last-write-wins.
- **Code does not travel through Sync** (markdown and media only). Scripts live in
  `~/automation`, never in the vault.

## Self-test

```bash
ssh vault-host 'systemctl is-active obsidian-sync; ob sync-status --path ~/vault; \
  GUARD_DRY_RUN=1 ~/automation/bin/sync-guard.sh'
```

Then a round trip: create `Inbox/sync test.md` on the Mac, check it appears on the server within
a minute (`ssh vault-host 'ls ~/vault/Inbox'`); then `ssh vault-host 'echo hi >> "$HOME/vault/Inbox/sync test.md"'`
and check the change reaches the Mac; then delete it on the Mac and check it disappears on the
server. Pass: service active, mode bidirectional, guard says writes allowed, all three
directions work.
