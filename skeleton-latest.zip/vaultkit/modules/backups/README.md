# Module: backups (nightly encrypted backup to Backblaze B2)

## What it does and why

Every night the server backs up the vault with **restic** to **Backblaze B2** cloud storage.
restic encrypts everything on the server before upload, so Backblaze holds only scrambled data.
It keeps 7 daily, 5 weekly, 12 monthly and 3 yearly snapshots, and only uploads what changed.

Why it matters: Obsidian Sync's version history is not a backup. A sync client bug has
destroyed thousands of files in practice, and Sync history only brings them back if it happens to
still hold them. With this module, the next incident is a restore, not a rescue.

Kit files: `bin/setup-b2.sh` (one-time interactive setup), `bin/backup-vault.sh` (the nightly
job), `bin/restore-test.sh` (proves a restore works).

## Already have one?

- **Time Machine or Backblaze Computer Backup on the Mac:** keep them. They cover the Mac, not the
  server. (Backblaze's Computer Backup product does not support Linux; that is why the server
  uses B2, a different product.)
- **Existing restic repository or B2 account:** reuse the account, create a **new bucket** and a
  **new key** just for this server.

## Accounts you need

**Backblaze B2** (first 10 GB free):

1. backblaze.com > Sign Up > choose **B2 Cloud Storage** (not Computer Backup). Pick a region
   (EU if the server is in the EU).
2. Buckets > **Create a Bucket**. Name it something unique like `<yourname>-vault-backup` (names
   are global across all Backblaze customers). **Private**, encryption off (restic encrypts),
   object lock off.
3. Application Keys > **Add a New Application Key**. Name `vault-host`, allow access to **only
   that bucket**, Read and Write. Create.
4. The page shows **keyID** and **applicationKey**. The applicationKey is shown **only once**.
   Keep the page open. Say "done".

## Steps

1. **Install restic** on the server: `ssh vault-host 'sudo apt -y install restic && restic version'`
2. **You run this in your own Terminal** (not through Claude: it shows the passphrase):
   ```bash
   ssh -t vault-host '~/automation/bin/setup-b2.sh'
   ```
   It asks for the bucket name, keyID and applicationKey with hidden input, creates a random
   passphrase, writes `~/.config/restic/b2-box.env` (mode 600), initialises the repository and
   shows the passphrase once. **Store the passphrase in your password manager now.** Without
   it the backup can never be read. There is no reset.
3. **Units**, from the shipped templates `units/backup-vault.service` and
   `units/backup-vault.timer` (03:20 server time, up to 15 minutes random delay). The service
   runs `~/automation/bin/backup-vault.sh` as `VK_USER` with `VAULT_PATH` set; the script reads
   its credentials from `~/.config/restic/b2-box.env`, never from the unit. Render as in
   CLAUDE.md:
   ```bash
   ssh vault-host 'set -a; . ~/.config/vaultkit/config.env; set +a; cd ~/automation/units && \
     for u in backup-vault.service backup-vault.timer; do \
       envsubst "\${VK_USER} \${VK_HOSTNAME} \${VAULT_PATH} \${VK_VAULT_NAME} \${VK_TIMEZONE} \${VK_ALERT_EMAIL} \${VK_SENDER_EMAIL} \${VK_TAILNET} \${VK_TAILNET_HOST}" \
         < "$u" > "/tmp/$u" && sudo install -m 644 "/tmp/$u" /etc/systemd/system/ && rm "/tmp/$u"; \
     done; sudo systemctl daemon-reload; sudo systemd-analyze verify /etc/systemd/system/backup-vault.timer'
   ```
4. **First backup through systemd**, so it survives the SSH session closing:
   ```bash
   ssh vault-host 'sudo systemctl enable backup-vault.timer && \
     sudo systemctl start --no-block backup-vault.service'
   ssh vault-host 'sudo journalctl -u backup-vault -f'     # watch; Ctrl-C when done
   ```
   Then `ssh vault-host 'sudo systemctl start backup-vault.timer'`.
5. **Run the restore test** once the first snapshot exists:
   `ssh vault-host '~/automation/bin/restore-test.sh'`. With no arguments it restores a random
   sample of 10 vault files (`SAMPLE=20` for more) and compares their hashes with the live
   vault; to test specific files, pass vault-relative paths
   (`restore-test.sh "Inbox/Some note.md"`).

## Gotchas

- **The passphrase is unrecoverable.** Lose it and every backup is permanently unreadable.
- **`401 bad_auth_token` is never a bucket problem.** The keyID/applicationKey pair is wrong. A
  keyID looks like hex; if it looks like a name, the bucket name went into the wrong field.
- **The keyID stays visible** in the Application Keys table; only the applicationKey is shown
  once. A wrong keyID never requires a new key.
- **Run the first backup through systemd**, not interactively: a long upload over SSH dies with
  the session and leaves zero snapshots.
- **A timer that stops firing sends no alert.** The script alerts when it runs and fails, not
  when it never runs. Check `systemctl list-timers backup-vault.timer` monthly, and consider a
  third Healthchecks.io check pinged at the end of `backup-vault.sh`.
- **Files above the Sync size limit** that exist only on the server are covered here and nowhere
  else.

## Self-test

```bash
ssh vault-host 'systemctl list-timers backup-vault.timer --no-pager; \
  set -a; . ~/.config/restic/b2-box.env; set +a; restic snapshots --compact | tail -3; \
  ~/automation/bin/restore-test.sh'
```

Pass: the timer is scheduled, at least one snapshot exists, and the restore test restores real
files whose hashes match the live vault.
