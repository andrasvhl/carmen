# Module: capture (a thought into your Inbox in two seconds)

## What it does and why

Two quick ways to drop a thought into the vault's `Inbox/` folder as a small typed note, without
opening and navigating Obsidian:

- **Mac:** a **Raycast** hotkey opens a tiny form (title, optional description, type: action or
  learning). On submit it writes the note file straight into the vault, even with Obsidian
  closed.
- **iPhone:** an **Apple Shortcut** on the Action Button (or home screen) asks for the text and
  creates the note through Obsidian's `obsidian://new` link.

Both write the same note format, which the vault's task views and `vt todos` read. Capture has
to be effortless or it does not happen; that is the whole point.

## Already have one?

- Alfred, a Raycast script, Drafts, Obsidian's QuickAdd plugin, an existing Shortcut: keep it if
  it works. Just make sure it writes the same frontmatter as below, into `Inbox/`.
- Check the vault's task schema in `vault-template/` (or the user's own) before building; both
  paths must match it exactly.

## Accounts you need

- **Raycast** (free): raycast.com > Download, install, sign in optional. Say "done".
- Nothing for the iPhone; Shortcuts is built in.

## Steps

**The note both paths write** (adapt to the vault's schema):
```markdown
---
type: action
captured: 2026-10-04T14:05
status: inbox
priority: 1-none
---
<Title>

<Description, if any>
```
Filename: the title with `\ / : # ^ [ ] |` replaced by `-`, cut to 60 characters. The title is
never cut inside the note, only in the filename.

1. **Mac, Raycast.** Simplest: a Raycast **Script Command** (Raycast > Settings > Extensions >
   Script Commands > add a folder) written by Claude in bash or Python, taking title, description
   and type as arguments and writing the note into `<mac vault path>/Inbox/`. It needs no Node.
   A full Raycast extension (TypeScript form with a dropdown) is possible if the user wants a
   nicer form; only that needs Node on the Mac: `brew install node` (Homebrew: see the email
   module, step 1), and check `node --version` is 22 or higher. Assign
   a hotkey (Raycast > the command > Record Hotkey).
2. **iPhone, Shortcut.** The fastest way is to generate it on the Mac. The kit ships a builder
   that writes a ready-made "Add to Inbox" Shortcut (Name, optional Description, then a menu:
   Action / Learning / Urgent) for the user's own vault:
   ```bash
   cd ~/Desktop
   VK_VAULT_NAME="<the vault name>" python3 ~/automation/tools/build_capture_shortcut.py .
   shortcuts sign --mode anyone --input "Add to Inbox (unsigned).shortcut" --output "Add to Inbox.shortcut"
   ```
   AirDrop `Add to Inbox.shortcut` to the iPhone (or put it in iCloud Drive and tap it), and add it.
   Then iPhone Settings > Action Button > Shortcut > "Add to Inbox". Test once: the note must
   appear in `Inbox/` with the right frontmatter. If the menu should differ (other types, a
   priority choice), edit the `items` dictionary in the builder and generate again.

   **Fallback, by hand**, in the Shortcuts app (or described in plain language to the Shortcuts
   AI builder):
   1. Ask for Text: "Name". Ask for Text: "Description" (optional).
   2. Choose from Menu: Action / Learning, which sets `type`.
   3. Build the note text as above, with the current date in `captured`.
   4. Copy the note text to the **clipboard**.
   5. Build the filename (sanitised, max 60 characters) and **URL-encode** it.
   6. Open URL: `obsidian://new?vault=<URL-encoded VK_VAULT_NAME>&file=Inbox%2F<encoded filename>.md&clipboard=true`
   7. iPhone Settings > Action Button > Shortcut > pick it.

## Gotchas

- **URL-encode every dynamic part of the link**, the filename and vault name too. An unencoded
  space or comma makes iOS cut the link and creates an empty, wrongly named note with no error.
- **Never put the note text in the URL.** Long captures get cut silently around a couple of
  hundred characters. Use the clipboard (`&clipboard=true`) as above.
- **Cut only the filename, never the body.** A long one-line capture otherwise becomes a giant
  filename and fails.
- **Re-importing a Shortcut creates a duplicate** with a new name, and the Action Button keeps
  running the old one. Delete the old one first.
- **Every iPhone capture switches to Obsidian**; inherent to the link. Obsidian then syncs it.
- **The Mac path writes files directly**, so it works with Obsidian closed; Sync picks the note
  up when Obsidian next runs (and the server gets it then).

## Self-test

Capture "test capture mac" with the hotkey and "test capture phone" from the iPhone. Pass: both
notes appear in `Inbox/` with identical frontmatter shape, show up on the server
(`ssh vault-host 'ls ~/vault/Inbox | grep test'`) and in `vt todos`. Delete both after.
