# Module: automation-runner (scheduled jobs, heartbeat, dead man's switch)

## What it does and why

A small Python runner in `~/automation` on the server (the kit's `code/automation/`, copied
there in the claude-code module), plus systemd timers that start its jobs. A second copy on
the Mac gives you the `vt` vault tools there too.
Every job reports what it found; real problems push to your phone, the rest go into an alert
log in the vault (`_system/maintenance/alert-log/`). An off-box service, **Healthchecks.io**,
notices if the pings stop, which is the only alarm that still works if the whole server dies.

Jobs shipped in `code/automation/jobs/`:

Times are the **server's clock**, so set its timezone to yours (vps module, step 5) or 07:30
means 07:30 UTC. Only `claude_update` names `VK_TIMEZONE` itself.

| Job | When | Does |
|---|---|---|
| `selftest` | daily 07:10 | checks the preconditions every other job needs (state dir, Inbox, credentials, mail, Healthchecks URL) |
| `heartbeat` | daily 07:30 | services running, Claude login, disk space, mail working, Remote Control session count |
| `rc_reap` | daily 08:00 | closes Remote Control sessions idle for 7 days (they hold ~250 MB each forever) |
| `snapshot` | every 15 min | commits vault changes to a local git history on the server (an undo for agent edits) |
| `sweep` | Mon 07:55 | moves finished tasks from `Inbox/` to `Archive/Inbox/<month>/` after a grace period |
| `claude_update` | Sun 03:00 your time | updates Claude Code and rolls back if a test turn fails |
| `wa_consumer` | always on | WhatsApp bridge only (whatsapp module) |
| `wiki` | daily 07:40 | wiki module only: lists sources that changed since they were compiled into `Wiki/`, in `Wiki/_pending.md`; never writes an article. Installed by the wiki module, not here |

Other kit files: `bin/run-job` (the one entry point every timer uses), `bin/vt` (vault tools:
`vt todos`, `vt move`, `vt docs`), `runner/` (locking, state, alerts, `notify.py` for push and
mail, `ask.py` for read-only Claude calls), `units/` (systemd templates), `GOTCHAS.md` (lessons
behind the design, worth reading once).

## Already have one?

- Existing cron jobs or timers on the server: `crontab -l; systemctl list-timers`. Keep them;
  nothing here replaces them.
- Existing Healthchecks.io account, Gmail app password: reuse (make a new check / new app
  password named for this server).

## Accounts you need

**Healthchecks.io (free Hobbyist plan):**

1. healthchecks.io > Sign Up, with email.
2. In the default project, **Add Check** twice:
   - `vault-host any job`: Period 15 minutes, Grace 30 minutes (the 15-minute snapshot keeps it
     alive, so it fires if the server or the runner is gone).
   - `vault-host heartbeat`: Period 1 day, Grace 2 hours.
3. Integrations: make sure email (and, once the push module is done, Pushover) is on.
4. Keep the two ping URLs open in the browser. Say "done".

**Gmail app password** (used only as a fallback when a push fails, but `heartbeat` treats mail
as required):

1. The sending Google account (`VK_SENDER_EMAIL`) needs 2-Step Verification on
   (myaccount.google.com > Security).
2. myaccount.google.com/apppasswords, **check the account chip top right is the right account**,
   create one named `vault-host`. Keep the page open. Say "done".

## Steps

1. **Code in git on the server.** It is at `~/automation` already (claude-code module, step 5);
   if not: `rsync -a --exclude __pycache__ ~/vaultkit/code/automation/ vault-host:~/automation/`.
   ```bash
   ssh vault-host 'cd ~/automation && git init -q 2>/dev/null; printf "__pycache__/\n.venv/\n" > .gitignore; \
     git config user.name "$USER"; git config user.email "$USER@$(hostname)"; \
     git add -A && git commit -qm "vaultkit install" && git log --oneline | head -1'
   ```
   Review `jobs/` and `runner/` for anything personal left in comments or defaults (see CLAUDE.md);
   fix and commit.
2. **Virtualenv: needed only for Telegram.** Skip it now: the shipped jobs, runner and tools
   are standard library only. The [telegram](../telegram/README.md) module creates it (its
   step 1), because the bridge needs `claude-agent-sdk` and `httpx`; so does any job you add
   later with third-party dependencies. `bin/run-job` and `bin/vt` use `.venv/bin/python` when
   it exists:
   `ssh vault-host 'cd ~/automation && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt'`
3. **Secrets file.** Claude creates it empty with the right mode:
   ```bash
   ssh vault-host 'touch ~/.automation.env && chmod 600 ~/.automation.env'
   ```
   **You run this in your own Terminal** (it opens a simple editor; save with Ctrl-O, Return,
   then quit with Ctrl-X):
   ```bash
   ssh -t vault-host 'nano ~/.automation.env'
   ```
   The user types (values from the pages they kept open):
   ```
   GMAIL_USER=<sending gmail address>
   GMAIL_APP_PASSWORD=<16 characters, spaces are fine>
   MAIL_TO=<VK_ALERT_EMAIL>
   HEALTHCHECKS_URL=<ping URL of "any job">
   HEALTHCHECKS_URL_HEARTBEAT=<ping URL of "heartbeat">
   ```
   Check shape only: `ssh vault-host "grep -o '^[A-Za-z0-9_]*=' ~/.automation.env; stat -c %a ~/.automation.env"`.
   Remind the user once: this app password opens the whole mailbox (WALKTHROUGH § 0), which is
   why the file stays mode 600 and the server stays Tailscale-only.
   Delete any `.save` or backup copies nano leaves behind.
4. **Vault git history** (for `snapshot`; local only, no remote, never pushed anywhere):
   ```bash
   ssh vault-host 'cd ~/vault && git init -q && printf ".obsidian/\n.trash/\n.DS_Store\n" > .gitignore && \
     git -c user.name=vault-host -c user.email=vault-host@localhost add -A && \
     git -c user.name=vault-host -c user.email=vault-host@localhost commit -qm "initial" && \
     git config user.name vault-host && git config user.email vault-host@localhost'
   ```
   Before the first commit, scan for anything secret-shaped in the vault and ask the user.
   Obsidian ignores dotfiles, so `.git/` never syncs to the Mac or phone.
5. **Render and install the units** from `~/automation/units/` (the render command from
   CLAUDE.md; the variable list keeps systemd's `%i` intact). The services run as `VK_USER`
   from `~/automation` through `bin/run-job`, with the kit identity baked in from
   `~/.config/vaultkit/config.env`; secrets stay in `~/.automation.env`:
   ```bash
   ssh vault-host 'set -a; . ~/.config/vaultkit/config.env; set +a; cd ~/automation/units && \
     for u in automation@.service automation-alert@.service \
              automation@{claude_update,heartbeat,rc_reap,selftest,snapshot,sweep}.timer; do \
       envsubst "\${VK_USER} \${VK_HOSTNAME} \${VAULT_PATH} \${VK_VAULT_NAME} \${VK_TIMEZONE} \${VK_ALERT_EMAIL} \${VK_SENDER_EMAIL} \${VK_TAILNET} \${VK_TAILNET_HOST}" \
         < "$u" > "/tmp/$u" && sudo install -m 644 "/tmp/$u" /etc/systemd/system/ && rm "/tmp/$u"; \
     done; sudo systemctl daemon-reload; \
     sudo systemd-analyze verify /etc/systemd/system/automation@{claude_update,heartbeat,rc_reap,selftest,snapshot,sweep}.timer'
   ```
6. **Dry runs first**, then enable:
   ```bash
   ssh vault-host 'cd ~/automation && for j in selftest heartbeat rc_reap snapshot sweep claude_update; do \
     echo "== $j"; bin/run-job $j --dry-run | tail -5; done'
   ssh vault-host 'for t in selftest heartbeat rc_reap snapshot sweep claude_update; do \
     sudo systemctl enable --now automation@$t.timer; done; systemctl list-timers "automation@*"'
   ```
7. **Watched services.** `heartbeat` watches whichever of its known services are installed
   (`obsidian-sync`, `claude-rc`, `obsidian-mcp`, `waha`, `wa-consumer`, `tg-bridge`), so new modules are
   picked up automatically. To pin the list instead, set `VK_WATCH_UNITS` in
   `~/.config/vaultkit/config.env` on the server (see `config.example.env`); a unit named there
   is reported when missing rather than skipped.
8. **A copy on the Mac**, so `vt todos`, `vt todos --add` and `vt move` (which the vault's
   skills and `CLAUDE.md` call as `~/automation/bin/vt`) work there too. Clone it from the
   server, so both machines run the same commit, and keep it outside the vault. (`git` on a
   Mac needs Apple's command line tools. If `git --version` opens a pop-up offering to install
   them, the user clicks **Install** and waits, then Claude continues.)
   ```bash
   git clone vault-host:automation ~/automation        # later: cd ~/automation && git pull
   mkdir -p ~/.config/vaultkit
   printf 'VAULT_PATH=%s\nVK_VAULT_NAME=%s\n' "<mac vault path>" "<VK_VAULT_NAME>" > ~/.config/vaultkit/config.env
   ~/automation/bin/vt todos
   ```
   (A plain `rsync -a --exclude __pycache__ ~/vaultkit/code/automation/ ~/automation/` works
   too, but then changes made on the server do not reach the Mac.) The Mac gets its **own**
   small `config.env`: the server's names the server's vault path, which does not exist on the
   Mac. No timers or secrets on the Mac.

## Gotchas

- **Never log to a file.** Every unit writes to journald, which rotates. Read logs with
  `sudo journalctl -u automation@heartbeat -n 50 --no-pager`.
- **"Still running" is not health.** A service printed "Connected" for a day on dead tokens.
  That is why every job asserts something about its output, and why Healthchecks.io exists.
- **`--dry-run` sends nothing and does not ping**, so a manual test never makes a dead job look
  alive.
- **Hetzner blocks outbound SMTP ports 25 and 465.** The runner uses 587 with STARTTLS. A
  blocked port hangs until timeout, which looks exactly like a wrong password.
- **App passwords are shown as four groups of four.** The runner strips spaces. A correct-looking
  one that still fails with `535 5.7.8` was usually made on the wrong Google account.
- **`TimeoutStartSec=600`** bounds every job. A job that calls Claude for longer needs its own
  drop-in, not a higher global limit.
- **`git revert` in `~/vault` is a live edit** that syncs to every device. Treat recovery as a
  real change.
- **Code never lives in the vault.** Sync does not carry `.py`; a script in the vault exists on
  one machine only.

## Self-test

```bash
ssh vault-host 'cd ~/automation && bin/run-job selftest && bin/run-job heartbeat; \
  systemctl list-timers "automation@*" --no-pager; ls ~/.local/state/automation/'
ssh vault-host 'cd ~/automation && bin/run-job selftest --fail; echo "exit=$?"; \
  sudo systemctl start automation-alert@selftest.service; ls ~/vault/_system/maintenance/alert-log/'
```

Pass: selftest and heartbeat finish with all checks passing (or only failures that belong to
modules not yet installed), six timers listed, state files present, both Healthchecks.io checks
turn green within their period, the forced failure exits 1, and the alert unit writes an entry
to the alert log.
