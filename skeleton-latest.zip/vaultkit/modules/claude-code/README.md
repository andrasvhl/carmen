# Module: claude-code (Claude on the server, Remote Control, login watch)

## What it does and why

Installs Claude Code on the server and runs it as **Remote Control**: a permanent session named
"Vault" that you open from the Claude app on your phone (Code tab) or from claude.ai, with the
server doing the work inside your vault. A daily watch warns you **before** the server's Claude
login expires (about every 30 days), because the running service cannot warn you itself.

## Already have one?

- On the Mac: `claude --version; claude auth status`. Remote Control needs a claude.ai
  subscription login (API keys do not work for it). **Whether your plan includes Remote Control,
  and its usage limits, depend on the plan: check the current details at claude.com/pricing.**
  Usage is shared between your own chats, the Remote Control sessions, the scheduled jobs that
  call Claude (`claude_update`'s test turn, for example) and the WhatsApp bridge. Max is
  recommended for heavy use.
- On an existing server: `ls ~/.local/bin/claude; claude auth status`. If Claude Code is already
  there, reuse it but check the version is current (`claude update`).
- Existing `~/.claude/CLAUDE.md`, `settings.json`, hooks or skills **on the Mac** are not touched
  by this module. If the user wants the same global instructions on the server, copy them over
  only after showing the file.

## Accounts you need

None new. The user's existing Claude Pro or Max account. If they do not have one yet: claude.ai
> sign up > upgrade to Pro. Say "done".

## Steps

1. **Install on the server** (native installer, lands in `~/.local/bin/claude`):
   ```bash
   ssh vault-host 'curl -fsSL https://claude.ai/install.sh | bash && ~/.local/bin/claude --version'
   ssh vault-host 'sudo ln -sf /home/$USER/.local/bin/claude /usr/local/bin/claude'
   ```
2. **Sign in with the full login** (it shows a browser link). **You run this in your own
   Terminal:**
   ```bash
   ssh -t vault-host 'claude auth login'
   ```
   The user opens the URL on the Mac, approves, and if asked pastes the code **into that
   terminal**, not into the chat. Check: `ssh vault-host 'claude auth status'`.
3. **Make the vault folder** (filled by the obsidian-sync module): `ssh vault-host 'mkdir -p ~/vault/Inbox'`
4. **Accept the two one-time prompts.** Remote Control needs both, and they need a real
   terminal. **You run this in your own Terminal** (one line at a time):
   ```bash
   ssh -t vault-host 'cd ~/vault && claude'                       # accept "trust this folder", then /exit
   ssh -t vault-host 'cd ~/vault && claude remote-control --name "Vault"'   # answer y to "Enable Remote Control?", then Ctrl-C
   ```
   They persist in `~/.claude.json` (`hasTrustDialogAccepted` for the folder, `remoteDialogSeen`).
5. **Copy the kit's code to the server.** It lives at `~/automation` there; every unit points
   at that path. This module is the first to need it (the login watch and the unit templates):
   ```bash
   rsync -a --exclude __pycache__ ~/vaultkit/code/automation/ vault-host:~/automation/
   ```
   The automation-runner module puts it under git later. Before installing anything from it,
   skim `jobs/`, `runner/` and `claude-auth-watch/` for anything personal (see CLAUDE.md).
6. **The service**, from the shipped template `units/claude-rc.service` (rendered as in
   CLAUDE.md; it runs `~/.local/bin/claude remote-control --name "Vault" --no-sandbox --verbose`
   as `VK_USER` in `VAULT_PATH`, logging to journald only, rate-limited). First check
   `claude remote-control --help` on the installed version in case flags changed; if they did,
   fix the template in `~/automation/units/` (and commit it once the runner module has made
   that a git repo), not the installed copy:
   ```bash
   ssh vault-host 'set -a; . ~/.config/vaultkit/config.env; set +a; cd ~/automation/units && \
     for u in claude-rc.service; do \
       envsubst "\${VK_USER} \${VK_HOSTNAME} \${VAULT_PATH} \${VK_VAULT_NAME} \${VK_TIMEZONE} \${VK_ALERT_EMAIL} \${VK_SENDER_EMAIL} \${VK_TAILNET} \${VK_TAILNET_HOST}" \
         < "$u" > "/tmp/$u" && sudo install -m 644 "/tmp/$u" /etc/systemd/system/ && rm "/tmp/$u"; \
     done; sudo systemctl daemon-reload; \
     sudo systemd-analyze verify /etc/systemd/system/claude-rc.service && sudo systemctl enable --now claude-rc'
   ```
7. **`renew-claude` helper**, so renewing is one command: `ssh -t vault-host renew-claude`.
   That is the exact command the login watch and `heartbeat` tell the user to run. It goes in
   `/usr/local/bin` because `ssh host command` does not see `~/.local/bin`. Write it on the
   server:
   ```bash
   ssh vault-host 'sudo tee /usr/local/bin/renew-claude >/dev/null <<"EOF"
   #!/usr/bin/env bash
   # Sign in again and restart Remote Control. The running service keeps the old
   # tokens in memory, so a login without the restart changes nothing.
   set -uo pipefail
   claude auth login || { echo "login failed"; exit 1; }
   sudo systemctl restart claude-rc
   claude auth status
   EOF
   sudo chmod 755 /usr/local/bin/renew-claude && cat /usr/local/bin/renew-claude'
   ```
   (`claude` resolves through the `/usr/local/bin/claude` symlink from step 1. `sudo` needs
   no password here: the vps module set up passwordless sudo. If the user later narrowed sudo
   in WALKTHROUGH § 4, `systemctl restart claude-rc` is on the allowlist, so this still works.)
8. **The login watch**, `~/automation/claude-auth-watch/check.py`, run daily by the shipped
   `units/claude-auth-watch.service` and `units/claude-auth-watch.timer` (07:30 server time).
   It reads identity from the unit's environment (`runner.config`) and mail and push secrets
   from `~/.automation.env`, like every job; there is no separate env file. Install both units
   with the render command from step 6, with `for u in claude-auth-watch.service
   claude-auth-watch.timer`, then:
   ```bash
   ssh vault-host 'sudo systemd-analyze verify /etc/systemd/system/claude-auth-watch.timer && \
     sudo systemctl enable --now claude-auth-watch.timer'
   ```
   It writes an Inbox note from day one; mail and push start working once the
   automation-runner and push modules have filled `~/.automation.env`.
9. **Keeping Claude current** is done by the `claude_update` job in the automation-runner module
   (auto-update never fires for short headless runs).
10. **Any later change to Claude's setup on the server** (a `claude mcp add` in the email or
    calendar module, a new permission rule, a new global `CLAUDE.md`) only reaches the phone's
    Remote Control session after `ssh vault-host 'sudo systemctl restart claude-rc'`. Restarting
    closes open phone sessions; their transcripts stay (see Gotchas).

## Gotchas

- **Remote Control needs the full `claude auth login`.** It rejects `ANTHROPIC_API_KEY` and the
  one-year `claude setup-token` / `CLAUDE_CODE_OAUTH_TOKEN`, which most headless guides tell you
  to use. So the ~30-day login expiry cannot be avoided, only watched.
- **The login expires about every 30 days** and the service keeps printing "Connected" on dead
  tokens. The watch pushes 3 days ahead; renewal is `ssh -t vault-host renew-claude`.
- **Trust dialog and the "Enable Remote Control?" consent** both need a real terminal (`ssh -t`)
  once. Without them the service starts and never serves sessions.
- **Idle sessions never close.** Each phone session holds about 250 MB forever. A handful of them
  can fill a 4 GB server until the kernel kills an unrelated job. The `rc_reap` job (runner
  module) closes sessions idle for 7 days; `heartbeat` warns a day before.
- **A closed session cannot be reopened from the phone** (it retries forever). The transcript
  survives in `~/.claude/projects/` and `claude --resume <id>` continues it on the server.
- **"Allocating sandbox" on the phone can take minutes.** It is slow, not broken. Prefer opening
  the existing "Vault" session (computer icon) over starting a cloud session, which runs at
  Anthropic and cannot see the vault.
- **Never log Claude's output to a file.** Redirecting it to a file grows a log of hundreds of
  megabytes of repainted terminal frames. journald with a size cap only.

## Self-test

```bash
ssh vault-host 'systemctl is-active claude-rc; claude auth status; \
  sudo journalctl -u claude-rc -n 20 --no-pager | grep -iE "connect|error"; \
  test -x /usr/local/bin/renew-claude && echo renew-claude ok; \
  systemctl list-timers claude-auth-watch.timer --no-pager; \
  sudo systemctl start claude-auth-watch.service; cat ~/.claude-auth-watch.state'
```

Then on the phone: Claude app > Code > open the **Vault** session > ask "what folder are you in
and what files are here?". Pass: it answers with `~/vault` contents, the service is active, auth
status is logged in, `renew-claude` is installed, the watch timer is scheduled and its state
shows days remaining.
