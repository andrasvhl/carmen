# Module: vps (the always-on server)

## What it does and why

A small rented Linux computer that never sleeps. Your Mac shuts when you travel; this does not.
It holds a copy of your vault and runs Claude Code and the scheduled jobs. After this module it
is hardened: key-only login, no root login, a firewall, automatic security updates, and swap
space so it does not run out of memory. It also gets passwordless sudo for your user (step 5),
so Claude can run admin commands; WALKTHROUGH § 4 offers to narrow that at the end.

## Already have one?

Reuse an existing server only if **all** are true:

- Linux with systemd (Ubuntu or Debian are easiest): `cat /etc/os-release; systemctl --version`
- At least 2 GB RAM, 4 GB better: `free -h`
- At least 20 GB free disk: `df -h /`
- The user is fine with Claude having a shell there, and with it seeing everything on that
  machine. Nothing sensitive and unrelated should live on it.

If any fails, recommend a fresh Hetzner server. A home server works too if it is always on and
the user accepts that a power cut takes the system down. On an existing server, skip the
"create" steps and run the hardening checks; change only what is missing, and show each change.

## Accounts you need

**Hetzner Cloud** (or another provider the user prefers; adapt the steps):

1. Go to hetzner.com/cloud and click **Sign up**. Use your own email.
2. Confirm the email, add a payment method. Hetzner sometimes asks for ID verification for new
   accounts; that can take a few hours.
3. In the Cloud Console, create a **Project** called `vault`.
4. Say "done".

## Steps

**Ask before step 3: it starts billing (about €6/month).**

1. **Make an SSH key on the Mac** (if `~/.ssh/vault_host` does not exist). The key is
   protected by a passphrase, and the passphrase is stored in the macOS Keychain, so the user
   types it once and never again (and Claude's commands can use the key without seeing it).
   **You run this in your own Terminal:**
   ```bash
   ssh-keygen -t ed25519 -f ~/.ssh/vault_host -C "vault-host"
   ```
   It asks for a passphrase twice: pick a new one and store it in the password manager. Then,
   also in your own Terminal (it asks for that passphrase once and saves it in the Keychain):
   ```bash
   ssh-add --apple-use-keychain ~/.ssh/vault_host
   ```
   Show the public key: `cat ~/.ssh/vault_host.pub`. Public keys are safe to show.
2. **Add the key in Hetzner:** project `vault` > Security > SSH keys > Add SSH key, paste the
   public key, name it `vault_host`.
3. **Create the server:** Add Server.
   - Location: **closest to the user** (Falkenstein/Nuremberg/Helsinki in the EU,
     Ashburn/Hillsboro in the US). The server's location is chosen first; the Obsidian Sync
     region is then picked to match it in the obsidian-sync module. (If the user already has a
     remote vault in Sync, its region is fixed; still pick the server closest to the user.)
   - Image: latest **Ubuntu LTS** offered (26.04 if available, else 24.04).
   - Type: **CX23** (2 vCPU, 4 GB RAM). If out of stock, **CAX11** (ARM, 4 GB) works: Claude
     Code, Node and restic all run on ARM.
   - Networking: keep IPv4 and IPv6 (IPv4 is about €0.50/month; some services still need it).
   - SSH key: `vault_host`. Name: the `VK_HOSTNAME` from config (default `vault-host`).
   - Leave backups, volumes, firewalls unticked (the server firewall is set up below).
4. **First login** as root using the public IP Hetzner shows (`accept-new` accepts the new
   server's fingerprint once, so the command does not stop to ask):
   ```bash
   ssh -o StrictHostKeyChecking=accept-new -i ~/.ssh/vault_host root@<public-ip> 'hostname'
   ```
5. **Create the user** (`VK_USER`) with sudo and the same key, run as root over
   `ssh root@<public-ip> '...'`. Claude substitutes the real values from `config.env` for
   `$VK_USER`, `$VK_HOSTNAME`, `$VK_TIMEZONE` (they are not set in the root shell):
   ```bash
   adduser --disabled-password --gecos "" $VK_USER
   usermod -aG sudo $VK_USER
   mkdir -p /home/$VK_USER/.ssh && cp ~/.ssh/authorized_keys /home/$VK_USER/.ssh/
   chown -R $VK_USER:$VK_USER /home/$VK_USER/.ssh && chmod 700 /home/$VK_USER/.ssh
   printf '%s ALL=(ALL) NOPASSWD:ALL\n' "$VK_USER" > /tmp/90-vaultkit && \
     visudo -cf /tmp/90-vaultkit && \
     install -m 440 -o root -g root /tmp/90-vaultkit /etc/sudoers.d/90-vaultkit && rm /tmp/90-vaultkit
   hostnamectl set-hostname $VK_HOSTNAME
   timedatectl set-timezone $VK_TIMEZONE   # e.g. Europe/Berlin; see below
   ```
   **Passwordless sudo, in plain words:** `sudo` is how admin commands run on Linux. Normally it
   asks for a password, but Claude's commands run without a keyboard and could not type one,
   so this lets your user run admin commands without a password. The user has no password at
   all (login is by key only). `visudo -cf` checks the file before it is installed, because a
   broken sudo file can lock admin access. The tradeoff (any Claude session on the server can
   run admin commands) is explained in WALKTHROUGH § 0, and § 4 offers to narrow it once the
   setup is done.
   **The timezone matters.** The daily timers (selftest 07:10, heartbeat 07:30, rc_reap 08:00,
   backup 03:20, ...) run on the server's own clock, and a new server is on UTC. Set to
   `VK_TIMEZONE`, "07:30" means your morning. On an existing server, or to fix it later, run
   `sudo timedatectl set-timezone $VK_TIMEZONE` as the user (with the real value) and check
   `timedatectl | grep "Time zone"`. Do it before installing any timer, and after a later
   change confirm with `systemctl list-timers` that the next run times look right.
6. **SSH alias on the Mac** so everything after is `ssh vault-host`. Add to `~/.ssh/config`
   (show the diff if the file exists):
   ```
   Host vault-host
     HostName <public-ip>          # changed to the Tailscale name in the tailscale module
     User <VK_USER>
     IdentityFile ~/.ssh/vault_host
     AddKeysToAgent yes
     UseKeychain yes
   ```
   `UseKeychain yes` makes ssh read the key's passphrase from the macOS Keychain, so neither
   the user nor Claude is asked for it again (also after a restart of the Mac).
   Test `ssh vault-host 'whoami'` before going further.
7. **Harden SSH** (on the server, as the new user):
   ```bash
   sudo tee /etc/ssh/sshd_config.d/10-vaultkit.conf >/dev/null <<'EOF'
   PermitRootLogin no
   PasswordAuthentication no
   KbdInteractiveAuthentication no
   MaxAuthTries 3
   EOF
   sudo sshd -t && sudo systemctl reload ssh
   ```
   Keep the current session open and test a **new** `ssh vault-host` before closing it.
8. **Updates and basics:**
   ```bash
   sudo apt update && sudo apt -y full-upgrade
   sudo apt -y install unattended-upgrades ufw git python3 python3-venv curl jq gettext-base bubblewrap
   sudo dpkg-reconfigure -f noninteractive unattended-upgrades
   ```
   (`gettext-base` provides `envsubst`, used to render the kit's units.)
9. **Firewall, phase one** (SSH still open to the internet until Tailscale works):
   ```bash
   sudo ufw default deny incoming && sudo ufw default allow outgoing
   sudo ufw allow OpenSSH
   sudo ufw --force enable
   ```
   The tailscale module replaces `allow OpenSSH` with tailnet-only rules.
10. **Swap, 4 GB:**
    ```bash
    sudo fallocate -l 4G /swapfile && sudo chmod 600 /swapfile
    sudo mkswap /swapfile && sudo swapon /swapfile
    echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
    echo 'vm.swappiness=10' | sudo tee /etc/sysctl.d/99-swappiness.conf
    sudo sysctl --system
    ```
11. **Cap the system journal** so a noisy service cannot fill the disk:
    ```bash
    sudo mkdir -p /etc/systemd/journald.conf.d
    printf '[Journal]\nSystemMaxUse=500M\n' | sudo tee /etc/systemd/journald.conf.d/size.conf
    sudo systemctl restart systemd-journald
    ```
12. **Node 22** (for Obsidian's headless client and the MCP connector), from NodeSource, the
    official Node.js packages for Ubuntu:
    ```bash
    ssh vault-host 'curl -fsSL https://deb.nodesource.com/setup_22.x -o /tmp/nodesource_setup.sh && \
      sudo -E bash /tmp/nodesource_setup.sh && sudo apt-get install -y nodejs && node --version && npm --version'
    ```
    `node --version` must print `v22.` or higher. (If NodeSource has changed its instructions,
    check the current ones at github.com/nodesource/distributions.)
13. **Kit config on the server:** copy the `config.env` filled in at WALKTHROUGH § 1b
    (`VK_TAILNET` and `VK_TAILNET_HOST` are still empty here; the tailscale module fills them
    and copies the file again, before any unit is installed):
    ```bash
    ssh vault-host 'mkdir -p ~/.config/vaultkit'
    scp ~/vaultkit/config.env vault-host:~/.config/vaultkit/config.env
    ```

## Gotchas

- **`systemctl` does not exist on macOS.** A command meant for the server, run on the Mac,
  silently does nothing (or asks for the Mac's sudo password and then does nothing). Always check
  the prompt says the server's name.
- **`set -e` plus `systemctl is-active` is a trap**: `is-active` returns non-zero for
  "activating" and aborts the rest of a script.
- **Sysctl settings go in `/etc/sysctl.d/`**, not `/etc/sysctl.conf`, which may not exist on
  new Ubuntu; writing there can silently not survive a reboot.
- **Hetzner blocks outbound mail ports 25 and 465** on new accounts. Use 587 (the kit does).
- **`~/.local/bin` is not on the PATH of `ssh host command`** (non-interactive shells). Anything
  you want to run as `ssh vault-host <command>` goes in `/usr/local/bin` (a symlink is fine).
- **Hetzner's web console** (server > Console) is the way back in if SSH or Tailscale break.
  It asks for a password login, and with key-only login no password exists: in the Cloud
  Console use the server's **Rescue > Reset root password** first, then log in as root there.
- **The vault sits unencrypted on the server's disk.** Accepted tradeoff; see WALKTHROUGH § 0.

## Self-test

```bash
ssh vault-host 'whoami; hostname; free -h | grep -i swap; sudo -n true && echo "sudo ok"; sudo ufw status; \
  sudo sshd -T | grep -E "permitrootlogin|passwordauthentication"; \
  systemctl is-enabled unattended-upgrades; node --version; timedatectl | grep "Time zone"'
ssh -o PasswordAuthentication=yes -o PubkeyAuthentication=no root@<public-ip>   # must be refused
```

Pass: right user and hostname, 4 GB swap, `sudo ok` (passwordless), ufw active, `permitrootlogin no`,
`passwordauthentication no`, unattended-upgrades enabled, Node 22+, time zone is
`VK_TIMEZONE`, root login refused.
