# Module: tailscale (your private network)

## What it does and why

Tailscale makes a private network between your own devices (Mac, phone, server), encrypted and
invisible to everyone else. After this module the server's **only door is Tailscale**: its
public address accepts no connections at all, not even SSH. You reach it as `vault-host` from
anywhere, as long as Tailscale is on.

## Already have one?

- On the Mac: `which tailscale; tailscale status 2>/dev/null` (or the Tailscale app in the menu
  bar). Ask which account they signed in with.
- If they already have a tailnet, **reuse it**: the server simply joins it as a new device.
- If they use another VPN (WireGuard, ZeroTier), Tailscale can coexist; the obsidian-mcp module
  relies on Tailscale Funnel, so Tailscale is still needed for that.

## Accounts you need

**Tailscale (Personal plan, free):**

1. Go to tailscale.com and click **Get started**.
2. Sign in with an identity provider (Google, Apple, Microsoft or GitHub). This account owns the
   network; pick one they will keep.
3. Install Tailscale on the Mac (Mac App Store or tailscale.com/download) and sign in.
4. Install Tailscale on the phone (App Store / Play Store) and sign in with the same account.
5. **Create the server's tag** (a label for the server, so later rules can apply to the server
   only, never to everyone in the tailnet). login.tailscale.com > **Access controls** > in the
   policy file, add (or extend) a `tagOwners` block, then Save:
   ```json
   "tagOwners": {
     "tag:vault": ["autogroup:admin"]
   }
   ```
   (If the file already has its own `acls` or `grants` rules rather than the default "allow
   all", make sure your own devices are still allowed to reach `tag:vault`.)
6. Say "done".

## Steps

1. **Install and join on the server, with the tag:**
   ```bash
   ssh vault-host 'curl -fsSL https://tailscale.com/install.sh | sh'
   ```
   **You run this in your own Terminal:**
   ```bash
   ssh -t vault-host 'sudo tailscale up --hostname=vault-host --advertise-tags=tag:vault'
   ```
   It prints a login URL. The user opens it on the Mac and approves the device.
2. **In the admin console** (login.tailscale.com > Machines): `vault-host` shows the tag
   `tag:vault`. Tagged devices have key expiry off by default; check its menu says so, or click
   **Disable key expiry** (otherwise the server drops off the network every 180 days).
3. **Note the tailnet name** (DNS page, e.g. `tail1234ab.ts.net`) into `config.env` as
   `VK_TAILNET`, and `vault-host.<tailnet>` as `VK_TAILNET_HOST`. Copy `config.env` to the server
   again (`scp ~/vaultkit/config.env vault-host:~/.config/vaultkit/config.env`) and check that
   nothing is empty any more:
   `ssh vault-host "grep -E '^[A-Z_]+=$' ~/.config/vaultkit/config.env || echo all filled"`.
   Every later module installs units, and they need all values.
4. **Point the SSH alias at Tailscale.** In `~/.ssh/config` change `HostName` to `vault-host`
   (MagicDNS) or the `100.x` address from `tailscale ip -4` on the server. Test
   `ssh vault-host whoami`.
5. **Close the public door.** Only after step 4 works:
   ```bash
   ssh vault-host 'sudo ufw allow in on tailscale0 && \
     sudo ufw allow from 100.64.0.0/10 to any port 22 proto tcp && \
     sudo ufw delete allow OpenSSH && sudo ufw status verbose'
   ```

## Gotchas

- **If Tailscale is stopped on the Mac, the server looks dead.** It is not; you just cannot reach
  it. Check the Mac's Tailscale first before diagnosing the server.
- **Key expiry** is on by default for new untagged devices. The tagged server has it off;
  leave it on for your Mac and phone.
- **`tailscale up` with different flags later** must repeat all of them (`--hostname`,
  `--advertise-tags`), or it refuses and lists what is missing.
- **If both ends ever lose Tailscale**, Hetzner's web console still gets you in.
- **Funnel needs two admin-console settings** (done in the obsidian-mcp module, not here): a
  `funnel` nodeAttr for `tag:vault` in the access policy, and HTTPS Certificates enabled under
  DNS.

## Self-test

```bash
ssh vault-host 'tailscale status | head -5; tailscale status --self --json | grep -A2 "\"Tags\""; sudo ufw status'
nc -vz -w 5 <public-ip> 22        # from the Mac: must time out
ssh vault-host whoami              # over Tailscale: must work
```

Pass: the server shows in `tailscale status` with `tag:vault`, ufw allows SSH only from `100.64.0.0/10` and
`tailscale0`, the public IP's port 22 times out, the Tailscale SSH works. Also try `ssh
vault-host` from the phone's Tailscale (optional).
