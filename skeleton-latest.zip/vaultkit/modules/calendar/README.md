# Module: calendar (Google Calendar for Claude)

## What it does and why

Lets Claude read your calendar ("am I free Thursday evening?") and, with your confirmation,
create events. It reuses the email module's MCP server (`workspace-mcp`) and Google Cloud
project, with the Calendar tools switched on. Do the email module first.

## Already have one?

- claude.ai's built-in Google Calendar connector works in chat, but not on the server and only
  for one account. Fine to keep alongside.
- Calendars imported into Google from elsewhere (event sites, a work calendar subscription)
  count as separate calendars. When asking "am I free", Claude should check all of them, not only
  the primary. Ask the user which calendars matter and note them in the vault.

## Accounts you need

None new. In the Google Cloud project from the email module:

1. APIs & Services > Library > **Google Calendar API** > Enable.
2. Google Auth Platform > Data access > add the scope `calendar` (or `calendar.readonly` if
   Claude should only read). The app stays In production.
3. Say "done".

## Steps

1. Change the registration's tool list from `--tools gmail` to `--tools gmail calendar` (check
   the package README for the exact syntax). Show the diff of `~/.claude.json` first:
   ```bash
   claude mcp remove -s user gws
   claude mcp add -s user gws ... -- "$(which uvx)" workspace-mcp@<version> --tools gmail calendar --single-user
   ```
2. Restart the session and run `start_google_auth` again for each account, so the new scope is
   granted (adding a scope needs a fresh consent).
3. Repeat on the server: copy the refreshed token files over (`scp -r ~/.google_workspace_mcp
   vault-host:~/`, then fix modes as in the email module) and update its registration. Then
   restart Remote Control so the phone session sees the change:
   `ssh vault-host 'sudo systemctl restart claude-rc'`. The send-deny rule from the email module
   stays in place.
4. Write a short note in the vault's `_system/` listing which calendars to check, so every
   session knows.

## Gotchas

- **A new scope needs re-consent.** Old tokens keep working for Gmail but fail on Calendar until
  the account is authorised again.
- **Imported or subscribed calendars are separate**; a free/busy question answered from the
  primary calendar alone is often wrong.
- **Creating events is a write that others may see** (invites). Claude confirms before creating
  or changing anything with attendees.
- Same token and session-restart gotchas as the email module.

## Self-test

"What is on my calendar tomorrow, across all my calendars?" on the Mac and from the phone's
Remote Control session. Pass: matches what the Google Calendar app shows.
