# Module: obsidian-mcp (your vault in claude.ai chat and the mobile app)

## What it does and why

Remote Control serves the Code tab only. This module makes your vault usable from **ordinary
Claude chats** on claude.ai, the desktop app and the phone app: search notes, read them, and (if
you choose) write. It runs the open-source MCP server `obsidian-sync-mcp` (npm, GitHub
`es617/obsidian-sync-mcp`) on the server against the local vault copy, and publishes it at one
HTTPS address through **Tailscale Funnel**, protected by a password (OAuth 2.1).

**This is the one deliberate hole in "nothing is public":** the connector address is reachable
from the internet, because Claude's servers have to reach it. Everything else stays
tailnet-only. Without the password it answers `401 Unauthorized`.

## Already have one?

- Check claude.ai > Settings > Connectors for an existing vault or filesystem connector.
- Another MCP server on the server already using port 8787 or Funnel: `sudo tailscale funnel
  status; ss -ltnp | grep 8787`. Pick another port if needed (Funnel exposes 443, 8443 or 10000
  publicly; the local port can be anything).

## Accounts you need

None new. Two one-time settings in the **Tailscale admin console** (login.tailscale.com):

1. **DNS** page: make sure **MagicDNS** is on, and click **Enable HTTPS** (HTTPS Certificates).
2. **Access controls** page: allow Funnel **for the server only**, through its tag `tag:vault`
   (created in the tailscale module). In the policy file, add (or extend) a `nodeAttrs` block:
   ```json
   "nodeAttrs": [
     { "target": ["tag:vault"], "attr": ["funnel"] }
   ]
   ```
   Save. Say "done". Granting it to the tag rather than to every member means no other device
   in the tailnet (your Mac, your phone) can publish anything to the internet by accident.

## Steps

1. **Pin the version in the shipped unit.** `units/obsidian-mcp.service` runs
   `/usr/bin/npx -y obsidian-sync-mcp` as `VK_USER` in `VAULT_PATH`, with `VAULT_PATH`,
   `HOST=127.0.0.1` and `PORT=8787` set and secrets from `~/.obsidian-mcp.env`. Look up the
   current version and the package's option names, then fix the template (not the installed
   copy) and commit:
   ```bash
   ssh vault-host 'npm view obsidian-sync-mcp version; command -v npx'
   ```
   **Check the current docs at https://www.npmjs.com/package/obsidian-sync-mcp (and its GitHub
   README) for the exact env names** it uses for vault path, host, port, auth token, read-only
   mode and instructions file. The names in this module (`MCP_AUTH_TOKEN`, `READ_ONLY`,
   `MCP_INSTRUCTIONS_FILE`, `WRITE_FOLDERS`) are the ones it used when the kit was written.
   Adapt the unit's `VERIFY:` lines and step 2 to what the docs say now. Change `ExecStart` to `npx -y obsidian-sync-mcp@<version>` (and the
   `npx` path if `command -v npx` printed another one). Then
   `ssh vault-host 'cd ~/automation && git commit -qam "obsidian-mcp: pin version"'`.
2. **Password and settings file.** The password is generated on the server and never printed:
   ```bash
   ssh vault-host 'umask 077; printf "MCP_AUTH_TOKEN=%s\n" "$(openssl rand -base64 24)" > ~/.obsidian-mcp.env'
   ssh vault-host 'cat >> ~/.obsidian-mcp.env <<EOF
   READ_ONLY=true
   MCP_INSTRUCTIONS_FILE=$HOME/vault/_system/mcp-instructions.md
   EOF
   chmod 600 ~/.obsidian-mcp.env'
   ```
   (Vault path, host and port come from the unit. Use the package's own names if step 1
   showed different ones.) **Start read-only.** Turning on writes is a separate decision (see
   Gotchas).
3. **Instructions file.** Create `_system/mcp-instructions.md` in the vault (the kit does not
   ship one): a short note saying where things are (Inbox, projects, the vault's `CLAUDE.md`)
   and whether writes are allowed. It is injected into every chat, so keep it under ~30 lines.
   Editing it in Obsidian takes effect from the next new chat.
4. **The service**, rendered as in CLAUDE.md:
   ```bash
   ssh vault-host 'set -a; . ~/.config/vaultkit/config.env; set +a; cd ~/automation/units && \
     for u in obsidian-mcp.service; do \
       envsubst "\${VK_USER} \${VK_HOSTNAME} \${VAULT_PATH} \${VK_VAULT_NAME} \${VK_TIMEZONE} \${VK_ALERT_EMAIL} \${VK_SENDER_EMAIL} \${VK_TAILNET} \${VK_TAILNET_HOST}" \
         < "$u" > "/tmp/$u" && sudo install -m 644 "/tmp/$u" /etc/systemd/system/ && rm "/tmp/$u"; \
     done; sudo systemctl daemon-reload; \
     sudo systemd-analyze verify /etc/systemd/system/obsidian-mcp.service && sudo systemctl enable --now obsidian-mcp'
   ```
5. **Publish through Funnel:** `ssh vault-host 'sudo tailscale funnel --bg 8787 && sudo tailscale funnel status'`
   The address is `https://<VK_TAILNET_HOST>/mcp`.
6. **Connect in Claude.** claude.ai > Settings > Connectors > **Add custom connector** > paste the
   address. When it asks for the password, the user reads it themselves and pastes it into the
   browser login page, never into a chat. **You run this in your own Terminal:**
   ```bash
   ssh vault-host "grep '^MCP_AUTH_TOKEN=' ~/.obsidian-mcp.env | cut -d= -f2-"
   ```

## Gotchas

- **Funnel needs both admin-console settings** (the `funnel` nodeAttr for `tag:vault` and HTTPS
  certificates). If `tailscale funnel` says Funnel is not enabled, check the server really has
  the tag: `ssh vault-host 'tailscale status --self --json | grep -A2 "\"Tags\""'`.
  Without them `tailscale funnel` errors or the address has no valid certificate.
- **Only ports 443, 8443 and 10000** can be public through Funnel.
- **Request-header (bearer token) auth for custom connectors may not be available** on every
  Claude account; this server uses OAuth, which works everywhere.
- **Writes are a real tradeoff.** With `READ_ONLY=false`, any chat (including one that read a
  malicious email or web page) can change notes, and can change the instruction files every
  future session loads. If you enable writes, consider `WRITE_FOLDERS=Inbox,Projects` (folder
  list, enforced by the server) so `_system/` stays read-only. Sync history, the vault git
  history and nightly backups are the undo.
- **The connector is third-party code** with access to your whole vault and a public address.
  Pin the version; update deliberately.
- **Instructions are read at chat start**; existing chats keep the old copy.

## Self-test

```bash
curl -s -o /dev/null -w "%{http_code}\n" https://<VK_TAILNET_HOST>/mcp     # from the Mac: expect 401
ssh vault-host 'systemctl is-active obsidian-mcp; ss -ltn | grep 8787'      # must show 127.0.0.1:8787 only
```

Then in a new claude.ai chat on the phone, with the connector on: "Search my vault for <a word
from a known note> and quote its first line." Pass: 401 without the password, listening on
loopback only, and the chat finds the note.
