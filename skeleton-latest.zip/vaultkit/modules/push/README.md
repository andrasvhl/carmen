# Module: push (phone alerts with Pushover)

## What it does and why

When something needs you now (the Claude login is about to expire, a service is down, a backup
failed twice), the server sends a push notification to your phone through **Pushover**. Push,
because people read pushes and do not read alert emails. Email stays as the fallback: if a push
fails, the mail subject says `[PUSH FAILED]`.

The code is already in the kit: `runner/notify.py` (`send_push`, `push_or_mail`), used by
`runner/job.py`, `runner/alert.py` and `claude-auth-watch/check.py`.

## Already have one?

- Pushover already on the phone: reuse the account, just create a new application token.
- Using **ntfy** or another push service instead: possible, but `notify.py` speaks Pushover. Claude
  can add an ntfy sender beside it; note that ntfy's free public server makes topics guessable.

## Accounts you need

**Pushover** ($4.99 once per platform after a 30-day trial; ask before buying):

1. Install **Pushover** from the App Store (iPhone) or Play Store (Android), open it, create an
   account. The licence is per platform: buy it on the platform of the phone from discovery.
2. Allow notifications (on iPhone also allow **Critical Alerts** if offered).
3. On a computer, log in at pushover.net. Your **User Key** is on the front page. Keep the page
   open.
4. Further down: **Create an Application/API Token**. Name `vault-host`, type Script, no icon
   needed. Create, then keep that page open too (it shows the **API Token**).
5. Say "done".

## Steps

1. The user adds both keys to the server's secrets file. **You run this in your own
   Terminal** (save with Ctrl-O, Return, quit with Ctrl-X):
   ```bash
   ssh -t vault-host 'nano ~/.automation.env'
   ```
   ```
   PUSHOVER_USER=<the user key, 30 characters>
   PUSHOVER_TOKEN=<the application token, 30 characters>
   ```
2. Check shape only:
   ```bash
   ssh vault-host "grep -o '^PUSHOVER_[A-Z]*=' ~/.automation.env; \
     awk -F= '/^PUSHOVER_/{print \$1, length(\$2)}' ~/.automation.env"
   ```
   Both should be 30 characters.
3. In Healthchecks.io, add the Pushover integration (Integrations > Pushover) so "the server went
   silent" also reaches the phone.

## Gotchas

- **The token is per application, the user key is per person.** The phone app shows only the
  user key; the token exists only after creating an application on pushover.net.
- **Editing the env file over ssh needs `-t`**, or nano refuses ("Standard input is not a
  terminal") and leaves a lock file.
- **Priority 1 bypasses quiet hours**; the runner uses it for critical alerts only. Emergency
  priority (2, repeats until acknowledged) is refused by `send_push` until the user decides what
  may wake them.
- **Keep the channel quiet.** Only critical things push. A push channel that carries noise gets
  muted, and then it carries nothing.

## Self-test

```bash
ssh vault-host 'cd ~/automation && python3 -c "from runner import notify; notify.send_push(\"vaultkit test\", \"Push works.\")"'
```

Pass: the notification arrives on the phone within seconds. Then
`ssh vault-host 'cd ~/automation && bin/run-job heartbeat'` and confirm no push arrives (nothing
is critical), which proves healthy runs stay quiet.
