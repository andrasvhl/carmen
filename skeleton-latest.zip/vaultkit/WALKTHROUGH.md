# vaultkit walkthrough

The script Claude follows. Sections are in order; do not skip § 0 or § 1.

Words you may not know (Tailscale, Funnel, systemd unit, SSH key, ...) are explained in the
[Glossary](#glossary) at the end. Steps marked **You run this in your own Terminal:** are the
ones you type or paste yourself; CLAUDE.md explains how.

---

## § 0 Briefing

Claude explains this in its own words before anything else, then waits for
**"I understand, continue"**.

### What the system does

- Your notes live in an **Obsidian vault**: a folder of plain text files on your Mac.
- **Obsidian Sync** keeps the same vault on your phone and on a **small rented Linux server**
  (a VPS at Hetzner, in Germany or Finland or the US, your choice).
- On that server, **Claude Code runs all the time**, inside your vault. From the Claude app on
  your phone you can open that session and talk to your notes, even with your laptop shut.
- **Scheduled jobs** run on the server: daily health checks, a backup every night, a weekly
  tidy-up, a weekly Claude update. If something breaks, your phone gets a push notification.
- Optional modules add email, calendar, a Telegram chat with your vault (the recommended way to
  use it on the go), WhatsApp, transcription and quick capture.

### Where your data goes, in plain language

| What | Goes to | Why |
|---|---|---|
| Anything Claude reads or writes: notes, and **emails, Telegram and WhatsApp messages if those modules are on** | **Anthropic**, to be processed by the model | That is how Claude works. Your plan's privacy terms apply |
| Your vault | Obsidian Sync (encrypted on the way), your Mac, your phone, your server | Keeping copies in step |
| Your vault, nightly | Backblaze B2, **encrypted on the server before upload** | Backup. Backblaze cannot read it |
| Email (if on) | Google, through your own Google Cloud project | Gmail access. Nothing passes through anyone else |
| Alerts | Pushover, to your phone | Short messages like "backup failed" |
| Telegram chats (if on) | Telegram, which carries the messages between your phone and your server | Bot chats are not end-to-end encrypted |
| Voice notes sent to the Telegram bot (if on) | Groq and/or OpenAI, for transcription | Turning speech into text; the audio is not stored |
| "Is it still alive" pings | Healthchecks.io | Only a ping, no content |

**The server itself is locked down:**

- It is reachable **only over your own private [Tailscale](#glossary) network**. Its public
  address accepts nothing. Only your own devices can log in, and only with an
  [SSH key](#glossary), not a password.
- Passwords and keys sit in **permission-locked files** on the server (mode 600), never in the
  vault, never in chat.
- **Nightly encrypted backups**, with a restore test.
- One deliberate exception if you choose the phone/claude.ai connector: a single
  password-protected web address for it. It is explained in that module.
- **Claude can run admin commands on the server without asking for a password.** During setup
  the server's user gets "passwordless sudo" (sudo is how admin commands run on Linux), because
  Claude's commands run without a keyboard and could not type one. The downside: anything that
  controls a Claude session on the server, including your Remote Control sessions from the
  phone, can change anything on that machine. At the end (§ 4) Claude offers to narrow this to a
  short list of commands, and explains the tradeoff.
- **If you turn on email: the Gmail app password gives full access to that mailbox** (read,
  send, delete). It sits only in `~/.automation.env` on the server, mode 600 (only your user can
  read it), and the server only accepts connections from your own Tailscale devices. That is
  why both locks matter. You can revoke it any time at myaccount.google.com/apppasswords.
- **The vault is stored unencrypted on the server's disk** (the sync is encrypted, the copy it
  writes is not). The server is rented hardware. This is the price of a ~€6 always-on box.

**The one exposure this kit cannot remove: Anthropic sees what Claude reads.** The only way
around that is a local "open-weight" AI model running on your own hardware. This kit does not
support that: a €6 server cannot run one (it would need a machine with a GPU or a Mac mini, and
a different setup than Claude Code). If that matters to you, the honest answer is that this kit
is not for you, or that you keep sensitive material out of the vault.

**The author of this kit sees nothing and has no access.** Every account is created by you and
in your name. Nothing is sent to the author, ever.

**WhatsApp warning.** The WhatsApp module uses an unofficial connection (WhatsApp does not offer
an official one for personal accounts). **WhatsApp can ban the phone number** it is linked to,
and a ban can be permanent. It is optional, off by default, and has safeguards, but the risk is
real.

**Telegram note.** If you turn on the Telegram module, **whoever controls your Telegram account
controls a Claude session on your server.** The bot answers only you, and by default Claude asks
with Allow/Deny buttons before anything beyond reading, writing notes and the vault tool. The
module helps you lock the Telegram account (two-step password, passcode) and explains the one
setting that would turn the buttons off, so you can decide knowingly.

### Costs (checked 2026-10-04)

| Item | Needed for | Cost | Notes |
|---|---|---|---|
| Claude Pro | Core | $20/month, or $17/month billed yearly ($200) | Max 5x is $100/month, Max 20x $200/month. See the note on plans below |
| Hetzner CX23 (2 vCPU, 4 GB RAM, 40 GB) | Core | €5.49/month + €0.50 for the IPv4 address, so about €6. Plus 19% VAT if billed in the EU (about €7.10) | Prices from Hetzner's 15 June 2026 adjustment. Hetzner has had stock shortages on its cheapest plans in 2026; the ARM plan CAX11 (€5.99) works too |
| Obsidian Sync Standard | Core | $4/month billed yearly, $5 monthly | 1 vault, 1 GB, 5 MB per file, 1 month of history |
| Obsidian Sync Plus | Optional upgrade | $8/month billed yearly, $10 monthly (approx., verify) | 10 GB, 200 MB per file, 12 months of history. Worth it if you keep PDFs or audio in the vault |
| Tailscale Personal | Core | Free | Up to 6 users, unlimited devices |
| Healthchecks.io Hobbyist | Core | Free | 20 checks |
| Backblaze B2 | Recommended | First 10 GB free, then $6.95 per TB per month | A typical vault fits in the free 10 GB |
| Pushover | Recommended | $4.99 once per platform (iPhone, Android) | 30-day free trial |
| Google Cloud project (email, calendar) | Recommended / optional | Free | No billing account needed |
| Telegram bot | Optional (recommended for use on the go) | Free | Made with Telegram's own @BotFather |
| Voice notes for Telegram: Groq and/or OpenAI | Optional | Groq about $0.04 per hour of audio (free tier available); OpenAI whisper-1 about $0.006 per minute | Approx., verify. Personal use is typically well under $1/month |
| WAHA (WhatsApp) | Optional | Free (open-source Core edition) | Approx., verify |
| whisper.cpp, Raycast | Optional | Free | Raycast's free tier is enough |
| Strava subscription (fitness module) | Optional | about $12/month in the US (approx., verify) | Required since June 2026 for API access on the account that owns the app. WHOOP's API is free with a WHOOP membership |

**Typical monthly total for core + recommended: about $30 to $40, plus $5 once.**

**Note on Claude plans.** Whether Remote Control (Claude on the server, from your phone) is
included, and how much you can use it, depends on your plan. Check the current details at
claude.com/pricing before you start. Your usage is **shared**: your normal chats, the Remote
Control sessions, the scheduled jobs that call Claude and the Telegram and WhatsApp bridges all
draw from the same allowance. Pro can be enough for light use; **Max is recommended if you plan to use it a
lot.**

Note on Obsidian Sync: on 2026-10-04 Obsidian's pricing page showed one Sync price ($4 yearly /
$5 monthly) while its help pages still listed Standard and Plus. Check the current offer at
obsidian.md/pricing before buying.

**Claude asks now:** "Does that all make sense? If you are happy with how your data flows and
the costs, reply **I understand, continue**."

---

## § 1 Discovery

**Before building anything, find out what already exists**, so it can be reused instead of
replaced. Claude uses read-only commands on the Mac and asks about everything else. Nothing is
changed during discovery.

### Before searching: macOS privacy pop-ups

**Claude warns the user first:** "While I look for your vault, your Mac may show pop-ups like
*Terminal would like to access files in your Documents folder*. Click **Allow** or **Don't
Allow**, both are fine. Don't Allow just means I ask you instead." The search stays inside
`~/Documents`, `~/Obsidian` and Obsidian's iCloud folder; never the whole home folder.

**Never print a file that can hold secrets** (settings files, `.env` files, `~/.claude.json`,
anything with "token", "key" or "secret" in its name). List key names only, as in the table.
`~/.claude/CLAUDE.md` is instructions, not secrets, but it is personal: look at its headings
only now, and read it in full later only when a change to it is planned and the user agrees.

### What to check

| Area | How to check (read-only) | Ask |
|---|---|---|
| Obsidian app | `ls -d /Applications/Obsidian.app 2>/dev/null` | Do you use Obsidian on the Mac? On the phone? |
| Obsidian vault(s) | Obsidian's own vault list (no pop-up): `python3 -c 'import json,os;p=os.path.expanduser("~/Library/Application Support/obsidian/obsidian.json");[print(v.get("path")) for v in (json.load(open(p)).get("vaults",{}).values() if os.path.exists(p) else [])]'`; then `find ~/Documents ~/Obsidian ~/Library/Mobile\ Documents/iCloud~md~obsidian/Documents -maxdepth 4 -name .obsidian -type d 2>/dev/null` | Which vault is "the" one? Roughly how many notes? Anything in it you would not want on a server? |
| How the vault syncs now | look for the vault under iCloud, a `.git` folder, a `.stignore` (Syncthing) | Do you pay for Obsidian Sync? Which plan? |
| Claude Code config | `ls -la ~/.claude/ ~/.claude/skills 2>/dev/null`; `wc -l ~/.claude/CLAUDE.md; grep '^#' ~/.claude/CLAUDE.md` (headings only); key names only from settings: `python3 -c 'import json,os;p=os.path.expanduser("~/.claude/settings.json");d=json.load(open(p)) if os.path.exists(p) else {};print("top-level keys:",sorted(d));print("env names:",sorted(d.get("env",{})));print("hook events:",sorted(d.get("hooks",{})))'` | Did you write these, or did a tool? |
| Claude plan | `claude auth status` | Pro or Max? (see the note on plans in § 0) |
| Server | ask | Any VPS or home server running? Provider, OS, RAM, what is on it? |
| Tailscale | `ls /Applications \| grep -i tailscale`; `which tailscale` | Already have a tailnet? Signed in with which account? |
| Backups | `tmutil destinationinfo 2>/dev/null`; `ls /Applications \| grep -i backblaze`; `which restic` | Anything backing up the Mac or the vault? |
| Google Cloud | ask; `ls ~/.google_workspace_mcp 2>/dev/null` (names only) | Ever created a Google Cloud project or OAuth client? |
| Gmail 2-Step Verification | ask (they can check at myaccount.google.com > Security) | Is 2-Step Verification on for the Gmail account the server will send from? It is required for an app password |
| Phone | ask | iPhone or Android? (Pushover is bought once per platform; the capture module's phone button is iPhone only) |
| Push notifications | ask | Pushover, ntfy, or something else on your phone? |
| Password manager | ask | Which one do you use? You will need it for the backup passphrase and the Obsidian Sync encryption password. If none: Apple's Passwords app (built into macOS and iOS) is free and fine |
| Homebrew | `which brew` | (Needed on the Mac for the email, transcription and capture modules) |
| Python on the Mac | `which python3 && python3 --version` | (If macOS offers to install "command line developer tools", that is normal: click Install. Python 3.9+ is fine) |
| Docker | ask | (Only matters on the server, for WhatsApp) |

### Rules of thumb

- **Existing vault: reuse it.** Never restructure it without explicit consent. Offer to add only
  the missing system files (`_system/`, `Inbox/`, a vault `CLAUDE.md`) alongside what is there,
  from `vault-template/`. **No vault yet:** `vault-template/` becomes the new vault on the Mac
  (obsidian-sync module, step 2).
- **No Obsidian app yet:** it is installed in the obsidian-sync module. **No Homebrew yet:** it
  is installed in the first module that needs it (email, step 1).
- **Existing sync other than Obsidian Sync** (iCloud, git, Syncthing): the server needs
  Obsidian Sync (the headless client is the only supported way onto the server here). Running
  two sync systems on the same folder causes conflicts, so plan to move the vault off iCloud or
  stop the other sync for that folder, with consent.
- **Existing server: reuse it only if** it runs Linux with systemd, has at least 2 GB RAM (4 GB
  better), and the user is fine with Claude having a shell on it with access to everything on
  that machine. Otherwise recommend a fresh dedicated VPS: it is cheap and keeps the blast radius
  small.
- **Existing `~/.claude/CLAUDE.md`, skills or hooks: never merge without showing a diff.** Back
  up first, add rather than replace.
- **Existing Tailscale, Pushover, Google Cloud project, Backblaze account: reuse.** Just create
  what is new inside them (a new device, a new app token, a new OAuth client, a new bucket).
- **Existing backups of the Mac** (Time Machine, Backblaze Computer Backup) are good but do not
  cover the server. Keep them; the backups module adds the server.

### Output

Claude writes a table like this to `PROGRESS.md` and asks the user to confirm it:

```
| Module            | Have now                         | Decision | Note                        |
|-------------------|----------------------------------|----------|-----------------------------|
| vps               | nothing                          | new      | Hetzner CX23                |
| tailscale         | installed on Mac, personal tailnet | reuse  | add the server as a device  |
| obsidian-sync     | Sync Standard, vault "Notes"     | reuse    | vault has 1,200 notes       |
| claude-code       | ~/.claude/CLAUDE.md (own text)   | adapt    | add 3 lines, diff shown     |
| backups           | Time Machine on Mac              | new      | server to B2                |
| config values     | vault "Notes", tz Europe/Berlin  | new      | config.env filled in § 1b   |
| ...               |                                  |          |                             |
```

---

## § 1b Your settings file (config.env)

Right after discovery, Claude creates the kit's settings file. It holds names and paths only,
**never a password or key**.

1. Copy the example: `cp ~/vaultkit/config.example.env ~/vaultkit/config.env` (only if
   `config.env` does not exist yet; if it does, show it and ask).
2. Fill in, together with the user, using the discovery answers:
   - `VK_USER`: the username on the server (lowercase, no spaces, e.g. `alex`)
   - `VK_HOSTNAME`: the server's name (default `vault-host`)
   - `VK_TIMEZONE`: e.g. `Europe/Berlin` or `America/New_York`
   - `VK_ALERT_EMAIL`: where alert emails go
   - `VK_SENDER_EMAIL`: the Gmail account the server sends from
   - `VK_VAULT_NAME`: the vault's name as Obsidian shows it (for a new vault, the name the
     user picks now)
   - `VAULT_PATH`: the server's vault path, `/home/<VK_USER>/vault`
3. **Leave `VK_TAILNET` and `VK_TAILNET_HOST` empty for now.** The tailscale module fills them
   in, before anything is installed that needs them.
4. Record in `PROGRESS.md` that `config.env` exists (it holds no secrets, so the values may be
   noted).

---

## § 2 Choose modules

Default: **Core + Highly recommended**, preselected. The user can drop any recommended or add any
optional module.

### Core (required)

| Module | What it gives you |
|---|---|
| [vps](modules/vps/README.md) | The rented server, hardened: firewall, key-only login, automatic security updates, swap |
| [tailscale](modules/tailscale/README.md) | Your private network; the server's only door |
| [claude-code](modules/claude-code/README.md) | Claude Code on the server, Remote Control from your phone, and a watch that warns before the login expires |
| [obsidian-sync](modules/obsidian-sync/README.md) | Your vault on the server, kept in sync, with the sync-guard that prevents mass deletions |
| [automation-runner](modules/automation-runner/README.md) | The job runner, heartbeat, self-test and the off-box dead man's switch (Healthchecks.io) |
| Starter vault | The system files from `vault-template/`, set up with `vault-template/SETUP-NOTES.md` (part of obsidian-sync, finished after automation-runner) |
| [tasks](modules/tasks/README.md) | The task cockpit inside the starter vault: `ToDo.base` views drawn by the TaskNotes plugin, a one-click Cockpit layout, a "Work in Claude" button on each task, and `vt todos` reading the same lists. No accounts, no cost |

### Highly recommended

| Module | What it gives you |
|---|---|
| [backups](modules/backups/README.md) | Nightly encrypted backup of the vault to Backblaze B2 (restic), with a restore test |
| [push](modules/push/README.md) | Phone alerts via Pushover when something needs you |
| [email](modules/email/README.md) | Claude can read, search and draft your Gmail, through your own Google Cloud project |
| [obsidian-mcp](modules/obsidian-mcp/README.md) | Your vault inside ordinary claude.ai chats and the mobile app, via a password-protected connector |
| [wiki](modules/wiki/README.md) | Your second brain: a small wiki Claude compiles from your own notes (what you know and have concluded), read first when you ask for advice. Never hand-edited; a daily job flags articles whose sources changed. No accounts, no cost |

### Optional

| Module | What it gives you |
|---|---|
| [telegram](modules/telegram/README.md) | **Recommended if you want Claude on the go.** Chat with your vault from a private Telegram bot: text, voice notes, photos and files, with Allow/Deny buttons before Claude acts. Official bot API, so no ban risk |
| [whatsapp](modules/whatsapp/README.md) | Chat with your vault from WhatsApp. **Ban risk on your number**. If you only want one chat bridge, pick Telegram |
| [calendar](modules/calendar/README.md) | Google Calendar access for Claude |
| [transcription](modules/transcription/README.md) | Turn recordings into text locally on your Mac (whisper.cpp) |
| [capture](modules/capture/README.md) | A hotkey on the Mac (Raycast) and a button on the iPhone to drop a thought into your Inbox (the iPhone Shortcut is generated for you) |
| [canvas](modules/canvas/README.md) | Your own Canvas courses archived into the vault (pages, files with their text extracted, your submissions), plus an optional daily sync that turns assignments into tasks. Only if your school uses Canvas and allows student access tokens |
| [fitness](modules/fitness/README.md) | Strava (and optionally WHOOP) sessions appended to a training-log note every 2 hours. **Strava's API needs a paid Strava subscription** (about $12/month) |

Record the chosen modules in `PROGRESS.md`.

---

## § 3 Order of execution

Each step: read the module README, do its "Already have one?" check against the § 1 table, walk
through "Accounts you need", run "Steps", then the **Self-test**. Only move on when it passes.

1. **[vps](modules/vps/README.md)** (asks before spending money)
2. **[tailscale](modules/tailscale/README.md)**, then close the public SSH port
3. **[claude-code](modules/claude-code/README.md)** on the server, including Remote Control, the
   `renew-claude` helper and the login-expiry watch. It also copies the kit's code to
   `~/automation` on the server, which every later module uses
4. **[obsidian-sync](modules/obsidian-sync/README.md)**, with the starter vault (its step 2
   runs sections 1 to 3 of `vault-template/SETUP-NOTES.md`: the vault, Bases, plugins, and the
   install date) and the sync-guard. Starts pull-only; turned bidirectional only after a clean
   comparison and a seeded manifest
5. **[automation-runner](modules/automation-runner/README.md)**, with Healthchecks.io
6. **Starter vault, part 2**: sections 4 to 7 of `SETUP-NOTES.md` in the vault (the `vt` tool,
   linking the skills, global instructions, first runs). Every change to `~/.claude/` there is
   shown as a diff first and needs a yes (CLAUDE.md § Respect what they already have)
   Then the **[tasks](modules/tasks/README.md)** self-test: the cockpit views render, the
   Cockpit button opens, a test task from `vt todos --add` shows up in them, and "Work in
   Claude" opens Claude Desktop with the task pre-filled
7. **[push](modules/push/README.md)** (the runner's alerts start reaching your phone)
8. **[backups](modules/backups/README.md)**
9. **[email](modules/email/README.md)**
10. **[obsidian-mcp](modules/obsidian-mcp/README.md)**
10b. **[wiki](modules/wiki/README.md)** (needs automation-runner for its staleness job; the first ingest is a session with you, best once you have some notes)
11. Optional: [telegram](modules/telegram/README.md) first if chosen (it needs claude-code and
    automation-runner, and is best after push and email, so failures reach the phone and the
    email tools are there), then in any order [calendar](modules/calendar/README.md),
    [capture](modules/capture/README.md), [canvas](modules/canvas/README.md) (its task sync needs the tasks module), [fitness](modules/fitness/README.md) (needs `VK_TAILNET_HOST`), [transcription](modules/transcription/README.md),
    [whatsapp](modules/whatsapp/README.md) (last, and only after re-reading its warning)

### § 4 Finish

- Run every self-test once more, in order, and record the results.
- Show the user the three things they will occasionally need to do themselves:
  1. **Renew the Claude login on the server about once a month**, when the phone says so.
     **You run this in your own Terminal:** `ssh -t <VK_HOSTNAME> renew-claude` (the helper from the claude-code module: it signs in
     and restarts Remote Control; the push, mail and Inbox note all name this same command)
  2. **Keep the backup passphrase safe** in their password manager. Without it the backups
     are unreadable, forever.
  3. **If a "Sync guard blocked" note appears in the Inbox**, the server is protecting the
     vault. Ask Claude to look at it.
- **Offer to narrow passwordless sudo** (set up in the vps module). Explain the tradeoff in
  plain words: right now any Claude session on the server, including a Remote Control session
  opened from the phone, can run any admin command. That is convenient, but a session that was
  tricked (for example by a malicious email it read) could change anything on the box.
  Narrowing it means Claude can only restart the kit's services and install updates without a
  password; anything else (installing a new module later) needs the user to type a password in
  their own Terminal. If they say yes:
  1. **You run this in your own Terminal:** `ssh -t <VK_HOSTNAME> 'sudo passwd $USER'` (sets a
     password for those future admin steps; store it in the password manager).
  2. Let the user read logs without sudo:
     `ssh <VK_HOSTNAME> 'sudo usermod -aG systemd-journal $USER'`.
  3. Write the allowlist, check it with `visudo -cf`, and only then install it (a broken sudo
     file can lock admin access, which is why the check comes first):
     ```bash
     ssh <VK_HOSTNAME> 'U=$USER; S=/usr/bin/systemctl; { printf "%s ALL=(root) NOPASSWD: " "$U"; \
       for u in claude-rc obsidian-sync obsidian-mcp waha wa-consumer tg-bridge backup-vault; do printf "%s restart %s, " "$S" "$u"; done; \
       printf "%s stop waha, /usr/bin/apt-get update, /usr/bin/apt-get -y upgrade\n" "$S"; } > /tmp/90-vaultkit && \
       sudo visudo -cf /tmp/90-vaultkit && cat /tmp/90-vaultkit && \
       sudo install -m 440 -o root -g root /tmp/90-vaultkit /etc/sudoers.d/90-vaultkit && rm /tmp/90-vaultkit'
     ```
     `systemctl status`, `is-active` and `list-timers` need no sudo at all, so they are not on
     the list (and `sudo systemctl status` would open a pager, which can be used to escape to a
     root shell).
  4. Test: `ssh <VK_HOSTNAME> 'sudo -n systemctl restart claude-rc && echo ok; sudo -n true || echo "other commands now need a password"'`.
  To go back to passwordless sudo later, rerun the sudo lines from the vps module, step 5 (the
  user types their password once for that). Record the choice in `PROGRESS.md`.
- Write a short "how my system works" note into the vault's `_system/` for future sessions.
- Mark the setup done in `PROGRESS.md`.

---

## Glossary

- **SSH key**: a pair of files that lets your Mac log in to the server without a password. The
  private half stays on your Mac (protected by a passphrase kept in the macOS Keychain); the
  public half is safe to share and goes on the server.
- **Tailscale / tailnet**: Tailscale is an app that builds a private, encrypted network between
  your own devices. Your "tailnet" is that network: your Mac, your phone and your server, and
  nobody else.
- **MagicDNS**: Tailscale's feature that lets you reach a device by its name (`vault-host`)
  instead of a number like `100.101.102.103`.
- **Funnel**: a Tailscale feature that makes one service on one of your devices reachable from
  the public internet at an HTTPS address. The kit uses it only for the optional claude.ai
  connector, behind a password.
- **nodeAttrs**: a section of the Tailscale access policy (the rules file in the admin console)
  that gives specific devices extra abilities, such as being allowed to use Funnel.
- **Tag**: a label for a device in Tailscale (here `tag:vault`). Rules can then apply to "the
  server" rather than to everyone in the tailnet.
- **OAuth client**: the "app identity" you create in Google Cloud so that Claude's email tool
  can ask Google for permission to your mailbox. You own it; nobody else is in between.
- **systemd unit**: a small text file that tells the Linux server how to run a program: start
  it at boot, restart it if it crashes, or run it on a schedule (a "timer").
- **envsubst**: a tool that fills placeholders like `${VK_USER}` in a file with values from
  `config.env`. The kit uses it to turn its unit templates into real unit files.
- **sudo**: how admin commands are run on Linux. "Passwordless sudo" means they run without
  typing a password each time.
