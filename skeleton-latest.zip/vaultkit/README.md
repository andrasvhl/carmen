# Skeleton

The infrastructure to build your own agent on. Carmen is the full agent built on this:
if you want everything as the author uses it, download `carmen-latest.zip` instead. It
already contains all of Skeleton.

Shared by András Habsburg. **Educational purposes only.** Provided as is, with no warranty of any
kind. András Habsburg takes zero responsibility for this kit or anything that results from using
it. Setting it up and running it is fully your decision and your responsibility.

## What is inside

- **The server and its upkeep:** setup guides for a small always-on Linux server, Tailscale and
  Obsidian Sync; the automation runner with timers, a heartbeat, self-tests, status, alert
  routing, push notifications, encrypted backups, the Claude login watch, the maintenance
  registry and the weekly maintenance brief.
- **Connections:** the Telegram and WhatsApp bridges (with their reply styles), Gmail, Calendar,
  Beeper for LinkedIn and Messenger, Wispr Flow meeting import, fitness sync, and the MCP
  instructions for chat apps.
- **The vault architecture:** the folder layout, the vault `CLAUDE.md` and router, the Vault
  Map, the task schema with its checker (`vt tasks`), the frontmatter registry, the profile
  convention and template, the component doc template, the wiki schema, the convention for
  writing skills, and capture from an iPhone Shortcut or Raycast into the Inbox.
- **The code** in `code/automation/`, with personal values replaced by placeholders. Start with
  `code/automation/CONFIGURE.md`. `vt` subcommands that belong to Carmen say so instead of
  running.

Not inside: the skills (planning, the daily check-in, the task cockpit, travel, reading and the
rest). Those are Carmen. Skeleton gives you the wiring to write your own.

## How to start

1. Install Claude Code from claude.com. You need a paid Claude plan.
2. Put this `vaultkit` folder in your home folder (`~/vaultkit`).
3. Open it in Claude Code (`cd ~/vaultkit` and then `claude`).
4. Type: **start the setup**. Claude explains what the system does and where your data goes,
   and builds nothing until you say "I understand, continue". Skip the modules that need
   Carmen (Canvas, tasks, transcription, wiki).

Details: `WALKTHROUGH.md`. Costs and privacy are the same as for Carmen (`START HERE.pdf`).
